// Error code mapping for SMS MT
var status_code = context.getVariable("statusCode");

if (status_code !=1) {
    
    switch(status_code) {
        
        // Error code 400
        case "105":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.001.1004");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Subscriber not found (105)");
            context.setVariable("httpError", "400");
            break;
        case "137":
            var error_list = context.getVariable("error_list");
            var uri_dec = decodeURIComponent(error_list);
            var sub_error = uri_dec.split(":");
            var cpa_error_code = sub_error[1].replace(",", "");
            
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("httpError", "400");
            
            // Subscriber not found
            if (cpa_error_code == "105") {
                context.setVariable("errorCode", "400.001.1004");
                context.setVariable("errorMessage", "Subscriber not found (105)");
            } else {
                context.setVariable("errorCode", "400.001.1003");
                context.setVariable("errorMessage", "Request Error: " + cpa_error_code + " (137)");
            }
            
            break;
        case "116":
        case "117":
        case "135":
        case "145":
        case "157":
        case "178":
        case "179":
        case "197":
        case "200":
        case "203":
        case "204":
        case "303":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.001.1003");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Request Error: " + status_code);
            context.setVariable("httpError", "400");
            break;
        
        // Error code 401
        case "51":
        case "52":
        case "129":
        case "140":
        case "300":
        case "2000":
            context.setVariable("exceptionName", "Unauthorized");
            context.setVariable("errorCode", "401.001.1002");
            context.setVariable("errorDesc", "Unauthorized");
            context.setVariable("errorMessage", "Authentication Error: " + status_code);
            context.setVariable("httpError", "401");
            break;
        
        // Error code 500
        default:
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.001.1001");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Internal Server Error: " + status_code);
            context.setVariable("httpError", "500");
            break;
    }
}

// This has been demonstrated to route calls to sandbox target by assuming "stage" environment as Sandbox
envName = context.getVariable("environment.name") 
if (envName.indexOf("sandbox") >= 0) {
    var cpId = "12345";
    var loginName = "cpaStagingLoginName";
    var serviceId = "cpaStagingServiceId";

    context.setVariable ("envType", "SANDBOX");

} else {
    var cpId = context.getVariable("app.cpId");
    var loginName = context.getVariable("app.loginName");
    var serviceId = context.getVariable("app.serviceId");

    context.setVariable ("envType","PRODUCTION");
}

context.setVariable("cpId", cpId);
context.setVariable("loginName", loginName);
context.setVariable("serviceId", serviceId);
    
//validate customAttributes
if (isEmpty(cpId) || isEmpty(loginName) || isEmpty(serviceId)) {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.001.0000");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Missing custom attributes");
    throw "serviceException";
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}

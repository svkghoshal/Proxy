var messageBody = context.getVariable("req.messageBody");
var recipientMsisdn = context.getVariable("req.recipientMsisdn");

context.setVariable("recipientMsisdn", recipientMsisdn);
context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00

var messageBodyLength = "";

//validate recipientMsisdn
if (isEmpty(recipientMsisdn)) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.001.0001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: recipientMsisdn");
    throw "serviceException";
}

//validate client_id
if (isEmpty(messageBody)) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.001.0002");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: messageBody");
    throw "serviceException";
}

messageBodyLength = messageBody.length;
if (messageBodyLength === 0)
{
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.001.0003");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Message body is empty");
    throw "serviceException";
} else if (messageBodyLength > 0 && messageBodyLength <= 150) {
    messageBody.trim();
    revisedMsgBody = escapeXml(messageBody);
    context.setVariable("revisedMsgBody", revisedMsgBody);
} else {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.001.0004");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Message body is more than 150 characters");
    throw "serviceException";
}

recipientMsisdn.trim();
var recipientMsisdnLength = recipientMsisdn.length;
var revisedMsisdn = "";
var revisedMsgBody = "";
 
if(recipientMsisdn.startsWith("6") && ((recipientMsisdnLength == 11) || (recipientMsisdnLength == 12))) {
    revisedMsisdn = recipientMsisdn.substring(1);
    context.setVariable("revisedMsisdn", revisedMsisdn);
} else {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.001.0005");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: recipientMsisdn");
    throw "serviceException";
}

function escapeXml(input) {
    return input.replace(/[<>&'"]/g, function (c) {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '\'': return '&apos;';
            case '"': return '&quot;';
        }
    });
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}

/* Use a function for the exact format desired... */
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
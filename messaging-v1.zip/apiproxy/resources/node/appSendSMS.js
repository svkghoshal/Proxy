http = require('http');
var querystring = require('querystring');

server = http.createServer(function(request, response) {
    console.log ('messaging-v1 Sandbox');
    
    // Extract information from URL
    var reqUrl = request.url;
    var reqMethod = request.method;
    
    // Generate data
    var transaction_id = getRandomInt(1000000000,9999999999);
    var error_code = "1";
    var success_list = "0146690306,"
    
    // Compose the body
    var body = "------=_Part_0_22402548.1467562719058 Content-Type: application/xop+xml; charset=UTF-8; type=\"application/soap+xml\"; Content-Transfer-Encoding: binary Content-ID: <root.message@cxf.apache.org> <soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\"><soap:Body><SmsMtResponse xmlns=\"http://xsd.gateway.sdp.digi.com\"><return><transaction_id>"+transaction_id+"</transaction_id><error_code>"+error_code+"</error_code><error_desc></error_desc><error_list></error_list><success_list>"+success_list+"</success_list></return></SmsMtResponse></soap:Body></soap:Envelope> ------=_Part_0_22402548.1467562719058--";
 
    response.writeHead(200, {'Content-Type': 'application/xop+xml'});
    response.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port);

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

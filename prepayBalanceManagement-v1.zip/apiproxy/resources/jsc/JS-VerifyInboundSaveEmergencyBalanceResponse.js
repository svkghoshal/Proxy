var errorCode = "" + context.getVariable("resp.apiResponseCode");
var errorMessage = "" + context.getVariable("resp.apiResponseMessage");
var endpointErrorCode = ""+ context.getVariable("resp.endpointErrorCode");
var endpointErrorMessage = ""+ context.getVariable("resp.endpointErrorMessage");
var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getSBTargetServer());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("request.verb", "POST");



printProxyRequest(requestContent);
printTargetResponse(responseContent);

if(errorCode !== "1"){
    if(!isEmpty(endpointErrorCode) && !isEmpty(endpointErrorMessage)){
        if(endpointErrorMessage.indexOf(":")){
             errorSaveEmergencyBalanceMapping(errorCode, trimErrorMessageOm(endpointErrorMessage));
        }else{
             errorSaveEmergencyBalanceMapping(endpointErrorCode, endpointErrorMessage);
        }
       
    }else{
         errorSaveEmergencyBalanceMapping(errorCode, errorMessage);
    }
   
}
else{
    setResponse("200", "200", "", "");
    context.setVariable("successResponse",  mapSuccessResponse());
}

function mapSuccessResponse(){
    var response = {
          "code": "0",
          "description": "Success",
          "timestamp": context.getVariable("resp.responseDttm")
        };
    return JSON.stringify(response);
}

function getSBTargetServer(){
    if(!isEmpty(context.getVariable("targetPath"))){
        return  context.getVariable("target.scheme") + "://" + context.getVariable("target.host") + context.getVariable("targetPath");
    } else {
        return context.getVariable("endpointUrl");
    }
}

setReasonPhrase(context.getVariable("resp.code"));
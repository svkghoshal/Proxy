var esbCode = context.getVariable("resp.esbResponseCode");
var esbMessage = context.getVariable("resp.esbResponseMessage");
var systemResponseCode = context.getVariable("resp.systemResponseCode");
var systemResponseMessage = context.getVariable("resp.systemResponseMessage");
var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundService1ResponseDatetime", getDatetime());
context.setVariable("southboundSevice1.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southboundSevice1.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("southboundSevice1.target.server", context.getVariable("endpointUrl"));
context.setVariable("southbound.responsedatetime", getTimestamp());
context.setVariable("request.verb", "POST");

printTargetResponse(responseContent);

if (isEmpty(esbCode) && isEmpty(systemResponseCode)) {
     setResponse("200", "200", "", "");
     context.setVariable("giveDayResponse",mapGiveawayDaysResponse());
} else if (!isEmpty(esbCode) && isEmpty(systemResponseCode)) {
    var esbResponseCode = trimErrorCodeEsb(esbCode);
    var esbResponseMessage = trimErrorMessageEsb(esbMessage);
    print("esbResponseMessage : " +esbResponseMessage);
    errorGiveDayResultMapping(esbResponseCode, esbResponseMessage);

} else if (!isEmpty(esbCode) && !isEmpty(systemResponseCode)) {
    var cbsResponseCode = trimCbsErrorCode(systemResponseCode);
    print("cbsResponseCode : " +cbsResponseCode);
    if(cbsResponseCode == "102012047"){
        context.setVariable("callDtac", "Y");
        context.setVariable("targetPath", context.getVariable("giveDayDTACPath"));
    } else {
        errorGiveDayResultMapping(cbsResponseCode, systemResponseMessage);
    }
} 

function getTargetServer() {
    var targetServer = "";
    if(isEmpty(context.getVariable("endpointUrl"))){
          targetServer = context.getVariable("target.scheme") + "://" + context.getVariable("target.host") + ":" + context.getVariable("target.port") + context.getVariable("payBillPath");
    }
        tagetServer = context.getVariable("endpointUrl");

    return targetServer;
}

function mapGiveawayDaysResponse(){
    response = {
        "id"                            : context.getVariable("req.id"),
        "partyAccount": {
            "accountBalance": 
                [
                  {
                    "type"                  : "Active",
                    "validFor": 
                       {
                          "endDateTime"     : context.getVariable("resp.ASCrdExpDate")
                       }
                  },
                  {
                    "type"                  : "Suspend",
                    "validFor":  
                       {
                          "endDateTime"     : context.getVariable("resp.ASSubscriptionExpDate")
                       }
                  },
                  {
                    "type"                  : "Disable",
                    "validFor": 
                        {
                             "endDateTime"  : context.getVariable("resp.ASSubscriberExpDate")
                        }
                  }
                ]
          },
         "bucket": {
                "id"                        : context.getVariable("resp.BILBalId"),
                "description"               : context.getVariable("resp.BILAcctTypeDesc"),
                "bucketType"                : context.getVariable("resp.BILAcctTypeCode"),
                "confirmationDate"          : context.getVariable("resp.BILApplyDttm"),
                "remainedAmount": 
                    {
                       "amount"             : context.getVariable("resp.BILCurrAcctBal"),
                       "units"              : context.getVariable("resp.BILMinMeasureId"),
                       "validFor": 
                           {
                               "endDateTime": context.getVariable("resp.BILCurrExpDttm")
                           }
                    },
                "changedAmount": 
                    {
                        "amount"            : context.getVariable("resp.BILChngAcctBal"),
                        "validFor": 
                             {
                                "endDateTime": context.getVariable("resp.BILChngExpTime")
                             }
                    }
              }
    };
    return JSON.stringify(response);
}

setReasonPhrase(context.getVariable("resp.code")); 
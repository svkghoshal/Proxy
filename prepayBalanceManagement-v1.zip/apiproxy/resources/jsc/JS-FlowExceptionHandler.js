var faultName = context.getVariable("fault.name");
var validateError = context.getVariable("validateError");
var path = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb");
var errorMsgEN = "" + context.getVariable("resp.userAuthenResp.errorEN");

print("faultName = " + faultName);

if(!isEmpty(validateError)) {
    faultName = validateError;
    print("override faultName = " + faultName);
}

try {
    switch(verb) {
        case "GET":
            switch(path) {
                case "/bucket":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.090.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.090.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.090.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.090.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.090.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.090.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.090.2007", "Internal Server Error", "Invalid JSON path.");
                            break;
                        case "MissingCustomAttributes":
                            setResponse("400", "400.090.0000", "Bad Request", "Missing custom attributes");
                            break;
                        case "InvalidRefToken":
                            setResponse("400", "400.090.0012", "Bad Request", "Invalid reference token");
                            break;
                        default:
                            setResponse("500", "500.090.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;			
                default:
                    setResponse("404", "404.090.0001", "Resource not found", "Resource not found/Invalid resource");
                    break;    
            }
            break;
		case "POST":
			switch(path){
				case "/balanceTopup":
					switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.091.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.091.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.091.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.091.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.091.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.091.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.091.2007", "Internal Server Error", "Invalid JSON path.");
                            break;
                        case "MissingCustomAttributes":
                            setResponse("400", "400.091.0000", "Bad Request", "Missing custom attributes");
                            break;
                        case "InvalidRefToken":
                            setResponse("400", "400.091.0005", "Bad Request", "Invalid reference token");
                            break;
                        default:
                            setResponse("500", "500.091.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;
				case "/balanceTransfer":
					switch(faultName){
						case "SpikeArrestViolation":
                            setResponse("429", "429.092.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.092.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.092.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.092.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.092.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.092.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.092.2007", "Internal Server Error", "Invalid JSON path.");
                            break;
                        case "MissingCustomAttributes":
                            setResponse("400", "400.092.0000", "Bad Request", "Missing custom attributes");
                            break;
                        case "InvalidRefToken":
                            setResponse("400", "400.092.0027", "Bad Request", "Invalid reference token");
                            break;
                        default:
                            setResponse("500", "500.092.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
					}
					break;
				case "/dayTopup":
					switch(faultName){
						case "SpikeArrestViolation":
                            setResponse("429", "429.093.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.093.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.093.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.093.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.093.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.093.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.093.2007", "Internal Server Error", "Invalid JSON path.");
                            break;
                        case "MissingCustomAttributes":
                            setResponse("400", "400.093.0000", "Bad Request", "Missing custom attributes");
                            break;
                        case "InvalidRefToken":
                            setResponse("400", "400.093.0011", "Bad Request", "Invalid reference token");
                            break;
                        default:
                            setResponse("500", "500.093.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
					}
					break;
				default:
                    setResponse("404", "404.091.0001", "Resource not found", "Resource not found/Invalid resource");
                    break;
			}
    }
}catch(ex){
    switch(verb){
        case "GET":
            switch(path) {
                case "/bucket":
                    setResponse("500", "500.090.2004", "Internal Server Error", "JavaScript runtime error");
                    break;
                default:
                    setResponse("404", "404.090.0001", "Resource not found", "Resource not found/Invalid resource");
					break;
                }
            break;
			
		case "POST":
			switch(path){
				case "/balanceTopup":
					setResponse("500", "500.091.2004", "Internal Server Error", "JavaScript runtime error");
                    break;
				case "/balanceTransfer":
					setResponse("500", "500.092.2004", "Internal Server Error", "JavaScript runtime error");
                    break;
                case "/dayTopup":
					setResponse("500", "500.093.2004", "Internal Server Error", "JavaScript runtime error");
                    break;
				default:
                    setResponse("404", "404.091.0001", "Resource not found", "Resource not found/Invalid resource");
					break;
			}
			break;
		
    }
}

context.setVariable("resp.responseDttm", getDatetime());
setReasonPhrase(context.getVariable("resp.httpStatusCode"));
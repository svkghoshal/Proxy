var path = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb");
var requestContent = context.getVariable("request.content");
var requestQuerystring = context.getVariable("request.querystring");

print("requestQuerystring : " +requestQuerystring );
print("requestContent : " +requestContent );

context.setVariable("clientIP", context.getVariable("client.ip"));
context.setVariable("appID", context.getVariable("system.uuid"));
context.setVariable("northboundRequestDatetime", "" + getDatetime());

switch(verb) {
    case "GET":
        context.setVariable("northbound.request", "" + requestQuerystring);
        switch(path) {
            case "/bucket":
                validateQueryEmergencyBalance();
                break;
            default:
                context.setVariable("validateError", "ResourceNotFound");
                break;
        }
        break;
     case "POST":
        context.setVariable("northbound.request", "" + setNorthSouthJsonRequestResponse(requestContent));
        switch(path) {
            case "/balanceTopup":
                validateSaveEmergencyBalance();
                break;
            case "/balanceTransfer":
                validateSaveBalanceTransfer();
                break;
            case "/dayTopup":
                validateJaideeGiveDay();
                break;
            default:
                context.setVariable("validateError", "ResourceNotFound");
                break;
        }
        break;
    default:
        context.setVariable("validateError", "ResourceNotFound");
        break;
}

function validateQueryEmergencyBalance(){
    var id = "" + context.getVariable("req.id");
    var description = "" + context.getVariable("req.description");
    var requestDttm = "" + context.getVariable("req.requestDttm");
    var bucketType = "" + context.getVariable("req.bucketType");
    var relatedPartyId = "" + context.getVariable("req.relatedPartyId");
    var partyAccountId = "" + context.getVariable("req.partyAccountId");
    var isEnableHttps = (context.getVariable("queryEmergencyBalanceIsEnableHttps") === "true");
    //set other varible for authen southbound
    var sourceSystemID = "" + context.getVariable("req.relatedPartyId");
    var now = new Date();
    var referenceKey = getReferenceKey(now);
    var sourceSystemKey = "" + context.getVariable("prepayBalanceSourceSystemKey");
    var authenCode = getAuthenCode(now, referenceKey, sourceSystemKey);
    
    // validate reference token
    var href = convertSymbol(context.getVariable("req.href"));
    print("validate href : " + href);
    var checkTicket = "" + context.getVariable("cusAttr.checkTicket");
    var key = "" + context.getVariable("decryptKey");
    var decryptData = getDecryptedDataAuthen(href.toString(),key);
    var timeExpireToken = "" + context.getVariable("timeExpireToken");
    var developerName = context.getVariable("apigee.developer.app.name");
    var subNum = "";
    var devName = "";
    var createTime = "";
    var timeExpire = "";
    
    print("validateQueryEmergencyBalance:param(mandatory):"
        + ", id = " + id
        + ", description = " + description 
        + ", requestDttm = " + requestDttm 
        + ", bucketType = " + bucketType 
        + ", relatedPartyId = " + relatedPartyId 
        + ", partyAccountId = " + partyAccountId);
    
    if(isEmpty(id) || isEmpty(description) || isEmpty(requestDttm)|| isEmpty(bucketType) ||
        isEmpty(relatedPartyId)|| isEmpty(partyAccountId)){
             context.setVariable("validateError", "BusinessValidationFailed");
    }
    else{
        print("checkTicket : " + checkTicket + ", href = " + href);
        if(!isEmpty(checkTicket) && checkTicket === "Y"){
            if(!isEmpty(href)){
                try{
                     var result = decryptData.split(/\|/);
                     print("result decrypt: " + result);
                        for(var index = 0; index < result.length; index++){
                            subNum = result[0];
                            devName = result[1];
                            createTime = result[2];
                        }
                    timeExpire = getMaxDateExpire(createTime,timeExpireToken);
                    partyAccountId = convertMobileNotoPrefix66(context.getVariable("req.partyAccountId"));
                   var test1 = new Date(timeExpire).getTime();
                   var test2 = new Date(getDateAndTimeHourMinuteFormat(now)).getTime();
                   
                    print("timeExpire : " + new Date(timeExpire).getTime());
                    print("now : " + new Date(getDateAndTimeHourMinuteFormat(now)).getTime());
                    print("result : " + test1 > test2);
                }catch(err){
                     context.setVariable("validateError", "InvalidRefToken");
                }
                    // validate token
                    if((partyAccountId !== subNum) || (developerName !== devName) 
                    || !matchDateFormatYYYYMMDDHHmm(createTime) || (getDateAndTimeHourMinuteFormat(now) > timeExpire)){
                        context.setVariable("validateError", "InvalidRefToken");
                    }
            }else{
    		    context.setVariable("validateError", "InvalidRefToken");
    		}
        }
    }

    context.setVariable("req.messageId", relatedPartyId+getYYYYMMddHHmmssSSSWithoutSymbolUseDate(now));
    context.setVariable("req.partyAccountId", convertMobileNotoPrefix66(context.getVariable("req.partyAccountId")));
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("targetPath", context.getVariable("queryEmergencyBalancePath"));
    context.setVariable("req.verbProxy", "GET");
    context.setVariable("req.requestDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(now));
    context.setVariable("req.referenceKey", referenceKey);
    context.setVariable("req.authenCode", authenCode);
    print("req.messageId : " + context.getVariable("req.messageId"));
    
}

function validateSaveEmergencyBalance(){
    var id = "" + context.getVariable("req.id");
    var description = "" + context.getVariable("req.description");
    var type = "" + context.getVariable("req.type");
    var requestDttm = "" + context.getVariable("req.requestDttm");
    var relatedPartyId = "" + context.getVariable("req.relatedPartyId");
    var partyAccountId = "" + context.getVariable("req.partyAccountId");
    var productId = "" + context.getVariable("req.productId");
    var isEnableHttps = (context.getVariable("saveEmergencyBalanceIsEnableHttps") === "true");
    //set other varible for authen southbound
    var sourceSystemID = "" + context.getVariable("req.relatedPartyId");
    var now = new Date();
    var referenceKey = getReferenceKey(now);
    var sourceSystemKey = "" + context.getVariable("prepayBalanceSourceSystemKey");
    var authenCode = getAuthenCode(now, referenceKey, sourceSystemKey);
    
    // validate reference token
    var href = "" + context.getVariable("req.href");
    var checkTicket = "" + context.getVariable("cusAttr.checkTicket");
    var key = "" + context.getVariable("decryptKey");
    var decryptData = getDecryptedDataAuthen(href,key);
    var timeExpireToken = "" + context.getVariable("timeExpireToken");
    var developerName = context.getVariable("apigee.developer.app.name");
    var subNum = "";
    var devName = "";
    var createTime = "";
    var timeExpire = "";
    
    print("validateSaveEmergencyBalance:param(mandatory):"
        + ", id = " + id
        + ", description = " + description 
        + ", type = " + type 
        + ", requestDttm = " + requestDttm 
        + ", relatedPartyId = " + relatedPartyId 
        + ", partyAccountId = " + partyAccountId
        + ", productId = " + productId
        );
        
    if(isEmpty(id) || isEmpty(description) || isEmpty(type) || isEmpty(requestDttm)||
        isEmpty(relatedPartyId) || isEmpty(partyAccountId) || isEmpty(productId)){
            context.setVariable("validateError", "BusinessValidationFailed");
    }
    else{
        print("checkTicket : " + checkTicket + ", href = " + href);
        if(!isEmpty(checkTicket) && checkTicket === "Y"){
            if(!isEmpty(href)){
                try{
                     var result = decryptData.split(/\|/);
                     print("result decrypt: " + result);
                        for(var index = 0; index < result.length; index++){
                            subNum = result[0];
                            devName = result[1];
                            createTime = result[2];
                        }
                    timeExpire = getMaxDateExpire(createTime,timeExpireToken);
                    partyAccountId = convertMobileNotoPrefix66(context.getVariable("req.partyAccountId"));
                    
                }catch(err){
                     context.setVariable("validateError", "InvalidRefToken");
                }
                    // validate token
                    if((partyAccountId != subNum) || (developerName != devName) 
                    || !matchDateFormatYYYYMMDDHHmm(createTime) || (getDateAndTimeHourMinuteFormat(now) > timeExpire)){
                        context.setVariable("validateError", "InvalidRefToken");
                    }
            }else{
    		    context.setVariable("validateError", "InvalidRefToken");
    		}
        }
    }

    context.setVariable("req.messageId", relatedPartyId+getYYYYMMddHHmmssSSSWithoutSymbolUseDate(now));
    context.setVariable("req.partyAccountId", convertMobileNotoPrefix66(context.getVariable("req.partyAccountId")));
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("targetPath", context.getVariable("saveEmergencyBalanceIsPath"));
    context.setVariable("req.verbProxy", "POST");
    context.setVariable("req.requestDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(now));
    context.setVariable("req.referenceKey", referenceKey);
    context.setVariable("req.authenCode", authenCode);
}

function validateSaveBalanceTransfer(){
    var id = "" + context.getVariable("req.id");
    var description = "" + context.getVariable("req.description");
    var type = "" + context.getVariable("req.type");
    var requestDttm = "" + context.getVariable("req.requestDttm");
    var relatedPartyId = "" + context.getVariable("req.relatedPartyId");
    var requestorId = "" + context.getVariable("req.requestorId");
    var targetId = "" + context.getVariable("req.targetId");
    var amount = "" + context.getVariable("req.amount");
    var isEnableHttps = (context.getVariable("saveBlanceTransferIsEnableHttps") === "true");
    //set other varible for authen southbound
    var sourceSystemID = "" + context.getVariable("req.relatedPartyId");
    var now = new Date();
    var referenceKey = getReferenceKey(now);
    var sourceSystemKey = "" + context.getVariable("prepayBalanceSourceSystemKey");
    var authenCode = getAuthenCode(now, referenceKey, sourceSystemKey);
    
    // validate reference token
    var href = "" + context.getVariable("req.href");
    var checkTicket = "" + context.getVariable("cusAttr.checkTicket");
    var key = "" + context.getVariable("decryptKey");
    var decryptData = getDecryptedDataAuthen(href,key);
    var timeExpireToken = "" + context.getVariable("timeExpireToken");
    var developerName = context.getVariable("apigee.developer.app.name");
    var subNum = "";
    var devName = "";
    var createTime = "";
    var timeExpire = "";
    
    print("validateSaveBalanceTransfer:param(mandatory):"
        + ", id = " + id
        + ", description = " + description 
        + ", type = " + type 
        + ", requestDttm = " + requestDttm 
        + ", relatedPartyId = " + relatedPartyId 
        + ", requestorId = " + requestorId
        + ", targetId = " + targetId
        + ", amount = " + amount
        );
        
    if(isEmpty(id) || isEmpty(description) || isEmpty(type) || isEmpty(requestDttm)||
        isEmpty(relatedPartyId) || isEmpty(requestorId) || isEmpty(targetId) || isEmpty(amount)){
            context.setVariable("validateError", "BusinessValidationFailed");
    }
    else{
        print("checkTicket : " + checkTicket + ", href = " + href);
        if(!isEmpty(checkTicket) && checkTicket === "Y"){
            if(!isEmpty(href)){
                try{
                     var result = decryptData.split(/\|/);
                     print("result decrypt: " + result);
                        for(var index = 0; index < result.length; index++){
                            subNum = result[0];
                            devName = result[1];
                            createTime = result[2];
                        }
                    timeExpire = getMaxDateExpire(createTime,timeExpireToken);
                    requestorId = convertMobileNotoPrefix66(context.getVariable("req.requestorId"));
                }catch(err){
                     context.setVariable("validateError", "InvalidRefToken");
                }
                    // validate token
                    if((requestorId != subNum) || (developerName != devName) 
                    || !matchDateFormatYYYYMMDDHHmm(createTime) || (getDateAndTimeHourMinuteFormat(now) > timeExpire)){
                        context.setVariable("validateError", "InvalidRefToken");
                    }
            }else{
    		    context.setVariable("validateError", "InvalidRefToken");
    		}
        }
    }

    context.setVariable("req.messageId", relatedPartyId+getYYYYMMddHHmmssSSSWithoutSymbolUseDate(now));
    context.setVariable("req.requestorId", convertMobileNotoPrefix66(context.getVariable("req.requestorId")));
    context.setVariable("req.targetId", convertMobileNotoPrefix66(context.getVariable("req.targetId")));
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("targetPath", context.getVariable("saveBalanceTransferPath"));
    context.setVariable("req.verbProxy", "POST");
    context.setVariable("req.requestDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(now));
    context.setVariable("req.referenceKey", referenceKey);
    context.setVariable("req.authenCode", authenCode);
}

function validateJaideeGiveDay(){
    var id = "" + context.getVariable("req.id");
    var type = "" + context.getVariable("req.type");
    var requestDttm = "" + context.getVariable("req.requestDttm");
    var partyAccountId = "" + context.getVariable("req.partyAccountId");
    var amount = "" + context.getVariable("req.amount");
    var isEnableHttps = (context.getVariable("giveDayDTNIsEnableHttps") === "true");
    
    //set other varible for authen southbound
    var sourceSystem = "" + context.getVariable("channelMedia");
    var now = new Date();
    var referenceKey = getReferenceKey(now);
    var sourceSystemKey = "" + context.getVariable("prepayBalanceSourceSystemKey");
    var authenCode = getAuthenCode(now, referenceKey, sourceSystemKey);
    
    // validate reference token
    var href = "" + context.getVariable("req.href");
    var checkTicket = "" + context.getVariable("cusAttr.checkTicket");
    var key = "" + context.getVariable("decryptKey");
    var decryptData = getDecryptedDataAuthen(href,key);
    var timeExpireToken = "" + context.getVariable("timeExpireToken");
    var developerName = context.getVariable("apigee.developer.app.name");
    var subNum = "";
    var devName = "";
    var createTime = "";
    var timeExpire = "";
    
    print("validateJaideeGiveDay:param(mandatory):"
        + ", id = " + id
        + ", type = " + type 
        + ", requestDttm = " + requestDttm 
        + ", partyAccountId = " + partyAccountId
        + ", amount = " + amount
        );
        
    if(isEmpty(id) || isEmpty(type) || isEmpty(requestDttm)|| isEmpty(partyAccountId) || isEmpty(amount)){
            context.setVariable("validateError", "BusinessValidationFailed");
    }
    else{
        print("checkTicket : " + checkTicket + ", href = " + href);
        if(!isEmpty(checkTicket) && checkTicket === "Y"){
            if(!isEmpty(href)){
                try{
                     var result = decryptData.split(/\|/);
                     print("result decrypt: " + result);
                        for(var index = 0; index < result.length; index++){
                            subNum = result[0];
                            devName = result[1];
                            createTime = result[2];
                        }
                    timeExpire = getMaxDateExpire(createTime,timeExpireToken);
                    partyAccountId = convertMobileNotoPrefix66(context.getVariable("req.partyAccountId"));
                }catch(err){
                     context.setVariable("validateError", "InvalidRefToken");
                }
                    // validate token
                    if((partyAccountId != subNum) || (developerName != devName) 
                    || !matchDateFormatYYYYMMDDHHmm(createTime) || (getDateAndTimeHourMinuteFormat(now) > timeExpire)){
                        context.setVariable("validateError", "InvalidRefToken");
                    }
            }else{
    		    context.setVariable("validateError", "InvalidRefToken");
    		}
        }
    }
    
    context.setVariable("req.messageId",  sourceSystem+id);
    context.setVariable("req.partyAccountId", convertMobileNotoPrefix66(context.getVariable("req.partyAccountId")));
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("req.verbProxy", "POST");
    context.setVariable("req.requestDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(now));
    context.setVariable("req.referenceKey", referenceKey);
    context.setVariable("req.authenCode", authenCode);
    context.setVariable("endpointUrl", context.getVariable("giveDayDTNEndpoint"));
}
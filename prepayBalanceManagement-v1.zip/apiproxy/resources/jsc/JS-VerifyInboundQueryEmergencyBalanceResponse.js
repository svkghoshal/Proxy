var errorCode = "" + context.getVariable("resp.apiResponseCode");
var errorMessage = "" + context.getVariable("resp.apiResponseMessage");
var endpointErrorCode = ""+ context.getVariable("resp.endpointErrorCode");
var endpointErrorMessage = ""+ context.getVariable("resp.endpointErrorMessage");

var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");
var emergencyMoneyRate = context.getVariable("resp.emergencyMoneyRate");

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getSBTargetServer());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("request.verb", "GET");


printProxyRequest(requestContent);
printTargetResponse(responseContent);

if(errorCode !== "1"){
    //errorQueryEmergencyBalanceResultMapping(errorCode, errorMessage);
    if(!isEmpty(endpointErrorCode) && !isEmpty(endpointErrorMessage)){
        if(endpointErrorMessage.indexOf(":")){
            errorQueryEmergencyBalanceResultMapping(errorCode, trimErrorMessageOm(endpointErrorMessage));
        }else{
            errorQueryEmergencyBalanceResultMapping(endpointErrorCode, endpointErrorMessage);
        }
    }else{
        errorQueryEmergencyBalanceResultMapping(errorCode, errorMessage);
    }
}
else{
    setResponse("200", "200", "", "");
    //set format number
    if(isEmpty(context.getVariable("resp.remainingLoan"))) {
        context.setVariable("resp.remainingLoan", 0.00);
    }
    if(isEmpty(context.getVariable("resp.totalOutstandLoan"))) {
        context.setVariable("resp.totalOutstandLoan", 0.00);
    }
    if(isEmpty(context.getVariable("resp.totalFeeLoan"))) {
        context.setVariable("resp.totalFeeLoan", 0.00);
    }
    mapQueryEmergencyBalanceToJson();
}

function getSBTargetServer(){
    if(!isEmpty(context.getVariable("targetPath"))){
        return  context.getVariable("target.scheme") + "://" + context.getVariable("target.host") + context.getVariable("targetPath");
    } else {
        return context.getVariable("endpointUrl");
    }
}


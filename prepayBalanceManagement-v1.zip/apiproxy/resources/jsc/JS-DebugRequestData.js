context.setVariable("southboundEndpointUrlDatetime", "" + getDatetime());
context.setVariable("southboundRequestDatetime", "" + getDatetime());
context.setVariable("southbound.requestdatetime", getTimestamp());

var path = context.getVariable("proxy.pathsuffix");

switch(path) {
    case "/dayTopup":
        context.setVariable("southboundService1EndpointUrlDatetime", "" + getDatetime());
        context.setVariable("southboundService1RequestDatetime", "" + getDatetime());
        break;
    default:
        break;
}
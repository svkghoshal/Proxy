function errorQueryEmergencyBalanceResultMapping(errorCode, errorDesc){
    switch(errorCode){
        case "210001":
            setResponse("400", "400.090.0001", "Bad Request", errorDesc);
            break;
        case "310013":
            setResponse("400", "400.090.0002", "Bad Request", errorDesc);
            break;
        case "310014":
            setResponse("400", "400.090.0003", "Bad Request", errorDesc);
            break;
        case "310015":
            setResponse("400", "400.090.0004", "Bad Request", errorDesc);
            break;
        case "310016":
            setResponse("400", "400.090.0005", "Bad Request", errorDesc);
            break;
        case "310017":
            setResponse("400", "400.090.0006", "Bad Request", errorDesc);
            break;
        case "110003":
            setResponse("400", "400.090.0007", "Bad Request", errorDesc);
            break;
        case "119001":
            setResponse("400", "400.090.0008", "Bad Request", errorDesc);
            break;
        case "405914951":
            setResponse("400", "400.090.0009", "Bad Request", "You have been exceeded loan credit limit");
            break;
        case "405914952":
            setResponse("400", "400.090.0010", "Bad Request", "Sorry, your request could not be completed. Please try again.");
            break;
        case "405914953":
            setResponse("400", "400.090.0011", "Bad Request", "You have been exceeded the number of loan limit");
            break;
        case "42099":
        case "129001":
        case "129002":
            setResponse("500", "500.090.1001", "Internal Server Error", errorDesc);
            break;
        default:
            setResponse("500", "500.090.0000", "Internal Server Error", "Internal System Error: {" + errorDesc + "}");
            break;
    }
}

function errorSaveEmergencyBalanceMapping(errorCode, errorDesc){
    switch(errorCode){
        case "210001":
            setResponse("400", "400.091.0001", "Bad Request", errorDesc);
            break;
        case "110003":
            setResponse("400", "400.091.0002", "Bad Request", errorDesc);
            break;
        case "119001":
            setResponse("400", "400.091.0003", "Bad Request", errorDesc);
            break;
        case "3001":
        case "3002":
        case "3003":
        case "3007":
        case "3008":
        case "3009":
        case "3010":
        case "4001":
        case "5001":
        case "5003":
        case "5004":
        case "5005":
        case "5007":
        case "5008":
        case "5009":
        case "5010":
        case "5011":
        case "5013":
        case "5014":
        case "5015": 
        case "5016":
        case "5017":
        case "4709":
            setResponse("400", "400.091.0004", "Bad Request", "Sorry, your request could not be completed. Please try again");
            break;
        case "42099":
        case "129001":
        case "129002":
            setResponse("500", "500.091.1001", "Internal Server Error", errorDesc);
            break;
        default:
            setResponse("500", "500.091.0000", "Internal Server Error", "Internal System Error: {" + errorDesc + "}");
            break;
    }
}

function errorSaveBalanceTransferMapping(errorCode, errorDesc){
    switch(errorCode){
        case "31002":
            setResponse("400", "400.092.0001", "Bad Request", "Subscriber status is not active or suspend");
            break;
        case "31003":
            setResponse("400", "400.092.0002", "Bad Request", "CompCode Unlike");
            break;
        case "31004":
            setResponse("400", "400.092.0003", "Bad Request", "Tranfer Number not prepaid");
            break;
        case "31006":
            setResponse("400", "400.092.0004", "Bad Request", "Number only specific types individual");
            break;
        case "31007":
            setResponse("400", "400.092.0005", "Bad Request", "Number must be activated for more than 90 days");
            break;
        case "31008":
            setResponse("400", "400.092.0006", "Bad Request", "Top-up amount list");
            break;
        case "110003":
            setResponse("400", "400.092.0007", "Bad Request", errorDesc);
            break;
        case "119001":
            setResponse("400", "400.092.0008", "Bad Request", errorDesc);
            break;
        case "102012014":
            setResponse("400", "400.092.0009", "Bad Request", "You must have accumulated service usage of at least 200 Baht, sufficient credit balance for transferring amount plus service fee, and at least 10 Baht in credit balance after the transfer");
            break;
        case "102012015":
        case "102012016":
            setResponse("400", "400.092.0010", "Bad Request", "You can transfer only amount left in balance of 20-200 Baht per time. Usage day balance cannot be transferred");
            break;
        case "102012017":
            setResponse("400", "400.092.0011", "Bad Request", "Sender and receiver must be dtac prepaid customers with active status and have at least 1 day of usage balance");
            break;
        case "102012018":
        case "102012019":
        case "102012020":
        case "102012021":
            setResponse("400", "400.092.0012", "Bad Request", "You can transfer up to twice a day and 400 Baht per calendar month");
            break;
        case "102012022":
            setResponse("400", "400.092.0013", "Bad Request", "Sender and receiver must be dtac prepaid customers with active status and have at least 1 day of usage balance");
            break;
        case "102012023":
            setResponse("400", "400.092.0014", "Bad Request", "Subscriber is not allowed to use this service (subscriber level flag)");
            break;
        case "102012024":
            setResponse("400", "400.092.0015", "Bad Request", "Balance transfer service is not allowed at subscriber's main product level");
            break;
        case "102012025":
            setResponse("400", "400.092.0016", "Bad Request", "Transferee COS level configuration doesn't allow to receive transfer amount");
            break;
        case "102012026":
            setResponse("400", "400.092.0017", "Bad Request", "Invalid receiver number");
            break;
        case "102012027":
            setResponse("400", "400.092.0018", "Bad Request", "You can not use balance transfer service due to your age of use or Usage eligibility criteria");
            break;
        case "102012028":
            setResponse("400", "400.092.0019", "Bad Request", "Invalid sender number");
            break;
        case "102012029":
            setResponse("400", "400.092.0020", "Bad Request", "Transferor and Transferee could not be the same");
            break;
        case "102012031":
            setResponse("400", "400.092.0021", "Bad Request", "Receiver's balance will exceed max balance limit when transfer complete");
            break;
        case "102011694":
            setResponse("400", "400.092.0022", "Bad Request", "Corporate subscriber is not allowed to use this service");
            break;
        case "102011695":
            setResponse("400", "400.092.0023", "Bad Request", "Subscriber type is not normal subscriber");
            break;
        case "102011698":
            setResponse("400", "400.092.0024", "Bad Request", "Transaction rejected as sender and receiver are not match with transfer mode");
            break;
        case "102011699":
            setResponse("400", "400.092.0025", "Bad Request", "Your total transfer amount will exceed maximum allowed transfer amount per bill cycle");
            break;
        case "405238900":
            setResponse("400", "400.092.0026", "Bad Request", "Sorry, your request could not be completed. Please try again");
            break;
        case "42099":
            setResponse("500", "500.092.1001", "Internal Server Error", errorDesc);
            break;
        default:
            setResponse("500", "500.092.0000", "Internal Server Error", "Internal System Error: {" + errorDesc + "}");
            break;
    }
}


function errorGiveDayResultMapping(errorCode, errorDesc){
    switch(errorCode){
        case "102012004":
            setResponse("400", "400.093.0001", "Bad Request", errorDesc);
            break;
        case "102012005":
            setResponse("400", "400.093.0002", "Bad Request", errorDesc);
            break;
        case "102012008":
            setResponse("400", "400.093.0003", "Bad Request", errorDesc);
            break;
        case "102012009":
            setResponse("400", "400.093.0004", "Bad Request", errorDesc);
            break;
        case "102012010":
            setResponse("400", "400.093.0005", "Bad Request", errorDesc);
            break;
        case "102012011":
            setResponse("400", "400.093.0006", "Bad Request", errorDesc);
            break;
        case "102012012":
            setResponse("400", "400.093.0007", "Bad Request", errorDesc);
            break;
        case "102012013":
            setResponse("400", "400.093.0008", "Bad Request", errorDesc);
            break;
        case "102012047":
            setResponse("400", "400.093.0009", "Bad Request", errorDesc);
            break;
        case "102010248":
            setResponse("400", "400.093.0010", "Bad Request", errorDesc);
            break;
        default:
            setResponse("500", "500.093.0000", "Internal Server Error", "Internal System Error: {" + errorDesc + "}");
            break;
    }
}
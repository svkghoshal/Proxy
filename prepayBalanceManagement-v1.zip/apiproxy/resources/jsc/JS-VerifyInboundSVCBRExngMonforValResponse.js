var esbCode = context.getVariable("resp.exngMonforVal.esbResponseCode");
var esbMessage = context.getVariable("resp.exngMonforVal.esbResponseMessage");
var systemResponseCode = context.getVariable("resp.exngMonforVal.systemResponseCode");
var systemResponseMessage = context.getVariable("resp.exngMonforVal.systemResponseMessage");
var requestContent = context.getVariable("svcBrExngMonforVal.content");
var responseContent = context.getVariable("svcBrExngMonforValResponse.content");

print("esbCode : " + esbCode);
print("esbMessage : " + esbMessage);
print("systemResponseCode : " + systemResponseCode);
print("systemResponseMessage : " + systemResponseMessage);

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("southbound.target.server", getTargetServiceCalloutServer());
context.setVariable("request.verb", "POST");


if (isEmpty(esbCode) && isEmpty(systemResponseCode)) {
     setResponse("200", "200", "", "");
     context.setVariable("giveDayResponse",mapGiveawayDaysResponse());
} else if (!isEmpty(esbCode) && isEmpty(systemResponseCode)) {
    var esbResponseCode = trimErrorCodeEsb(esbCode);
    var esbResponseMessage = trimErrorMessageEsb(esbMessage);
    
    errorGiveDayResultMapping(esbResponseCode, esbResponseMessage);

} else if (!isEmpty(esbCode) && !isEmpty(systemResponseCode)) {
    var cbsResponseCode = trimCbsErrorCode(systemResponseCode);
    errorGiveDayResultMapping(cbsResponseCode, systemResponseMessage);
} 

function mapGiveawayDaysResponse(){
    response = {
        "id"                            : context.getVariable("req.id"),
        "partyAccount": {
            "accountBalance": 
                [
                  {
                    "type"                  : "Active",
                    "validFor": 
                       {
                          "endDateTime"     : context.getVariable("resp.exngMonforVal.ASCrdExpDate")
                       }
                  },
                  {
                    "type"                  : "Suspend",
                    "validFor":  
                       {
                          "endDateTime"     : context.getVariable("resp.exngMonforVal.ASSubscriptionExpDate")
                       }
                  },
                  {
                    "type"                  : "Disable",
                    "validFor": 
                        {
                             "endDateTime"  : context.getVariable("resp.exngMonforVal.ASSubscriberExpDate")
                        }
                  }
                ]
          },
         "bucket": {
                "id"                        : context.getVariable("resp.exngMonforVal.BILBalId"),
                "description"               : context.getVariable("resp.exngMonforVal.BILAcctTypeDesc"),
                "bucketType"                : context.getVariable("resp.exngMonforVal.BILAcctTypeCode"),
                "confirmationDate"          : context.getVariable("resp.exngMonforVal.BILApplyDttm"),
                "remainedAmount": 
                    {
                       "amount"             : context.getVariable("resp.exngMonforVal.BILCurrAcctBal"),
                       "units"              : context.getVariable("resp.exngMonforVal.BILMinMeasureId"),
                       "validFor": 
                           {
                               "endDateTime": context.getVariable("resp.exngMonforVal.BILCurrExpDttm")
                           }
                    },
                "changedAmount": 
                    {
                        "amount"            : context.getVariable("resp.exngMonforVal.BILChngAcctBal"),
                        "validFor": 
                             {
                                "endDateTime": context.getVariable("resp.exngMonforVal.BILChngExpTime")
                             }
                    }
              }
    };
    return JSON.stringify(response);
}

function getTargetServiceCalloutServer() {
    if(!isEmpty(context.getVariable("servicecallout.requesturi"))) {
        targetServer = context.getVariable("svcBrExngMonforVal.url");
    } else {
        targetServer = context.getVariable("endpointUrl");
    }  
    return targetServer;
}

setReasonPhrase(context.getVariable("resp.code")); 
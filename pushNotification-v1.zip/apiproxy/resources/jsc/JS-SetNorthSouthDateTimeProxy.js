var clientEndTimeStamp = new Date().getTime();

context.setVariable("clientStartTime", getClientStartTime());
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("clientEndTime", getClientEndTime());
context.setVariable("clientElapsTime", getClientElaspTime());
context.setVariable("targetElapsTime", getTargetElaspTime());
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("apigw.txId", getApigwTransactionId());

if(isEmpty(context.getVariable("response.content"))) {
  // context.setVariable("northbound.response", setNorthboundSouthboundRequestResponse(context.getVariable("error.content")));
}

function getApigwTransactionId() {
    var proxyName = context.getVariable("apiproxy.name");
    var suffixPath = context.getVariable("proxy.pathsuffix");
    var timestamp = new Date().getTime();
    var randomNumber = Math.floor(100000 + Math.random() * 900000);
    
    var useProxyName = proxyName.substring(0, 1).toUpperCase() + proxyName.substring(1);
    var useSuffixPath = suffixPath.substring(1, 2).toUpperCase() + suffixPath.substring(2);
    
    return useProxyName + useSuffixPath + timestamp + randomNumber;
}

function getTargetServer() {
    if(isEmpty(context.getVariable("targetStartTime")) && isEmpty(context.getVariable("targetEndTime"))) {
        return "";
    } else {
        return context.getVariable("target.url");
    }
}

function getClientElaspTime() {
    var clientElapsTime = (clientEndTimeStamp - context.getVariable("client.received.start.timestamp"));

    return "" + clientElapsTime;
}

function getTargetElaspTime() {
    if(isEmpty(context.getVariable("target.received.end.timestamp")) || isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        var targetElapsTime = context.getVariable("target.received.end.timestamp") - context.getVariable("target.sent.start.timestamp");
        return "" + targetElapsTime;
    }
}

function getClientStartTime() {
    return getTimePattern(context.getVariable("client.received.start.timestamp"));
}

function getTargetStartTime() {
    if(isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.sent.start.timestamp"));
    }
}

function getTargetEndTime() {
    if(isEmpty(context.getVariable("target.received.end.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.received.end.timestamp"));
    }
}

function getClientEndTime() {
    return getTimePattern(clientEndTimeStamp);
} 
var responseContent = "";

if(isEmpty(context.getVariable("error.content"))) {
    responseContent = "" + context.getVariable("response.content");
} else {
    responseContent = "" + context.getVariable("error.content");
}

 context.setVariable("northbound.response", setNorthboundSouthboundRequestResponse(responseContent)); 
 
 if (context.getVariable("httpResponse_status_code") == 200) {
     context.setVariable("errorCode", "200");
 }
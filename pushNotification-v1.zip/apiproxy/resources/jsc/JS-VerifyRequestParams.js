print("JS:VerifyRequestParams");
var path = context.getVariable("proxy.pathsuffix");
print("PATH ::" + path);
var referenceCode = getISODate().concat(getRandomNumber());
context.setVariable("referenceCode", referenceCode);

if (path == "/sms") {
    print("SMS ::");
    var transactionId = context.getVariable("req.transactionId");
    var senderIdType = context.getVariable("req.senderIdType");
    var recipientMsisdn = context.getVariable("req.senderIdValue");
    var senderAddr = context.getVariable("req.senderAddr");
    var senderName = context.getVariable("req.senderName");
    var messageBody = context.getVariable("req.messageBody");
    var username = context.getVariable("req.username");
    var passworddigest = context.getVariable("req.passworddigest");
    var nonce = context.getVariable("req.nonce");
    var created = context.getVariable("req.created");
    var passworddigest = context.getVariable("req.passworddigest");
    
    context.setVariable("transactionId", transactionId);
    context.setVariable("recipientMsisdn", recipientMsisdn);
    context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00
    //
    context.setVariable("orgRequest", request.content);
    print("REQ BODY ::" + request.content);
    var requestcontent = request.content;
    var smsMSg = JSON.parse(requestcontent);
    context.setVariable("SMS_REQ", JSON.stringify(smsMSg));
    context.setVariable("northbound.request", setNorthboundSouthboundRequestResponse(JSON.stringify(smsMSg)));
    
    var messageBodyLength = "";
    
    //validate recipientMsisdn
    if (isEmpty(recipientMsisdn)  ){
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.001.0001");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Missing input parameter: recipientMsisdn");
        throw "serviceException";
    }
    
    //validate client_id
    if (isEmpty(messageBody)) {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.001.0002");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Missing input parameter: messageBody");
        throw "serviceException";
    }
    
    messageBodyLength = messageBody.length;
    if (messageBodyLength === 0)
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.001.0003");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Message body is empty");
        throw "serviceException";
    } else if (messageBodyLength > 0 && messageBodyLength <= 1500) {
        messageBody.trim();
        revisedMsgBody = escapeXml(messageBody);
        context.setVariable("revisedMsgBody", revisedMsgBody);
    } else {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.001.0004");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Message body is more than 150 characters");
        throw "serviceException";
    }
    
    recipientMsisdn.trim();
    var recipientMsisdnLength = recipientMsisdn.length;
    var revisedMsisdn = "";
    var revisedMsgBody = "";
     
    if(recipientMsisdn.startsWith("6") && ((recipientMsisdnLength == 11) || (recipientMsisdnLength == 12))) {
        revisedMsisdn = recipientMsisdn.substring(1);
        context.setVariable("revisedMsisdn", revisedMsisdn);
    } else {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.001.0005");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid input parameter: recipientMsisdn");
        throw "serviceException";
    }
}

 if (path == "/digitalNotification") {
    print("DN");
    context.setVariable("orgRequest", request.content);
    print("REQ BODY ::" + request.content);
    var requestcontent = request.content;
    var notificationMSg = JSON.parse(requestcontent);
    context.setVariable("digitalNotification", JSON.stringify(notificationMSg));
    context.setVariable("northbound.request", setNorthboundSouthboundRequestResponse(JSON.stringify(notificationMSg)));
    // context.setVariable("digitalNotification", orginalRequest);

    print("Digital Notification ::");
    var id = context.getVariable("req.id");
    var type = context.getVariable("req.type");
    var content = context.getVariable("req.content");  
    var senderName = context.getVariable("req.senderName");
    var receiverId = context.getVariable("req.receiverId");
    var receiverName = context.getVariable("req.receiverName"); 
    var receiverEmail = context.getVariable("req.receiverEmail");
    var receiverPhoneNumber = context.getVariable("req.receiverPhoneNumber");
    var characteristicNameEng = context.getVariable("req.characteristicNameEng");
    var characteristicNameTh = context.getVariable("req.characteristicNameTh");
    var characteristicValueEng = context.getVariable("req.characteristicValueEng");
    var characteristicValueTh = context.getVariable("req.characteristicValueTh");
    
   
    context.setVariable("phonenumber", receiverPhoneNumber);
    print("phone number " +receiverPhoneNumber);
    context.setVariable("req.idValue", receiverPhoneNumber);
    
    print("digitalNotification ::"
        + " id = " + id
        + ", type = " + type
        + ", content = " + content
        + ", senderName = " + senderName
        + ", receiverId = " + receiverId
        + ", receiverName = " + receiverName
        + ", receiverEmail = " + receiverEmail
        + ", receiverPhoneNumber = " + receiverPhoneNumber
        + ", characteristicNameEng = " + characteristicNameEng
        + ", characteristicNameTh = " + characteristicNameTh
        + ", characteristicValueEng = " + characteristicValueEng);
        
   if (characteristicNameEng == "messageEN") {
       // print("languageCode ::" +languageCode);
        context.setVariable("languageCode", "EN");
    } else if (characteristicNameTh == "messageTH") {
        context.setVariable("languageCode", "TH");
    }
    
    print("Language Code ::" + context.getVariable("languageCode"));
    
 }




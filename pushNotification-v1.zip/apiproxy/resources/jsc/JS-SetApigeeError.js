var faultName = context.getVariable("fault.name");
context.setVariable("isoTimestamp", ISODateString()); 
var pathsuffix = context.getVariable("proxy.pathsuffix");
print("proxy.pathsuffix ::" +pathsuffix);
var apino;

if (pathsuffix  == '/digitalNotification') {
    apino = '072';
} 
if (pathsuffix  == '/sms'){
     apino = '001';
}
    
switch(faultName) {
    
    case "SpikeArrestViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429."+apino+".2001");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Spike arrest violation");
        context.setVariable("httpError", "429");
        break;
    
    case "QuotaViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429."+apino+".2002");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Quota limit exceeded");
        context.setVariable("httpError", "429");
        break;
    
    case "ConcurrentRatelimtViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429."+apino+".2003");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Concurrent rate limit connection exceeded");
        context.setVariable("httpError", "429");
        break;
    
    case "ScriptExecutionFailed":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apino+".2004");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "JavaScript runtime error");
        context.setVariable("httpError", "500");
    	break;
    
    case "InvalidApiKeyForGivenResource":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apino+".2005");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Invalid ApiKey for given resource");
        context.setVariable("httpError", "500");
        break;
        
    case "invalid_access_token":   			
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apino+".2005");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Invalid ApiKey for given resource");
        context.setVariable("httpError", "500");
        break;     
    
    case "ExecutionFailed":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apino+".2006");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Request input is malformed or invalid");
        context.setVariable("httpError", "500");
        break;
    
    case "InvalidJSONPath":   			
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apino+".2007");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Invalid JSON path");
        context.setVariable("httpError", "500");
        break;
    
       
    
    default:
		context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apino+".2000");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Internal Server Error: " + faultName);
		context.setVariable("httpError", "500");
		break;	
}





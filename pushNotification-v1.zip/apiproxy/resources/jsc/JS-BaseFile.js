// Put All Common Methods Here.

context.setVariable("isoTimestamp", ISODateString());
context.setVariable("referenceid", getReferenceId());


function isEmpty(data){
    return (data === "" || data === "null" || data === "undefined" || 
            data === null || data === undefined || 0 === data.length);
}

function getISODate() {
    var d = new Date();
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
     var n = d.getFullYear() 
         + pad(d.getMonth()+1)
         + pad(d.getDate())
         + pad(d.getHours())
         + pad(d.getMinutes()) 
         + pad(d.getSeconds()) 
         + pad(d.getMilliseconds())
    return n;
}
function getRandomNumber() {
  var val = Math.floor(100 + Math.random() * 900);
  return val;
}

function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}

function getReferenceId() {
    var today = new Date();
    var day = getDateFormat("" + today.getDate());
    var month = getDateFormat("" + (today.getMonth() + 1));
    var year = getDateFormat("" + today.getFullYear());
    var hour = getDateFormat("" + today.getHours());
    var minute = getDateFormat("" + today.getMinutes());
    var second = getDateFormat("" + today.getSeconds());
    var milliSecond = getDateFormat("" + today.getMilliseconds());
    var num = Math.floor(Math.random() * 999) + 100;
    return year + month + day + hour + minute + second + milliSecond +num;
}

function getDateTimeFormat() {
    var today = new Date();
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    
    return year + month + day + hour + minute + second;
}

function getTimestamp() {
    var nowTimestamp = new Date().getTime();
    
    return nowTimestamp;
}

function getDatetime() {
    var nowTimestamp = new Date().getTime();
    var nowDatetime = getTimePattern(nowTimestamp);
    
    return nowDatetime;
}

function getDateFormat(today) {
    if(today.length == 1) {
        today = "0" + today;
    }
    return today;
}

function getTimePattern(dateTime) {
    var today = new Date(dateTime);
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second + "," + milliSecond;
}

function checkLengthDateFormat(today) {
    if(today.length == 1) {
        today = "0" + today;
    }
    
    return today;
}

function setNorthboundSouthboundRequestResponse(text) {
    var content = text.replace(/(\r\n|\n|\r)/gm, '');
    var contentRemoveSpace = content.replace(/([^"]+)|""|("[^"]+")/g, function($0, $1, $2) {
        if ($1) {
            return $1.replace(/\s/g, '');      
        } else {
            return $0;   
        }
    });
    
    return contentRemoveSpace;
}

function setSouthboundRequestResponse(text) {
    var content = text.replace(/(\r\n|\n|\r)/gm, '');
    var contentRemoveSpace = content.replace(/([>][ ]+[<])/g, function($0, $1, $2) {
        if ($0) {
            return $0.replace(/\s/g, '');      
        } else {
            return $1;   
        } 
    });
    
    return contentRemoveSpace;
}

function escapeXml(input) {
    return input.replace(/[<>&'"]/g, function (c) {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '\'': return '&apos;';
            case '"': return '&quot;';
        }
    });
}

function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
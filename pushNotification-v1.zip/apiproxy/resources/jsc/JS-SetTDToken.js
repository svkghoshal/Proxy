print("SetTD Token");

var TDToken = context.getVariable("access_token");
var expires_in = context.getVariable("expires_in");

print("TD Token :;" + TDToken+ "expires in "+expires_in );

context.setVariable("tdaceestoken", TDToken);

context.setVariable("Authorization", context.getVariable("validateAuthorization"));

print("cache val "+ context.getVariable("lookupcache.LC-AccessTokenCache.cachekey"));


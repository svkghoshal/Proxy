print("JS-SetTragetURL ::");

var idType = "MSISDN";
var idValue = context.getVariable("phonenumber");
// var sbtargetURL = context.getVariable("notificationEndpoint");
var  sbtargetURL=  "https://notify-dtac.dataplan.telenordigital.com/notify/dtac/v1/single";
print("Endpoint " + sbtargetURL);
var targetURL = sbtargetURL+"?idValue"+"="+idValue+"&idType="+idType;
print("sbtargetURL ::" +targetURL);
context.setVariable("target.url", targetURL);
print("Target::" +context.getVariable("target.url"));
// Set TD Token.
context.setVariable("access_token", context.getVariable("tdaceestoken"));
print("TD Token ::" + context.getVariable("tdaceestoken"));

// Set Backend Request.
var sbrequest1 = context.getVariable("PushNotification");
var sbrequest = JSON.parse(sbrequest1);
print("SB request " + JSON.stringify(sbrequest));
context.setVariable("southbound.request", setNorthboundSouthboundRequestResponse(JSON.stringify(sbrequest)));

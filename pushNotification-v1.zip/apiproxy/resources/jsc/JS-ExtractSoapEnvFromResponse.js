//var url = "http://10.89.94.194:8312/1/smsmessaging/outbound/";
//var recipientMsisdn=context.getVariable("recipientMsisdn");
//var serverIp=context.getVariable("server.url");
//context.setVariable("target.url", url + recipientMsisdn + "/requests");
//context.setVariable("target.url", serverIp + recipientMsisdn + "/requests123");


var response = context.getVariable("backendResponseContent");
//var start = response.indexOf("soap:Envelope");
//var end = response.lastIndexOf("soap:Envelope");
var revisedResponse = response;
//context.setVariable("revisedResponse", revisedResponse);

context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00



/* Use a function for the exact format desired... */
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}




/*var resPayload = context.getVariable('response.content');
//context.setVariable('payload', payload);
context.setVariable('response.content', process(resPayload));

function process(jsonObject) {
    var parsedJSONObject = JSON.parse(jsonObject);
    var messageId = '' + context.getVariable("messageid") + '';
    
    envName = context.getVariable("environment.name");
    if (envName.indexOf("production") >= 0) {
        print("Environment Name : production");
        parsedJSONObject.TransactionId = messageId;
    }

    return JSON.stringify(parsedJSONObject);
}
*/

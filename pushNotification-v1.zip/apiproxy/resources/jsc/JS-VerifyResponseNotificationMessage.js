print("JS-VerifyResponseNotificationMessage ::");
print("Response ::" +context.getVariable("response.content"));
var httpResCode = context.getVariable("httpResponse_status_code");
print("httpResCode ::" + httpResCode);
context.setVariable("southbound.target.server", getTargetServer());
print("Target server ::" + getTargetServer);
// need to check the erro code for success response.
/*if(errorCode === null) {
    context.setVariable("statusCode", "success");
    context.setVariable("errorCode", '200'); // override the error code with 200 for success.For Logging purpose.
}*/

if (httpResCode !== null) {
    var responseContent = context.getVariable("backendResponseContent");
    print("JS-VerifyResponseNotificationMessage:: responseContent ::" +responseContent);
    if (!isEmpty(responseContent)) {
        context.setVariable("southbound.response", setNorthboundSouthboundRequestResponse(responseContent));
    }
    print("httpResCode ::" +httpResCode);
    var description = context.getVariable("description");
    print("Description"+ description);
    switch(httpResCode) {
        case "400":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.072.0001");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", description);
            context.setVariable("httpError", "400");
            break;
        case "401":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "401.072.0001");
            context.setVariable("errorDesc", "Unauthorized");
            context.setVariable("errorMessage", description);
            context.setVariable("httpError", "401");
            break;    
        case "403":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "403.072.0001");
            context.setVariable("errorDesc", "Forbidden");
            context.setVariable("errorMessage", description);
            context.setVariable("httpError", "403");
            break; 
        case "404":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "404.072.0001");
            context.setVariable("errorDesc", "Resource not found");
            context.setVariable("errorMessage", description);
            context.setVariable("httpError", "404");
            break;  
        case "429":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "429.072.0001");
            context.setVariable("errorDesc", "Too Many Requests");
            context.setVariable("errorMessage", description);
            context.setVariable("httpError", "429");
            break;     
        case "500":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.072.1001");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", description);
            context.setVariable("httpError", "500");
            break;
        case "502":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "502.072.1001");
            context.setVariable("errorDesc", "Bad Gateway");
            context.setVariable("errorMessage", description);
            context.setVariable("httpError", "502");
            break;
           
        // Error code 500
        default:
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.072.0000");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Internal System Error :" + description);
            context.setVariable("httpError", "500");
            break;
    }
    

}



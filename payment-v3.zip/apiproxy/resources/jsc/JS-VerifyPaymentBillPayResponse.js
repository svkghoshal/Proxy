var status_code = context.getVariable("newstatusCode");
var transactionId = context.getVariable("newTransactionId");
context.setVariable("transactionId",transactionId);
var faultCode = context.getVariable("newfaultCode");
var faultString = context.getVariable("newfaultString");
var faultMsg = context.getVariable("newfaultMessage");
var apiNo = "031";

if ((response.content.length > 0))
{
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("errorCode", "500." + apiNo + ".500");
    context.setVariable("errorDesc", "Service Unavailable ");
    context.setVariable("errorMessage", "The Service is unavailable");
    context.setVariable("httpError", "500");
    
}

if((status_code =='0'))
{
    context.setVariable("status","Success");
}
else if ((status_code =='1')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".202");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "BAD_FORMAT");
 context.setVariable("httpError", "400");
}
else if ((status_code =='3')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".203");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_NOT_FOUND");
 context.setVariable("httpError", "400");
}
else if ((status_code =='4')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".204");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_NOT_REGISTERED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='5')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".205");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_INACTIVE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='6')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".206");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_SUSPENDED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='7')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".207");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "ACCESS_DENIED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='8')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".208");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "BAD_PASSWORD");
 context.setVariable("httpError", "400");
}
else if ((status_code =='9')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".209");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "PASSWORD_EXPIRED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='10')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".210");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "PASSWORD_PREV_USED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='11')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".211");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "PASSWORD_RETRY_EXCEED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='12')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".212");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "PASSWORD_SAME");
 context.setVariable("httpError", "400");
}
else if ((status_code =='13')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".213");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TARGET_NOT_FOUND");
 context.setVariable("httpError", "400");
}
else if ((status_code =='14')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".214");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TARGET_NOT_REGISTERED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='15')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".215");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TARGET_INACTIVE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='16')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".216");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TARGET_SUSPENDED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='17')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".217");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "INVALID_AMOUNT");
 context.setVariable("httpError", "400");
}
else if ((status_code =='18')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".218");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "ALREADY_REGISTERED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='19')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".219");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_BLACKLISTED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='20')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".220");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TARGET_BLACKLISTED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='22')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".221");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TARGET_IS_SELF");
 context.setVariable("httpError", "400");
}
else if ((status_code =='23')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".222");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AMOUNT_TOO_SMALL");
 context.setVariable("httpError", "400");
}
else if ((status_code =='24')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".223");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AMOUNT_TOO_BIG");
 context.setVariable("httpError", "400");
}
else if ((status_code =='25')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".224");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIRM_WRONG_AMOUNT");
 context.setVariable("httpError", "400");
}
else if ((status_code =='26')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".225");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TARGET_REQUIRED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='27')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".226");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_EXPIRED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='28')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".227");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TARGET_EXPIRED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='29')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".228");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "INVALID_PASSWORD");
 context.setVariable("httpError", "400");
}
else if ((status_code =='30')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".229");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_ACTIVE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='31')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".230");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_NOT_PARTY");
 context.setVariable("httpError", "400");
}
else if ((status_code =='32')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".231");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "REQUEST_EXPIRED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='33')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".232");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TRANSACTION_REVERSED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='34')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".233");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TRANSACTION_NOT_TWO_PARTY");
 context.setVariable("httpError", "400");
}
else if ((status_code =='35')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".234");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "INVALID_STATUS_CHANGE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='36')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".235");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TRANSACTION_TOO_OLD");
 context.setVariable("httpError", "400");
}
else if ((status_code =='37')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".236");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TRANSACTION_NOT_COMPLETED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='38')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".237");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_STOPPED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='39')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".238");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TARGET_STOPPED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='40')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".239");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_STARTED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='41')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".240");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "IN_SYS_ERROR");
 context.setVariable("httpError", "400");
}
else if ((status_code =='42')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".241");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "IN_BAD_MSISDN");
 context.setVariable("httpError", "400");
}
else if ((status_code =='43')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".242");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "IN_SYS_NOT_AVAILABLE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='44')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".243");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "IN_BAD_VOUCHER");
 context.setVariable("httpError", "400");
}
else if ((status_code =='45')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".244");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "IN_TIMEOUT");
 context.setVariable("httpError", "400");
}
else if ((status_code =='46')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".245");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AMOUNT_OUT_OF_RANGE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='47')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".246");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TARGET_IS_NOT_SPECIAL");
 context.setVariable("httpError", "400");
}
else if ((status_code =='48')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".247");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "BILLPAY_ACCOUNT_INVALID");
 context.setVariable("httpError", "400");
}
else if ((status_code =='49')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".248");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "BANK_OFFLINE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='50')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".249");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "BANK_ERROR");
 context.setVariable("httpError", "400");
}
else if ((status_code =='51')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".250");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "SYNC_NOT_REQUIRED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='52')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".251");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "DEVICE_ALREADY_ACTIVE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='53')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".252");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIG_UPDATE_NOT_REQUIRED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='54')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".253");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "NOT_DEVICE_OWNER");
 context.setVariable("httpError", "400");
}
else if ((status_code =='55')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".254");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "ALIAS_ALREADY_EXISTS");
 context.setVariable("httpError", "400");
}
else if ((status_code =='56')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".255");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "ALIAS_NOT_FOUND");
 context.setVariable("httpError", "400");
}
else if ((status_code =='57')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".256");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_ALREADY_SUSPENDED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='58')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".257");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_ALREADY_STOPPED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='59')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".258");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CANNOT_USE_WALLET_TYPE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='60')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".259");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "SCHEDULE_DISALLOWED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='61')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".260");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "INVALID_SCHEDULE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='62')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".261");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "SCHEDULE_NOT_FOUND");
 context.setVariable("httpError", "400");
}
else if ((status_code =='63')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".262");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIRM_MULTIPLE_TXNS");
 context.setVariable("httpError", "400");
}
else if ((status_code =='64')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".263");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_IS_NOT_SPECIAL");
 context.setVariable("httpError", "400");
}
else if ((status_code =='66')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".264");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONNECTION_OFFLINE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='67')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".265");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONNECTION_ERROR");
 context.setVariable("httpError", "400");
}
else if ((status_code =='68')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".266");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "OPERATION_NOT_SUPPORTED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='69')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".267");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_NOT_WELL_CONFIGURED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='70')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".268");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_HAS_TRANSACTIONS");
 context.setVariable("httpError", "400");
}
else if ((status_code =='71')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".269");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_DELETED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='72')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".270");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TARGET_DELETED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='73')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".271");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENT_HAS_BALANCE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='74')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".272");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "INVALID_PASSWORD_MISMATCH");
 context.setVariable("httpError", "400");
}
else if ((status_code =='75')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".273");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "REVERSAL_FAILED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='76')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".274");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "GROUPNAME_SAME_OR_EXISTS");
 context.setVariable("httpError", "400");
}
else if ((status_code =='77')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".275");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "GROUP_NOT_EMPTY");
 context.setVariable("httpError", "400");
}
else if ((status_code =='78')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".276");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIRM_SAME_INITIATOR");
 context.setVariable("httpError", "400");
}
else if ((status_code =='103')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".277");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIRM_REJECTED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='250')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".278");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIRM_TRANSFER");
 context.setVariable("httpError", "400");
}
else if ((status_code =='251')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".279");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIRM_CASHOUT");
 context.setVariable("httpError", "400");
}
else if ((status_code =='252')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".280");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIRM_SELL");
 context.setVariable("httpError", "400");
}
else if ((status_code =='253')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".281");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIRM_BILLPAY");
 context.setVariable("httpError", "400");
}
else if ((status_code =='255')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".282");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIRM_LINK");
 context.setVariable("httpError", "400");
}
else if ((status_code =='256')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".283");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIRM_JOIN_PARENT");
 context.setVariable("httpError", "400");
}
else if ((status_code =='257')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".284");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CONFIRM_JOIN_CHILD");
 context.setVariable("httpError", "400");
}
else if ((status_code =='312')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".285");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "MODIFY_WALLET_OK");
 context.setVariable("httpError", "400");
}
else if ((status_code =='400')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".286");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TRANSACTION_NOT_FOUND");
 context.setVariable("httpError", "400");
}
else if ((status_code =='401')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".287");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TRANSFER_CONFIRM_REJECTED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='415')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".288");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TRACE_TRANSACTION_NOT_FOUND");
 context.setVariable("httpError", "400");
}
else if ((status_code =='423')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".289");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TRANS_ALREADY_FINALIZED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='425')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".290");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "MESSAGE_TOO_LONG");
 context.setVariable("httpError", "400");
}
else if ((status_code =='501')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".291");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CANNOT_LINK_TO_SUBAGENT");
 context.setVariable("httpError", "400");
}
else if ((status_code =='502')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".292");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CANNOT_LINK_TO_SELF");
 context.setVariable("httpError", "400");
}
else if ((status_code =='503')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".293");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "LINK_AGENT_DELETED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='504')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".294");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "CANNOT_JOIN_TO_SELF");
 context.setVariable("httpError", "400");
}
else if ((status_code =='505')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".295");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENTS_ALREADY_JOINED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='506')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".296");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "JOIN_AGENT_DELETED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='507')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".297");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "AGENTS_NOT_JOINED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='508')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".298");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "PURCHASE_ORDER_NUMBER_NOT_UNIQUE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='509')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".299");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "REBATE_AMOUNT_NOT_EXACT");
 context.setVariable("httpError", "400");
}
else if ((status_code =='510')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".300");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "REBATE_AMOUNT_NOT_MULTIPLE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='511')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".301");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "REBATE_AMOUNT_TOO_SMALL");
 context.setVariable("httpError", "400");
}
else if ((status_code =='520')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".302");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "VOUCHER_RECIPIENT_NOT_FOUND");
 context.setVariable("httpError", "400");
}
else if ((status_code =='521')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".303");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "VOUCHER_EXPIRY_DATE_PASSED");
 context.setVariable("httpError", "400");
}
else if ((status_code =='522')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".304");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "VOUCHER_NOT_EXIST");
 context.setVariable("httpError", "400");
}
else if ((status_code =='523')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".305");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "NONDELETED_VOUCHERID_PROVIDERID_EXISTS");
 context.setVariable("httpError", "400");
}
else if ((status_code =='524')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".306");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "VOUCHER_NOT_DELETABLE_STATE");
 context.setVariable("httpError", "400");
}
else if ((status_code =='525')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".307");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "MATCHING_VOUCHER_NOT_FOUND");
 context.setVariable("httpError", "400");
}
else if ((status_code =='556')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".308");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "DUPLICATE_RECORDS  ");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1001')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".309");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Insufficient funds");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1002')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".310");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Transaction Recovered");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1003')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".311");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Wallet Balance Exceeded");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1004')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".312");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Wallet Cap Exceeded");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1005')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".313");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Request Expired");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1006')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".314");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "System Error");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1007')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".315");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Database Error");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1008')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".316");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Bad Request");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1009')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".317");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Database Constraint Error");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1010')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".318");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Record no found");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1011')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".319");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Password/agent not found/invalid");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1012')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".320");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Password error retry exceeded");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1013')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".321");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Password expired");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1014')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".322");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Password invalid");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1015')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".323");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Change Password – password is the same");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1016')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".324");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Change Password – password has been used previously");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1020')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".325");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Mandatory parameter not supplied");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1021')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".326");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Parameter value too short");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1022')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".327");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Parameter value too long");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1023')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".328");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Parameter value does not match regular expression");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1024')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".329");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Licence expired");
 context.setVariable("httpError", "400");
}
else if ((status_code =='1025')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".330");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Rule Malformed or Rule version locked");
 context.setVariable("httpError", "400");
}
else if ((status_code =='0003')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".331");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Product Expired");
 context.setVariable("httpError", "400");
}
else if ((status_code =='0004')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".332");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Product does not exists");
 context.setVariable("httpError", "400");
}
else if ((status_code =='0005')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".333");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Product is not active");
 context.setVariable("httpError", "400");
}
else if ((status_code =='0008')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".334");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Price Point/Charge amount is not matching with the configured value");
 context.setVariable("httpError", "400");
}
else if ((status_code =='0009')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".335");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Authentication Failure");
 context.setVariable("httpError", "400");
}
else if ((status_code =='0013')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".336");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "TPS limit exceeded");
 context.setVariable("httpError", "400");
}
else if ((status_code =='0014')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".337");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Price Point not Configured");
 context.setVariable("httpError", "400");
}
else if ((status_code =='0015')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".338");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Charge Amount not matching");
 context.setVariable("httpError", "400");
}
else if ((status_code =='4007')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".339");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Subscriber number not belongs to IN");
 context.setVariable("httpError", "400");
}
else if ((status_code =='4001')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".340");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Refund Failed");
 context.setVariable("httpError", "400");
}
else if ((status_code =='4004')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".341");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Refund Internal Error");
 context.setVariable("httpError", "400");
}
else if ((status_code =='4005')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".342");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Refund Invalid Transaction Id");
 context.setVariable("httpError", "400");
}
else if ((status_code =='4006')) {
 context.setVariable("exceptionName", "exceptionName");
 context.setVariable("errorCode", "400." + apiNo + ".343");
 context.setVariable("errorDesc", "Bad Request");
 context.setVariable("errorMessage", "Refund Invalid Request");
 context.setVariable("httpError", "400");
}
else
{

	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Internal Server Error");
	context.setVariable("httpError", "500");
}







 var resp=context.getVariable("SessionResponse");
 //print (response);
 context.setVariable("resp",resp);
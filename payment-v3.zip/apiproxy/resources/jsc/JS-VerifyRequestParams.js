var clientip = context.getVariable("client.ip");
context.setVariable("client.ip", "10.101.255.126" );
var id = context.getVariable("req.idValue");
var UserName = context.getVariable("req.UserName");
var payer = context.getVariable("req.payer");
context.setVariable("recipientId", id);
var rechargeAmount = context.getVariable("req.rechargeAmount");
context.setVariable("rechargeAmount",rechargeAmount);
//var sessionId=context.getVariable("req.sessionId");
context.setVariable("isoTimestamp", ISODateString());
var SessionId = context.getVariable("req.SessionId");
/*var requestVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",requestVerb);*/
/*var requestVerb = context.getVariable("req.action");
context.setVariable("reqVerb",requestVerb);
*/
context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00
/*context.setVariable("recipientMsisdn",chargeMsisdn);*/
var msisdnLength = UserName.length;


if (isEmpty(id) || isEmpty(payer) ||isEmpty(rechargeAmount)) 
{
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.031.102");
    context.setVariable("errorMessage","Missing Parameters");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";
}  

if ((id.length > 10) ||(id.length < 10) ||(payer.length > 10) ||(payer.length < 10)) 
{
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.031.101");
    context.setVariable("errorMessage","Invalid Input");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";
} 


if((!UserName.startsWith("97") && UserName.length === 10))
    {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.031.101");
    context.setVariable("errorMessage","Invalid account Id");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";   
    }
    
if((!payer.startsWith("97") && UserName.length === 10))
    {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.031.101");
    context.setVariable("errorMessage","Invalid Payer Id");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";   
    }
    
if((!id.startsWith("97") && UserName.length === 10))
    {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.031.101");
    context.setVariable("errorMessage","Invalid User Id");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";   
    }
 

function isEmpty(input) {
    return (!input || 0 === input.length);
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}

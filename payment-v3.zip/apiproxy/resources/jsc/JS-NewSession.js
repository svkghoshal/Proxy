 
 var newSessionId = context.getVariable("new.SessionId");
context.setVariable("newSessionId",newSessionId);
print(newSessionId);
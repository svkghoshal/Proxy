var customError = context.getVariable("customError");

if (!isEmpty(customError)) {
    switch (customError) {
        case "Token_CCCP_GMDP":
        case "Token_CCCP_FBFLEX":
            var errorStatus = 500;
            var errorReason = "Internal Server Error";
            var errorFault = "Missing CCCP Token";
            var errorDetail = "deverloper_app.custom_attribute."+customError;
            break;
        case "channelId":
            var errorStatus = 400;
            var errorReason = "Bad Request";
            var errorFault = "Missing Channel ID";
            var errorDetail = "request.header.Channel-Id";
            break;
        default:
            var errorStatus = 500;
            var errorReason = "Internal Server Error";
            var errorFault = "Unknown error";
            var errorDetail = "undefined.custom.error";
    }
    
    // Construct the error message
    var errorContent = "";
    var json = {};
    json.fault = {};
    json.fault.faultstring = errorFault;
    json.fault.detail = {};
    json.fault.detail.errorcode = errorDetail;
    errorContent = JSON.stringify(json);
    
    context.setVariable("error.status.code", errorStatus);
    context.setVariable("error.reason.phrase", errorReason);
    context.setVariable("error.content", errorContent);
}

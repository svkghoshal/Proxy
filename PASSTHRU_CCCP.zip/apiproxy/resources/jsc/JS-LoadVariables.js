// Set the timestamp of request
context.setVariable("isoTimestamp", ISODateString());

// Set the transactionId
var transactionIdSeq = randomString(8);
context.setVariable("transactionIdSeq", transactionIdSeq);
context.setVariable("transactionId", transactionDateTime() + transactionIdSeq);

// Set the Target environment
envName = context.getVariable("environment.name");
if (envName.indexOf("sandbox") >= 0) {
    context.setVariable("envType", "SANDBOX");
} else {
    context.setVariable("envType", "PRODUCTION");
}

// Specific APIGW-Source-Id will verify using APIGW's oauth
// Others will verify using apikey
sourceId = context.getVariable("sourceId");
switch (sourceId) {
    case "TELENORDIGITAL":
        var useOauth = "true";
        break;
    default:
        var useOauth = "false";
}
context.setVariable("useOauth", useOauth);


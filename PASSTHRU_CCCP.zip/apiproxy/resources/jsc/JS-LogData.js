var MessageStatusCode = ""+context.getVariable("message.status.code");
switch (MessageStatusCode.charAt(0)) {
    case "1":
        logType = "INFO";
        break;
    case "2":
        logType = "SUCCESS";
        break;
    case "3":
        logType = "REDIRECTION";
        break;
    case "4":
        logType = "ERROR_CLIENT";
        break;
    case "5":
        logType = "ERROR_SERVER";
        break;
    default:
        logType = "UNKNOWN";
}
context.setVariable("logType", logType);

/****************************************************************/

// Extract Headers (request)
var reqHeaderNames = context.getVariable("request.headers.names");
var reqHeaderCount = context.getVariable("request.headers.count");
try {
    var reqHeaderArr = reqHeaderNames.toArray();
    var reqHeaderVal = new Array();
    for (var i=0; i<reqHeaderCount; i++) {
        var n = reqHeaderArr[i];
        var a = context.getVariable("request.header."+n+".values").toArray();
        var v = a.join(",");
        context.setVariable("HeadersRequest_"+n, v);
        
        var s = n+"="+v;
        reqHeaderVal.push(s);
    }
    context.setVariable("HeadersRequestFull", reqHeaderVal.join("|"));
} catch (err) {
    context.setVariable("HeadersRequestFull", "N/A");
}

// Extract Headers (response)
var resHeaderNames = context.getVariable("response.headers.names");
var resHeaderCount = context.getVariable("response.headers.count");
try {
    var resHeaderArr = resHeaderNames.toArray();
    var resHeaderVal = new Array();
    for (var i=0; i<resHeaderCount; i++) {
        var n = resHeaderArr[i];
        var a = context.getVariable("response.header."+n+".values").toArray();
        var v = a.join(",");
        context.setVariable("HeadersResponse_"+n, v);
        
        var s = n+"="+v;
        resHeaderVal.push(s);
    }
    context.setVariable("HeadersResponseFull", resHeaderVal.join("|"));
} catch (err) {
    context.setVariable("HeadersResponseFull", "N/A");
}

/****************************************************************/

// Payload from client request
var clientRequestContent = context.getVariable("clientRequestContent");
var clientRequestContentFlat = "";
if (!isEmpty(clientRequestContent)) {
    try {
        // Content is JSON
        var clientRequestContentParse = JSON.parse(clientRequestContent);
        var clientRequestContentFlat = JSON.stringify(clientRequestContentParse);
    } catch (err) {
        // Something wrong with above (eg. invalid JSON), so just flatten the string
        var clientRequestContentFlat = str2flat(clientRequestContent);
    }
    
    switch (logType) {
        case "ERROR_CLIENT":
        case "ERROR_SERVER":
        case "UNKNOWN":
            // Do nothing -- do not truncate
            break;
        default:
            // Looks like a success request, so truncate the payload (only for logging purposes)
            // This is to prevent the log from getting too big!
            var truncLength = 2048;
            if (clientRequestContentFlat.length > truncLength) {
                clientRequestContentFlat = clientRequestContentFlat.substring(0, truncLength) + "<TRUNCATED>";
            }
    }
    context.setVariable("clientRequestContentFlat", clientRequestContentFlat);
} else {
    context.setVariable("clientRequestContentFlat", "N/A");
}

// Payload from client request
var clientResponseContent = context.getVariable("clientResponseContent");
var clientResponseContentFlat = "";
if (!isEmpty(clientResponseContent)) {
    try {
        // Content is JSON
        var clientResponseContentParse = JSON.parse(clientResponseContent);
        var clientResponseContentFlat = JSON.stringify(clientResponseContentParse);
    } catch (err) {
        // Something wrong with above (eg. invalid JSON), so just flatten the string
        var clientResponseContentFlat = str2flat(clientResponseContent);
    }
    
    switch (logType) {
        case "ERROR_CLIENT":
        case "ERROR_SERVER":
        case "UNKNOWN":
            // Do nothing -- do not truncate
            break;
        default:
            // Looks like a success request, so truncate the payload (only for logging purposes)
            // This is to prevent the log from getting too big!
            var truncLength = 2048;
            if (clientResponseContentFlat.length > truncLength) {
                clientResponseContentFlat = clientResponseContentFlat.substring(0, truncLength) + "<TRUNCATED>";
            }
    }
    context.setVariable("clientResponseContentFlat", clientResponseContentFlat);
} else {
    context.setVariable("clientResponseContentFlat", "N/A");
}

/****************************************************************/

// Return the backend environment as Header for Sandbox
var envType = context.getVariable("envType");
var rmp_ip = context.getVariable("system.interface.ens192");
if (envType != "PRODUCTION") {
    switch (rmp_ip) {
        case "10.88.1.20":
            var rmp_hostname = "a0110papirmp01";
            break;
        case "10.88.1.21":
            var rmp_hostname = "a0110papirmp02";
            break;
        default:
            var rmp_hostname = rmp_ip;
    }
    context.setVariable("message.header.APIGW-Router-Message-Processor", rmp_hostname);
}

/****************************************************************/

// Calculate target elapsed time
var targetElapsedTime = getTargetElaspedTime();
context.setVariable("targetElapsedTime", ((targetElapsedTime) ? targetElapsedTime : "X"));

// Calculate the total elapsed time
// Time request is received from client to time response is sent back to client
var client_start = context.getVariable("client.received.start.timestamp");
var system_timestamp = context.getVariable("system.timestamp");
var totalElapsedTime = context.setVariable("totalElapsedTime", ""+(system_timestamp-client_start));

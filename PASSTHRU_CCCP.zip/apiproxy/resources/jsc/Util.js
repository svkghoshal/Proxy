function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}

function isInteger(value) {
    var x;
    return isNaN(value) ? !1 : (x = parseFloat(value), (0 | x) === x);
}

// Flatten the payload into a single line
function xml2flat(str) {
    str = str.replace(/>\s*/g, '>');  // Remove space after >
    str = str.replace(/\s*</g, '<');  // Remove space before <
    str = str.replace(/[\n\r]/g, ''); // Remove all newlines
    return str;
}

function str2flat(str) {
    str = str.replace(/[\n\r]/g, ""); // Remove all newlines
    return str;
}

// Target start time
function getTargetStartTime() {
    if (isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";	
    } else {
        return getTimePattern(context.getVariable("target.sent.start.timestamp"));
    }
}

// Target end time
function getTargetEndTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.received.end.timestamp"));
    }
}

// Target elapsed time
function getTargetElaspedTime() {
    var startTime = context.getVariable("target.sent.start.timestamp");
    var endTime = context.getVariable("target.received.end.timestamp");
    if (isEmpty(startTime) || isEmpty(endTime)) {
        return "";
    } else {
        var elaspedTime = endTime - startTime;
        return "" + elaspedTime;
    }
}

function getTimePattern(dateTime) {
    var now = new Date(dateTime),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
        pad2 = function(num) {
            var norm = Math.abs(Math.floor(num));
            var str = norm;
            if (norm < 10) {
                str = '00' + norm;
            } else if ((norm >= 10) && (norm < 100)) {
                str = '0' + norm;
            }
            return str;
        };
    return now.getFullYear()
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes())
        + ':' + pad(now.getSeconds())
        + '.' + pad2(now.getMilliseconds())
        + dif + pad(tzo / 60)
        + ':' + pad(tzo % 60);
}

function checkLengthDateFormat(today) {
    if (today.length == 1) {
        today = "0" + today;
    }
    return today;
}

function transactionDateTime() {
    var now = new Date(),
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear()
        + pad(now.getMonth()+1)
        + pad(now.getDate())
        + pad(now.getHours())
        + pad(now.getMinutes())
        + pad(now.getSeconds());
}

function randomString(length) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for(var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}

// Set Spike Arrest bypass flag
var SpikeArrestDevAppBypass = context.getVariable("verifyapikey.VK-VerifyApiKey.SpikeArrest_bypass");
context.setVariable("SpikeArrest_bypass", SpikeArrestDevAppBypass);

// Set the Spike Arrest value in following priority
// - Developer App
// - KVM
// - Bypass
// If Developer App or KVM is set to "0" (without "ps"), then it means bypass
var SpikeArrestKVM = context.getVariable("SpikeArrest_KVM");
var SpikeArrestDevAppVal = context.getVariable("verifyapikey.VK-VerifyApiKey.SpikeArrest_value");
if (!isEmpty(SpikeArrestDevAppVal) && SpikeArrestDevAppVal != "0") {
    context.setVariable("SpikeArrest", SpikeArrestDevAppVal);
} else if (!isEmpty(SpikeArrestKVM) && SpikeArrestKVM != "0") {
    context.setVariable("SpikeArrest", SpikeArrestKVM);
} else {
    // If Spike Arrest is not set, default it to bypass
    context.setVariable("SpikeArrest_bypass", 1);
}

var useOauth = context.getVariable("useOauth");
if (useOauth == "true") {
    // Get accessToken values from Developer App - Custom Attribute
    var accessToken_GMDP = context.getVariable("app.Token_CCCP_GMDP");
    var accessToken_FBFLEX = context.getVariable("app.Token_CCCP_FBFLEX");
    if (isEmpty(accessToken_GMDP)) {
        context.setVariable("customError", "Token_CCCP_GMDP");
        throw "Token_CCCP_GMDP";
    }
    if (isEmpty(accessToken_FBFLEX)) {
        context.setVariable("customError", "Token_CCCP_FBFLEX");
        throw "Token_CCCP_FBFLEX";
    }
    
    // Channel-Id is needed
    var channelId = context.getVariable("channelId");
    switch (channelId) {
        case "GMDP":
            var accessToken = accessToken_GMDP;
            break;
        case "FBFLEX":
            var accessToken = accessToken_FBFLEX;
            break;
        default:
            context.setVariable("customError", "channelId");
            throw "channelId";
    }
    context.setVariable("accessToken", accessToken);
}

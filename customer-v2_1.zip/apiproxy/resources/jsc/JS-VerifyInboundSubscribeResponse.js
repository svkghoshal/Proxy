var errrorCode = "" + context.getVariable("resp.errorCode");
var errrorMessage = "" + context.getVariable("resp.errorDescription");
var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");

context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));

printProxyRequest(requestContent);
printTargetResponse(responseContent);

if(isEmpty(errrorCode)) {
    setResponse("200", "200", "", "");
} else {
    if(errrorMessage.indexOf("SDP") > 1) {
        errorSubscribeResultMapping(trimErrorCodeOm(errrorMessage), trimErrorMessageSdp(errrorMessage));
    } else {
        errorSubscribeResultMapping(trimErrorCodeEsb(errrorCode), errrorMessage);
    }
}
setReasonPhrase(context.getVariable("resp.httpStatusCode"));
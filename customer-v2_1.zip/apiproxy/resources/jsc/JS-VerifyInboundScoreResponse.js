var esbCode = "" + context.getVariable("resp.esbResponseCode");
var esbMessage = "" + context.getVariable("resp.esbResponseMessage");
var systemResponseCode = "" + context.getVariable("resp.systemResponseCode");
var systemResponseMessage = "" + context.getVariable("resp.systemResponseMessage");
var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("request.verb", "GET");

printProxyRequest(requestContent);
printTargetResponse(responseContent);

if(isEmpty(esbCode) && isEmpty(systemResponseCode)) {
    var bilCrdSegment = "" + context.getVariable("resp.bilCrdSegment");
    if(bilCrdSegment == "0") {
        context.setVariable("resp.scoreValue", "Colorless");
    } else if(bilCrdSegment == "1") {
        context.setVariable("resp.scoreValue", "Green");
    } else if(bilCrdSegment == "2") {
        context.setVariable("resp.scoreValue", "Blue");
    } else if(bilCrdSegment == "3") {
        context.setVariable("resp.scoreValue", "Yellow");
    } else if(bilCrdSegment == "4") {
        context.setVariable("resp.scoreValue", "Red");
    }
    
    setResponse("200", "200", "", "");
}  else if (!isEmpty(esbCode) && isEmpty(systemResponseCode)) {
    var esbResponseCode = trimErrorCodeEsb(esbCode);
    var esbResponseMessage = trimErrorMessageEsb(esbMessage);
    
    errorScoreResultMapping(esbResponseCode, esbResponseMessage);
} else if (!isEmpty(esbCode) && !isEmpty(systemResponseCode)) {
    errorScoreResultMapping(systemResponseCode, systemResponseMessage);
}
setReasonPhrase(context.getVariable("resp.httpStatusCode"));
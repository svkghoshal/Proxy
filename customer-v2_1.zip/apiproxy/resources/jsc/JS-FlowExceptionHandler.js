var faultName = context.getVariable("fault.name");
var validateError = context.getVariable("validateError");
var path = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb");

print("faultName = " + faultName);
print("validateError = " + validateError)
//print(context.getVariable("request.content"));
print("verb : " + verb);


if(!isEmpty(validateError)) {
    faultName = validateError;
    print("override faultName = " + faultName);
}
try {
    switch(verb) {
        case "GET":
            switch(path) {
                case "/balance":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.030.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.030.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.030.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.030.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.030.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.030.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.030.2007", "Internal Server Error", "Invalid JSON path.");
                            break;
                        case "InvalidRefToken":
                            setResponse("400", "400.030.0012", "Bad Request", "Invalid reference token");
                            break;
                        default:
                            setResponse("500", "500.030.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;
                case "/fupBalance":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.037.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.037.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.037.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.037.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.037.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "037.037.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.037.2007", "Internal Server Error", "Invalid JSON path.");
                            break;

                        default:
                            setResponse("500", "500.037.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;
                case "/vasBalance":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.036.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.036.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.036.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.036.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.036.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.036.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.036.2007", "Internal Server Error", "Invalid JSON path.");
                            break;

                        default:
                            setResponse("500", "500.036.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;
                case "/cdr":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.038.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.038.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.038.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.038.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.038.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.038.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.038.2007", "Internal Server Error", "Invalid JSON path.");
                            break;
                        case "InvalidRefToken":
                            setResponse("400", "400.038.0010", "Bad Request", "Invalid reference token");
                            break;
                        default:
                            setResponse("500", "500.038.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;
                case "/checkBlackList":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.050.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.050.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.050.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.050.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.050.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.050.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.050.2007", "Internal Server Error", "Invalid JSON path.");
                            break;
                        default:
                            setResponse("500", "500.050.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;
                case "/checkLockedID":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.051.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.051.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.051.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.051.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.051.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.051.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.051.2007", "Internal Server Error", "Invalid JSON path.");
                            break;
                        default:
                            setResponse("500", "500.051.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;
                case "/profile":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.047.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.047.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.047.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.047.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.047.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.047.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.047.2007", "Internal Server Error", "Invalid JSON path.");
                            break;

                        case "MissingCustomAttributes":
                            setResponse("400", "400.047.0000", "Bad Request", "Missing custom attributes");
                            break;

                        default:
                            setResponse("500", "500.047.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;
                case "/score":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.048.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.048.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.048.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.048.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.048.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.048.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.048.2007", "Internal Server Error", "Invalid JSON path.");
                            break;
                        default:
                            setResponse("500", "500.048.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;
                 case "/device":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.049.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.049.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.049.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.049.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.049.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.049.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.049.2007", "Internal Server Error", "Invalid JSON path.");
                            break;

                        case "MissingCustomAttributes":
                            setResponse("400", "400.049.0000", "Bad Request", "Missing custom attributes");
                            break;

                        default:
                            setResponse("500", "500.049.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;
                default:
                    switch(true){
                        case (/(\/usageConsumptionReport\/)(0|6{2})(\d{9})(?!.+)/).test(path):
                            switch(faultName) {
                                case "SpikeArrestViolation":
                                    setResponse("429", "429.061.2001", "Too Many Requests", "Spike arrest violation");
                                    break;
                                case "QuotaViolation":
                                    setResponse("429", "429.061.2002", "Too Many Requests", "Quota limit exceeded");
                                    break;
                                case "ConcurrentRatelimtViolation":
                                    setResponse("429", "429.061.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                                    break;
        
                                case "ScriptExecutionFailed":
                                case "ScriptExecutionFailedLineNumber":
                                case "ScriptSecurityError":
                                    setResponse("500", "500.061.2004", "Internal Server Error", "JavaScript runtime error");
                                    break;
        
                                case "access_token_expired":
                                case "invalid_access_token":
                                case "InvalidAccessToken":
                                    setResponse("500", "500.061.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                                    break;
        
                                case "BusinessValidationFailed":
                                    setResponse("500", "500.061.2006", "Internal Server Error", "Request input is malformed or invalid");
                                    break;
        
                                case "JSONPathCompilationFailed":
                                case "InvalidJSONPath":
                                case "JsonPathParsingFailure":
                                    setResponse("500", "500.061.2007", "Internal Server Error", "Invalid JSON path.");
                                    break;
                                case "InvalidRefToken":
                                    setResponse("400", "400.061.0011", "Bad Request", "Invalid reference token");
                                    break;
                                default:
                                    setResponse("500", "500.061.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                                    break;
                            }
                        break;
                        case (/(\/validatePre2Post\/)(0|6{2})(\d{9})(?!.+)/).test(path):
                            switch(faultName) {
                                case "SpikeArrestViolation":
                                    setResponse("429", "429.069.2001", "Too Many Requests", "Spike arrest violation");
                                    break;
                                case "QuotaViolation":
                                    setResponse("429", "429.069.2002", "Too Many Requests", "Quota limit exceeded");
                                    break;
                                case "ConcurrentRatelimtViolation":
                                    setResponse("429", "429.069.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                                    break;
        
                                case "ScriptExecutionFailed":
                                case "ScriptExecutionFailedLineNumber":
                                case "ScriptSecurityError":
                                    setResponse("500", "500.069.2004", "Internal Server Error", "JavaScript runtime error");
                                    break;
        
                                case "access_token_expired":
                                case "invalid_access_token":
                                case "InvalidAccessToken":
                                    setResponse("500", "500.069.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                                    break;
        
                                case "BusinessValidationFailed":
                                    setResponse("500", "500.069.2006", "Internal Server Error", "Request input is malformed or invalid");
                                    break;
        
                                case "JSONPathCompilationFailed":
                                case "InvalidJSONPath":
                                case "JsonPathParsingFailure":
                                    setResponse("500", "500.069.2007", "Internal Server Error", "Invalid JSON path.");
                                    break;
                                case "MissingCustomAttributes":
                                    setResponse("400", "400.069.0000", "Bad Request", "Missing custom attributes");
                                    break;
                                default:
                                    setResponse("500", "500.069.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                                    break;
                            }
                        break;
                    case (/(\/cdr\/)(0|6{2})(\d{9})(?!.+)/).test(path): 
                        switch(faultName) {
                            case "SpikeArrestViolation":
                                setResponse("429", "429.096.2001", "Too Many Requests", "Spike arrest violation");
                                break;
                            case "QuotaViolation":
                                setResponse("429", "429.096.2002", "Too Many Requests", "Quota limit exceeded");
                                break;
                            case "ConcurrentRatelimtViolation":
                                setResponse("429", "429.096.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                                break;
    
                            case "ScriptExecutionFailed":
                            case "ScriptExecutionFailedLineNumber":
                            case "ScriptSecurityError":
                                setResponse("500", "500.096.2004", "Internal Server Error", "JavaScript runtime error");
                                break;
    
                            case "access_token_expired":
                            case "invalid_access_token":
                            case "InvalidAccessToken":
                                setResponse("500", "500.096.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                                break;
    
                            case "BusinessValidationFailed":
                                setResponse("500", "500.096.2006", "Internal Server Error", "Request input is malformed or invalid");
                                break;
    
                            case "JSONPathCompilationFailed":
                            case "InvalidJSONPath":
                            case "JsonPathParsingFailure":
                                setResponse("500", "500.096.2007", "Internal Server Error", "Invalid JSON path.");
                                break;
                            case "InvalidRefToken":
                                setResponse("400", "400.096.0003", "Bad Request", "Invalid reference token");
                                break;
                            default:
                                setResponse("500", "500.096.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                                break;
                        }
                    break;
                    default:
                        setResponse("404", "404.030.0001", "Resource not found", "Resource not found/Invalid resource");
                        break;
                    }
                    
            }
            break;
        case "POST":
            switch(path) {
                case "/subscribe":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.035.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.035.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.035.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.035.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.035.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.035.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.035.2007", "Internal Server Error", "Invalid JSON path.");
                            break;

                        case "MissingCustomAttributes":
                            setResponse("400", "400.035.0000", "Bad Request", "Missing custom attributes");
                            break;

                        default:
                            setResponse("500", "500.035.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;
                    case "/savePre2Post":
                        switch(faultName) {
                            case "SpikeArrestViolation":
                                setResponse("429", "429.070.2001", "Too Many Requests", "Spike arrest violation");
                                break;
                            case "QuotaViolation":
                                setResponse("429", "429.070.2002", "Too Many Requests", "Quota limit exceeded");
                                break;
                            case "ConcurrentRatelimtViolation":
                                setResponse("429", "429.070.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                                break;
    
                            case "ScriptExecutionFailed":
                            case "ScriptExecutionFailedLineNumber":
                            case "ScriptSecurityError":
                                setResponse("500", "500.070.2004", "Internal Server Error", "JavaScript runtime error");
                                break;
    
                            case "access_token_expired":
                            case "invalid_access_token":
                            case "InvalidAccessToken":
                                setResponse("500", "500.070.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                                break;
    
                            case "BusinessValidationFailed":
                                setResponse("500", "500.070.2006", "Internal Server Error", "Request input is malformed or invalid");
                                break;
    
                            case "JSONPathCompilationFailed":
                            case "InvalidJSONPath":
                            case "JsonPathParsingFailure":
                                setResponse("500", "500.070.2007", "Internal Server Error", "Invalid JSON path.");
                                break;
    
                            case "MissingCustomAttributes":
                                setResponse("400", "400.070.0000", "Bad Request", "Missing custom attributes");
                                break;
    
                            default:
                                setResponse("500", "500.070.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                                break;
                        }
                    break;
                default:
                    setResponse("404", "404.030.0001", "Resource not found", "Resource not found/Invalid resource");
                    break;
            }
            break;
        default:
            setResponse("404", "404.030.0001", "Resource not found", "Resource not found/Invalid resource");
            break;
    }
} catch(ex) {
    switch(path) {
        case "/balance":
            setResponse("500", "500.030.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case "/fupBalance":
            setResponse("500", "500.037.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case "/vasBalance":
            setResponse("500", "500.036.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case "/cdr":
            setResponse("500", "500.038.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case "/checkBlackList":
            setResponse("500", "500.050.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case "/checkLockedID":
            setResponse("500", "500.051.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case "/profile":
            setResponse("500", "500.047.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case "/score":
            setResponse("500", "500.048.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case "/device":
            setResponse("500", "500.049.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case "/subscribe":
            setResponse("500", "500.035.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case (/(\/usageConsumptionReport\/)(0|6{2})(\d{9})(?!.+)/).test(path):
            setResponse("500", "500.061.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case (/(\/validatePre2Post\/)(0|6{2})(\d{9})(?!.+)/).test(path):
            setResponse("500", "500.069.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case "/savePre2Post":
            setResponse("500", "500.070.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        case (/(\/cdr\/)(0|6{2})(\d{9})(?!.+)/).test(path):
            setResponse("500", "500.096.2004", "Internal Server Error", "JavaScript runtime error");
            break;
        default:
            setResponse("404", "404.030.0001", "Resource not found", "Resource not found/Invalid resource");
            break;
    }
}
context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
setReasonPhrase(context.getVariable("resp.httpStatusCode"));
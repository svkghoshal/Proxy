var errorCode = context.getVariable("resp.messageSqlCode");
var errorMessage = context.getVariable("resp.messageTextEng");
var requestContent = "" + context.getVariable("request.content");
var responseContent = "" + context.getVariable("response.content");

printTargetResponse(responseContent);

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("request.verb", "GET");

if(!isEmpty(errorCode)) {
    if(errorCode == "202336") {
        setResponse("200", "200", "", "");
        context.setVariable("resp.statusBlackList", "TRUE");
    } else {
        errorCheckBlackListResultMapping(errorCode, errorMessage);
    }
} else {
    setResponse("200", "200", "", "");
    context.setVariable("resp.statusBlackList", "FALSE");
}
setReasonPhrase(context.getVariable("resp.code"));
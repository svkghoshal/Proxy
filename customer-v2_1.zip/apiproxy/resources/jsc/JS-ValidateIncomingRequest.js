var path = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb");

context.setVariable("northboundRequestDatetime", "" + getDatetime());

switch(verb) {
    case "GET":
        context.setVariable("northbound.request", "" + context.getVariable("request.querystring"));
        switch(path) {
            case "/balance":
                validateQueryBalance();
                break;
            case "/fupBalance" :
                validateFupBalance();
                break;
            case "/vasBalance" :
                validateVasBalance();
                break;
            case "/cdr" :
                validateCdr();
                break;
            case "/checkBlackList" :
                validateCheckBlackList();
                break;
            case "/checkLockedID" :
                validateCheckLockedId();
                break;
            case "/profile" :
                validateProfile();
                break;
            case "/score" :
                validateScore();
                break;
            case "/device" :
                validateDevice();
                break;
            
            default:
                switch(true) {
                    case (/(\/cdr\/)(0|6{2})(\d{9})(?!.+)/).test(path):
                        validateEscCdr();
                        break;
                    case (/(\/usageConsumptionReport\/)(0|6{2})(\d{9})(?!.+)/).test(path):
                        context.setVariable("northbound.request", ""+context.getVariable("request.querystring"));
                        validateQueryUsageSummary();
                        break;
                     case (/(\/validatePre2Post\/)(0|6{2})(\d{9})(?!.+)/).test(path):
                        validatePreToPost();
                        break;
                    default:
                        context.setVariable("validateError", "ResourceNotFound");
                        break;
                }
        }
        break;
    case "POST":
        context.setVariable("northbound.request", setNorthSouthJsonRequestResponse("" + context.getVariable("request.content")));
        switch(path) {
            case "/subscribe":
                validateSubscribe();
                break;
            case "/savePre2Post" :
                validateSavePreToPost();
                break;
            default:
                context.setVariable("validateError", "ResourceNotFound");
                break;
        }
        break;
    default:
        context.setVariable("validateError", "ResourceNotFound");
        break;
}
context.setVariable("responseDatetime", getYYYYMMddHHmmssWithoutSymbol());

function validateQueryBalance(){
    var transactionId = "" + context.getVariable("req.qbTransactionId");
    var idType = "" + context.getVariable("req.qbIdType");
    var idValue = "" + context.getVariable("req.qbIdValue");
    var channelName = "" + context.getVariable("req.qbChannelName");
    var ccbIsEnableHttps = context.getVariable("ccbIsEnableHttps");
    var now = new Date();
    
     // validate reference token
    var href = convertSymbol(context.getVariable("req.href"));
    var checkTicket = "" + context.getVariable("cusAttr.checkTicket");
    var key = "" + context.getVariable("decryptKey");
    var decryptData = getDecryptedDataAuthen(href,key);
    var timeExpireToken = "" + context.getVariable("timeExpireToken");
    var developerName = context.getVariable("apigee.developer.app.name");
    var subNum = "";
    var devName = "";
    var createTime = "";
    var timeExpire = "";
    
    print("validateQueryBalance:param(mandatory):"
        + ", transactionId = " + transactionId
        + ", idType = " + idType 
        + ", idValue = " + idValue
        + ", channelName = " + channelName);
    
    if(isEmpty(transactionId) || isEmpty(idType) || isEmpty(idValue) || 
       isEmpty(channelName)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    else{
        print("checkTicket : " + checkTicket);
    	if(!isEmpty(checkTicket) && checkTicket === "Y"){
    		if(!isEmpty(href)){
    			try{
    				 var result = decryptData.split(/\|/);
    				 print("result decrypt: " + result);
    					for(var index = 0; index < result.length; index++){
    						subNum = result[0];
    						devName = result[1];
    						createTime = result[2];
    					}
    				timeExpire = getMaxDateExpire(createTime,timeExpireToken);
    			}catch(err){
    				 context.setVariable("validateError", "InvalidRefToken");
    				 print("error : " + err);
    			}
    			// validate token
    			if((idValue != subNum) || (developerName != devName) 
    			|| !matchDateFormatYYYYMMDDHHmm(createTime) || (getDateAndTimeHourMinuteFormat(now) > timeExpire)){
    				context.setVariable("validateError", "InvalidRefToken");
    			}
    		}else{
    		    context.setVariable("validateError", "InvalidRefToken");
    		}
    	}
    }
    
    context.setVariable("req.sentDttm", getDatetime());
    context.setVariable("req.qbIdValue",convertMobileNotoPrefix66(idValue));
    context.setVariable("ccbIsEnableHttps", ccbIsEnableHttps);
}

function validateFupBalance() {
    var now = new Date();
    var transactionId = "" + context.getVariable("req.fbTransactionId");
    var idType = "" + context.getVariable("req.fbIdType");
    var idValue = "" + context.getVariable("req.fbIdValue");
    var channelName = "" + context.getVariable("req.fbChannelName");
    var activePack = "" + context.getVariable("req.fbActivePack");
    var lang = "" + context.getVariable("req.fbLang");
    var isEnableHttps = context.getVariable("fupBalanceIsEnableHttps");
    var sourceSystemID = "" + context.getVariable("fbSourceSystemID");
    var referenceKey = getReferenceKey(now);
    var sourceSystemKey = "" + context.getVariable("fupSourceSystemKey");
    var authenCode = getAuthenCode(now, referenceKey, sourceSystemKey);
    
    
    print("validateFupBalance:param(mandatory):"
        + ", transactionId = " + transactionId
        + ", idType = " + idType 
        + ", idValue = " + idValue
        + ", channelName = " + channelName
        + ", activePack = " + activePack
        + ", lang = " + lang);
    
    if(isEmpty(transactionId) || isEmpty(idType) || isEmpty(idValue) || 
       isEmpty(channelName) || isEmpty(activePack) || isEmpty(lang)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    
    context.setVariable("req.messageId", sourceSystemID + getYYYYMMddHHmmssSSSWithoutSymbolUseDate(now));
    context.setVariable("req.requestDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(now));
    context.setVariable("req.referenceKey", referenceKey);
    context.setVariable("req.authenCode", authenCode);
    context.setVariable("req.fbIdValue",convertMobileNotoPrefix66(idValue));
    context.setVariable("endpointUrl", context.getVariable("fupBalanceEndpoint"));
    context.setVariable("isEnableHttps", isEnableHttps);
                                
    var telpType = "" + context.getVariable("req.fbTelpType");
    var compCode = convertCompCode("" + context.getVariable("req.fbCompCode")); 

    var arraySoapData = {
        tagSingle : [
          { name : 'SubrNumb', value : convertMobileNotoPrefix66(idValue) },
          { name : 'Lang', value : lang },
          { name : 'ActivePackageOnly', value : activePack},
          { name : 'TelType', value : telpType },
          { name : 'CompCode', value : compCode }
        ]
    };
    
    var soapDataMassage = setSoapRequest(arraySoapData);
    context.setVariable("req.soapMessage", soapDataMassage);
}

function validateVasBalance() {
    var now = new Date();
    var transactionId = "" + context.getVariable("req.vbTransactionId");
    var idValue2 = "" + context.getVariable("req.vbIdValue2");
    var idValue = "" + context.getVariable("req.vbIdValue");
    var lang = "" + context.getVariable("req.vbLang");
    var telpType = "" + context.getVariable("req.vbTelpType");
    var offerRange = "" + context.getVariable("req.vbOfferRange");
    var isEnableHttps = context.getVariable("vasBalanceIsEnableHttps");
    var sourceSystemID = "" + context.getVariable("vbSourceSystemID");
    var referenceKey = getReferenceKey(now);
    var sourceSystemKey = "" + context.getVariable("vasSourceSystemKey");
    var authenCode = getAuthenCode(now, referenceKey, sourceSystemKey);

    print("validateVasBalance:param(mandatory):"
        + ", transactionId = " + transactionId
        + ", idValue = " + idValue
        + ", lang = " + lang);
    
    if(isEmpty(transactionId) || isEmpty(idValue) || isEmpty(lang)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    
    context.setVariable("req.messageId", sourceSystemID + getYYYYMMddHHmmssSSSWithoutSymbolUseDate(now));
    context.setVariable("req.requestDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(now));
    context.setVariable("req.referenceKey", referenceKey);
    context.setVariable("req.authenCode", authenCode);
    context.setVariable("req.offerRangeList", setOfferRangeList(offerRange));
    context.setVariable("req.vbIdValue",convertMobileNotoPrefix66(idValue));
    context.setVariable("endpointUrl", context.getVariable("vasBalanceEndpoint"));
    context.setVariable("isEnableHttps", isEnableHttps);
}

function validateCdr(){
    context.setVariable("functionValidateCdr", "validateCdr");
    var now = new Date();
    var transactionId = "" + context.getVariable("req.CdrTransactionId");
    var idValue = "" + context.getVariable("req.CdrIdValue");
    var lang = "" + context.getVariable("req.CdrLang");
    var startDTTM = "" + context.getVariable("req.CdrStartDTTM");
    var endDTTM = "" + context.getVariable("req.CdrEndDTTM");
    var totalCDR = "" + context.getVariable("req.CdrTotalCDR");
    var beginRow = "" + context.getVariable("req.CdrBeginRow");
    var fetchRow = "" + context.getVariable("req.CdrFetchRow");
    var calledCellparty = "" + context.getVariable("req.CdrCalledCellparty");
    var usageServiceType = "" + context.getVariable("req.CdrUsageServiceType");
    var usageServiceCat = "" + context.getVariable("req.CdrUsageServiceCat");
    var usageServiceOtherCat = "" + context.getVariable("req.CdrUsageServiceOtherCat");
    
    var isEnableHttps = context.getVariable("queryCdrIsEnableHttps");
    
    var sourceSystemID = "" + context.getVariable("queryCdrSourceSystemID");
    var referenceKey = getReferenceKey(now);
    var sourceSystemKey = "" + context.getVariable("queryCdrSourceSystemKey");
    var authenCode = getAuthenCode(now, referenceKey, sourceSystemKey);
    
        // validate reference token
    var href = convertSymbol(context.getVariable("req.href"));
    var checkTicket = "" + context.getVariable("cusAttr.checkTicket");
    var key = "" + context.getVariable("decryptKey");
    var decryptData = getDecryptedDataAuthen(href,key);
    var timeExpireToken = "" + context.getVariable("timeExpireToken");
    var developerName = context.getVariable("apigee.developer.app.name");
    var subNum = "";
    var devName = "";
    var createTime = "";
    var timeExpire = "";
    
     print("validateCdr:param(mandatory):"
        + ", transactionId = " + transactionId
        + ", idValue = " + idValue
        + ", startDTTM = " + startDTTM
        + ", endDTTM = " + endDTTM
        + ", lang = " + lang
        + ", totalCDR = " + totalCDR
        + ", beginRow = " + beginRow
        + ", fetchRow = " + fetchRow);
        
    if(isEmpty(transactionId) || isEmpty(idValue) || isEmpty(lang) || isEmpty(startDTTM) || 
        isEmpty(endDTTM) || isEmpty(totalCDR) || isEmpty(beginRow) || isEmpty(fetchRow)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    else{
        print("checkTicket : " + checkTicket);
    	if(!isEmpty(checkTicket) && checkTicket === "Y"){
    		if(!isEmpty(href)){
    			try{
    				 var result = decryptData.split(/\|/);
    				 print("result decrypt: " + result);
    					for(var index = 0; index < result.length; index++){
    						subNum = result[0];
    						devName = result[1];
    						createTime = result[2];
    					}
    				timeExpire = getMaxDateExpire(createTime,timeExpireToken);
    			}catch(err){
    				 context.setVariable("validateError", "InvalidRefToken");
    				 print("error : " + err);
    			}
                // validate token
                if((idValue != subNum) || (developerName != devName) 
                || !matchDateFormatYYYYMMDDHHmm(createTime) || (getDateAndTimeHourMinuteFormat(now) > timeExpire)){
                    context.setVariable("validateError", "InvalidRefToken");
                }
    		}else{
    		    context.setVariable("validateError", "InvalidRefToken");
    		}
    	}
    }
    
    context.setVariable("req.messageId", sourceSystemID + getYYYYMMddHHmmssSSSWithoutSymbolUseDate(now));
    context.setVariable("req.requestDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(now));
    context.setVariable("req.referenceKey", referenceKey);
    context.setVariable("req.authenCode", authenCode);
    context.setVariable("req.queryCdrIdValue",convertMobileNotoPrefix66(idValue));
    context.setVariable("endpointUrl", context.getVariable("queryCdrEndpoint"));
    context.setVariable("isEnableHttps", isEnableHttps);
    
    var usageServiceTypeList = "" + context.getVariable("req.CdrUsageServiceTypeList");
    var usageServiceCatList = "" + context.getVariable("req.CdrUsageServiceCatList"); 
    
    usageServiceTypeList = isEmpty(usageServiceTypeList)?null:usageServiceTypeList.split(",");
    usageServiceCatList = isEmpty(usageServiceCatList)?null:usageServiceCatList.split(",");
        
    var messages = {
        tagList: [
            {
                tagParent : 'UsageSvcTypeList', tagChild : [
                    { name : 'UsageSvcTypeRec', value: usageServiceTypeList }
                ],
                isEmpty : checkIsEmptyArray(usageServiceTypeList)
            },
            {
                tagParent : 'UsageSvcCatList', tagChild: [
                    { name : 'UsageSvcCatList', value : usageServiceCatList }
                ],
                isEmpty: checkIsEmptyArray(usageServiceCatList)
            }
        ],
        tagSingle: [
            { name : 'SubrNumb', value : idValue },
            { name : 'StartDTTM', value : startDTTM },
            { name : 'EndDTTM', value : endDTTM },
            { name: 'FetchRowNumb', value: fetchRow },
            { name: 'TotalCDRNumb', value: totalCDR },
            { name: 'BeginRowNumb', value: beginRow },
            { name: 'Lang', value: lang },
            { name: 'CalledPartyNumb', value: calledCellparty },
            { name: 'UsageSvcType', value: usageServiceType },
            { name: 'UsageSvcCat', value: usageServiceCat },
            { name : 'UsageSvc_ESVOtherSvcCat', value : usageServiceOtherCat }
        ]
    };
    
    var soapMessage = setSoapRequest(messages);
    context.setVariable("req.soapMessage", soapMessage);
}

function validateEscCdr() {
context.setVariable("functionValidateCdr", "validateEscCdr");
  var now = new Date();
  var isoNow = convertToISO(now);
  var transactionId = "" + context.getVariable("req.escCdrTransactionId");
  var sourceSystemId = "" + context.getVariable("escSourceSystemId");
  var businessEvent = "" + context.getVariable("escQryCdrBusinessEvent");
  var isAsynchronous = "" + context.getVariable("escQryCdrIsAsyncRequest");
  var isEnableHttps = context.getVariable("escQryCdrIsEnableHttps");
  var idValue = "" + context.getVariable("req.id");
  var lang = "" + context.getVariable("req.CdrLang");
  var usageServiceTypeFlag = "" + context.getVariable("req.escCdrBucket.idFlag");
  var usageServiceCatFlag = "" + context.getVariable("req.escCdrBucket.usageTypeFlag");
  var startDate = "" + context.getVariable("req.escCdrStartDateTime");
  var endDate = "" + context.getVariable("req.escCdrEndDateTime");
  var customerNo = "" + context.getVariable("req.escCdrCustomerNo");
  var byCycle = "" + context.getVariable("req.escCdrByCycle");
  var relatedPartyId = "" + context.getVariable("req.escCdrRelatedParty.id");
  var customerType = "" + context.getVariable("req.escCdrCustomerType");
  var billSource = "" + context.getVariable("req.escCdrBillSource");
  var excludeFlag = ""+ context.getVariable("req.escCdrExcludeFlag");
  var telType = ""+ context.getVariable("escQryCDRTelType");
  var totalCDR = "" + context.getVariable("req.escCdrTotalCDR");
  var beginRow = "" + context.getVariable("req.escCdrBeginRow");
  var fetchRow = "" + context.getVariable("req.escCdrFetchRow");
  
      // validate reference token
    var href = convertSymbol(context.getVariable("req.href"));
    var checkTicket = "" + context.getVariable("cusAttr.checkTicket");
    var key = "" + context.getVariable("decryptKey");
    var decryptData = getDecryptedDataAuthen(href,key);
    var timeExpireToken = "" + context.getVariable("timeExpireToken");
    var developerName = context.getVariable("apigee.developer.app.name");
    var subNum = "";
    var devName = "";
    var createTime = "";
    var timeExpire = "";
    
     print("validateCdr:param(mandatory):"
        + ", transactionId = " + transactionId
        + ", id = " + idValue
        + ", startDate = " + startDate
        + ", endDate = " + endDate
        + ", billSource = " + billSource
        + ", totalCDR = " + totalCDR
        + ", beginRow = " + beginRow
        + ", fetchRow = " + fetchRow
          + ", now = " + isoNow
        );

    if(isEmpty(transactionId) || isEmpty(idValue) || isEmpty(startDate) || isEmpty(endDate) || 
        isEmpty(billSource) || isEmpty(totalCDR) || isEmpty(beginRow) || isEmpty(fetchRow)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    else{
        print("checkTicket : " + checkTicket);
    	if(!isEmpty(checkTicket) && checkTicket === "Y"){
    		if(!isEmpty(href)){
    			try{
    				 var result = decryptData.split(/\|/);
    				 print("result decrypt: " + result);
    					for(var index = 0; index < result.length; index++){
    						subNum = result[0];
    						devName = result[1];
    						createTime = result[2];
    					}
    				timeExpire = getMaxDateExpire(createTime,timeExpireToken);
    			}catch(err){
    				 context.setVariable("validateError", "InvalidRefToken");
    				 print("error : " + err);
    			}
                // validate token
                if((idValue != subNum) || (developerName != devName) 
                || !matchDateFormatYYYYMMDDHHmm(createTime) || (getDateAndTimeHourMinuteFormat(now) > timeExpire)){
                    context.setVariable("validateError", "InvalidRefToken");
                }
    		}else{
    		    context.setVariable("validateError", "InvalidRefToken");
    		}
    	}
    }
    
    if(!isEmpty(lang)){
        lang = lang.toUpperCase();
    }
    
    var usageServiceType = "" + context.getVariable("req.escCdrBucket.id");
    var usageServiceCat = "" + context.getVariable("req.escCdrBucket.usageType"); 
    
    var usageServiceTypeList = isEmpty(usageServiceType)?null:usageServiceType.split(",");
    var usageServiceCatList = isEmpty(usageServiceCat)?null:usageServiceCat.split(",");

    var messages = {
        tagList: [
            {
                tagParent : 'com:MessageHeader', tagChild: [
                    { name : 'com:MessageID', value : sourceSystemId+transactionId },
                    { name : 'com:BusinessEvent', value : businessEvent },
                    { name : 'com:SourceSystemID', value : sourceSystemId },
                    { name : 'com:SentDttm', value : isoNow },
                    { name : 'com:IsAsyncRequest', value : isAsynchronous },
                ],
                isEmpty: checkIsEmptyArray("MessageHeader")
            }
        ],
        tagSingle: [
            { name: 'com:SubscriberNo', value : idValue },
            { name: 'com:CompCode', value : customerType },
            { name: 'com:CustomerNo', value : customerNo },
            { name: 'com:TelpType', value : telType },
            { name: 'com:Lang', value : lang}
        ]
    };
    var usageSvcTypeFlag = {
         tagSingle: [
             { name: 'dat:UsageSvcType', value : usageServiceTypeFlag },
             ]
    }
    var usageSvcTypeList = {
          tagList: [   
              {
                tagParent : 'dat:ListUsageSvcType', tagChild : [
                    { name : 'dat:UsageSvcType', value: usageServiceTypeList }
                ],
                isEmpty : checkIsEmptyArray(usageServiceTypeList)
            }
              ]
     }
    var usageSvcCatFlag = {
         tagSingle: [
             { name: 'dat:UsageSvcCat', value : usageServiceCatFlag },
             ]
    }
     var usageSvcCatList = {
          tagList: [   
            {
                tagParent : 'dat:ListUsageSvcCat', tagChild: [
                    { name : 'dat:UsageSvcCat', value : usageServiceCatList }
                ],
                isEmpty: checkIsEmptyArray(usageServiceCatList)
            }
              ]
     }
    var messages2 = {
            tagSingle: [
                { name: 'dat:StartDate', value : startDate },
                { name: 'dat:EndDate', value : endDate },
                { name: 'dat:BillCyclId', value : byCycle },
                { name: 'dat:DestinationNo', value : relatedPartyId },
                { name: 'dat:BillSource', value : billSource },
                { name: 'dat:ExcludeFlag', value : excludeFlag },
                { name: 'dat:TotalCDRNumb', value: totalCDR },
                { name: 'dat:BeginRowNumb', value: beginRow },
                { name: 'dat:FetchRowNumb', value: fetchRow }
            ]
     }    
    //escQryCdrEndpoint
    context.setVariable("endpointUrl", context.getVariable("escQryCdrEndpoint"));
    context.setVariable("req.idValue",idValue);
    var soapUsageSvcTypeList=setSoapRequestWithTagList(usageSvcTypeList)
    var soapUsageSvcCatList=setSoapRequestWithTagList(usageSvcCatList)
    var soapMessage = setSoapRequestEscCdr(messages)+setSoapRequest(usageSvcTypeFlag)+setSoapRequestWithTagList(usageSvcTypeList)+setSoapRequest(usageSvcCatFlag)+setSoapRequestWithTagList(usageSvcCatList)+setSoapRequest(messages2);
    context.setVariable("req.soapMessage", soapMessage);
    context.setVariable("isEnableHttps", isEnableHttps);
}

function validateCheckBlackList() {
    var transactionId = "" + context.getVariable("req.cblTransactionId");
    var channelName = "" + context.getVariable("req.cblChannelName");
    var idType = "" + context.getVariable("req.cblIdType");
    var funcId = "" + context.getVariable("req.cblFuncId");
    var isEnableHttps = context.getVariable("checkBlackListIsEnableHttps");
    
    print("validateCheckBlackList:param(mandatory):"
        + ", transactionId = " + transactionId
        + ", channelName = " + channelName 
        + ", idType = " + idType
        + ", funcId = " + funcId);
    
    if(isEmpty(transactionId) || isEmpty(channelName) || isEmpty(idType) || isEmpty(funcId)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }

    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("endpointUrl", context.getVariable("checkBlackListEndpoint"));
}

function validateCheckLockedId() {
    var transactionId = "" + context.getVariable("req.cliTransactionId");
    var channelName = "" + context.getVariable("req.cliChannelName");
    var idType = "" + context.getVariable("req.cliIdType");
    var funcId = "" + context.getVariable("req.cliFuncId");
    var checkLockedIdType = "" + context.getVariable("checkLockedIdType");
    var isEnableHttps = context.getVariable("checkLockedIdIsEnableHttps");
    
    print("validateCheckLockedId:param(mandatory):"
        + ", transactionId = " + transactionId
        + ", channelName = " + channelName 
        + ", idType = " + idType
        + ", funcId = " + funcId);
    
    if(isEmpty(transactionId) || isEmpty(channelName) || isEmpty(idType) || isEmpty(funcId)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("req.idType", getCheckLockIdType(idType.toUpperCase(), checkLockedIdType.toUpperCase()));
    context.setVariable("endpointUrl", context.getVariable("checkLockedIdEndpoint"));
}

function validateProfile() {
    var transactionId = "" + context.getVariable("req.prfTransactionId");
    var idType = "" + context.getVariable("req.prfIdType");
    var idValue = "" + context.getVariable("req.prfIdValue");
    var channelName = "" + context.getVariable("req.prfChannelName");
    var isEnableHttps = context.getVariable("profileIsEnableHttps");

    print("validateProfile:param(mandatory):"
        + ", transactionId = " + transactionId
        + ", idType = " + idType
        + ", idValue = " + idValue
        + ", channelName = " + channelName);
    
    if(isEmpty(transactionId) || isEmpty(channelName) || isEmpty(idType) || isEmpty(idValue)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    
    if(isEmpty("" + context.getVariable("cusAttr.authenUsername")) || isEmpty("" + context.getVariable("cusAttr.authenPassword")) || isEmpty("" + context.getVariable("cusAttr.showDataPrivacyFlag"))) {
        context.setVariable("validateError", "MissingCustomAttributes");
    }

    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("endpointUrl", context.getVariable("profileEndpoint"));
    context.setVariable("req.prfIdValue",convertMobileNotoPrefix66(idValue));
}

function validateScore() {
    var transactionId = "" + context.getVariable("req.scrTransactionId");
    var idType = "" + context.getVariable("req.scrIdType");
    var idValue = "" + context.getVariable("req.scrIdValue");
    var isEnableHttps = context.getVariable("scoreIsEnableHttps");

    print("validateScore:param(mandatory):"
        + ", transactionId = " + transactionId
        + ", idType = " + idType
        + ", idValue = " + idValue);
    
    if(isEmpty(transactionId) || isEmpty(idType) || isEmpty(idValue)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("req.sentDttm", getTimePatternForService1());
    context.setVariable("req.scrIdValue",convertMobileNotoPrefix66(idValue));
}

function validateDevice() {
    var transactionId = "" + context.getVariable("req.devTransactionId");
    var idType = "" + context.getVariable("req.devIdType");
    var idValue = "" + context.getVariable("req.devIdValue");
    var channelName = "" + context.getVariable("req.devChannelName");
    var isEnableHttps = context.getVariable("deviceIsEnableHttps");

    print("validateDevice:param(mandatory):"
        + ", transactionId = " + transactionId
        + ", idType = " + idType
        + ", idValue = " + idValue
        + ", channelName = " + channelName);
    
    if(isEmpty(transactionId) || isEmpty(idType) || isEmpty(idValue) || isEmpty(channelName)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    
    if(isEmpty("" + context.getVariable("cusAttr.authenUsername")) || isEmpty("" + context.getVariable("cusAttr.authenPassword"))) {
        context.setVariable("validateError", "MissingCustomAttributes");
    }
    
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("endpointUrl", context.getVariable("deviceEndpoint"));
    context.setVariable("req.devDeviceAttr", setDeviceAttribute());
    context.setVariable("req.devIdValue",convertMobileNotoPrefix66(idValue));
}

function validateSubscribe() {
    var idValue = "" + context.getVariable("req.subIdValue");
    var txTransactionId = "" + context.getVariable("req.subTxTransactionId");
    var subscriptionServiceId = "" + context.getVariable("req.subSubscriptionServiceId");
    var subscriptionCode = "" + context.getVariable("req.subSubscriptionCode");
    var subscriptionDescription = "" + context.getVariable("req.subSubscriptionDescription");
    var subscriptionServiceKey = "" + context.getVariable("req.subSubscriptionServiceKey");
    var productId = "" + context.getVariable("req.subProductId");
    var productType = "" + context.getVariable("req.subProductType");
    var productTitle = "" + context.getVariable("req.subProductTitle");
    var isEnableHttps = context.getVariable("subscribeIsEnableHttps");

    print("validateSubscribe:param(mandatory):"
        + ", idValue = " + idValue
        + ", txTransactionId = " + txTransactionId
        + ", subscriptionServiceId = " + subscriptionServiceId
        + ", subscriptionCode = " + subscriptionCode
        + ", subscriptionDescription = " + subscriptionDescription
        + ", subscriptionServiceKey = " + subscriptionServiceKey
        + ", productId = " + productId
        + ", productType = " + productType
        + ", productTitle = " + productTitle);

    if(isEmpty(idValue) || isEmpty(txTransactionId) || isEmpty(subscriptionServiceId) || 
       isEmpty(subscriptionCode) || isEmpty(subscriptionDescription) || isEmpty(subscriptionServiceKey) || 
       isEmpty(productId) || isEmpty(productType) || isEmpty(productTitle)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    
    if(isEmpty("" + context.getVariable("cusAttr.dpdpSdpAuthorizationKey"))) {
        context.setVariable("validateError", "MissingCustomAttributes");
    }
    
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("endpointUrl", context.getVariable("subscribeEndpoint"));
    context.setVariable("req.idValue",convertMobileNotoPrefix66(idValue));
}

function getCheckLockIdType(idType, checkLockedIdType){
    if(!isEmpty(checkLockedIdType)) {
        var arrayIdType = checkLockedIdType.split(",");
        for(index = 0; index < arrayIdType.length; index++) {
            if(arrayIdType[index].indexOf(idType) >= 0) {
                var position = arrayIdType[index].indexOf("=") + 1;
                return arrayIdType[index].substring(position);
            }
        }
        return "01";
    } else {
        return "01";
    }
}

function setDeviceAttribute() {
    var data = "" + context.getVariable("req.devDeviceAttr");
    var arrayData = data.split(",");
    var message = "";
    
    if(!isEmpty(data)) {
        for(index = 0; index < arrayData.length; index++) {
            message = message + "<dev:DeviceAttribute>" + arrayData[index] + "</dev:DeviceAttribute>";
        }
    } else {
        message = "<dev:DeviceAttribute>imei</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>imsi</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>msisdn</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>tac</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_capability</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_manufacturer</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_is_smartphone</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_model</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_id</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_year</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_edge</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_os_name</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_os</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_os_version</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_lte</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_umts</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_frequency</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_processor</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_width</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_height</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_length</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_weight</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_touch_screen</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_has_camera</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_camera_type</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_camera_resolution</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_battery_type</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>battery_capacity</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_has_bluetooth</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_has_infrared</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_has_usb</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_has_gprs</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_has_wireless_lan</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_has_sms</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_has_mms</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_has_email</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_has_gps</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_has_games</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_dual_sim</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_ram_capacity</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_accelerometer</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_hard_disk</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_loudspeaker</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_graphical_controller</dev:DeviceAttribute>" +
                   "<dev:DeviceAttribute>device_kernel_version</dev:DeviceAttribute>";
    }
    
    return message;
}

function validateQueryUsageSummary(){
    var now = new Date();
    var randomNumber = Math.floor(100000 + Math.random() * 900000);
    var idValue = context.getVariable("req.id");
    var transactionId = "" + context.getVariable("req.transactionId");
    var idType = "" + context.getVariable("req.idType");
    var channelName = "" + context.getVariable("req.channelName");
    var paymentMethod = "" + context.getVariable("req.paymentMethod");
    var usgeStart = "" + context.getVariable("req.usgeStart");
    var isEnableHttps = context.getVariable("usgSumIsEnableHttps");
    var usgTypeId = "" + context.getVariable("req.typeIDList");
    var endpoint = "" +  context.getVariable("queryUsgSumEndpoint");
    var lang = "" + context.getVariable("req.lang");
    var langRTB = "" + context.getVariable("req.langRTB");
    var sourceSystem = "" + context.getVariable("queryUsgSourceSystemID");
    var journeyId = sourceSystem + now + randomNumber;
    
    // validate reference token
    var href = convertSymbol(context.getVariable("req.href"));
    var checkTicket = "" + context.getVariable("cusAttr.checkTicket");
    var key = "" + context.getVariable("decryptKey");
    var decryptData = getDecryptedDataAuthen(href,key);
    var timeExpireToken = "" + context.getVariable("timeExpireToken");
    var developerName = context.getVariable("apigee.developer.app.name");
    var subNum = "";
    var devName = "";
    var createTime = "";
    var timeExpire = "";

    print("validateQueryUsageSummary:param(mandatory):"
        + ", idValue = " + idValue
        + ", transactionId = " + transactionId
        + ", idType = " + idType
        + ", channelName = " + channelName
        + ", paymentMethod = " + paymentMethod
        + ", usgeStart = " + usgeStart);
    
    if(paymentMethod == '2'){
        if(isEmpty(idValue) || isEmpty(transactionId) || isEmpty(idType) || isEmpty(channelName) || isEmpty(paymentMethod)) {
            context.setVariable("validateError", "BusinessValidationFailed");
        }
    }else{
        if(isEmpty(idValue) || isEmpty(transactionId) || isEmpty(idType) || isEmpty(channelName) || isEmpty(paymentMethod) || isEmpty(usgeStart)) {
            context.setVariable("validateError", "BusinessValidationFailed");
        }else{
        print("checkTicket : " + checkTicket);
    	if(!isEmpty(checkTicket) && checkTicket === "Y"){
    		if(!isEmpty(href)){
    			try{
    				 var result = decryptData.split(/\|/);
    				 print("result decrypt: " + result);
    					for(var index = 0; index < result.length; index++){
    						subNum = result[0];
    						devName = result[1];
    						createTime = result[2];
    					}
    				timeExpire = getMaxDateExpire(createTime,timeExpireToken);
    			}catch(err){
    				 context.setVariable("validateError", "InvalidRefToken");
    			}
                // validate token
                if((idValue != subNum) || (developerName != devName) 
                || !matchDateFormatYYYYMMDDHHmm(createTime) || (getDateAndTimeHourMinuteFormat(now) > timeExpire)){
                    context.setVariable("validateError", "InvalidRefToken");
                }
    		}else{
    		    context.setVariable("validateError", "InvalidRefToken");
    		}
    	}
    }
    }
    
    
    if(usgeStart === '00000000'){
        context.setVariable("usageStartVal", usgeStart);
    } else{
        context.setVariable("usageStartVal", usgeStart);
    }
    
    print("Usage Start : " + context.getVariable("usageStartVal"));
    
    var endpoint = usgeStart === '00000000'?""+(context.getVariable("queryUsgSumReadRBTEndpoint")):""+(context.getVariable("queryUsgSumEndpoint"));
    context.setVariable("endpointUrl",endpoint);
    
    if(paymentMethod != '0'){
        context.setVariable("req.paymentMethod","1");
    }
    
    if(paymentMethod=='1'&&usgeStart != '00000000'){
        context.setVariable("endpointUrl",context.getVariable("escQryUsageSummEndpoint"));
        isEnableHttps = context.getVariable("qryUsageSummPostIsEnableHttps");
        sourceSystem = "" + context.getVariable("escSourceSystemId");
//        context.setVariable("req.messageId", sourceSystem + getYYYYMMddHHmmssSSSWithoutSymbolUseDate(now));
//        context.setVariable("req.sentDttm", getDatetime());
        context.setVariable("req.soapMessage", mapQrySummUsagePostData(now, idValue, transactionId, paymentMethod, checkUsageStart(usgeStart)));

    }else if(paymentMethod=='2'){
        context.setVariable("req.previousPaymentMethod","2");
        context.setVariable("req.paymentMethod","0");
        context.setVariable("endpointUrl",context.getVariable("queryUsgSumEndpoint"));
        isEnableHttps = context.getVariable("usgSumIsEnableHttps");
        sourceSystem = "" + context.getVariable("queryUsgSourceSystemID");

        paymentMethod='1';
        context.setVariable("req.authorization", context.getVariable("qrySumnAuthorization"));
		context.setVariable("req.soapMessage", mapQrySummUsageData(now, idValue, transactionId, paymentMethod, checkUsageStart(usgeStart)));

    }else{
        //for readRTB
        if((!isEmpty(langRTB) && langRTB === '1')){
            context.setVariable("req.langRTB","TH");
        }else if((!isEmpty(langRTB) && langRTB === '2')){
            context.setVariable("req.langRTB","EN");
        }else if(isEmpty(context.getVariable("req.langRTB"))){
            context.setVariable("req.langRTB","TH");
        }
        
        context.setVariable("req.authorization", context.getVariable("qrySumnAuthorization"));
        context.setVariable("req.soapMessage", mapQrySummUsageData(now, idValue, transactionId, paymentMethod, checkUsageStart(usgeStart)));
    }
    
    context.setVariable("req.idValue", convertMobileNotoPrefix66(idValue));
    context.setVariable("req.journeyID", journeyId);
    context.setVariable("req.transactionId", transactionId);
    context.setVariable("req.sourceSystem", sourceSystem);
    context.setVariable("isEnableHttps", isEnableHttps);
}

function validatePreToPost(){
    var now = new Date().getTime();
    var randomNumber = Math.floor(100000 + Math.random() * 900000);
    var idValue = context.getVariable("req.id");
    var channelName = "" + context.getVariable("req.channelName");
    var transactionId = "" + context.getVariable("req.transactionId");
    var idType = "" + context.getVariable("req.idType");
    var citizenId = "" + context.getVariable("req.citizenID");
    var lang = "" + context.getVariable("req.lang");
    var isEnableHttps = context.getVariable("valPreToPostIsEnableHttps");
    var sourceSystem = "" + context.getVariable("valPreToPostSourceSystem");
    var journeyId = sourceSystem + now + randomNumber;
    
    
    print("validatePreToPost:param(mandatory):"
        + ", idValue = " + idValue
        + ", channelName = " + channelName
        + ", transactionId = " + transactionId
        + ", idType = " + idType
        + ", citizenID = " + citizenId);
        
    if(isEmpty(idValue) || isEmpty(channelName) || isEmpty(transactionId) || isEmpty(idType) || isEmpty(citizenId)){
         context.setVariable("validateError", "BusinessValidationFailed");
    }
    
    // prepare to southbound
    context.setVariable("endpointUrl", context.getVariable("valPreToPostEndpoint"));
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("req.journeyID", journeyId);
    context.setVariable("req.transactionId", transactionId);
    context.setVariable("req.sourceSystem", sourceSystem);
    context.setVariable("req.authorization", context.getVariable("valPreToPostAuthorization"));
    context.setVariable("req.idValue", convertMobileNotoPrefix66(idValue));
    context.setVariable("req.idNumb", citizenId);
     if((!isEmpty(context.getVariable("req.lang")) && context.getVariable("req.lang") === '1')){
         context.setVariable("request.queryparam.lang","TH");
     }else if((!isEmpty(context.getVariable("req.lang")) && context.getVariable("req.lang") === '2')){
         context.setVariable("request.queryparam.lang","EN");
     }else if(isEmpty(context.getVariable("req.lang"))){
         context.setVariable("request.queryparam.lang","TH");
     }
}


function validateSavePreToPost(){
    var now = new Date().getTime();
    var randomNumber = Math.floor(100000 + Math.random() * 900000);
    var idType = "" + context.getVariable("req.savePreIdType");
    var idValue = "" + context.getVariable("req.savePreIdValue");
    var channelName = "" + context.getVariable("req.savePreChannel");
    var transactionId = "" + context.getVariable("req.savePreTransId");
    var lang = "" + context.getVariable("req.savePreLang");
    var mainPack = "" + context.getVariable("req.savePreMainPack");
    var requestDttm = "" + context.getVariable("req.savePreReqDttm");
    var isEnableHttps = context.getVariable("savePreToPostIsEnableHttps");
    var sourceSystem = "" + context.getVariable("savePreToPostSourceSystem");
    var journeyId = sourceSystem + now + randomNumber;
    
    context.setVariable("req.transactionId",transactionId);
    
    print("validatePreToPost:param(mandatory):"
        + ", idType = " + idType
        + ", idValue = " + idValue
        + ", channelName = " + channelName
        + ", transactionId = " + transactionId
        + ", requestDttm = " + requestDttm
        + ", mainPack = " + mainPack);
        
    if(isEmpty(idType) || isEmpty(idValue) || isEmpty(channelName) || 
    isEmpty(transactionId) || isEmpty(requestDttm) || isEmpty(mainPack)){
         context.setVariable("validateError", "BusinessValidationFailed");
    }
    
    // prepare to southbound
    context.setVariable("endpointUrl", context.getVariable("savePreToPostEndpoint"));
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("req.sourceSystem", sourceSystem);
    context.setVariable("req.journeyID", journeyId);
    context.setVariable("req.authorization", context.getVariable("savePreToPostAuthorization"));
    context.setVariable("req.idValue", convertMobileNotoPrefix66(idValue));
    context.setVariable("req.packGroupCode", mainPack);
    if((!isEmpty(context.getVariable("req.savePreLang")) && context.getVariable("req.savePreLang") === '1')){
         context.setVariable("req.savePreLang","TH");
     }else if((!isEmpty(context.getVariable("req.savePreLang")) && context.getVariable("req.savePreLang") === '2')){
         context.setVariable("req.savePreLang","EN");
     }else if(isEmpty(context.getVariable("req.savePreLang"))){
         context.setVariable("req.savePreLang","TH");
     }

}

function mapQrySummUsageData(now, idValue, transactionId, paymentMethod, usgeStart) {
    var svcGroupIdList = isEmpty(context.getVariable("req.svcGroupIdList")) ? null : context.getVariable("req.svcGroupIdList").split(",");
    var typeIDList = isEmpty(context.getVariable("req.typeIDList")) ? null : context.getVariable("req.typeIDList").split(",");
    var businessEvent = context.getVariable("queryUsgBusinessEvent");
    var sentDttm = context.getVariable("req.requestDttm");
    var isAsyncRequest = context.getVariable("queryUsgIsAsyncRequest");
    var bill3rdPartyId = context.getVariable("queryUsgBILCBS3rdPartyId");
    var lang = "" + context.getVariable("req.lang");
    var requestDttm = getYYYYMMddHHmmssSSSWithSymbolDotUseDate(now);
    var sourceSystemID = context.getVariable("sourceSystemID");
    var referenceKey = getReferenceKey(now);
    var idValue = convertMobileNotoPrefix66(idValue);
    var soapData = "";
        
    soapData =  setSoapData(setSoapData(transactionId, "com:MessageID") + 
                    setSoapData(referenceKey, "com:ReferenceKey") + 
                    setSoapData(businessEvent, "com:BusinessEvent") + 
                    setSoapData(sourceSystemID, "com:SourceSystemID") + 
                    setSoapData(requestDttm, "com:SentDttm") + 
                    setSoapData("N", "com:IsAsyncRequest"), "com:MessageHeader") + 
                setSoapData(setSoapData(sourceSystemID, "bil:BILCBS3rdPartyId"), "bil:CBSHeaderRec") + 
                setSoapData(idValue, "ass:ASAssetNumb") + 
                setSoapData(paymentMethod, "bil:BILPreFlag");
    if(svcGroupIdList != null) {
        soapData = soapData + "<svc:SvcGroupIDList>";
        for(index = 0; index < svcGroupIdList.length; index++) {
            soapData = soapData + setSoapData(svcGroupIdList[index], "bil:BILSvcGroupID");
        }
        soapData = soapData + "</svc:SvcGroupIDList>";
    }
    if(typeIDList != null) {
        soapData = soapData + "<svc:UsageSvcTypeList>";
        for(index = 0; index < typeIDList.length; index++) {
            soapData = soapData + setSoapData(typeIDList[index], "bil:BILUsageSvcType");
        }
        soapData = soapData + "</svc:UsageSvcTypeList>";
    }
    soapData = soapData + setSoapData(usgeStart, "bil:BILUsageMonth")
                        + setSoapData(lang, "bil:BILLangFlag");
    return soapData;
}

function mapQrySummUsagePostData(now, idValue, transactionId, paymentMethod, usgeStart) {
    var soapData = "";
    var svcGroupIdList = isEmpty(context.getVariable("req.svcGroupIdList")) ? null : context.getVariable("req.svcGroupIdList").split(",");

//    var messageId = context.getVariable("req.messageId");
    var sourceSystemID = context.getVariable("escSourceSystemId");
    var requestDttm = getYYYYMMddHHmmssSSSWithSymbolDotUseDate(now);
    var idValue = convertMobileNotoPrefix66(idValue);
    var lang = "" + context.getVariable("req.lang");
    var customerNo = context.getVariable("req.customerNo");
    var customerType = context.getVariable("req.customerType");
    var lang = context.getVariable("req.lang");
    var byCycle = context.getVariable("req.byCycle");
    var srvcGroupFlag = context.getVariable("req.srvcGroupFlag");

    
    soapData =  setSoapData(
                    setSoapData(transactionId, "com:MessageID") + 
                    setSoapData("QryUsage", "com:BusinessEvent") + 
                    setSoapData(sourceSystemID, "com:SourceSystemID") + 
                    setSoapData(requestDttm, "com:SentDttm") + 
                    setSoapData("N", "com:IsAsyncRequest"), "com:MessageHeader") + 
                    
                setSoapData(idValue, "com:SubscriberNo");

    if(customerType != null) {
        soapData = soapData + setSoapData(customerType,"com:CompCode");
    }
    
    if(customerNo != null) {
        soapData = soapData + setSoapData(customerNo,"com:CustomerNo");
    }
    
    if(lang != null) {
        if(lang=='1'){
            lang ="T";
        }else{
            lang ="E";
        }
        soapData = soapData + setSoapData(lang,"com:Lang");
    }
    
    soapData = soapData + setSoapData("T", "com:TelpType");
    soapData = soapData + setSoapData(usgeStart, "dat:UsageMonth");
    
    if(srvcGroupFlag != null) {
        soapData = soapData + setSoapData(srvcGroupFlag,"dat:SvcGroupFlag");
    }
    
    if(byCycle != null) {
        soapData = soapData + setSoapData(byCycle,"dat:BillCyclId");
    }
    
    if(svcGroupIdList != null) {
        soapData = soapData + "<dat:ListSvcGroupID>";
        for(index = 0; index < svcGroupIdList.length; index++) {
            soapData = soapData + setSoapData(svcGroupIdList[index], "dat:SvcGroupID");
        }
        soapData = soapData + "</dat:ListSvcGroupID>";
    }
    
    return soapData;
}

function checkUsageStart(usageStart) {
    if(usageStart.length == 8) {
        if(usageStart.substring(6) == "00") {
            usageStart = usageStart.substring(0, 6);
        }
    }
    
    return usageStart;
}

function setSoapData(data, soapTag) {
    if(isEmpty(data)) {
        return "";
    } else {
        return "<" + soapTag + ">" + data + "</" + soapTag + ">";
    }
}

function convertCompCode(compCode){
    switch(compCode.toUpperCase()){
        case "DTAC":
            compCode = "10";
            break;
        case "DTN" :
            compCode = "20";
            break;
    }
    return compCode;
}

function setOfferRangeList(data) {
    var arrayData = data.split(",");
    var message = "";
    
    for(indexOut = 0; indexOut < arrayData.length; indexOut++) {
        var firstLast = arrayData[indexOut].split("-");
        if(firstLast.length == 2) {
            message = message + "<OfferRangeRec>" +
                                    "<OfferIDStart>" + firstLast[0] + "</OfferIDStart>" +
                                    "<OfferIDEnd>" + firstLast[1] + "</OfferIDEnd>" +
                                "</OfferRangeRec>";
        }
    }
    
    return message;
}

function setSoapRequest(messages) {
    var soapData = '';
    if (Array.isArray(messages.tagSingle)) {
        messages.tagSingle.forEach(function (e) {
            if(!isEmpty(e.value)) {
                soapData += '<' + e.name + '>'+e.value +'</'+e.name+'>';
            }
        });
        if (!isEmpty(messages.tagList)) {
            messages.tagList.forEach(function (e) {
                if (e.isEmpty) {
                    soapData += '<' + e.tagParent + '>';
                }
                e.tagChild.forEach(function (el) {
                    if (Array.isArray(el.value)) {
                        el.value.forEach(function (els) {
                            soapData += '<' + el.name + '>' + els + '</' + el.name + '>';
                        });
                    } else if(!isEmpty(el.value)) {
                        soapData += '<' + el.name + '>'+el.value +'</'+el.name+'>';
                    }
                });
                if (e.isEmpty) {
                    soapData += '</' + e.tagParent + '>';
                }
            });
        }
    }
    return soapData;
}

function checkIsEmptyArray(array) {
    var status = false;
    if (Array.isArray(array)) {
        array.forEach(function (e,i) {
            if (!isEmpty(e)) {
                status = true;
                return false;
            }
        });
    }
    return status;
}

function setSrvcGroupIdList(data) {
    var arrayData = data.split(",");
    var message = "";
   
   if(!isEmpty(data)){
       for(indexOut = 0; indexOut < arrayData.length; indexOut++) {
              message = message + "<bil:BILSvcGroupID>" + arrayData[indexOut] +  "</bil:BILSvcGroupID>";
        }
   }
        
    
    return message;
}

function setTypeIDList(data) {
    var arrayData = data.split(",");
    var message = "";
    
    if(!isEmpty(data)){
        for(indexOut = 0; indexOut < arrayData.length; indexOut++) {
            message = message + "<bil:BILUsageSvcType>" + arrayData[indexOut] +  "</bil:BILUsageSvcType>";
        }
    }     
    return message;
}

function setSoapRequestQrySumn(messages) {
    var soapData = '';
	if(!isEmpty(messages.tagHeader)){
		messages.tagHeader.forEach(function (e) {
			if(!e.isEmpty){
				soapData += '<' + e.tagMsgHead + '>';
			    e.tagMsgHeadDetail.forEach(function (el) {
				    if(!isEmpty(el.value)) {
                        soapData += '<' + el.name + '>'+el.value +'</'+el.name+'>';
		            } else {
                        soapData += '';
				    }
				});
                soapData += '</' + e.tagMsgHead + '>';
		    }
		});
	}
	if(!isEmpty(messages.tagBody)) {
		messages.tagBody.forEach(function (e) {
			if(!e.isEmpty){
				soapData += '<' + e.tagMsgBody + '>';
			    e.tagMsgBodyDetail.forEach(function (el) {
				    if(!isEmpty(el.value)) {
                        soapData += '<' + el.name + '>'+el.value +'</'+el.name+'>';
		            } else {
				        soapData += '';
					}
				});
				soapData += '</' + e.tagMsgBody + '>';
			}
		});
	}
	if (Array.isArray(messages.tagSingle)) {
        messages.tagSingle.forEach(function (e) {
            if(!isEmpty(e.value)) {
                soapData += '<' + e.name + '>'+e.value +'</'+e.name+'>';
            }else{
                soapData += '';
            }
        });
	}
	messages.tagQryList.forEach(function (e) {
	    e.tagQryChild.forEach(function (el) {
	        if(!isEmpty(el.value) || (el.value !== null)) {
                soapData += '<' + e.tagQryParent + '>' ;
                if (Array.isArray(el.value)) {
                    el.value.forEach(function (els) {
                        if(!isEmpty(els.value) || (els.value !== null)){
                            soapData +=  '<' + el.name + '>' + els + '</' + el.name + '>';
                        }
                    });
				} else {
				    soapData +=  '<' + el.name + '>' + els + '</' + el.name + '>';
    		    }
				soapData += '</' + e.tagQryParent + '>' 
	         } else {
	             delete e.tagQryParent;
	         }
	    });
	});
    return soapData;
}

function setSoapRequestEscCdr(messages) {
    var soapData = '';
    if (Array.isArray(messages.tagSingle)) {
                if (!isEmpty(messages.tagList)) {
            messages.tagList.forEach(function (e) {
                if (!e.isEmpty) {
                    soapData += '<' + e.tagParent + '>';
                }
                e.tagChild.forEach(function (el) {
                    if (Array.isArray(el.value)) {
                        el.value.forEach(function (els) {
                            soapData += '<' + el.name + '>' + els + '</' + el.name + '>';
                        });
                    } else if(!isEmpty(el.value)) {
                        soapData += '<' + el.name + '>'+el.value +'</'+el.name+'>';
                    }
                });
                if (!e.isEmpty) {
                    soapData += '</' + e.tagParent + '>';
                }
            });
        }
        messages.tagSingle.forEach(function (e) {
            if(!isEmpty(e.value)) {
                soapData += '<' + e.name + '>'+e.value +'</'+e.name+'>';
            }
        });

    }
    return soapData;
}
function setSoapRequestWithTagList(messages) {
    var soapData = '';
        if (!isEmpty(messages.tagList)) {
            messages.tagList.forEach(function (e) {
                if (e.isEmpty) {
                    soapData += '<' + e.tagParent + '>';
                }
                e.tagChild.forEach(function (el) {
                    if (Array.isArray(el.value)) {
                        el.value.forEach(function (els) {
                            soapData += '<' + el.name + '>' + els + '</' + el.name + '>';
                        });
                    } else if(!isEmpty(el.value)) {
                        soapData += '<' + el.name + '>'+el.value +'</'+el.name+'>';
                    }
                });
                if (e.isEmpty) {
                    soapData += '</' + e.tagParent + '>';
                }
            });
        }
    return soapData;
}
var statusCode = "" + context.getVariable("resp.blockList.statusCode");
var requestContent = context.getVariable("getSubrBlockListRequest.content");
var responseContent = context.getVariable("getSubrBlockListResponse.content");
var custGroupCode = context.getVariable("resp.custGroupCode");
// error case
var errorCode = "" + context.getVariable("resp.blockList.errorCode");
var errorMessage = "" + context.getVariable("resp.blockList.errorDesc");

// get response
var customBlockList = "" +context.getVariable("cusAttr.customBlockList");
var blockListService = "" +context.getVariable("blockListService");
var blockListServiceGrp = "" +context.getVariable("blockListServiceGrp");
var blockListAll = "" + context.getVariable("blockListAll");
var blockInfo = "" + context.getVariable("resp.blockList.blockListInfo");
var blockAll = "" + context.getVariable("resp.blockList.blockAll");
var service = "" + context.getVariable("resp.blockList.service");
var serviceGroup = "" + context.getVariable("resp.blockList.serviceGroup");
var serviceList = [];

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getTargetSC());
context.setVariable("southbound.request", setNorthSouthJsonRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthJsonRequestResponse(responseContent));
context.setVariable("request.verb", "GET");

printProxyRequest(requestContent);
printTargetResponse(responseContent);


if(!isEmpty(statusCode) && (statusCode == "200")){
    
        var serviceObj = JSON.stringify(service);
        var serviceGroupObj = JSON.stringify(serviceGroup);
        
        // set blockAll, service,serviceGroup
        serviceList = ((serviceObj.indexOf(null) == 1) ? [] : checkLengthArray(JSON.parse(service)));
        serviceGroup = ((serviceGroupObj.indexOf(null) == 1) ? [] : checkLengthArray(JSON.parse(serviceGroup)));
        
        var blockAllFlag = "";
        if(!isEmpty(blockListAll) && !isEmpty(serviceGroup)){
            if(isCheckBlockAllService(blockListAll,serviceGroup)){
                blockAllFlag = "Y";
            }
        }
        
        
        

        if(isEmpty(customBlockList) || (customBlockList.toUpperCase() == "N")){
            if(!isEmpty(blockAllFlag) && blockAllFlag == "Y"){
                 context.setVariable("blockAllName","ALL");
            }
           context.setVariable("resp.responseMessage", setResponseMessage());
          
        }else{
            context.setVariable("resp.responseMessage", setResponseMessage());
        }
}else{
    errorGetBlockListResultMapping(errorCode, errorMessage);
}

function setResponseMessage() {
    var now = new Date();
    var serviceValue = "",serviceGrpValue = "", displayFlag = "";
    var subrNumbStatus = checkSubrStatus(context.getVariable("resp.subrStatus"));
    var subTypeCust = ((!isEmpty(custGroupCode) && (custGroupCode > "0")) ? "Corporate" : checkSubType(context.getVariable("resp.subrType")));
    print("subTypeCust : " + subTypeCust);

    var response = {
        "tx" : {
            "transactionId" : context.getVariable("req.transactionId"),
            "timeStamp" : context.getVariable("resp.responseDttm")
        },
        "profile" : {
            "subCompany" : checkCompanyCode(context.getVariable("resp.companyCode")),
            "paidType" : checkTelephoneType(context.getVariable("resp.telephoneType")),
            "status" : subrNumbStatus,
            "subType" : subTypeCust
        },
        "registeredID" : {
            "type" : context.getVariable("resp.idType"),
            "value" : context.getVariable("resp.idNumb")
        },
        "lang" : {
            "sms" : checkLanguage("" + context.getVariable("resp.smsLang")),
            "callcenter" : checkCallCenterLang("" + context.getVariable("resp.callCenterLang")),
            "ivr" : checkLanguage("" + context.getVariable("resp.ivrLang"))
        },
        "birthDate" : context.getVariable("resp.birthDate"),
        "gender" : checkSex(context.getVariable("resp.gender")),
        "aou" : setAouAndFirstAou(now, context.getVariable("resp.switchOnDttm")),
        "firstAou" : setAouAndFirstAou(now, context.getVariable("resp.firstSwitchOnDttm")),
        "blockListInfo" : []
    };
            var typeObj = {
                "type"  : []
            };
            // add blockAll if blockAll is true
            if(!isEmpty(context.getVariable("blockAllName"))){
                 var blockNameObj = {
                    "name"  :   context.getVariable("blockAllName")
                };
                typeObj.type.push(blockNameObj);
            }
            
            // add service if it is not null
            if(!isEmpty(serviceList)){
                    var serviceObj = {
                        "name"      :       "services",
                        "list"      :       []
                    };
                
                    for(index = 0; index < serviceList.length ; index++){
                        var listObj = {
                            "name"      :   serviceList[index].serviceName,
                            "remark"    :   serviceList[index].serviceIdentifier
                        };
                        serviceObj.list.push(listObj);
                        serviceValue = serviceList[index].serviceIdentifier;
                        if(!isEmpty(blockListService)){
                             if(ischeckServiceBlockList(blockListService,serviceValue,"")){
                                    displayFlag = "N"; // set disPlayFlag if checkServiceBlockList is true
                             }
                        }
                    }
                typeObj.type.push(serviceObj);
            }
            
             // add serviceGroup if it is not null
            if(!isEmpty(serviceGroup)){
                var serviceGroupObj = {
                        "name"      :       "serviceGroup",
                        "list"      :       []
                    };
                
                    for(index = 0; index < serviceGroup.length ; index++){
                        var listServiceGrpObj = {
                            "name"      :   serviceGroup[index]
                        };
                        serviceGroupObj.list.push(listServiceGrpObj);
                        serviceGrpValue = serviceGroup[index];
                        if(!isEmpty(blockListServiceGrp)){
                             if(ischeckServiceBlockList(blockListServiceGrp,"",serviceGrpValue)){
                                    displayFlag = "N"; // set disPlayFlag if checkServiceBlockList is true
                             }
                        }
                    }
                typeObj.type.push(serviceGroupObj);
            }
            
    if(isEmpty(blockInfo)){
         delete response.blockListInfo;
    }else{
        if(((customBlockList.toUpperCase() == "N") || isEmpty(customBlockList)) 
                &&(isEmpty(serviceList)) && (isEmpty(serviceGroup))){
                delete response.blockListInfo;
        }else{
               if(customBlockList.toUpperCase() == "Y"){
                    if(blockAll == "true"){
                        response.profile.status = "Suspend";
                        delete response.blockListInfo;
                    }else{
                        if(!isEmpty(blockAllFlag) && blockAllFlag == "Y"){
                            response.profile.status = "Suspend";
                            delete response.blockListInfo;
                        }else if(displayFlag == "N"){
                            response.profile.status = "Suspend";
                            delete response.blockListInfo;
                        }else{
                            delete response.blockListInfo;
                        }
                    }
                
            }else{
                 response.blockListInfo.push(typeObj);
            }
        }
    }
    
    if(isEmpty(context.getVariable("resp.subrType"))) {
        delete response.profile.subType;
    }
    if(isEmpty(context.getVariable("resp.idNumb"))) {
        delete response.registeredID;
    }
    if(isEmpty(context.getVariable("resp.smsLang")) && isEmpty(context.getVariable("resp.callCenterLang")) && isEmpty(context.getVariable("resp.ivrLang"))) {
        delete response.lang;
    } else {
        if(isEmpty(context.getVariable("resp.smsLang"))) {
            delete response.lang.sms;
        }
        if(isEmpty(context.getVariable("resp.callCenterLang"))) {
            delete response.lang.callcenter;
        }
        if(isEmpty(context.getVariable("resp.ivrLang"))) {
            delete response.lang.ivr;
        }
    }
    if(isEmpty(context.getVariable("resp.birthDate"))) {
        delete response.birthDate;
    }
    if(isEmpty(context.getVariable("resp.gender"))) {
        delete response.gender;
    }
    if(isEmpty(context.getVariable("resp.switchOnDttm"))) {
        delete response.aou;
    }
    if(isEmpty(context.getVariable("resp.firstSwitchOnDttm"))) {
        delete response.firstAou;
    }
    
    return JSON.stringify(response);
}

function setAouAndFirstAou(now, date) {
    if(isEmpty(date)) {
        return "";
    } else {
        var switchOnDttm = new Date((date).substring(0, 10)).getTime();
        var todayString = now.getFullYear() + "-" + checkLengthDateFormat("" + (now.getMonth() + 1)) + "-" + checkLengthDateFormat("" + now.getDate());
        var today = new Date(todayString).getTime();
        
        return "" + (((today - switchOnDttm) / 86400000) + 1);
    }
}

function isCheckBlockAllService(serviceBlockAll,serviceGrp){
    var result = "",serviceName="",blockAllService="", serviceFlag="" ,lengthBlockAll = "",setServiceFlag=[];
    if(!isEmpty(serviceBlockAll)){
        serviceName = serviceBlockAll.toString();
        var data = serviceBlockAll.split(",");
        lengthBlockAll = data.length;
        for(index = 0; index < serviceGrp.length ; index++){
            blockAllService =   serviceGrp[index];
            if(serviceName.indexOf(blockAllService) > -1){
                serviceFlag = true;
            }else{
                serviceFlag = false;
            }
            setServiceFlag.push(serviceFlag);
        }

       var serviceFlagList = setServiceFlag.sort();
       var current = null,cnt = 0,lengthOfTrue="";
        for (var index2=0;index2 < serviceFlagList.length ; index2++) {
            if (serviceFlagList[index2] != current) {
                if (cnt > 0) {
                   lengthOfTrue = cnt ;
                }
                current = serviceFlagList[index2];
                cnt = 1;
            } else {
                cnt++;
            }
        }
        if (cnt > 0) {
            lengthOfTrue = cnt ;
        }
        if(current === true){
             if(lengthOfTrue == lengthBlockAll){
                result = true;
             }else{
                result = false;
             }
        }else{
            result = false;
        }
    }
   
    return result;
}

function ischeckServiceBlockList(blockList,services,serviceGrp){
    //To check service from response is matching with the service in kvm or not
    var result = "";
        if(!isEmpty(blockList) && (!isEmpty(services) || !isEmpty(serviceGrp))){
                var data = blockList.split(",");
                var serviceBlockSetting = data;
                for(var index=0; index<serviceBlockSetting.length; index++){
                    var serviceBlockList = serviceBlockSetting[index];
                     if((serviceBlockList == services) || (serviceBlockList == serviceGrp)){
                         result = true;
                         break;
                     }else{
                         result = false;
                     }
        }
        
    }
    return result;
}

function checkCompanyCode(compCode) {
    if(isEmpty(compCode)) {
        return "";
    } else {
        if(compCode == "10") {
            return "DTAC";
        } else if(compCode == "20") {
            return "DTN";
        }
    }
}

function checkTelephoneType(telpType) {
    if(isEmpty(telpType)) {
        return "";
    } else {
        if(telpType == "T" || telpType == "t") {
            return "Postpaid";
        } else if(telpType == "P" || telpType == "p") {
            return "Prepaid";
        }
    }
}

function checkSubrStatus(status) {
    if(isEmpty(status)) {
        return "";
    } else {
        if(status == "A" || status == "a") {
            return "Active";
        } else if(status == "S" || status == "s") {
            return "Suspend";
        } else if(status == "O" || status == "o") {
            return "SwitchOff";
        } else if(status == "C" || status == "c") {
            return "Close";
        }
    }
}

function checkSubType(subType) {
    if(isEmpty(subType)) {
        return "";
    } else {
        if(subType == "V" || subType == "v") {
            return "VIP-Business";
        } else if(subType == "S" || subType == "s") {
            return "Staff";
        } else if(subType == "T" || subType == "t") {
            return "Test";
        } else if(subType == "A" || subType == "a") {
            return "Airport";
        } else if(subType == "R" || subType == "r") {
            return "Corp-Indi";
        } else if(subType == "D" || subType == "d") {
            return "VIP-Indi";
        } else if(subType == "O" || subType == "o") {
            return "Other";
        } else if(subType == "B" || subType == "b") {
            return "Inbound Roamer";
        } else if(subType == "E" || subType == "e") {
            return "ALC/EPC";
        } else if(subType == "I" || subType == "i") {
            return "Individual";
        } else if(subType == "M" || subType == "m") {
            return "SME";
        } else if(subType == "N" || subType == "n") {
            return "Investor";
        } else if(subType == "P" || subType == "p") {
            return "VIP-Special";
        } else if(subType == "X" || subType == "x") {
            return "Taxi";
        } else if(subType == "-" || subType === "") {
            return "Normal";
        }
    }      
}

function checkLanguage(lang) {
    if(isEmpty(lang)) {
        return "";
    } else {
        if(lang == "T" || lang == "t") {
            return "Thai";
        } else if(lang == "E" || lang == "e") {
            return "English";
        } else if(lang == "3") {
            return "Burmese";
        }
    }
}

function checkCallCenterLang(lang) {
    if(isEmpty(lang)) {
        return "";
    } else {
        if(lang == "01") {
            return "Thai";
        } else if(lang == "02") {
            return "English";
        } else if(lang == "03") {
            return "Chinese";
        } else if(lang == "04") {
            return "Japanese";
        } else if(lang == "05") {
            return "Yawee";
        } else if(lang == "06") {
            return "Burmese";
        } else if(lang == "07") {
            return "Cambodia";
        } else if(lang == "08") {
            return "Laos";
        } else if(lang == "09") {
            return "Mon";
        }
    }
}

function checkSex(sex) {
    if(isEmpty(sex)) {
        return "";
    } else {
        if(sex == "M" || sex == "m") {
            return "Male";
        } else if(sex == "F" || sex == "f") {
            return "Female";
        } else if(sex == "U" || sex == "u") {
            return "Undefined";
        }
    }
}

function checkLengthArray (arrayList) {
    if(isEmpty(arrayList.length)) {
        var array_item = [];
        array_item[0] = arrayList;
        arrayList = array_item;   
    }
    
    return arrayList;
}

function getTargetSC() {
    if(!isEmpty(context.getVariable("servicecallout.requesturi"))) {
        targetServer = context.getVariable("getSubrBlockListRequest.url");
    } else {
        targetServer = context.getVariable("endpointUrl");
    }  
    return targetServer;
}

setReasonPhrase(context.getVariable("resp.httpStatusCode"));
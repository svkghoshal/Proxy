var errorCode = "" + context.getVariable("resp.errorCode");
var statusType = ""+context.getVariable("resp.statusType");
var server = ""+context.getVariable("resp.server");
var errorMessage = "" + context.getVariable("resp.errorMessage");
var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");
var newCust = "" + context.getVariable("resp.newCustNumb");

print("status :" + statusType);

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("southbound.request", setNorthSouthJsonRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthJsonRequestResponse(responseContent));
context.setVariable("request.verb", "POST");

printProxyRequest(requestContent);
printTargetResponse(responseContent);

if(statusType === 'S'){
    context.setVariable("resp.statusType", "TRUE");
    context.setVariable("resp.responseMessage", setResponseMessage());
    setResponse("200", "200", "", "");
}else{
    context.setVariable("resp.statusType", "FALSE");
    errorSavePreToPostResultMapping(errorCode, errorMessage);
    context.setVariable("resp.responseMessage", setResponseMessage());
}



function setResponseMessage(){
    var response = 
        {
            "id"    :
            { 
              "type"    :  context.getVariable("req.savePreIdType"),
              "value"   :  context.getVariable("req.savePreIdValue")
            },
             "data"     :
            { 
              "requestDateTime"     :  context.getVariable("req.savePreReqDttm"),
              "responseDateTime"    :  context.getVariable("resp.responseDttm"),
              "transactionId"       :  context.getVariable("req.transactionId")
            },
            "save"      :
            {
               "status"    :  context.getVariable("resp.statusType"),
               "newCust"   :  context.getVariable("resp.newCustNumb")
            },
            "code"          : context.getVariable("resp.code"),
            "error"         : context.getVariable("resp.error"),
            "message"       : context.getVariable("resp.message")
        }
        
        if(isEmpty(context.getVariable("resp.newCustNumb")) || context.getVariable("resp.newCustNumb") === null){
            delete response.save;
        }
        
        if(statusType === 'S'){
          delete response.code;
          delete response.error;
          delete response.message;
     }
        
    return JSON.stringify(response);
}

setReasonPhrase(context.getVariable("resp.httpStatusCode"));
var responseContent = "";

if(isEmpty(context.getVariable("error.content"))) {
    responseContent = "" + context.getVariable("response.content");
} else {
    responseContent = "" + context.getVariable("error.content");
}

context.setVariable("northbound.response", setNorthSouthJsonRequestResponse(responseContent));
context.setVariable("southboundEndpointUrlDatetime", "" + getDatetime());
context.setVariable("southboundRequestDatetime", "" + getDatetime());
if(isEmpty(context.getVariable("southbound.requestdatetime"))) {
    context.setVariable("southbound.requestdatetime", getTimestamp());
}
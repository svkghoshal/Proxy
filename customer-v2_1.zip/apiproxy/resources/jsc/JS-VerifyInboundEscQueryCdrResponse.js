var statusCode = "" + context.getVariable("resp.apiStatusCode");
var errorCode = "" + context.getVariable("resp.apiResponseCode");
var errorMessage = "" + context.getVariable("resp.apiResponseMessage");
var requestContent = "" + context.getVariable("request.content");
var responseContent = "" + context.getVariable("response.content");

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("request.verb", "GET");
printProxyRequest(requestContent);
printTargetResponse(responseContent);


if(statusCode === "S") {
    mapEscCdrToJson();
    setResponse("200", "200", "", "");
} else {
    errorEscCdrResultMapping(errorCode, errorMessage,statusCode);
}
setReasonPhrase(context.getVariable("resp.httpStatusCode"));
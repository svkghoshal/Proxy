var errorCode = "" + context.getVariable("resp.errorCode");
var statusType = ""+context.getVariable("resp.statusType");
var server = ""+context.getVariable("resp.server");
var errorMessage = "" + context.getVariable("resp.errorMessage");
var requestContent = context.getVariable("request.querystring");
var responseContent = context.getVariable("response.content");


context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("request.verb", "GET");

printProxyRequest(requestContent);
printTargetResponse(responseContent);

if(statusType === 'S'){
    context.setVariable("resp.statusType", "TRUE");
    setResponse("200", "200", "", "");
}else{
    context.setVariable("resp.statusType", "FALSE");
    errorValidatePreToPostResultMapping(errorCode, errorMessage);
}

setReasonPhrase(context.getVariable("resp.httpStatusCode"));
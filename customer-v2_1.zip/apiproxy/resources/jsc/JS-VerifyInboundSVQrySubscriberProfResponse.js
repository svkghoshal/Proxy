var errrorCode = "" + context.getVariable("resp.svqProf.errorCode");
var errrorMessage = "" + context.getVariable("resp.svqProf.errorDescription");
var requestContent = context.getVariable("svQrySubscriberProfRequest.content");
var responseContent = context.getVariable("svQrySubscriberProfResponse.content");

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));

context.setVariable("southbound.responsedatetime", getTimestamp());
context.setVariable("southboundService1ResponseDatetime", getDatetime());
context.setVariable("southboundSevice1.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southboundSevice1.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("southboundSevice1.target.server", getServiceCalloutTargetServer());
context.setVariable("request.verb", "GET");

printProxyRequest(requestContent);
printTargetResponse(responseContent);

if(isEmpty(errrorCode)) {
    var companyCode = "" + context.getVariable("resp.svqProf.companyCode");
    
    if(companyCode == 10) {
        var isEnableHttps = (context.getVariable("scoreDtacIsEnableHttps") === "true");
        context.setVariable("isEnableHttps", isEnableHttps);
        context.setVariable("endpointUrl", context.getVariable("scoreDtacEndpoint"));
    } else if (companyCode == 20) {
        var isEnableHttps = (context.getVariable("scoreDtnIsEnableHttps") === "true");
        context.setVariable("isEnableHttps", isEnableHttps);
        context.setVariable("endpointUrl", context.getVariable("scoreDtnEndpoint"));
    }
    setResponse("200", "200", "", "");
    context.setVariable("req.sentDttm", getTimePatternForService1());
} else {
    if(errrorMessage.indexOf("OM") > 1) {
        errorSvQrySubscriberProfResultMapping(trimErrorCodeOm(errrorMessage), trimErrorMessageOm(errrorMessage));
    } else {
        errorSvQrySubscriberProfResultMapping(trimErrorCodeEsb(errrorCode), errrorMessage);
    }
}
setReasonPhrase(context.getVariable("resp.httpStatusCode"));

function getServiceCalloutTargetServer() {
    return context.getVariable("servicecallout.requesturi");
}
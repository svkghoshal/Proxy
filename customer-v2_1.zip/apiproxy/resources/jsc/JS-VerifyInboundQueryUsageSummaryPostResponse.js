var statusCode = "" + context.getVariable("resp.statusCode");
var esbCode = "" + context.getVariable("resp.esbResponseCode");
var esbMessage = "" + context.getVariable("resp.esbResponseMessage");
var systemResponseCode = "" + context.getVariable("resp.systemResponseCode");
var systemResponseMessage = "" + context.getVariable("resp.systemResponseMessage");
var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("request.verb", "GET");

printTargetResponse(responseContent);

if(statusCode === "S") {
    setResponse("200", "200", "", "");
    mapQueryUsageSummaryPostToJson();
}else if (!isEmpty(esbCode) && isEmpty(systemResponseCode)) {
    var esbResponseCode = trimErrorCodeEsb(esbCode);
    var esbResponseMessage = trimErrorMessageEsb(esbMessage);
    
    errorQueryUsageSummaryResultMapping(esbResponseCode, esbResponseMessage);
} else if (!isEmpty(esbCode) && !isEmpty(systemResponseCode)) {
    errorQueryUsageSummaryResultMapping(systemResponseCode, systemResponseMessage);
}
setReasonPhrase(context.getVariable("resp.httpStatusCode"));
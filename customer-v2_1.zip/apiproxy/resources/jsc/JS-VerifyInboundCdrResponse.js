var errorCode = "" + context.getVariable("resp.apiResponseCode");
var errorMessage = "" + context.getVariable("resp.apiResponseMessage");
var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("request.verb", "GET");

printProxyRequest(requestContent);
printTargetResponse(responseContent);


if(errorCode === "1") {
    setResponse("200", "200", "", "");
    mapQueryCdrToJson();
} else {
    if(errorCode === "129004") {
        errorMessage = "Endpoint Business: " + context.getVariable("resp.endpointName") + ";" + context.getVariable("resp.endpointErrorCode") + ";" + context.getVariable("resp.endpointErrorMessage");
    }
    errorQueryCdrResultMapping(errorCode, errorMessage);
}
setReasonPhrase(context.getVariable("resp.httpStatusCode"));
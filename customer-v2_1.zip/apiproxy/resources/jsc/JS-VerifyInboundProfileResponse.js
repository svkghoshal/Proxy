var errrorCode = "" + context.getVariable("resp.errorCode");
var errrorMessage = "" + context.getVariable("resp.errorDescription");
var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");

context.setVariable("southbound.responsedatetime", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundService1ResponseDatetime", getDatetime());
context.setVariable("southboundService1EndpointUrlDatetime", "" + getDatetime());
context.setVariable("southboundService1RequestDatetime", "" + getDatetime());
context.setVariable("southboundSevice1.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southboundSevice1.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("southboundSevice1.target.server", getTargetServer());
context.setVariable("request.verb", "GET");


printProxyRequest(requestContent);
printTargetResponse(responseContent);

if(isEmpty(errrorCode)) {
    context.setVariable("getBlockListFlag", "Y");
    setResponse("200", "200", "", "");
} else {
    if(errrorMessage.indexOf("OM") > 1) {
        errorProfileResultMapping(trimErrorCodeOm(errrorMessage), trimErrorMessageOm(errrorMessage));
    } else {
        errorProfileResultMapping(trimErrorCodeEsb(errrorCode), errrorMessage);
    }
}
setReasonPhrase(context.getVariable("resp.httpStatusCode"));

function getServiceCalloutTargetServer() {
    return context.getVariable("servicecallout.requesturi");
}

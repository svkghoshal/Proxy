var clientEndTimeStamp = new Date().getTime();

context.setVariable("clientStartTime", getClientStartTime());
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("clientEndTime", getClientEndTime());
context.setVariable("clientElapsTime", getClientElaspTime());
context.setVariable("targetElapsTime", getTargetElaspTime());
context.setVariable("apigw.txId", getApigwTransactionId());
context.setVariable("southbound.target.server", getServiceCalloutTargetServer());

function getApigwTransactionId() {
    var proxyName = context.getVariable("apiproxy.name");
    var suffixPath = context.getVariable("proxy.pathsuffix");
    var timestamp = new Date().getTime();
    var randomNumber = Math.floor(100000 + Math.random() * 900000);
    
    var useProxyName = proxyName.substring(0, 1).toUpperCase() + proxyName.substring(1);
    var useSuffixPath = suffixPath.substring(1, 2).toUpperCase() + suffixPath.substring(2);
    
    return useProxyName + useSuffixPath + timestamp + randomNumber;
}

function getClientElaspTime() {
    var clientElapsTime = (clientEndTimeStamp - context.getVariable("client.received.start.timestamp"));

    return "" + clientElapsTime;
}

function getTargetElaspTime() {
    if(isEmpty(context.getVariable("southbound.responsedatetime")) || isEmpty(context.getVariable("southbound.requestdatetime"))) {
        return "";
    } else {
        var targetElapsTime = context.getVariable("southbound.responsedatetime") - context.getVariable("southbound.requestdatetime");
        return "" + targetElapsTime;
    }
}

function getClientStartTime() {
    return getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(context.getVariable("client.received.start.timestamp"));
}

function getTargetStartTime() {
    if(isEmpty(context.getVariable("southbound.requestdatetime"))) {
        return "";
    } else {
        return getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(context.getVariable("southbound.requestdatetime"));
    }
}

function getTargetEndTime() {
    if(isEmpty(context.getVariable("southbound.responsedatetime"))) {
        return "";
    } else {
        return getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(context.getVariable("southbound.responsedatetime"));
    }
}

function getClientEndTime() {
    return getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(clientEndTimeStamp);
}

function getServiceCalloutTargetServer() {
    if(isEmpty(context.getVariable("endpointUrl"))) {
        return "";
    } else {
        return context.getVariable("servicecallout.requesturi");
    }
}
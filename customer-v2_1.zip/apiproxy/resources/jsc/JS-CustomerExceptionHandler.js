function errorReadSubrIACCWSResultMapping(errorCode, errorMessage) {
    switch(errorCode){
        case "405238900":
            setResponse("400", "400.030.0009", "Bad Request", "Number of fields send is less than the required number of fields.");
            break;
        case "100009":
            setResponse("400", "400.030.0010", "Bad Request", "Blank not allowed");
            break;
        case "201453":
            setResponse("400", "400.030.0011", "Bad Request", "Invalid subscriber");
            break;
        default :
            setResponse("500", "500.030.0000", "Internal Server Error", errorMessage);
            break;
    }
}

function errorQueryBalanceResultMapping(errorCode, errorDesc) {
    switch(errorCode){
        case "000":
            setResponse("500", "500.030.1001", "Internal Server Error", "General Transport error");
            break;
        case "001":
            setResponse("500", "500.030.1002", "Internal Server Error", "General Runtime error");
            break;
        case "002":
            setResponse("500", "500.030.1003", "Internal Server Error", "General parse failure from binding layer");
            break;
        case "003":
            setResponse("500", "500.030.1004", "Internal Server Error", "WS-I compliance failure");
            break;
        case "004":
            setResponse("500", "500.030.1005", "Internal Server Error", "Message must be a soap:Envelope ");
            break;
        case "005":
            setResponse("500", "500.030.1006", "Internal Server Error", "A soap:Envelope must contain a soap:Body");
            break;
        case "006":
            setResponse("500", "500.030.1007", "Internal Server Error", errorDesc);
            break;
        case "007":
            setResponse("500", "500.030.1008", "Internal Server Error", "OSB service callout action received an unrecognized response. XML details: An Unrecognized Response was Received");
            break;
        case "008":
            setResponse("500", "500.030.1009", "Internal Server Error", "OSB Validate action validation failed. XML details: Validation Failed ");
            break;
        case "009":
            setResponse("500", "500.030.1010", "Internal Server Error", errorDesc);
            break;
        case "010":
            setResponse("500", "500.030.1011", "Internal Server Error", errorDesc);
            break;
        case "011":
            setResponse("500", "500.030.1012", "Internal Server Error", errorDesc);
            break;
        case "999":
            setResponse("500", "500.030.1013", "Internal Server Error", errorDesc);
            break;
        case "CBS-0-405238900":
            setResponse("400", "400.030.0001", "Bad Request", errorDesc);
            break;
        case "CBS-0-102012001":
            setResponse("400", "400.030.0002", "Bad Request", errorDesc);
            break;
        case "CBS-0-102010248":
            setResponse("400", "400.030.0003", "Internal Server Error", errorDesc);
            break;
        case "CBS-0-405010001":
            setResponse("400", "400.030.0004", "Bad Request", errorDesc);
            break;
        case "CBS-0-102010248":
            setResponse("400", "400.030.0005", "Resource not found", errorDesc);
            break;
        case "CBS-0-102012045":
            setResponse("400", "400.030.0006", "Bad Request", errorDesc);
            break;
        case "CBS-0-102012046":
            setResponse("400", "400.030.0007", "Unauthorized", errorDesc);
            break;
        case "CBS-0-102012047":
            setResponse("400", "400.030.0008", "Bad Request", errorDesc);
            break;
        case "CBS-0-102010663":
            setResponse("500", "500.030.0001", "Bad Request", errorDesc);
            break;
        default:
            setResponse("500", "500.030.0000", "Internal Server Error", errorDesc);
            break;
    }
}

function errorQueryCdrResultMapping(errorCode, errorMessage){
    switch(errorCode){
        case "0"    :
            setResponse("404", "404.038.1001", "Resource not found", "Data not found");
            break;
        case "19002":
            setResponse("400", "400.038.0001", "Bad Request", "SourceSystemId not found");
            break;
        case "19005":
            setResponse("400", "400.038.0002", "Bad Request", "AuthenCode not format");
            break;
        case "19006":
            setResponse("400", "400.038.0003", "Bad Request", "RequestDTTM not found");
            break;
        case "19007":
            setResponse("400", "400.038.0004", "Bad Request", "RequestDTTM after today 15 minute");
            break;
        case "51001":
            setResponse("400", "400.038.0005", "Bad Request", "Not available for postpaid subscriber.");
            break;
        case "51004":
            setResponse("400", "400.038.0006", "Bad Request", "Invalid Date");
            break;
        case "210001":
            setResponse("400", "400.038.0007", "Bad Request", "Inactive subscriber");
            break;
        case "129003":
            setResponse("400", "400.038.0008", "Bad Request", "No XML input");
            break;
        case "129004":
            setResponse("400", "400.038.0009", "Bad Request", errorMessage);
            break;
        case "129001":
            setResponse("500", "500.038.1001", "Internal Server Error", "System error");
            break;
        default :
            setResponse("500", "500.038.0000", "Internal Server Error", errorMessage);
            break;
    }
}

function errorFupBalanceResultMapping(errorCode, errorMessage) {
    switch(errorCode){
        case "19002":
            setResponse("400", "400.037.0001", "Bad Request", "SourceSystemId not found");
            break;
        case "19005":
            setResponse("400", "400.037.0002", "Bad Request", "AuthenCode not format");
            break;
        case "19006":
            setResponse("400", "400.037.0003", "Bad Request", "RequestDTTM not found");
            break;
        case "19007":
            setResponse("400", "400.037.0004", "Bad Request", "RequestDTTM after today 15 minute");
            break;
        case "110003":
            setResponse("400", "400.037.0005", "Bad Request", "Subscriber Number does not exist");
            break;
        case "129002":
            setResponse("400", "400.037.0006", "Bad Request", errorMessage);
            break;
        case "129003":
            setResponse("400", "400.037.0007", "Bad Request", "No request data");
            break;
        case "41116":
            setResponse("400", "400.037.0008", "Bad Request", "Invalid input compCode");
            break;
        case "41117":
            setResponse("400", "400.037.0009", "Bad Request", "Invalid input telpType");
            break;
        case "129001":
            setResponse("500", "500.037.1001", "Internal Server Error", "System fail exception");
            break;
        case "110002":
            setResponse("500", "500.037.1002", "Internal Server Error", "No output");
            break;
        default :
            setResponse("500", "500.037.0000", "Internal Server Error", errorMessage);
            break;
    }
}

function errorVasBalanceResultMapping(errorCode, errorMessage) {
    switch(errorCode){
        case "0":
            setResponse("400", "404.036.1001", "Resource not found", "Data not found");
            break;
        case "19002":
            setResponse("400", "400.036.0001", "Bad Request", "SourceSystemId not found");
            break;
        case "19005":
            setResponse("400", "400.036.0002", "Bad Request", "AuthenCode not format");
            break;
        case "19006":
            setResponse("400", "400.036.0003", "Bad Request", "RequestDTTM not found");
            break;
        case "19007":
            setResponse("400", "400.036.0004", "Bad Request", "RequestDTTM after today 15 minute");
            break;
        case "119001":
            setResponse("400", "400.036.0005", "Bad Request", errorMessage);
            break;
        case "119002":
            setResponse("400", "400.036.0006", "Bad Request", "Running status data not found");
            break;
        case "119003":
            setResponse("400", "400.036.0007", "Bad Request", "Running status old subscriber");
            break;
        case "129002":
            setResponse("400", "400.036.0008", "Bad Request", "Running status time out");
            break;
        case "129003":
            setResponse("400", "400.036.0009", "Bad Request", "No request data");
            break;
        case "129001":
            setResponse("500", "500.036.1001", "Internal Server Error", "System error");
            break;
        default :
            setResponse("500", "500.036.0000", "Internal Server Error", errorMessage);
            break;
    }
}

function errorCheckBlackListResultMapping(errorCode, errorMessage) {
    switch(errorCode){
        case "100009":
            setResponse("400", "400.050.0001", "Bad Request", "Blank is not allowed.");
            break;
        case "201306":
            setResponse("400", "400.050.0002", "Bad Request", "Invalid function ID.");
            break;
        case "201356":
            setResponse("400", "400.050.0003", "Bad Request", "Invalid flag.");
            break;
        case "201738":
            setResponse("400", "400.050.0004", "Bad Request", "Invalid customer number.");
            break;
        case "209371":
            setResponse("400", "400.050.0006", "Bad Request", "Unable to make transaction because ID number is locked by 3 layers application. Please unlock via 3 levels application.");
            break;
        default :
            setResponse("500", "500.050.0000", "Internal Server Error", errorMessage);
            break;
    }
}

function errorCheckLockedIdResultMapping(errorCode, errorMessage) {
    switch(errorCode){
        case "100009":
            setResponse("400", "400.051.0001", "Bad Request", "Blank is not allowed.");
            break;
        case "201306":
            setResponse("400", "400.051.0002", "Bad Request", "Invalid function ID.");
            break;
        case "201738":
            setResponse("400", "400.051.0003", "Bad Request", "Invalid customer number.");
            break;
        default :
            setResponse("500", "500.051.0000", "Internal Server Error", errorMessage);
            break;
    }
}

function errorProfileResultMapping(errorCode, errorMessage) {
    switch(errorCode){
        case "001":
            setResponse("500", "500.047.1001", "Internal Server Error", "Mandatory Attribute missing");
            break;
        case "002":
            setResponse("500", "500.047.1002", "Internal Server Error", "Bind/Unbind exception");
            break;
        case "003":
            setResponse("500", "500.047.1003", "Internal Server Error", "Transport error");
            break;
        case "004":
            setResponse("500", "500.047.1004", "Internal Server Error", "General runtime error");
            break;
        case "005":
            setResponse("500", "500.047.1005", "Internal Server Error", "Security error");
            break;
        case "006":
            setResponse("500", "500.047.1006", "Internal Server Error", "Failed to convert message");
            break;
        case "007":
            setResponse("500", "500.047.1007", "Internal Server Error", "Invalid Request Payload");
            break;
        case "008":
            setResponse("500", "500.047.1008", "Internal Server Error", "Incorrect Request Payload Body");
            break;
        case "009":
            setResponse("500", "500.047.1009", "Internal Server Error", "Incorrect Request Header");
            break;
        case "010":
            setResponse("500", "500.047.1010", "Internal Server Error", errorMessage);
            break;
        case "011":
            setResponse("500", "500.047.1011", "Internal Server Error", errorMessage);
            break;
        case "012":
            setResponse("500", "500.047.1012", "Internal Server Error", "Invalid Date Format");
            break;
        case "013":
            setResponse("500", "500.047.1013", "Internal Server Error", "Invalid RequestMode");
            break;
        case "014":
            setResponse("500", "500.047.1014", "Internal Server Error", "Exceeded the max throttle rate of x within 1000ms for xx user");
            break;
        case "015":
            setResponse("500", "500.047.1015", "Internal Server Error", "Exceeded the max throttle rate of x within 1000ms for xx service");
            break;
        case "999":
            setResponse("500", "500.047.1016", "Internal Server Error", errorMessage);
            break;
        case "100009":
            setResponse("400", "400.047.0001", "Bad Request", "Blank not allowed");
            break;
        case "201453":
            setResponse("400", "400.047.0002", "Bad Request", "Invalid subscriber");
            break;
        default :
            setResponse("500", "500.047.0000", "Internal Server Error", "Internal System Error : " + errorMessage);
            break;
    }
}

function errorSvQrySubscriberProfResultMapping(errorCode, errorMessage) {
    if(errorCode.match("[0-9]{6}")) {
        switch(errorCode){
            case "201453":
                setResponse("400", "400.048.0007", "Bad Request", "Invalid Subscriber");
                break;
            default :
                setResponse("400", "400.048.0008", "Bad Request", errorMessage);
                break;
        }
    } else {
        setResponse("500", "500.048.1015", "Internal Server Error", errorMessage);
    }
}

function errorScoreResultMapping(errorCode, errorMessage) {
    switch(errorCode){
        case "000":
            setResponse("500", "500.048.1001", "Internal Server Error", "General Transport error");
            break;
        case "001":
            setResponse("500", "500.048.1002", "Internal Server Error", "General Runtime error");
            break;
        case "002":
            setResponse("500", "500.048.1003", "Internal Server Error", "General parse failure from binding layer");
            break;
        case "003":
            setResponse("500", "500.048.1004", "Internal Server Error", "WS-I compliance failure");
            break;
        case "004":
            setResponse("500", "500.048.1005", "Internal Server Error", "Message must be a soap:Envelope ");
            break;
        case "005":
            setResponse("500", "500.048.1006", "Internal Server Error", "A soap:Envelope must contain a soap:Body");
            break;
        case "006":
            setResponse("500", "500.048.1007", "Internal Server Error", errorMessage);
            break;
        case "007":
            setResponse("500", "500.048.1008", "Internal Server Error", "OSB service callout action received an unrecognized response. XML details: An Unrecognized Response was Received");
            break;
        case "008":
            setResponse("500", "500.048.1009", "Internal Server Error", "OSB service callout has received an error response from the server XML details: An Unknown Error Response Was Received");
            break;
        case "009":
            setResponse("500", "500.048.1010", "Internal Server Error", "OSB Validate action validation failed. XML details: Validation Failed");
            break;
        case "010":
            setResponse("500", "500.048.1011", "Internal Server Error", errorMessage);
            break;
        case "011":
            setResponse("500", "500.048.1012", "Internal Server Error", errorMessage);
            break;
        case "999":
            setResponse("500", "500.048.1013", "Internal Server Error", errorMessage);
            break;
        case "CBS-0-102010535":
        case "CBS-0-102011685":
            setResponse("400", "400.048.0001", "Bad Request", errorMessage);
            break;
        case "CBS-0-102010732":
            setResponse("400", "400.048.0002", "Bad Request", "The entered account code is not the account code of the customer to which the subscriber belongs.");
            break;
        case "CBS-0-102011378":
            setResponse("400", "400.048.0003", "Bad Request", errorMessage);
            break;
        case "CBS-0-102012726":
            setResponse("400", "400.048.0004", "Bad Request", "When subscriber credit is queried for accounts of multiple subscribers, subscriber numbers are required.");
            break;
        case "CBS-0-102011634":
            setResponse("400", "400.048.0005", "Bad Request", "The SubscriberNo and AccountCode do not match");
            break;
        case "CBS-0-102010248":
            setResponse("400", "400.048.0006", "Bad Request", errorMessage);
            break;
        case "CBS-0-102010114":
            setResponse("500", "500.048.1014", "Internal Server Error", errorMessage);
            break;
        default :
            setResponse("500", "500.048.0000", "Internal Server Error", "Internal System Error : " + errorMessage);
            break;
    }
}

function errorDeviceResultMapping(errorCode, errorMessage) {
    switch(errorCode){
        case "001":
            setResponse("500", "500.049.1001", "Internal Server Error", "Mandatory Attribute missing");
            break;
        case "002":
            setResponse("500", "500.049.1002", "Internal Server Error", "Bind/Unbind exception");
            break;
        case "003":
            setResponse("500", "500.049.1003", "Internal Server Error", "Transport error");
            break;
        case "004":
            setResponse("500", "500.049.1004", "Internal Server Error", "General runtime error");
            break;
        case "005":
            setResponse("500", "500.049.1005", "Internal Server Error", "Security error");
            break;
        case "006":
            setResponse("500", "500.049.1006", "Internal Server Error", "Failed to convert message");
            break;
        case "007":
            setResponse("500", "500.049.1007", "Internal Server Error", "Invalid Request Payload");
            break;
        case "008":
            setResponse("500", "500.049.1008", "Internal Server Error", "Incorrect Request Payload Body");
            break;
        case "009":
            setResponse("500", "500.049.1009", "Internal Server Error", "Incorrect Request Header");
            break;
        case "010":
            setResponse("500", "500.049.1010", "Internal Server Error", errorMessage);
            break;
        case "011":
            setResponse("500", "500.049.1011", "Internal Server Error", errorMessage);
            break;
        case "012":
            setResponse("500", "500.049.1012", "Internal Server Error", "Invalid Date Format");
            break;
        case "013":
            setResponse("500", "500.049.1013", "Internal Server Error", "Invalid RequestMode");
            break;
        case "014":
            setResponse("500", "500.049.1014", "Internal Server Error", "Exceeded the max throttle rate of x within 1000ms for xx user");
            break;
        case "015":
            setResponse("500", "500.049.1015", "Internal Server Error", "Exceeded the max throttle rate of x within 1000ms for xx service");
            break;
        case "999":
            setResponse("500", "500.049.1016", "Internal Server Error", errorMessage);
            break;
        case "1044":
            setResponse("400", "400.049.0001", "Bad Request", "Invalid or missing lock entity info type");
            break;
        case "1001":
            setResponse("400", "400.049.0002", "Bad Request", "TAC not found");
            break;
        case "1055":
            setResponse("400", "400.049.0003", "Bad Request", "New MSISDN already exists");
            break;
        case "1035":
            setResponse("400", "400.049.0004", "Bad Request", "Invalid or missing input file name");
            break;
        case "1049":
            setResponse("400", "400.049.0005", "Bad Request", "IMEI/TAC length is invalid");
            break;
        case "1011":
            setResponse("400", "400.049.0006", "Bad Request", "Invalid or missing GroupId");
            break;
        case "1031":
            setResponse("400", "400.049.0007", "Bad Request", "Invalid or missing model name");
            break;
        case "1052":
            setResponse("400", "400.049.0008", "Bad Request", "Invalid OS Type");
            break;
        case "1033":
            setResponse("400", "400.049.0009", "Bad Request", "Handset already exists");
            break;
        case "1003":
            setResponse("400", "400.049.0010", "Bad Request", "Image not available");
            break;
        case "1059":
            setResponse("400", "400.049.0011", "Bad Request", "Missing custom ConfigId");
            break;
        case "1037":
            setResponse("400", "400.049.0012", "Bad Request", "Extension not allowed");
            break;
        case "1023":
            setResponse("400", "400.049.0013", "Bad Request", "Invalid or missing AccessType");
            break;
        case "1009":
            setResponse("400", "400.049.0014", "Bad Request", "Invalid or missing Direction");
            break;
        case "1026":
            setResponse("400", "400.049.0015", "Bad Request", "Not found");
            break;
        case "1056":
            setResponse("400", "400.049.0016", "Bad Request", "Subscriber not found");
            break;
        case "1061":
            setResponse("400", "400.049.0017", "Bad Request", "Profile not found");
            break;
        case "1045":
            setResponse("400", "400.049.0018", "Bad Request", "Lock entity does not exist");
            break;
        case "1054":
            setResponse("400", "400.049.0019", "Bad Request", "Unknown Manufacturer");
            break;
        case "1013":
            setResponse("400", "400.049.0020", "Bad Request", "Error creating group");
            break;
        case "1010":
            setResponse("400", "400.049.0021", "Bad Request", "Invalid or missing Settings");
            break;
        case "1053":
            setResponse("400", "400.049.0022", "Bad Request", "TAC is known");
            break;
        case "1039":
            setResponse("400", "400.049.0023", "Bad Request", "Invalid blacklist type");
            break;
        case "1002":
            setResponse("400", "400.049.0024", "Bad Request", "Missing or invalid ModelId");
            break;
        case "1010":
            setResponse("400", "400.049.0025", "Bad Request", "Invalid or missing Settings");
            break;
        case "1047":
            setResponse("400", "400.049.0026", "Bad Request", "Range start and end must have same length");
            break;
        case "102":
            setResponse("400", "400.049.0027", "Bad Request", "Action not allowed");
            break;
        case "1015":
            setResponse("400", "400.049.0028", "Bad Request", "Invalid or missing UsrId");
            break;
        case "2046":
            setResponse("400", "400.049.0029", "Bad Request", "requested plan not in Opt-In invitation");
            break;
        case "1005":
            setResponse("400", "400.049.0030", "Bad Request", "Invalid or Missing IMEI");
            break;
        case "104":
            setResponse("400", "400.049.0031", "Bad Request", "Session timed out please re-login");
            break;
        case "1012":
            setResponse("400", "400.049.0032", "Bad Request", "Invalid or missing GroupName");
            break;
        case "1038":
            setResponse("400", "400.049.0033", "Bad Request", "Missing file name");
            break;
        case "2044":
            setResponse("400", "400.049.0034", "Bad Request", "Opt-In grace period not defined in DB");
            break;
        case "1008":
            setResponse("400", "400.049.0035", "Bad Request", "No subscriber provided");
            break;
        case "1007":
            setResponse("400", "400.049.0036", "Bad Request", "Missing IMSI and/or MSISDN");
            break;
        case "1042":
            setResponse("400", "400.049.0037", "Bad Request", "Invalid or missing lock entity name");
            break;
        case "1024":
            setResponse("400", "400.049.0038", "Bad Request", "One of UsrId or GroupId must be given at least");
            break;
        case "1028":
            setResponse("400", "400.049.0039", "Bad Request", "Invalid or missing value");
            break;
        case "2041":
            setResponse("400", "400.049.0040", "Bad Request", "Invalid or missing Tarrif Plan");
            break;
        case "2045":
            setResponse("400", "400.049.0041", "Bad Request", "Opt-In invitation expired");
            break;
        case "1057":
            setResponse("400", "400.049.0042", "Bad Request", "Missing params");
            break;
        case "1008":
            setResponse("400", "400.049.0043", "Bad Request", "Invalid or Missing MSISDN");
            break;
        case "1027":
            setResponse("400", "400.049.0044", "Bad Request", "Invalid or missing field");
            break;
        case "1040":
            setResponse("400", "400.049.0045", "Bad Request", "Blacklisted");
            break;
        case "1048":
            setResponse("400", "400.049.0046", "Bad Request", "Range start must be less than its end");
            break;
        case "100":
            setResponse("400", "400.049.0047", "Bad Request", "Invalid action");
            break;
        case "1006":
            setResponse("400", "400.049.0048", "Bad Request", "Missing IMSI/MSISDN");
            break;
        case "1020":
            setResponse("400", "400.049.0049", "Bad Request", "Invalid or missing AccessId");
            break;
        case "1043":
            setResponse("400", "400.049.0050", "Bad Request", "Invalid or missing lock entity id");
            break;
        case "1000":
            setResponse("400", "400.049.0051", "Bad Request", "Missing or invalid TAC");
            break;
        case "1046":
            setResponse("400", "400.049.0052", "Bad Request", "Invalid or missing range start and/or end");
            break;
        case "1041":
            setResponse("400", "400.049.0053", "Bad Request", "Invalid or missing lock entity type (must be company or service)");
            break;
        case "2047":
            setResponse("400", "400.049.0054", "Bad Request", "Missing/Invalid Subscription");
            break;
        case "1063":
            setResponse("400", "400.049.0055", "Bad Request", "Duplicate entries found");
            break;
        case "1018":
            setResponse("400", "400.049.0056", "Bad Request", "Error creating user");
            break;
        case "1017":
            setResponse("400", "400.049.0057", "Bad Request", "Invalid or missing Pwd");
            break;
        case "1016":
            setResponse("400", "400.049.0058", "Bad Request", "Invalid or missing Usrname");
            break;
        case "1022":
            setResponse("400", "400.049.0059", "Bad Request", "Invalid or missing TableName");
            break;
        case "1004":
            setResponse("400", "400.049.0060", "Bad Request", "Invalid or Missing ManufacturerId");
            break;
        case "1051":
            setResponse("400", "400.049.0061", "Bad Request", "Invalid Model");
            break;
        case "1058":
            setResponse("400", "400.049.0062", "Bad Request", "New IMSI already exists");
            break;
        case "2042":
            setResponse("400", "400.049.0063", "Bad Request", "no Opt-in invitation");
            break;
        case "1050":
            setResponse("400", "400.049.0064", "Bad Request", "Invalid or missing Text");
            break;
        case "103":
            setResponse("500", "500.049.1017", "Internal Server Error", "Could not generate a session id");
            break;
        case "101":
            setResponse("500", "500.049.1018", "Internal Server Error", "Not authenticated");
            break;
        case "1032":
            setResponse("500", "500.049.1019", "Internal Server Error", "Error Adding handset");
            break;
        case "2043":
            setResponse("500", "500.049.1020", "Internal Server Error", "Could not change tarrif");
            break;
        case "1062":
            setResponse("500", "500.049.1021", "Internal Server Error", "Could not create new entry");
            break;
        case "1056":
            setResponse("500", "500.049.1022", "Internal Server Error", "Could not get MSISDN from IMSI");
            break;
        case "1025":
            setResponse("500", "500.049.1023", "Internal Server Error", "Error adding user access");
            break;
        case "1021":
            setResponse("500", "500.049.1024", "Internal Server Error", "Error removing user access");
            break;
        case "1029":
            setResponse("500", "500.049.1025", "Internal Server Error", "Error setting field");
            break;
        case "1014":
            setResponse("500", "500.049.1026", "Internal Server Error", "Error deleting group");
            break;
        case "1019":
            setResponse("500", "500.049.1027", "Internal Server Error", "Error deleting user");
            break;
        case "1030":
            setResponse("500", "500.049.1028", "Internal Server Error", "Error removing field");
            break;
        case "1036":
            setResponse("500", "500.049.1029", "Internal Server Error", "Error uploading file");
            break;
        case "1034":
            setResponse("500", "500.049.1030", "Internal Server Error", "Error removing handset");
            break;
        default :
            setResponse("500", "500.049.0000", "Internal Server Error", "Internal System Error : " + errorMessage);
            break;
    }
}

function errorSubscribeResultMapping(errorCode, errorMessage) {
    switch(errorCode){
        case "001":
            setResponse("500", "500.035.1001", "Internal Server Error", "Mandatory Attribute missing");
            break;
        case "002":
            setResponse("500", "500.035.1002", "Internal Server Error", "Bind/Unbind exception");
            break;
        case "003":
            setResponse("500", "500.035.1003", "Internal Server Error", "Transport error");
            break;
        case "004":
            setResponse("500", "500.035.1004", "Internal Server Error", "General runtime error");
            break;
        case "005":
            setResponse("500", "500.035.1005", "Internal Server Error", "Security error");
            break;
        case "006":
            setResponse("500", "500.035.1006", "Internal Server Error", "Failed to convert message");
            break;
        case "007":
            setResponse("500", "500.035.1007", "Internal Server Error", "Invalid Request Payload");
            break;
        case "008":
            setResponse("500", "500.035.1008", "Internal Server Error", "Incorrect Request Payload Body");
            break;
        case "009":
            setResponse("500", "500.035.1009", "Internal Server Error", "Incorrect Request Header");
            break;
        case "010":
            setResponse("500", "500.035.1010", "Internal Server Error", errorMessage);
            break;
        case "011":
            setResponse("500", "500.035.1011", "Internal Server Error", errorMessage);
            break;
        case "012":
            setResponse("500", "500.035.1012", "Internal Server Error", "Invalid Date Format");
            break;
        case "013":
            setResponse("500", "500.035.1013", "Internal Server Error", "Invalid RequestMode");
            break;
        case "014":
            setResponse("500", "500.035.1014", "Internal Server Error", "Exceeded the max throttle rate of x within 1000ms for xx user");
            break;
        case "015":
            setResponse("500", "500.035.1015", "Internal Server Error", "Exceeded the max throttle rate of x within 1000ms for xx service");
            break;
        case "999":
            setResponse("500", "500.035.1016", "Internal Server Error", errorMessage);
            break;
        case "52003":
            setResponse("500", "500.035.1017", "Internal Server Error", "Platform authentication failed");
            break;
        case "52004":
            setResponse("405", "405.035.0001", "Method Not Allowed", "Method not allowed");
            break;
        case "52005":
            setResponse("400", "400.035.0001", "Bad Request", "Duplicate transaction request.");
            break;
        case "52007":
            setResponse("400", "400.035.0002", "Bad Request", "Invalid access channel");
            break;
        case "52008":
            setResponse("400", "400.035.0003", "Bad Request", "Invalid msisdn");
            break;
        case "52009":
            setResponse("400", "400.035.0004", "Bad Request", "Invalid profile status");
            break;
        case "52018":
            setResponse("400", "400.035.0005", "Bad Request", "Service not found or service identifier does not exist");
            break;
        case "52020":
            setResponse("400", "400.035.0006", "Bad Request", "Service not active");
            break;
        case "52021":
            setResponse("400", "400.035.0007", "Bad Request", "Charge code does not exist in the service");
            break;
        case "52030":
            setResponse("500", "500.035.1018", "Internal Server Error", "Tps limit exceeded");
            break;
        case "52031":
            setResponse("500", "500.035.1019", "Internal Server Error", errorMessage);
            break;
        case "52032":
            setResponse("500", "500.035.1020", "Internal Server Error", "Transaction failed, internal request timeout occured");
            break;
        case "52033":
            setResponse("500", "500.035.1021", "Internal Server Error", errorMessage);
            break;
        case "52034":
            setResponse("500", "500.035.1022", "Internal Server Error", "Charging gateway is busy(diameter)");
            break;
        case "52036":
            setResponse("400", "400.035.0008", "Bad Request", "No action can be performed for this request");
            break;
        case "52037":
            setResponse("400", "400.035.0009", "Bad Request", "Invalid parameter value");
            break;
        case "52041":
            setResponse("400", "400.035.0010", "Bad Request", "You are already subscribed for this service");
            break;
        case "52049":
            setResponse("400", "400.035.0011", "Bad Request", "Invalid service identifier");
            break;
        default :
            setResponse("500", "500.035.0000", "Internal Server Error", "Internal System Error : " + errorMessage);
            break;
    }
}

// custom error for query usage sammary
function errorQueryUsageSummaryResultMapping(errorCode, errorMessage){
 switch(errorCode){
        case "000":
            setResponse("500", "500.061.1001", "Internal Server Error", "General Transport error");
            break;
        case "001":
            setResponse("500", "500.061.1002", "Internal Server Error", "General Runtime error");
            break;
        case "002":
            setResponse("500", "500.061.1003", "Internal Server Error", "General parse failure from binding layer");
            break;
        case "003":
            setResponse("500", "500.061.1004", "Internal Server Error", "WS-I compliance failure");
            break;
        case "004":
            setResponse("500", "500.061.1005", "Internal Server Error", "Message must be a soap:Envelope ");
            break;
        case "005":
            setResponse("500", "500.061.1006", "Internal Server Error", "A soap:Envelope must contain a soap:Body");
            break;
        case "006":
            setResponse("500", "500.061.1007", "Internal Server Error", errorMessage);
            break;
        case "007":
            setResponse("500", "500.061.1008", "Internal Server Error", "OSB service callout action received an unrecognized response. XML details: An Unrecognized Response was Received");
            break;
        case "008":
            setResponse("500", "500.061.1009", "Internal Server Error", "OSB service callout has received an error response from the server XML details: An Unknown Error Response Was Received");
            break;
        case "009":
            setResponse("500", "500.061.1010", "Internal Server Error", "OSB Validate action validation failed. XML details: Validation Failed");
            break;
        case "010":
            setResponse("500", "500.061.1011", "Internal Server Error", errorMessage);
            break;
        case "011":
            setResponse("500", "500.061.1012", "Internal Server Error", errorMessage);
            break;
        case "999":
            setResponse("500", "500.061.1013", "Internal Server Error", errorMessage);
            break;
        case "CBS-0-405960006":
            setResponse("400", "400.061.0001", "Bad Request", "Not support Corporate case.");
            break;
        case "CBS-0-405960561":
            setResponse("400", "400.061.0002", "Bad Request", "The date span between the start date and end date is larger than One Month.");
            break;
        case "CBS-0-102011685":
            setResponse("400", "400.061.0003", "Bad Request", "Account code doesn't exist. This errorcode should be valid for all services of CBS.");
            break;
        case "CBS-0-102011686":
            setResponse("400", "400.061.0004", "Bad Request", "In the request of the API, the MSISDN and AccountID are optional. If these two values are not matched with AccountCode, the API will response failure.");
            break;
        case "CBS-0-102010248":
            setResponse("400", "400.061.0005", "Bad Request", "If subscriber number head is not found in DTAC CBS or DTN CBS platform.");
            break;
        case "CBS-0-102012044":
            setResponse("400", "400.061.0006", "Bad Request", "Request can not be processed as subscriber is under migration or subscriber number head is under migration.");
            break;
        case "CBS-0-102012045":
            setResponse("400", "400.061.0007", "Bad Request", "Service Request can not be processed as subscriber is under porting.");
            break;
        case "CBS-0-102012046":
            setResponse("400", "400.061.0008", "Bad Request", "Subscriber can not be ported to DTN platform as another service request is under process in DTAC platform.");
            break;
        case "CBS-0-102012047":
            setResponse("400", "400.061.0009", "Bad Request", "DTAC CBS receives request and subscriber number head belong to DTAC CBS, but subscriber doesn’t belong to DTAC CBS.");
            break;
        case "CBS-0-405960566":
            setResponse("400", "400.061.0010", "Bad Request", "The length of parameter startMonth is incorrect.");
            break;
        case "B-POR-00014":
            setResponse("400", "400.061.0009", "Bad Request", "Not found Subscriber");
            break;
        case "T-POR-00001":
            setResponse("500", "500.061.1014", "Internal Server Error", "System Error");
            break;
        default :
            setResponse("500", "500.061.0000", "Internal Server Error", "Internal System Error : " + errorMessage);
            break;
    }
}


function errorValidatePreToPostResultMapping(errorCode, errrorMessage){
   switch(errorCode){
        case "B-POR-00001":
            setResponse("400", "400.069.0001", "Bad Request", "Pre2Post not valid");
            break;
        case "B-POR-00004":
            setResponse("400", "400.069.0002", "Bad Request", "IDCard incorrect");
            break;
        case "B-POR-00006":
            setResponse("400", "400.069.0003", "Bad Request", "Subscriber is not prepaid");
            break;
        case "B-POR-00007":
            setResponse("400", "400.069.0004", "Bad Request", "CustGroupCode not equal zero");
            break;
        case "B-POR-00008":
            setResponse("400", "400.069.0005", "Bad Request", "Not registered by IDCard");
            break;
        case "B-POR-00010":
            setResponse("400", "400.069.0006", "Bad Request", "Prepaid register flag not pass");
            break;
        case "B-POR-00011":
            setResponse("400", "400.069.0007", "Bad Request", "Document flag not pass");
            break;
        case "B-POR-00015":
            setResponse("400", "400.069.0008", "Bad Request", "Invalid username or password");
            break;
        case "B-POR-00022":
            setResponse("400", "400.069.0009", "Bad Request", "Please wait for the results of the document review");
            break;
        case "B-POR-00024":
            setResponse("400", "400.069.0010", "Bad Request", "Invalid Billing Product");
            break;
        case "B-POR-00002":
            setResponse("403", "403.069.0001", "Forbidden", "Validate Pre2Post not valid");
            break;
        case "B-POR-00009":
            setResponse("403", "403.069.0002", "Forbidden", "User is blacklist");
            break;
        case "B-POR-00003":
            setResponse("403", "403.069.0003", "Forbidden", "Save Pre2Post not valid");
            break;
        case "B-POR-00012":
            setResponse("403", "403.069.0004", "Forbidden", "SavePre2PostDoc ECM Failed");
            break;
        case "B-POR-00014":
            setResponse("404", "404.069.0002", "Resource not found", "Not found Subscriber");
            break;
        case "B-POR-00013":
            setResponse("404", "404.069.0003", "Resource not found", "Invalid customer occupation");
            break;
        case "B-POR-00016":
            setResponse("404", "404.069.0004", "Resource not found", "No table or index for purge data");
            break;
        case "T-POR-00001":
            setResponse("500", "500.069.1001", "Internal Server Error", "System Error");
            break;
        default :
            setResponse("500", "500.069.0000", "Internal Server Error", "Internal System Error : " + errorMessage);
            break;
    }
}

function errorSavePreToPostResultMapping(errorCode, errorMessage){
   switch(errorCode){
        case "B-POR-00003":
            setResponse("400", "400.070.0001", "Bad Request", "Save Pre2Post not valid");
            break;
        case "B-POR-00005":
            setResponse("400", "400.070.0002", "Bad Request", "Cannot change package from prepaid package to postpaid package");
            break;
        case "B-POR-00013":
            setResponse("400", "400.070.0003", "Bad Request", "Invalid customer occupation");
            break;
        case "B-POR-00014":
            setResponse("404", "404.070.0002", "Resource not found", "Not found Subscriber");
            break;
        case "T-POR-00001":
            setResponse("500", "500.070.1001", "Internal Server Error", "System Error");
            break;
        case "T-POR-00002":
            setResponse("500", "500.070.1002", "Internal Server Error", "Cannot Connect ECM");
            break;
        default :
            setResponse("500", "500.070.0000", "Internal Server Error", "Internal System Error : " + errorMessage);
            break;
    }
}
function errorEscCdrResultMapping(errorCode, errorMessage, errorStatus) {
    switch(errorStatus){
        case "E":
            setResponse("400", "400.096.0001", "Bad Request", errorMessage);
            break; 
        case "X":
            setResponse("400", "400.096.0002", "Bad Request", errorMessage);
            break;
        case "F":
            setResponse("500", "500.096.0003", "Internal Server Error", errorMessage);
            break;
        default :
            setResponse("500", "500.096.1001", "Internal Server Error", "Internal System Error : " + errorMessage);
            break;
    }
}

function errorGetBlockListResultMapping(errorCode, errorMessage){
     switch(errorCode){
        case "52001":
            setResponse("500", "500.047.1017", "Internal Server Error", errorMessage);
            break;
        case "52002":
            setResponse("400", "400.047.0003", "Bad Request", errorMessage);
            break;
        case "52003":
            setResponse("500", "500.047.1018", "Internal Server Error", "Platform authentication failed");
            break;
        case "52004":
            setResponse("405", "405.047.0001", "Method Not Allowed", "Method Not Allowed");
            break;
        case "52005":
            setResponse("400", "400.047.0004", "Bad Request", "Duplicate transaction request.");
            break;
        case "52006":
            setResponse("400", "400.047.0005", "Bad Request", errorMessage);
            break;
        case "52007":
            setResponse("400", "400.047.0006", "Bad Request", "Invalid access channel");
            break;
        case "52008":
            setResponse("400", "400.047.0007", "Bad Request", "Invalid msisdn");
            break;
        case "52009":
            setResponse("400", "400.047.0008", "Bad Request", "Invalid profile status");
            break;
        case "52010":
            setResponse("400", "400.047.0009", "Bad Request", "Invalid language parameter value");
            break;
        case "52011":
            setResponse("400", "400.047.0010", "Bad Request", "Invalid employee flag value");
            break;
        case "52012":
            setResponse("400", "400.047.0011", "Bad Request", "Invalid dnd flag value");
            break;
        case "52013":
            setResponse("400", "400.047.0012", "Bad Request", "Invalid blocklist value");
            break;
        case "52014":
            setResponse("400", "400.047.0013", "Bad Request", "Invalid service category");
            break;
        case "52015":
            setResponse("400", "400.047.0014", "Bad Request", "Invalid service sub category");
            break;
        case "52016":
            setResponse("400", "400.047.0015", "Bad Request", "Service list not found for the pass request");
            break;
        case "52017":
            setResponse("400", "400.047.0016", "Bad Request", "Invalid pagination start index");
            break;
        case "52018":
            setResponse("400", "400.047.0017", "Bad Request", "Service not found or service identifier does not exist");
            break;
        case "52019":
            setResponse("400", "400.047.0018", "Bad Request", "Product identifier not found in passed service");
            break;
        case "52020":
            setResponse("400", "400.047.0019", "Bad Request", "Service not active");
            break;
        case "52021":
            setResponse("400", "400.047.0020", "Bad Request", "Charge code does not exist in the service");
            break;
        case "52022":
            setResponse("400", "400.047.0021", "Bad Request", "Invalid auto renewal flag value");
            break;
        case "52023":
            setResponse("400", "400.047.0022", "Bad Request", "Invalid charge user flag value");
            break;
		case "52024":
            setResponse("400", "400.047.0023", "Bad Request", "Subscriber does not have any subscription based transactions for the passed request");
            break;
		case "52025":
            setResponse("400", "400.047.0024", "Bad Request", "Subscriber does not have any transactions made on the platform for the passed request");
            break;
		case "52026":
            setResponse("400", "400.047.0025", "Bad Request", "Invalid transaction type filter value");
            break;
		case "52028":
            setResponse("400", "400.047.0026", "Bad Request", "Refund transaction failed, charging reference code does not exist");
            break;
		case "52029":
            setResponse("400", "400.047.0027", "Bad Request", "MNP port out transaction failed, subscriber already in port out state");
            break;
        case "52030":
		case "52144":
		case "52145":
		case "52146":
            setResponse("500", "500.047.1019", "Internal Server Error", "Tps limit exceeded");
            break;
        case "52031":
            setResponse("500", "500.047.1020", "Internal Server Error", errorMessage);
            break;
        case "52032":
            setResponse("500", "500.047.1021", "Internal Server Error", "Transaction failed, internal request timeout occured");
            break;
        case "52033":
            setResponse("500", "500.047.1022", "Internal Server Error", errorMessage);
            break;
        case "52034":
            setResponse("500", "500.047.1023", "Internal Server Error", "Charging gateway is busy(diameter)");
            break;
        case "52035":
            setResponse("403", "403.047.0001", "Forbidden", errorMessage);
            break;
		case "52036":
            setResponse("400", "400.047.0028", "Bad Request", "No action can be performed for this request");
            break;
        case "52037":
            setResponse("400", "400.047.0029", "Bad Request", "Invalid parameter value");
            break;
		case "52038":
            setResponse("400", "400.047.0030", "Bad Request", "Otp transaction reference and otp pin does not match ");
            break;
		case "52039":
            setResponse("400", "400.047.0031", "Bad Request", "Transaction reference code does not exist or taransaction not found in last 10 mins ");
            break;
		case "52040":
            setResponse("400", "400.047.0032", "Bad Request", "OTP no of attempts exceeded");
            break;	
		case "52041":
            setResponse("400", "400.047.0033", "Bad Request", "You are already subscribed for this service");
            break;
		case "52042":
            setResponse("400", "400.047.0034", "Bad Request", "Subscriber not available");
            break;
		case "52043":
             setResponse("500", "500.047.1024", "Internal Server Error", "IP is not from whitelist");
            break;
		case "52044":
            setResponse("400", "400.047.0035", "Bad Request", "Subscriber already exists");
            break;
		case "52045":
            setResponse("400", "400.047.0036", "Bad Request", "Tax rules not found");
            break;
			
		case "52046":
            setResponse("400", "400.047.0037", "Bad Request", "Invalid stop request type");
            break;
		case "52047":
            setResponse("400", "400.047.0038", "Bad Request", "Invalid stop request type");
            break;
		case "52048":
            setResponse("400", "400.047.0039", "Bad Request", "Invalid service group type");
            break;
		case "52049":
            setResponse("400", "400.047.0040", "Bad Request", "Invalid service identifier");
            break;
		case "52050":
            setResponse("400", "400.047.0041", "Bad Request", "Service group is already in block list");
            break;
		case "52051":
            setResponse("400", "400.047.0042", "Bad Request", "Service is already in block list");
            break;
		case "52052":
            setResponse("400", "400.047.0043", "Bad Request", "Charge amount exceeded the allowed range");
            break;
		case "52053":
            setResponse("400", "400.047.0044", "Bad Request", "Resend OTP attempts exceded");
            break;
		case "52054":
            setResponse("400", "400.047.0045", "Bad Request", errorMessage);
            break;
		case "52055":
            setResponse("400", "400.047.0046", "Bad Request", "Spam words exits in the message");
            break;
		case "52056":
		case "52091":
            setResponse("400", "400.047.0047", "Bad Request", "Subscriptions does not exist for the subscriber");
            break;
		case "52057":
            setResponse("400", "400.047.0048", "Bad Request", "Subscriber does not have any block list");
            break;
		case "52058":
            setResponse("400", "400.047.0049", "Bad Request", "No data exists for the intiated request");
            break;
		case "52059":
            setResponse("400", "400.047.0050", "Bad Request", errorMessage);
            break;
		case "52154":
		case "52141":
            setResponse("400", "400.047.0051", "Bad Request", errorMessage);
            break;
		case "52155":
            setResponse("400", "400.047.0052", "Bad Request", "Charging failed as  range based has been disabled");
            break;
        case "52138":
            setResponse("400", "400.047.0053", "Bad Request", "Send to friend not allowed");
            break;
		 case "52139":
            setResponse("400", "400.047.0054", "Bad Request", "Invalid refund reason code");
            break;
        
        case "52140":
		case "52149":
		case "52150":
		case "52151":
		case "52152":
            setResponse("400", "400.047.0055", "Bad Request", "Eligibility check failed");
            break;
        default:
            setResponse("500", "500.047.0000", "Internal Server Error", "Internal System Error : {" + errorMessage + "}");
            break;
    }
}
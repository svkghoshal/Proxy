var errrorCode = "" + context.getVariable("resp.apiResponseCode");
var errrorMessage = "" + context.getVariable("resp.apiResponseMessage");
var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("request.verb", "GET");

printProxyRequest(requestContent);
printTargetResponse(responseContent);

if(errrorCode === "1") {
    setResponse("200", "200", "", "");
    mapFupBalanceToJson();
} else {
    if(errrorCode === "129002") {
        errrorMessage = "Endpoint exception: " + context.getVariable("resp.endpointName") + ";" + context.getVariable("resp.endpointErrorCode") + ";" + context.getVariable("resp.endpointErrorMessage");
    }
    errorFupBalanceResultMapping(errrorCode, errrorMessage);
}
setReasonPhrase(context.getVariable("resp.httpStatusCode"));
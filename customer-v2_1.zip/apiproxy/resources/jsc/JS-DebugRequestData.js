var path = context.getVariable("proxy.pathsuffix");

switch(path) {
    case "/balance":
    case "/score":
    case "/profile":
        context.setVariable("southboundService1EndpointUrlDatetime", "" + getDatetime());
        context.setVariable("southboundService1RequestDatetime", "" + getDatetime());
        break;
    default:
        break;
}
context.setVariable("southbound.requestdatetime", getTimestamp());
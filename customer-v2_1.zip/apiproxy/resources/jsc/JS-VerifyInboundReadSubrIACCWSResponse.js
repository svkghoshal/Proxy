var errorCode = context.getVariable("resp.readSubr.messageSqlCode");
var errorMessage = context.getVariable("resp.readSubr.messageTextEng");
var requestContent = "" + context.getVariable("readSubrIACCWSRequest.content");
var responseContent = "" + context.getVariable("readSubrIACCWSResponse.content");

printTargetResponse(responseContent);

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));

context.setVariable("southbound.responsedatetime", getTimestamp());
context.setVariable("southboundService1ResponseDatetime", getDatetime());
context.setVariable("southboundSevice1.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southboundSevice1.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("southboundSevice1.target.server", getServiceCalloutTargetServer());
context.setVariable("request.verb", "GET");

if (!isEmpty(errorCode)) {
    errorReadSubrIACCWSResultMapping(errorCode, errorMessage);
    setReasonPhrase(context.getVariable("resp.code"));
} else {
    var compCode = "" + context.getVariable("resp.readSubr.compCode");

    if(compCode == 10) {
        var isEnableHttps = (context.getVariable("queryBalanceDtacIsEnableHttps") === "true");
        context.setVariable("isEnableHttps", isEnableHttps);
        context.setVariable("endpointUrl", context.getVariable("queryBalanceDtacEndpoint"));
    } else if (compCode == 20) {
        var isEnableHttps = (context.getVariable("queryBalanceDtnIsEnableHttps") === "true");
        context.setVariable("isEnableHttps", isEnableHttps);
        context.setVariable("endpointUrl", context.getVariable("queryBalanceDtnEndpoint"));
    }
    setResponse("200", "200", "", "");
    context.setVariable("req.sentDttm", getTimePatternForService1());
}

function getServiceCalloutTargetServer() {
    return context.getVariable("servicecallout.requesturi");
}
function printProxyRequest(data) {
    print("Proxy Request = " + data);
}

function printTargetResponse(data) {
    print("Target Response = " + data);
    print("------------------------------------------------------------------");
}

function isEmpty(data){
    return (data === "" || data === "null" || data === "undefined" || 
            data === null || data === undefined || 0 === data.length);
}

function convertMobileNotoPrefix66(mobileNo){
    if(mobileNo.match("(0)[0-9]{9}")){
        mobileNo = "66" + mobileNo.substring(1, mobileNo.length);
    }
    
    return mobileNo;
}

function getYYYYMMddHHmmssSSSWithoutSymbolUseDate(today) {
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSeconds = checkLengthMillisecFormat("" + today.getMilliseconds());
    
    return year + month + day + hour + minute + second + milliSeconds;
}

function getYYYYMMddHHmmssWithoutSymbolUseDate(today) {
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    
    return year + month + day + hour + minute + second;
}

function getYYYYMMddHHmmssWithoutSymbol() {
    var today = new Date();
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    
    return year + month + day + hour + minute + second;
}

function getTimestamp() {
    var nowTimestamp = new Date().getTime();
    
    return nowTimestamp;
}

function getDatetime() {
    var nowTimestamp = new Date().getTime();
    var nowDatetime = getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(nowTimestamp);
    
    return nowDatetime;
}

function getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(dateTime) {
    var today = new Date(dateTime);
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second + "," + milliSecond;
}

function getYYYYMMddHHmmssSSSWithSymbolDotUseDate(today) {
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + "T" + hour + ":" + minute + ":" + second + "." + milliSecond;
}

function getTimePatternForService1() {
    var today = new Date();
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + "T" + hour + ":" + minute + ":" + second + "." + milliSecond;
}

function checkLengthDateFormat(today) {
    if(today.length == 1) {
        today = "0" + today;
    }
    
    return today;
}

function checkLengthMillisecFormat(milli) {
    if(milli.length == 1) {
        milli = "00" + milli;
    } else if(milli.length == 2) {
        milli = "0" + milli;
    }
    
    return milli;
}

function trimErrorCodeEsb(errorCode) {
    var trimCode = errorCode;
    
    if(errorCode !== "ESB_14000") {
        trimCode = errorCode.substring(6, errorCode.length);
    }
    
    return trimCode;
}

function trimErrorMessageEsb(errorMessage) {
    var index = errorMessage.indexOf(")");
    var trimMessage = errorMessage.substring((index+1), errorMessage.length).trim();
    
    return trimMessage;
}

function trimErrorCodeOm(errorMessage) {
    var indexFirst = errorMessage.indexOf("-") + 1;
    var indexLast = errorMessage.indexOf(")");
    
    return errorMessage.substring(indexFirst, indexLast);
}

function trimErrorMessageOm(errorMessage) {
    var indexFirst = errorMessage.indexOf(":") + 1;
    
    return errorMessage.substring(indexFirst);
}

function trimErrorMessageSdp(errorMessage) {
    var indexFirst = errorMessage.indexOf(")") + 2;
    
    return errorMessage.substring(indexFirst);
}


function setNorthSouthJsonRequestResponse(text) {
    var content = text.replace(/(\r\n|\n|\r)/gm, '');
    var contentRemoveSpace = content.replace(/([^"]+)|""|("[^"]+")/g, function($0, $1, $2) {
        if ($1) {
            return $1.replace(/\s/g, '');      
        } else {
            return $0;   
        }
    });
    
    return contentRemoveSpace.trim();
}

function setNorthSouthSoapRequestResponse(text) {
    var content = text.replace(/(\r\n|\n|\r)/gm, '');
    var contentRemoveSpace = content.replace(/([>][ ]+[<])/g, function($0, $1, $2) {
        if ($0) {
            return $0.replace(/\s/g, '');      
        } else {
            return $1;   
        } 
    });
    
    return contentRemoveSpace.trim();
}

function getTargetServer() {
    var path = context.getVariable("proxy.pathsuffix");
    if(path == "/profile"){
        if(isEmpty(context.getVariable("servicecallout.requesturi"))) {
            return context.getVariable("endpointUrl");
        }else{
             return context.getVariable("getSubrBlockListRequest.url");
        }
    }else{
        if(isEmpty(context.getVariable("targetStartTime")) && isEmpty(context.getVariable("targetEndTime"))) {
            return "";
        } else {
            return context.getVariable("endpointUrl");
        }
    }
    
    
}

function setResponse(httpStatusCode, statusCode, statusDesc, statusMsg) {
    context.setVariable("resp.httpStatusCode", httpStatusCode);
    context.setVariable("resp.code", statusCode);
    context.setVariable("resp.error", statusDesc);
    context.setVariable("resp.message", statusMsg);
}

function setReasonPhrase(respCode){
    switch(respCode){
        case "200" :
            context.setVariable("resp.reasonPhrase", "OK");
            break;
        case "400" :
            context.setVariable("resp.reasonPhrase", "Bad Request");
            break;
        case "500" :
            context.setVariable("resp.reasonPhrase", "Internal Server Error");
            break;
    }
}

function decryptByAES(encrypted, key) {
	var plain = Aes.Ctr.decrypt(encrypted, key, 256);
	return plain;
}

function getDecryptedDataAuthen(ciphertext,key){
    var ciphertextDecrypt = decryptByAES(ciphertext, key);
    print("ciphertextDecrypt : " + ciphertextDecrypt);
    return ciphertextDecrypt;
}

function getMaxDateExpire(dateTime, increaseMinute){
    increaseMinute = increaseMinute/60;
    var year = dateTime.substring(0, 4);
    var month = dateTime.substring(4, 6);
    var date = dateTime.substring(6, 8);
    var hours = dateTime.substring(8, 10);
    var minutes = dateTime.substring(10, 12);
    var d = new Date();
    d.setYear(year);
    d.setMonth(month-1);
    d.setDate(date);
    d.setHours(hours);
    d.setMinutes(minutes);
    d.setHours(d.getHours() + increaseMinute);
    return getYYYYMMddHHmmssWithoutSymbolUseDate(d).substring(0,12);
}

function convertSymbol(text){
    //Convert space from query param to +
    var result = "";
    if(!isEmpty(text)){
        result = text.replace(/ +/g, "+");
    }
    return result;
}

function formatDate(strDate){
    var year, month, date, hour, minutes;
    year = strDate.substring(0,4);
	month = strDate.substring(4,6);
	date = strDate.substring(6,8);
	hour = strDate.substring(8,10);
	minutes = strDate.substring(10,12);
	var dateFormat = year + "/" + month + "/" + date + " " + hour + ":" + minutes;
	var dateResult = new Date(dateFormat);
	return dateResult
}

function getDateAndTimeHourMinuteFormat(date) {
    var day = checkLengthDateFormat("" + date.getDate());
    var month = checkLengthDateFormat("" + (date.getMonth() + 1));
    var year = checkLengthDateFormat("" + date.getFullYear());
    var hour = checkLengthDateFormat("" + date.getHours());
    var minute = checkLengthDateFormat("" + date.getMinutes());
    
    return year + month + day + hour + minute;
}

function matchDateFormatYYYYMMDDHHmm(strDate){
    
    if(!isEmpty(strDate)){
        if((/^([0-9]){12}$/).test(strDate)){
            return true;
        }
        else{
            return false;
        }
    }
    else{
        return false;
    }
    
}
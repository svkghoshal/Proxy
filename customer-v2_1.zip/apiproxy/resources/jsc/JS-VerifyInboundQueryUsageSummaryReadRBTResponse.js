var errorCode = "" + context.getVariable("resp.errorCode");
var statusType = ""+context.getVariable("resp.statusType");
var server = ""+context.getVariable("resp.server");
var errorMessage = "" + context.getVariable("resp.errorMessage");
var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");

context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("southbound.request", setNorthSouthJsonRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthJsonRequestResponse(responseContent));
context.setVariable("request.verb", "POST");

printProxyRequest(requestContent);
printTargetResponse(responseContent);

if(statusType === 'S'){
    context.setVariable("resp.responseMessage", mapRTBDataList());
    setResponse("200", "200", "", "");
}else{
    errorQueryUsageSummaryResultMapping(errorCode, errorMessage);
}

function mapRTBDataList() {
    var byMonth = context.getVariable("resp.byMonth");
    var byYear = context.getVariable("resp.byYear");
    var jsonRtbDataList = parseDeleteRtbDataList();
    
    var response = {
        "transactionId" : context.getVariable("req.transactionId"),
        "effectiveDate" : context.getVariable("resp.responseDttm"),
        "bucket"        : []
    };
    
    var stringRtbDataList = JSON.stringify(jsonRtbDataList);
        stringRtbDataList = stringRtbDataList.substring(1, stringRtbDataList.length - 1) + ",";
    var numberOfRightParenthesis = (stringRtbDataList.match(/{/g) || []).length;
    var arrayRtb = [];
    for(index = 0; index < numberOfRightParenthesis; index++) {
        arrayRtb.push(JSON.parse("{" + stringRtbDataList.substring(0, stringRtbDataList.indexOf("},") + 1) + "}"));
        stringRtbDataList = stringRtbDataList.substring(stringRtbDataList.indexOf("},") + 2, stringRtbDataList.length);
    }
    
    for(index = 0; index < arrayRtb.length; index++) {
        var usageType = "";
        var bucketObj = null;
        if(!isEmpty(arrayRtb[index].mou)) {
            usageType = "MOU";
            bucketObj = arrayRtb[index].mou;
        } else if(!isEmpty(arrayRtb[index].internetUsage)) {
            usageType = "Internet";
            bucketObj = arrayRtb[index].internetUsage;
        } else if(!isEmpty(arrayRtb[index].refillAmount)) {
            usageType = "Refill";
            bucketObj = arrayRtb[index].refillAmount;
        } else if(!isEmpty(arrayRtb[index].arpu)) {
            usageType = "ARPU";
            bucketObj = arrayRtb[index].arpu;
        } else {
            usageType = JSON.stringify(arrayRtb[index]).match(/"([^"]+)"/)[1];
            bucketObj = arrayRtb[index][usageType];
        }
        
        var bucketObject = {
            "id"    : index + 1,
            "usageType" : usageType,
            "bucketCounter" : []
        };
        
        var dataInsideBucketObj = JSON.stringify(bucketObj);
        var numberOfDataInside = (dataInsideBucketObj.match(/:/g) || []).length;
        
        for(index1 = 0; index1 < numberOfDataInside; index1++) {
            var valueBucketCounter = dataInsideBucketObj.match(/"([^"]+)"/)[1];
            var bucketCounterObject = {
                "value" : bucketObj[valueBucketCounter],
                    "validFor" : {
                        "byMonth"   : byMonth,
                        "byYear"    : byYear,
                        "byCycle"   : getByCycle(valueBucketCounter)
                    }
            };
            dataInsideBucketObj = dataInsideBucketObj.substring(dataInsideBucketObj.indexOf(",") + 1, dataInsideBucketObj.length);
            bucketObject.bucketCounter.push(bucketCounterObject);
        }
        response.bucket.push(bucketObject);
    }
    
    return JSON.stringify(response);
}

function parseDeleteRtbDataList() {
    var listObject = JSON.parse(context.getVariable("resp.rtbDataList"));
    delete listObject.monthData;
    delete listObject.yearData;
    delete listObject.subrNumb;
    delete listObject.custNumb;
    
    return listObject;
}

function getByCycle(valueBucketCounter) {
    if(valueBucketCounter == "previous_1m") {
        return "01";
    } else if(valueBucketCounter == "previous_2m") {
        return "02";
    } else if(valueBucketCounter == "average_3m") {
        return "03";
    }
}

setReasonPhrase(context.getVariable("resp.httpStatusCode"));
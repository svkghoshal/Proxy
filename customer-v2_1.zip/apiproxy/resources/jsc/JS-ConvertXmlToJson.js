function mapBalanceToJson() {
    var hpyBonFreList = [];
    var bonBalList = [];
    
    if(!isEmpty(context.getVariable("resp.HpyBonFreList"))) {
        hpyBonFreList = checkLengthArray(JSON.parse(context.getVariable("resp.HpyBonFreList")));
    }
    if(!isEmpty(context.getVariable("resp.BonBalList"))) {
        bonBalList = checkLengthArray(JSON.parse(context.getVariable("resp.BonBalList")));
    }
    
    context.setVariable("resp.listFreeBonusJson", setListFreeBonus(hpyBonFreList));
    context.setVariable("resp.listBonusJson", setListBonus(bonBalList));
}

function mapFupBalanceToJson() {
    var fupToppingList = [];
    var fupOnTopList = [];
    var fupMainList = [];
    
    if(!isEmpty(context.getVariable("resp.FupToppingList"))) {
        fupToppingList = checkLengthArray(JSON.parse(context.getVariable("resp.FupToppingList")));
    }
    if(!isEmpty(context.getVariable("resp.FupOnTopList"))) {
        fupOnTopList = checkLengthArray(JSON.parse(context.getVariable("resp.FupOnTopList")));
    }
    if(!isEmpty(context.getVariable("resp.FupMainList"))) {
        fupMainList = checkLengthArray(JSON.parse(context.getVariable("resp.FupMainList")));
    }
    
    context.setVariable("resp.listFupToppingJson", setListFupToping(fupToppingList));
    context.setVariable("resp.listFupOnTopJson", setListFupOnTop(fupOnTopList));
    context.setVariable("resp.listFupMainJson", setListFupMain(fupMainList));
}

function setListFupToping(fupToppingList){
    var listFupTopping = [];
    
    if(Array.isArray(fupToppingList)){
        fupToppingList.forEach(function(e){
            var fupToping = {
                groupName : e.GroupName,
                packType : e.PackType,
                packTypeDesc : e.PackTypeDesc,
                maxSpd : e.MaxSpd,
                fupQuot : e.FupQuot,
                thrtSpd : e.ThrtSpd,
                fupAlert : e.FupAlrt,
                currUsge : e.CurrUsge,
                remnUsge : e.RemnUsge,
                fupStatus : e.FupStatus
            };
            listFupTopping.push(fupToping);
        });
    }

    return JSON.stringify(listFupTopping);
}

function setListFupOnTop(fupOnTopList){
    var listFupOnTop = [];
    
    if(Array.isArray(fupOnTopList)){
        fupOnTopList.forEach(function(e){
            var fupOnTop = {
                groupName : e.GroupName,
                packType : e.PackType,
                packTypeDesc : e.PackTypeDesc,
                maxSpd : e.MaxSpd,
                fupQuot : e.FupQuot,
                thrtSpd : e.ThrtSpd,
                fupAlert : e.FupAlrt,
                currUsge : e.CurrUsge,
                remnUsge : e.RemnUsge,
                fupStatus : e.FupStatus
            };
            listFupOnTop.push(fupOnTop);
        });
    }
    return JSON.stringify(listFupOnTop);
}

function setListFupMain(fupMainList){
    var listFupMain = [];
    
    if(Array.isArray(fupMainList)){
        fupMainList.forEach(function(e){
            var fupMain = {
                groupName : e.GroupName,
                packType : e.PackType,
                packTypeDesc : e.PackTypeDesc,
                maxSpd : e.MaxSpd,
                fupQuot : e.FupQuot,
                thrtSpd : e.ThrtSpd,
                fupAlert : e.FupAlrt,
                currUsge : e.CurrUsge,
                remnUsge : e.RemnUsge,
                fupStatus : e.FupStatus
            };
            listFupMain.push(fupMain);
        });
    }
    return JSON.stringify(listFupMain);
}

function mapQueryCdrToJson(){
    var voiceCDRList = [];
    var dataCDRList = [];
    var smsCDRList = [];
    var mmsCDRList = [];
    var contentCDRList = [];
    var otherServicesCDRList = [];
    
    if(!isEmpty(context.getVariable("resp.VoiceCDRList"))) {
        voiceCDRList = checkLengthArray(JSON.parse(context.getVariable("resp.VoiceCDRList")));
    }
    if(!isEmpty(context.getVariable("resp.DataCDRList"))) {
        dataCDRList = checkLengthArray(JSON.parse(context.getVariable("resp.DataCDRList")));
    }
    if(!isEmpty(context.getVariable("resp.SmsCDRList"))) {
        smsCDRList = checkLengthArray(JSON.parse(context.getVariable("resp.SmsCDRList")));
    }
    if(!isEmpty(context.getVariable("resp.MmsCDRList"))) {
        mmsCDRList = checkLengthArray(JSON.parse(context.getVariable("resp.MmsCDRList")));
    }
    if(!isEmpty(context.getVariable("resp.ContentCDRList"))) {
        contentCDRList = checkLengthArray(JSON.parse(context.getVariable("resp.ContentCDRList")));
    }
    if(!isEmpty(context.getVariable("resp.OtherServicesCDRList"))) {
        otherServicesCDRList = checkLengthArray(JSON.parse(context.getVariable("resp.OtherServicesCDRList")));
    }
    
    context.setVariable("resp.listVoiceCDRsJson", setListVoiceCDR(voiceCDRList));
    context.setVariable("resp.listDataCDRsJson", setListDataCDR(dataCDRList));
    context.setVariable("resp.listSmsCDRsJson", setListSmsCDR(smsCDRList));
    context.setVariable("resp.listMmsCDRsJson", setListMmsCDR(mmsCDRList));
    context.setVariable("resp.listContentCDRsJson", setListContentCDR(contentCDRList));
    context.setVariable("resp.listOtherServicesCDRsJson", setListOtherServicesCDR(otherServicesCDRList));
}

function setListVoiceCDR(voiceCDRList){
    var listVoiceCDRs = [];
    
    if(Array.isArray(voiceCDRList)){
        voiceCDRList.forEach(function(e){
            var voiceCDRs = {
                usageService : {
                    usageServiceTypeGroup : {
                        id : checkDataString(e.UsageServiceTypeGroupID),
                        value : checkDataString(e.UsageServiceTypeGroup)
                    },
                    usageServiceType : {
                        id : checkDataString(e.UsageServiceTypeID),
                        value : checkDataString(e.UsageServiceType)
                    },
                    usageDuration : e.UsageDuration
                },
                startDTTM : e.StartDTTM,
                endDTTM : e.EndDTTM,
                chargedDuration : e.ChargedDuration,
                balType : e.BalType,
                acctTypeDesc : e.AcctTypeDesc,
                amount : e.Amount,
                callingCell : {
                    id : checkDataString(e.CallingCellID),
                    desc : checkDataString(e.CallingCellDesc)
                },
                calledCell : {
                    id : checkDataString(e.CalledCellID),
                    desc : checkDataString(e.CalledCellDesc),
                    party : checkDataString(e.CalledPartyNumb)
                }
            };
            listVoiceCDRs.push(voiceCDRs);
        });
    }
    return JSON.stringify(listVoiceCDRs);
}

function setListDataCDR(dataCDRList){
    var listDataCDRs = [];
    if(Array.isArray(dataCDRList)){
        dataCDRList.forEach(function(e){
            var dataCDRs = {
                usageService : {
                    usageServiceTypeGroup : {
                        id : checkDataString(e.UsageServiceTypeGroupID),
                        value : checkDataString(e.UsageServiceTypeGroup),
                    },
                    usageServiceType : {
                        id : checkDataString(e.UsageServiceTypeID),
                        value : checkDataString(e.UsageServiceType),
                    },
                    usageDuration : checkDataString(e.UsageDuration)
                },
                startDTTM : e.StartDTTM,
                endDTTM : e.EndDTTM,
                chargedDuration : e.ChargedDuration,
                balType : e.BalType,
                acctTypeDesc : e.AcctTypeDesc,
                amount : e.Amount,
                callingCell : {
                    id : checkDataString(e.CallingCellID),
                    desc : checkDataString(e.CallingCellDesc)
                },
                usageFlux : checkDataString(e.UsageFlux),
                chargedFlux : checkDataString(e.ChargedFlux)
            };
            listDataCDRs.push(dataCDRs);
        });
    }
    return JSON.stringify(listDataCDRs); 
}

function setListSmsCDR(smsCDRList){
    var listSmsCDRs = [];
    
    if(Array.isArray(smsCDRList)){
        smsCDRList.forEach(function(e){
            var smsCDRs = {
                usageService : {
                    usageServiceTypeGroup : {
                        id : checkDataString(e.UsageServiceTypeGroupID),
                        value : checkDataString(e.UsageServiceTypeGroup)
                    },
                    usageServiceType : {
                        id : checkDataString(e.UsageServiceTypeID),
                        value : checkDataString(e.UsageServiceType)
                    }
                },
                startDTTM : e.StartDTTM,
                balType : e.BalType,
                acctTypeDesc : e.AcctTypeDesc,
                amount : e.Amount,
                calledCell : {
                    party : checkDataString(e.CalledPartyNumb)
                }
            };
            listSmsCDRs.push(smsCDRs);
        });
    }
    
    return JSON.stringify(listSmsCDRs);
}

function setListMmsCDR(mmsCDRList){
    var listMmsCDRs = [];
    
    if(Array.isArray(mmsCDRList)){
        mmsCDRList.forEach(function(e){
            var mmsCDRs = {
                usageService : {
                    usageServiceTypeGroup : {
                        id : checkDataString(e.UsageServiceTypeGroupID),
                        value : checkDataString(e.UsageServiceTypeGroup)
                    },
                    usageServiceType : {
                        id : checkDataString(e.UsageServiceTypeID),
                        value : checkDataString(e.UsageServiceType)
                    }
                },
                startDTTM : e.StartDTTM,
                balType : e.BalType,
                acctTypeDesc : e.AcctTypeDesc,
                amount : e.Amount,
                calledCell : {
                    party : checkDataString(e.CalledPartyNumb)
                }
            };
            listMmsCDRs.push(mmsCDRs);
        });
    }
    return JSON.stringify(listMmsCDRs);
}

function setListContentCDR(contentCDRList){
    var listContentCDRs = [];
    
    if(Array.isArray(contentCDRList)){
        contentCDRList.forEach(function(e){
            var contentCDRs = {
                usageService : {
                    usageServiceTypeGroup : {
                        id : checkDataString(e.UsageServiceTypeGroupID),
                        value : checkDataString(e.UsageServiceTypeGroup)
                    },
                    usageServiceType : {
                        id : checkDataString(e.UsageServiceTypeID),
                        value : checkDataString(e.UsageServiceType)
                    }
                },
                startDTTM : e.StartDTTM,
                balType : e.BalType,
                acctTypeDesc : e.AcctTypeDesc,
                amount : e.Amount,
                serviceId : e.ServiceID,
                serviceType : e.ServiceType,
                contentProviderId : e.ContentProviderID,
                contentId : e.ContentID,
                contentType : e.ContentType
            };
            listContentCDRs.push(contentCDRs);
        });
    }
    return JSON.stringify(listContentCDRs);
}

function setListOtherServicesCDR(otherServicesCDRList){
    var listOtherServicesCDRs = [];
    
    if(Array.isArray(otherServicesCDRList)){
        otherServicesCDRList.forEach(function(e){
            var otherServicesCDRs = {
                usageService : {
                    usageServiceTypeGroup : {
                        id : checkDataString(e.UsageServiceTypeGroupID),
                        value : checkDataString(e.UsageServiceTypeGroup)
                    },
                    usageServiceType : {
                        id : checkDataString(e.UsageServiceTypeID)
                    }
                },
                startDTTM : e.StartDTTM,
                balType : e.BalType,
                acctTypeDesc : e.AcctTypeDesc,
                amount : e.Amount,
                feeType : e.BILFeeType,
                companyDataSource : e.CompanyDataSource
            };
            listOtherServicesCDRs.push(otherServicesCDRs);
        });
    }
    
    return JSON.stringify(listOtherServicesCDRs);
}

function mapVasBalanceToJson() {
    var offerList = [];
    var accountList = [];
    var vasAdditionalPackageList = [];
    
    if(!isEmpty(context.getVariable("resp.OfferList"))) {
        offerList = checkLengthArray(JSON.parse(context.getVariable("resp.OfferList")));
    }
    if(!isEmpty(context.getVariable("resp.AccountList"))) {
        accountList = checkLengthArray(JSON.parse(context.getVariable("resp.AccountList")));
    }
    if(!isEmpty(context.getVariable("resp.VasAdditionalPackageList"))) {
        vasAdditionalPackageList = checkLengthArray(JSON.parse(context.getVariable("resp.VasAdditionalPackageList")));
    }
    
    context.setVariable("resp.listOffersJson", setListOffers(offerList));
    context.setVariable("resp.listAccountJson", setListAccount(accountList));
    context.setVariable("resp.listVasAdditionalPackageJson", setListVasAdditionalPackage(vasAdditionalPackageList));
}

function setListFreeBonus(hpyBonFreList) {
    var listFreeBonus = [];
    
    for(index = 0; index < hpyBonFreList.length; index++) {
        var objectFreeBonus =  {
            "id"            : hpyBonFreList[index].BILBalId,
            "accountType"   : {
                "code"      : hpyBonFreList[index].BILAcctTypeCode,
                "desc"      : hpyBonFreList[index].BILAcctTypeDesc
            },
            "measure"       : mapMeasure(hpyBonFreList[index].BILMinMeasureId),
            "value"         : hpyBonFreList[index].BILBalAmt,
            "applyDttm"     : checkDataString(hpyBonFreList[index].BILApplyDttm),
            "expDttm"       : checkDataString(hpyBonFreList[index].BILExpDttm),
            "relatedObj"    : checkDataString(hpyBonFreList[index].BILRelObjId),
            "relatedType"   : checkDataLong(hpyBonFreList[index].BILRelType)
        };
        listFreeBonus.push(objectFreeBonus);
    }
    
    return JSON.stringify(listFreeBonus);
}

function setListBonus(bonBalList) {
    var listBonus = [];
    
    for(index = 0; index < bonBalList.length; index++) {
        var objectBonus =  {
            "id"            : bonBalList[index].BILBalId,
            "accountType"   : {
                "code"      : bonBalList[index].BILAcctTypeCode,
                "desc"      : bonBalList[index].BILAcctTypeDesc
            },
            "measure"       : mapMeasure(bonBalList[index].BILMinMeasureId),
            "value"         : bonBalList[index].BILBalAmt,
            "applyDttm"     : checkDataString(bonBalList[index].BILApplyDttm),
            "expDttm"       : checkDataString(bonBalList[index].BILExpDttm),
            "relatedObj"    : checkDataString(bonBalList[index].BILRelObjId),
            "relatedType"   : checkDataLong(bonBalList[index].BILRelType)
        };
        listBonus.push(objectBonus);
    }
    
    return JSON.stringify(listBonus);
}

function mapMeasure(measure) {
    if(measure === "1") {
        return "Second";
    } else if(measure === "2") {
        return "Byte";
    } else if(measure === "3") {
        return "Times";
    } else if(measure === "4") {
        return "Points";
    } else if(measure === "101") {
        return "Satang";
    } else {
        return "";
    }
}

function checkDataString(data) {
    if(!isEmpty(data)) {
        return data;
    } else {
        return "";
    }
}

function checkDataLong(data) {
    if(!isEmpty(data)) {
        return data + ".0";
    } else {
        return "0.0";
    }
}

function setListVasAdditionalPackage(vasAdditionalPackageList) {
    var listVasAdditionalPackage = [];
    for(index1 = 0; index1 < vasAdditionalPackageList.length; index1++) {
        var objectVasAdditional =  {
            "package"               : {
                "type"              : vasAdditionalPackageList[index1].VasPackageType,
                "code"              : vasAdditionalPackageList[index1].VasPackageCode,
                "name"              : vasAdditionalPackageList[index1].VasPackageName
            },
            "currentCycle"          : vasAdditionalPackageList[index1].VasCurrentCycle,
            "currentValidityDttm"   : vasAdditionalPackageList[index1].VasCurrentCycleValidityDTTM,
            "totalCycle"            : vasAdditionalPackageList[index1].VasTotalCycle,
            "vasOffers"             : [],
            "vasAccounts"           : []
        };
        if(isEmpty(vasAdditionalPackageList[index1].VasOfferList)) {
            vasAdditionalPackageList[index1].VasOfferList = {
                "VasOfferRec" : []
            };
        } else {
            vasAdditionalPackageList[index1].VasOfferList.VasOfferRec = checkLengthArray(vasAdditionalPackageList[index1].VasOfferList.VasOfferRec);
            for(index2 = 0; index2 < vasAdditionalPackageList[index1].VasOfferList.VasOfferRec.length; index2++) {
                vasOffers = {
                    "id"          : vasAdditionalPackageList[index1].VasOfferList.VasOfferRec[index2].OfferID,
                    "vasAccounts" : []
                };
                objectVasAdditional.vasOffers.push(vasOffers);
                
                if(isEmpty(vasAdditionalPackageList[index1].VasOfferList.VasOfferRec[index2].VasAccountList)) {
                    vasAdditionalPackageList[index1].VasOfferList.VasOfferRec[index2].VasAccountList = {
                        "VasAccountRec" : []
                    };
                } else {
                    vasAdditionalPackageList[index1].VasOfferList.VasOfferRec[index2].VasAccountList.VasAccountRec = checkLengthArray(vasAdditionalPackageList[index1].VasOfferList.VasOfferRec[index2].VasAccountList.VasAccountRec);
                    for(index3 = 0; index3 < vasAdditionalPackageList[index1].VasOfferList.VasOfferRec[index2].VasAccountList.VasAccountRec.length; index3++) {
                        vasAccounts = {
                            "id"                : vasAdditionalPackageList[index1].VasOfferList.VasOfferRec[index2].VasAccountList.VasAccountRec[index3].AccountID,
                            "typeID"            : vasAdditionalPackageList[index1].VasOfferList.VasOfferRec[index2].VasAccountList.VasAccountRec[index3].AccountTypeID,
                            "currentBalance"    : vasAdditionalPackageList[index1].VasOfferList.VasOfferRec[index2].VasAccountList.VasAccountRec[index3].CurrentBalance,
                            "measureType"       : vasAdditionalPackageList[index1].VasOfferList.VasOfferRec[index2].VasAccountList.VasAccountRec[index3].MeasureTypeID,
                            "accountEndDttm"    : vasAdditionalPackageList[index1].VasOfferList.VasOfferRec[index2].VasAccountList.VasAccountRec[index3].AccountEndDTTM
                        };
                        objectVasAdditional.vasOffers[index2].vasAccounts.push(vasAccounts);
                    }
                }
            }
        }
        if(isEmpty(vasAdditionalPackageList[index1].VasAccountList)) {
            vasAdditionalPackageList[index1].VasAccountList = {
                "VasAccountRec" : []
            };
        } else {
            vasAdditionalPackageList[index1].VasAccountList.VasAccountRec = checkLengthArray(vasAdditionalPackageList[index1].VasAccountList.VasAccountRec);
            for(index4 = 0; index4 < vasAdditionalPackageList[index1].VasAccountList.VasAccountRec.length; index4++) {
                vasAccounts = {
                    "id"                : vasAdditionalPackageList[index1].VasAccountList.VasAccountRec[index4].AccountID,
                    "typeID"            : vasAdditionalPackageList[index1].VasAccountList.VasAccountRec[index4].AccountTypeID,
                    "currentBalance"    : vasAdditionalPackageList[index1].VasAccountList.VasAccountRec[index4].CurrentBalance,
                    "measureType"       : vasAdditionalPackageList[index1].VasAccountList.VasAccountRec[index4].MeasureTypeID,
                    "accountEndDttm"    : vasAdditionalPackageList[index1].VasAccountList.VasAccountRec[index4].AccountEndDTTM
                };
                objectVasAdditional.vasAccounts.push(vasAccounts);
            }
        }
        listVasAdditionalPackage.push(objectVasAdditional);
    }
    
    return JSON.stringify(listVasAdditionalPackage);
}

function setListAccount(accountList) {
    var listAccounts = [];
    
    for(index = 0; index < accountList.length; index++) {
        var objectAccount =  {
            "id"                : accountList[index].AccountID,
            "type"              : {
                "id"            : accountList[index].AccountTypeID,
                "desc"          : accountList[index].AccountTypeDesc
            },
            "beginDttm"         : accountList[index].AccountBeginDTTM,
            "endDttm"           : accountList[index].AccountEndDTTM,
            "freeResource"      : accountList[index].IsFreeResource,
            "currBalance"       : accountList[index].CurrentBalance,
            "measureTypeID"     : accountList[index].MeasureTypeID,
            "relatedType"       : accountList[index].RelatedType,
            "relatedObjectID"   : accountList[index].RelatedObjectID
        };
        listAccounts.push(objectAccount);
    }
    
    return JSON.stringify(listAccounts);
}

function setListOffers(offerList) {
    var listOffers = [];
    
    for(index = 0; index < offerList.length; index++) {
        var objectOffers =  {
            "package"       : {
                "code"          : offerList[index].PackageCode,
                "name"          : offerList[index].PackageName
            },
            "code"              : offerList[index].OfferID,
            "rangeType"         : offerList[index].OfferRangeType,
            "withPocket"        : offerList[index].IsWithPocket,
            "orderKey"          : offerList[index].OfferOrderKey,
            "effectiveDttm"     : offerList[index].EffectiveTime,
            "expireDttm"        : offerList[index].ExpireTime,
            "currentCycles" : {
                "num"           : offerList[index].CurrentCycle,
                "startDttm"     : checkDataString(offerList[index].CurrentCycleStartDTTM), 
                "endDttm"       : checkDataString(offerList[index].CurrentCycleEndDTTM)
            },
            "totalCycl"         : offerList[index].TotalCycle,
            "statusE"           : offerList[index].OfferStatus,
            "integrationKey"    : offerList[index]['CBS-OfferOrderIntegrationKey'],                                 
            "externalOffer"     : offerList[index]['CRM-ExternalOfferCode'],
            "recurringFlag"     : offerList[index].IsRecurring
        };
        listOffers.push(objectOffers);
    }
    
    return JSON.stringify(listOffers);
}

function checkLengthArray (arrayList) {
    if(isEmpty(arrayList.length)) {
        var array_item = [];
        array_item[0] = arrayList;
        arrayList = array_item;   
    }
    
    return arrayList;
}

function mapQueryUsageSummaryToJson(){
    var cdrSummList = [];
    var cdrSummPostList = [];
    var cdrSummPreList = [];
    var paymentMethod = "" + context.getVariable("req.paymentMethod");
    var previousPaymentMethod = ""+context.getVariable("req.previousPaymentMethod");
    
    if(!isEmpty(context.getVariable("resp.CDRSummList"))) {
        cdrSummList = checkLengthArray(JSON.parse(context.getVariable("resp.CDRSummList")));
    }
    if(!isEmpty(context.getVariable("resp.CDRSummPostList"))) {
        cdrSummPostList = checkLengthArray(JSON.parse(context.getVariable("resp.CDRSummPostList")));
    }
    if(!isEmpty(context.getVariable("resp.CDRSummPreList"))) {
        cdrSummPreList = checkLengthArray(JSON.parse(context.getVariable("resp.CDRSummPreList")));
    }

    if(paymentMethod === "0" && isEmpty(previousPaymentMethod)){
         context.setVariable("resp.listCdrSummListJson",  setListCdrSummList(cdrSummList));
    }else if(previousPaymentMethod ==="2"){
         context.setVariable("resp.listCdrSummListJson",  setListCdrSummPreList(cdrSummPreList));
    }else {
         context.setVariable("resp.listCdrSummListJson", setListCdrSummPostList(cdrSummPostList));
    }
    
}

function mapQueryUsageSummaryPostToJson(){
    var usageSummList = [];

    if(!isEmpty(context.getVariable("resp.usageSummList"))) {
        usageSummList = checkLengthArray(JSON.parse(context.getVariable("resp.usageSummList")));
    }
    
    context.setVariable("resp.listCdrSummListJson",  setListQrySummPostList(usageSummList));
    
}

function setListCdrSummList(cdrSummList){
    var listCdrSummList = [];

    for(index = 0; index < cdrSummList.length ; index++){
        var cdrSummPreRec = {
            "id"        : (index + 1),
            "usageType" : cdrSummList[index].BILAcctTypeCode,
            "product"   : {
                "id"        : "" + cdrSummList[index].PDProdKey
            },
            "type"      :    {
                "id"        : "" + cdrSummList[index].BILSvcTypeID,
                "descEN"    : cdrSummList[index].BILEngDesc1,
                "descTH"    : cdrSummList[index].BILThaiDesc1
            },
            "srvcGroup" : {
                "id"        : "" + cdrSummList[index].BILSvcGroupID,
                "descEN"    : cdrSummList[index].BILEngDesc,
                "descTH"    : cdrSummList[index].BILThaiDesc
            },
            "bucketBalance" : [
                {
                    "unit"  : "" + cdrSummList[index].BILMinMeasureId,
                    "value" : "" + cdrSummList[index].BILChrgAmt
                }
            ],
            "bucketCounter" : [
                {
                    "unit"          : "" + cdrSummList[index].BILUsageUnit,
                    "value"         : parseInt(cdrSummList[index].BILActualVol),
                    "specialValue"  : parseInt(cdrSummList[index].BILRatingVol),
                    "validFor"      : {
                        "byMonth"   : "" + cdrSummList[index].BILUsageMonth,
                        "byCycle"   : "" + cdrSummList[index].BILBillCyclId
                    }
                }
            ]
        };
        
        if(isEmpty(cdrSummPreRec.product.id)) {
            delete cdrSummPreRec.product;
        }
        if(isEmpty(cdrSummPreRec.type.id) && isEmpty(cdrSummPreRec.type.descEN) && isEmpty(cdrSummPreRec.type.descTH)) {
            delete cdrSummPreRec.type;
        } else {
            if(isEmpty(cdrSummPreRec.type.id)) {
                delete cdrSummPreRec.type.id;
            }
            if(isEmpty(cdrSummPreRec.type.descEN)) {
                delete cdrSummPreRec.type.descEN;
            }
            if(isEmpty(cdrSummPreRec.type.descTH)) {
                delete cdrSummPreRec.type.descTH;
            }
        }
        if(isEmpty(cdrSummPreRec.srvcGroup.id) && isEmpty(cdrSummPreRec.srvcGroup.descEN) && isEmpty(cdrSummPreRec.srvcGroup.descTH)) {
            delete cdrSummPreRec.srvcGroup;
        } else {
            if(isEmpty(cdrSummPreRec.srvcGroup.id)) {
                delete cdrSummPreRec.srvcGroup.id;
            }
            if(isEmpty(cdrSummPreRec.srvcGroup.descEN)) {
                delete cdrSummPreRec.srvcGroup.descEN;
            }
            if(isEmpty(cdrSummPreRec.srvcGroup.descTH)) {
                delete cdrSummPreRec.srvcGroup.descTH;
            }
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].unit)) {
            delete cdrSummPreRec.bucketCounter[0].unit;
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].value)) {
            delete cdrSummPreRec.bucketCounter[0].value;
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].specialValue)) {
            delete cdrSummPreRec.bucketCounter[0].specialValue
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].validFor.byCycle)) {
            delete cdrSummPreRec.bucketCounter[0].validFor.byCycle
        }
        listCdrSummList.push(cdrSummPreRec);
    }
    
    return JSON.stringify(listCdrSummList);
}

function setListQrySummPostList(usageSummList){
    var listUsageSummList = [];

    for(index = 0; index < usageSummList.length ; index++){
        var usageSummInfo = {
            "id"        : (index + 1),
            "usageType" : usageSummList[index].AcctTypeCode,
            "desc"      : usageSummList[index].AcctTypeDesc,
            "note"      : usageSummList[index].Remark,
            "product"   : {
                "id"        : "" + usageSummList[index].PackageCode
            },
            "specialProduct"    : {
                "id"            : usageSummList[index].OfferId,
                "name"          : usageSummList[index].OfferName,
                "integration"   : usageSummList[index].ODIntegrationId
            },
            "type"      :    {
                "id"        : "" + usageSummList[index].SvcTypeID
            },
            "srvcGroup" : {
                "id"        : "" + usageSummList[index].ServiceGroupID,
                "desc"    : usageSummList[index].SvcGroupDesc
            },
            "bucketBalance" : [
                {
                    "value" : "" + usageSummList[index].ChrgAmt
                }
            ],
            "bucketCounter" : [
                {
                    "unit"          : "" + usageSummList[index].UsageUnit,
                    "value"         : parseInt(usageSummList[index].UsageAmt),
                    "validFor"      : {
                        "byMonth"   : "" + usageSummList[index].UsageMonth,
                        "byCycle"   : "" + usageSummList[index].BillCyclId
                    }
                }
            ]
        };
        
        if(isEmpty(usageSummInfo.desc)) {
            delete usageSummInfo.desc;
        }
        
        if(isEmpty(usageSummInfo.note)) {
            delete usageSummInfo.note;
        }
        
        if(isEmpty(usageSummInfo.product.id)) {
            delete usageSummInfo.product;
        }
        
        if(isEmpty(usageSummInfo.specialProduct.id) && isEmpty(usageSummInfo.specialProduct.name) && isEmpty(usageSummInfo.specialProduct.integration)) {
            delete usageSummInfo.specialProduct;
        } else {
            if(isEmpty(usageSummInfo.specialProduct.id)) {
                delete usageSummInfo.specialProduct.id
            }
            if(isEmpty(usageSummInfo.specialProduct.name)) {
                delete usageSummInfo.specialProduct.name
            }
            if(isEmpty(usageSummInfo.specialProduct.integration)) {
                delete usageSummInfo.specialProduct.integration
            }
        }
        
        if(isEmpty(usageSummInfo.type.id)) {
            delete usageSummInfo.type;
        }
        
        if(isEmpty(usageSummInfo.srvcGroup.id) && isEmpty(usageSummInfo.srvcGroup.desc)) {
            delete usageSummInfo.srvcGroup;
        } else {
            if(isEmpty(usageSummInfo.srvcGroup.id)) {
                delete usageSummInfo.srvcGroup.id;
            }
            if(isEmpty(usageSummInfo.srvcGroup.desc)) {
                delete usageSummInfo.srvcGroup.desc;
            }
        }
        
        if(isEmpty(usageSummInfo.bucketCounter[0].unit)) {
            delete usageSummInfo.bucketCounter[0].unit;
        }
        if(isEmpty(usageSummInfo.bucketCounter[0].value)) {
            delete usageSummInfo.bucketCounter[0].value;
        }
 
        if(isEmpty(usageSummInfo.bucketCounter[0].validFor.byCycle)) {
            delete usageSummInfo.bucketCounter[0].validFor.byCycle
        }
        
        listUsageSummList.push(usageSummInfo);
    }
    
    return JSON.stringify(listUsageSummList);
}

function setListCdrSummPreList(cdrSummPreList){
    var listCdrSummPreList = [];
    
    for(index = 0; index < cdrSummPreList.length ; index++){
        var cdrSummPreRec = {
            "id"        : "" + (index + 1),
            "usageType" : cdrSummPreList[index].BILAcctTypeCode,
            "desc"      : cdrSummPreList[index].BILAcctTypeDesc,
            "product"   : {
                "id"        : "" + cdrSummPreList[index].PDProdKey
            },
            "specialProduct"    : {
                "id"            : cdrSummPreList[index].PDOfferId,
                "name"          : cdrSummPreList[index].BILOfferName,
                "integration"   : cdrSummPreList[index].ODIntegrationId,
                "reserve"       : cdrSummPreList[index].BILReserve
            },
            "type"      :    {
                "id"        : "" + cdrSummPreList[index].BILSvcTypeID
            },
            "srvcGroup" : {
                "id"        : "" + cdrSummPreList[index].BILSvcGroupID,
                "desc"    :   !isEmpty(cdrSummPreList[index].BILEngDesc) ? cdrSummPreList[index].BILEngDesc :  cdrSummPreList[index].BILThaiDesc
            },
            "bucketBalance" : [
                {
                    "unit"  : "" + cdrSummPreList[index].BILMinMeasureId,
                    "value" : "" + cdrSummPreList[index].BILChrgAmt
                }
            ],
            "bucketCounter" : [
                {
                    "unit"          : "" + cdrSummPreList[index].BILUsageUnit,
                    "value"         : parseInt(cdrSummPreList[index].BILActualVol),
                    "specialValue"  : parseInt(cdrSummPreList[index].BILRatingVol),
                    "validFor"      : {
                        "byMonth"   : "" + cdrSummPreList[index].BILUsageMonth,
                        "byCycle"   : "" + cdrSummPreList[index].BILBillCyclId
                    }
                }
            ]
        };
        
        if(isEmpty(cdrSummPreRec.product.id)) {
            delete cdrSummPreRec.product;
        }
        if(isEmpty(cdrSummPreRec.specialProduct.id) && isEmpty(cdrSummPreRec.specialProduct.name) && isEmpty(cdrSummPreRec.specialProduct.integration) && isEmpty(cdrSummPreRec.specialProduct.reserve)) {
            delete cdrSummPreRec.specialProduct
        } else {
            if(isEmpty(cdrSummPreRec.specialProduct.id)) {
                delete cdrSummPreRec.specialProduct.id
            }
            if(isEmpty(cdrSummPreRec.specialProduct.name)) {
                delete cdrSummPreRec.specialProduct.name
            }
            if(isEmpty(cdrSummPreRec.specialProduct.integration)) {
                delete cdrSummPreRec.specialProduct.integration
            }
            if(isEmpty(cdrSummPreRec.specialProduct.reserve)) {
                delete cdrSummPreRec.specialProduct.reserve
            }
        }
        if(isEmpty(cdrSummPreRec.type.id) && isEmpty(cdrSummPreRec.type.descEN) && isEmpty(cdrSummPreRec.type.descTH)) {
            delete cdrSummPreRec.type;
        } else {
            if(isEmpty(cdrSummPreRec.type.id)) {
                delete cdrSummPreRec.type.id;
            }
        }
        if(isEmpty(cdrSummPreRec.srvcGroup.id) && isEmpty(cdrSummPreRec.srvcGroup.descEN) && isEmpty(cdrSummPreRec.srvcGroup.descTH)) {
            delete cdrSummPreRec.srvcGroup;
        } else {
            if(isEmpty(cdrSummPreRec.srvcGroup.id)) {
                delete cdrSummPreRec.srvcGroup.id;
            }
            if(isEmpty(cdrSummPreRec.srvcGroup.desc)) {
                delete cdrSummPreRec.srvcGroup.desc;
            }
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].unit)) {
            delete cdrSummPreRec.bucketCounter[0].unit;
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].value)) {
            delete cdrSummPreRec.bucketCounter[0].value;
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].specialValue)) {
            delete cdrSummPreRec.bucketCounter[0].specialValue
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].validFor.byCycle)) {
            delete cdrSummPreRec.bucketCounter[0].validFor.byCycle
        }
        listCdrSummPreList.push(cdrSummPreRec);
    }

    return JSON.stringify(listCdrSummPreList);
    
}

function setListCdrSummPostList(cdrSummPostList){
    var listCdrSummPostList = [];

    for(index = 0; index < cdrSummPostList.length ; index++){
        var cdrSummPostRec = {
            "id"        : "" + (index + 1),
            "usageType" : cdrSummPostList[index].BILAcctTypeCode,
            "product"   : {
                "id"        : "" + cdrSummList[index].PDProdKey
            },
            "specialProduct"    : {
                "id"            : cdrSummPostList[index].PDOfferId,
                "name"          : cdrSummPostList[index].BILOfferName,
                "integration"   : cdrSummPostList[index].ODIntegrationId,
                "reserve"       : cdrSummPostList[index].BILReserve
            },
            "type"      :    {
                "id"        : "" + cdrSummList[index].BILSvcTypeID,
                "descEN"    : cdrSummPostList[index].BILEngDesc1,
                "descTH"    : cdrSummPostList[index].BILThaiDesc1
            },
            "srvcGroup" : {
                "id"        : "" + cdrSummList[index].BILSvcGroupID,
                "descEN"    : cdrSummPostList[index].BILEngDesc,
                "descTH"    : cdrSummPostList[index].BILThaiDesc
            },
            "bucketBalance" : [
                {
                    "unit"  : "" + cdrSummList[index].BILMinMeasureId,
                    "value" : "" + cdrSummList[index].BILChrgAmt
                }
            ],
            "bucketCounter" : [
                {
                    "unit"          : "" + cdrSummList[index].BILUsageUnit,
                    "value"         : parseInt(cdrSummList[index].BILActualVol),
                    "specialValue"  : parseInt(cdrSummList[index].BILRatingVol),
                    "validFor"      : {
                        "byMonth"   : "" + cdrSummList[index].BILUsageMonth,
                        "byCycle"   : "" + cdrSummList[index].BILBillCyclId
                    }
                }
            ]
        };
        
        if(isEmpty(cdrSummPreRec.product.id)) {
            delete cdrSummPreRec.product;
        }
        if(isEmpty(cdrSummPostRec.specialProduct.id) && isEmpty(cdrSummPostRec.specialProduct.name) && isEmpty(cdrSummPostRec.specialProduct.integration) && isEmpty(cdrSummPostRec.specialProduct.reserve)) {
            delete cdrSummPreRec.specialProduct
        } else {
            if(isEmpty(cdrSummPostRec.specialProduct.id)) {
                delete cdrSummPreRec.specialProduct.id
            }
            if(isEmpty(cdrSummPostRec.specialProduct.name)) {
                delete cdrSummPreRec.specialProduct.name
            }
            if(isEmpty(cdrSummPostRec.specialProduct.integration)) {
                delete cdrSummPreRec.specialProduct.integration
            }
            if(isEmpty(cdrSummPostRec.specialProduct.reserve)) {
                delete cdrSummPreRec.specialProduct.reserve
            }
        }
        if(isEmpty(cdrSummPreRec.type.id) && isEmpty(cdrSummPreRec.type.descEN) && isEmpty(cdrSummPreRec.type.descTH)) {
            delete cdrSummPreRec.type;
        } else {
            if(isEmpty(cdrSummPreRec.type.id)) {
                delete cdrSummPreRec.type.id;
            }
            if(isEmpty(cdrSummPreRec.type.descEN)) {
                delete cdrSummPreRec.type.descEN;
            }
            if(isEmpty(cdrSummPreRec.type.descTH)) {
                delete cdrSummPreRec.type.descTH;
            }
        }
        if(isEmpty(cdrSummPreRec.srvcGroup.id) && isEmpty(cdrSummPreRec.srvcGroup.descEN) && isEmpty(cdrSummPreRec.srvcGroup.descTH)) {
            delete cdrSummPreRec.srvcGroup;
        } else {
            if(isEmpty(cdrSummPreRec.srvcGroup.id)) {
                delete cdrSummPreRec.srvcGroup.id;
            }
            if(isEmpty(cdrSummPreRec.srvcGroup.descEN)) {
                delete cdrSummPreRec.srvcGroup.descEN;
            }
            if(isEmpty(cdrSummPreRec.srvcGroup.descTH)) {
                delete cdrSummPreRec.srvcGroup.descTH;
            }
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].unit)) {
            delete cdrSummPreRec.bucketCounter[0].unit;
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].value)) {
            delete cdrSummPreRec.bucketCounter[0].value;
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].specialValue)) {
            delete cdrSummPreRec.bucketCounter[0].specialValue
        }
        if(isEmpty(cdrSummPreRec.bucketCounter[0].validFor.byCycle)) {
            delete cdrSummPreRec.bucketCounter[0].validFor.byCycle
        }
        listCdrSummPostList.push(cdrSummPostRec);
    }

    return JSON.stringify(listCdrSummPostList);
}

function mapEscCdrToJson(){
 var response = context.getVariable("resp.qryCDRResponse")
 //var response = context.getVariable("resp.response")
 var qryCdr = JSON.parse(response);
 var jsonResp = {}
 jsonResp.transactionId = "" + context.getVariable("req.escCdrTransactionId")
 jsonResp.data={}
 if(!isEmpty(qryCdr.TotalCDRNumb)){
    jsonResp.data.totalCDR=parseInt(qryCdr.TotalCDRNumb)
 }
 if(!isEmpty(qryCdr.BeginRowNumb)){
    jsonResp.data.beginRow=parseInt(qryCdr.BeginRowNumb)
 }
 if(!isEmpty(qryCdr.FetchRowNumb)){
    jsonResp.data.fetchRow=parseInt(qryCdr.FetchRowNumb)
 }
 jsonResp.bucket=[]
 //forloop
 if(validateNil(qryCdr.ListVoiceCDR)!==""){
   validateBucket(jsonResp,qryCdr.ListVoiceCDR.VoiceCDRInfo,"Voice")
 }
 if(validateNil(qryCdr.ListSmsCDR)!==""){
   validateBucket(jsonResp,qryCdr.ListSmsCDR.SmsCDRInfo,"SMS")
 }
 if(validateNil(qryCdr.ListMmsCDR)!==""){
   validateBucket(jsonResp,qryCdr.ListMmsCDR.MmsCDRInfo,"MMS")
 }
 if(validateNil(qryCdr.ListContentCDR)!==""){
   validateBucket(jsonResp,qryCdr.ListContentCDR.ContentCDRInfo,"Content")
 }
 if(validateNil(qryCdr.ListDataCDR.DataCDRInfo)!==""){
   validateBucket(jsonResp,qryCdr.ListDataCDR.DataCDRInfo,"Data")
 }
 if(validateNil(qryCdr.ListOtherCDR)!==""){
   validateBucket(jsonResp,qryCdr.ListOtherCDR.OtherCDRInfo,"Other")
 }
 
 context.setVariable("resp.json", JSON.stringify(jsonResp));
}

function validateBucket(jsonResp,listCdr,typeCdr){
   if(whatIsIt(listCdr)=="Array"){
       for(var i =0 ; i <listCdr.length; i++){
           setBucket(jsonResp,listCdr[i],typeCdr)
       }
   }else if(whatIsIt(listCdr)=="Object"){
      setBucket(jsonResp,listCdr,typeCdr)
   }
 }
 function setBucket(jsonResp,listCdr,typeCdr){
   var bucketObj={}
   bucketObj.id=""+validateNil(listCdr.ServiceType)
   bucketObj.name=""+validateNil(listCdr.BILUsageSvcTypeDesc)
   bucketObj.usageType=""+typeCdr
   bucketObj.product={}
   bucketObj.product.name=""+validateNil(listCdr.BILPrimaryOfferName)
   bucketObj.product.relationParty={}
   bucketObj.product.relationParty.id=""+validateNil(listCdr.DestinationNo)
   var hasOriginatedArea=whatIsIt(listCdr.OriginatedArea)=="String"
   var hasDestinationArea= whatIsIt(listCdr.DestinationArea)=="String"
   bucketObj.product.relationParty.characteristic=[]
   if(hasOriginatedArea){
      var characteristicObj ={}
      characteristicObj.name="OriginatedArea"
      characteristicObj.value=""+listCdr.OriginatedArea
      bucketObj.product.relationParty.characteristic.push(characteristicObj)
   }
   if(hasDestinationArea){
      var characteristicObj ={}
      characteristicObj.name="DestinationArea"
      characteristicObj.value=""+listCdr.DestinationArea
      bucketObj.product.relationParty.characteristic.push(characteristicObj)
   }
   bucketObj.bucketBalance=[]
   bucketObj.bucketCounter=[]
   //check Duration or TotalVolume
   if(whatIsIt(listCdr.Duration)=="String"){

      var bucketCounterObj ={}
      bucketCounterObj.contentType="Used"
      if(!isEmpty(listCdr.Duration)){      
        bucketCounterObj.value=parseFloat(listCdr.Duration)
      }
      bucketObj.bucketCounter.push(bucketCounterObj)
   }else if(whatIsIt(listCdr.TotalVolume)=="String"){
      var bucketCounterObj ={}
      bucketCounterObj.contentType="Used"
      if(!isEmpty(listCdr.TotalVolume)){  
        bucketCounterObj.value=parseFloat(listCdr.TotalVolume)
      }
      bucketObj.bucketCounter.push(bucketCounterObj)
   }
   if(validateNil(listCdr.ListPayment)!==""){
      validateBucketBalance(jsonResp,listCdr.ListPayment.PaymentInfo,"Other",bucketObj,listCdr)
    }

 }
 
 function validateBucketBalance(jsonResp,listPayment,typeCdr,bucketObj,listCdr){
   if(whatIsIt(listPayment)=="Array"){
       for(var i =0 ; i <listPayment.length; i++){
         setBucketBalance(jsonResp,listPayment[i],typeCdr,bucketObj,listCdr)
       }
   }else if(whatIsIt(listPayment)=="Object"){
      setBucketBalance(jsonResp,listPayment,typeCdr,bucketObj,listCdr)
   }
 }
 function setBucketBalance(jsonResp,listPayment,typeCdr,bucketObj,listCdr){
   var bucketBalanceObj ={}
   bucketBalanceObj.unit="THB"
   if(!isEmpty(listPayment.Amount)){
    bucketBalanceObj.value=parseFloat(listPayment.Amount)
   }
   bucketBalanceObj.valueLabel=""+validateNil(listPayment.Remark)
   bucketBalanceObj.validFor={}
   bucketBalanceObj.validFor.startDateTime=""+listCdr.StartDate+"Z"
   bucketObj.bucketBalance.push(bucketBalanceObj)
   jsonResp.bucket.push(bucketObj)
 }
 function whatIsIt(object) {
   if (object === null) {
       return "null";
   }
   else if (object === undefined) {
       return "undefined";
   }
   else if (object.constructor === String) {
       return "String";
   }
   else if (object.constructor === Array) {
       return "Array";
   }
   else if (object.constructor === Object) {
       return "Object";
   }
   else {
       return "don't know";
   }
 }
 
 function validateNil(obj){
   if(whatIsIt(obj)=="Object"){
     if(obj.hasOwnProperty("nil")){
       return ""
     }
   }else if(whatIsIt(obj)=="null"){
      return ""
   }
      return obj
 }
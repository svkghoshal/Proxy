http = require('http');

server = http.createServer( function(req, res) {

    var statusCode = 200;
    var body =  "<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 				
                "<S:Body>" + 
                    "<ns2:ReadVasBalanceResponse xmlns:ns2=\"http://service.v2.vas.api.esv.tac.co.th/\" xmlns:ns3=\"http://request.ws.api.esv.tac.co.th\" xmlns:ns4=\"http://response.ws.api.esv.tac.co.th\">" +
                        "<ReadVasBalanceResponse>" +
                            "<ns4:MessageHeader>" + 
                                "<MessageID>ESVWEB20140509180627123</MessageID>" +
                                "<ReferenceKey>2014050918062786766859189881</ReferenceKey>" + 
                                "<BusinessEvent>archive</BusinessEvent>" + 
                                "<SourceSystemID>ESVWEB</SourceSystemID>" + 
                                "<ResponseDTTM>2017-12-29T11:24:15.622+07:00</ResponseDTTM>" + 
                                "<ResponseTime>174</ResponseTime>" +
                                "<IsAsyncRequest></IsAsyncRequest>" + 
                                "<ResponseURL></ResponseURL>" + 
                                "<APIVersion>01.00.000</APIVersion>" +
                                "<APIMachine>esvappm1</APIMachine>" +
                            "</ns4:MessageHeader>" +
                            "<ns4:MessageStatus>" + 
                                "<APIResponseCode>1</APIResponseCode>" + 
                                "<APIResponseMessage>Success with data</APIResponseMessage>" + 
                                "<LatestEndpoint>" + 
                                    "<EndpointStatusCode>1</EndpointStatusCode>" + 
                                    "<EndpointName></EndpointName>" + 
                                "</LatestEndpoint>" + 
                            "</ns4:MessageStatus>" + 
                            "<MessageBody>" + 
                                "<SubrNumb>668</SubrNumb>" + 
                                "<OfferList>" +
                                    "<OfferRec>" +
                                        "<PackageCode>15000611</PackageCode>" +
                                        "<PackageName>Staff dtac 4G Package</PackageName>" +
                                        "<OfferID>15000611</OfferID>" +
                                        "<OfferRangeType>Main Offer (Postpaid)</OfferRangeType>" +
                                        "<IsWithPocket>N</IsWithPocket>" +
                                        "<OfferOrderKey>687470460</OfferOrderKey>" +
                                        "<EffectiveTime>20141215125853</EffectiveTime>" +
                                        "<ExpireTime>20370101000000</ExpireTime>" + 
                                        "<CurrentCycle>36</CurrentCycle>" +
                                        "<CurrentCycleStartDTTM>20171202000000</CurrentCycleStartDTTM>" +
                                        "<CurrentCycleEndDTTM>20180102000000</CurrentCycleEndDTTM>" +
                                        "<TotalCycle>10000</TotalCycle>" +
                                        "<OfferStatus>0</OfferStatus>" +
                                        "<CBS-OfferOrderIntegrationKey>O79_15000611_671343137</CBS-OfferOrderIntegrationKey>" +
                                        "<CRM-ExternalOfferCode>15000611_02_15000611</CRM-ExternalOfferCode>" +
                                        "<IsRecurring>Y</IsRecurring>" +
                                    "</OfferRec>" +
                                    "<OfferRec>" +
                                        "<PackageCode>21231214</PackageCode>" +
                                        "<PackageName>ฟรี เน็ตความเร็ว 64 Kbps</PackageName>" +
                                        "<OfferID>20700450</OfferID>" +
                                        "<OfferRangeType>GPRS time based without pocket</OfferRangeType>" +
                                        "<IsWithPocket>N</IsWithPocket>" +
                                        "<OfferOrderKey>4000000002388717147</OfferOrderKey>" +
                                        "<EffectiveTime>20170221101641</EffectiveTime>" +
                                        "<ExpireTime>20181220000000</ExpireTime>" + 
                                        "<CurrentCycle>1</CurrentCycle>" +
                                        "<CurrentCycleStartDTTM>20170221000000</CurrentCycleStartDTTM>" +
                                        "<CurrentCycleEndDTTM>20180222000000</CurrentCycleEndDTTM>" +
                                        "<TotalCycle>1</TotalCycle>" +
                                        "<OfferStatus>0</OfferStatus>" +
                                        "<CBS-OfferOrderIntegrationKey>O45_21231214_1322858235</CBS-OfferOrderIntegrationKey>" +
                                        "<CRM-ExternalOfferCode>21231214_02_</CRM-ExternalOfferCode>" +
                                        "<IsRecurring>Y</IsRecurring>" +
                                    "</OfferRec>" +
                                "</OfferList>" +
                                "<AccountList>" +
                                    "<AccountRec>" + 
                                        "<AccountID>5380027917894</AccountID>" +
                                        "<AccountTypeID>2618</AccountTypeID>" + 
                                        "<AccountTypeDesc>SMSจากแพ็กหลัก</AccountTypeDesc>" +
                                        "<AccountBeginDTTM>20171202000000</AccountBeginDTTM>" +
                                        "<AccountEndDTTM>20180102000000</AccountEndDTTM>" + 
                                        "<IsFreeResource>N</IsFreeResource>" +
                                        "<CurrentBalance>147.0</CurrentBalance>" +
                                        "<MeasureTypeID>101</MeasureTypeID>" +
                                        "<RelatedType>7</RelatedType>" +
                                        "<RelatedObjectID>O79_15000611_671343137</RelatedObjectID>" +
                                    "</AccountRec>" +
                                    "<AccountRec>" +							
                                        "<AccountID>5380027917896</AccountID>" +
                                        "<AccountTypeID>2619</AccountTypeID>" +
                                        "<AccountTypeDesc>MMSจากแพ็กหลัก</AccountTypeDesc>" +
                                        "<AccountBeginDTTM>20171202000000</AccountBeginDTTM>" +
                                        "<AccountEndDTTM>20180102000000</AccountEndDTTM>" +
                                        "<IsFreeResource>N</IsFreeResource>" +
                                        "<CurrentBalance>150.0</CurrentBalance>" +
                                        "<MeasureTypeID>101</MeasureTypeID>" +
                                        "<RelatedType>7</RelatedType>" +
                                        "<RelatedObjectID>O79_15000611_671343137</RelatedObjectID>" +
                                    "</AccountRec>" +
                                    "<AccountRec>" +
                                        "<AccountID>5380027917897</AccountID>" +
                                        "<AccountTypeID>2622</AccountTypeID>" +
                                        "<AccountTypeDesc>โทรทุกเครือข่าย</AccountTypeDesc>" +
                                        "<AccountBeginDTTM>20171202000000</AccountBeginDTTM>" +
                                        "<AccountEndDTTM>20180102000000</AccountEndDTTM>" +
                                        "<IsFreeResource>N</IsFreeResource>" +
                                        "<CurrentBalance>1065.68</CurrentBalance>" +
                                        "<MeasureTypeID>101</MeasureTypeID>" +
                                        "<RelatedType>7</RelatedType>" +
                                        "<RelatedObjectID>O79_15000611_671343137</RelatedObjectID>" +
                                    "</AccountRec>" +
                                "</AccountList>" +
                                "<VasAdditionalPackageList>" +
                                    "<VasAdditionalPackageRec>" +
                                        "<VasPackageType>Main Offer (Postpaid)</VasPackageType>" +
                                        "<VasPackageCode>15000611</VasPackageCode>" +
                                        "<VasPackageName>Staff dtac 4G Package</VasPackageName>" +
                                        "<VasCurrentCycle>36</VasCurrentCycle>" +
                                        "<VasCurrentCycleValidityDTTM>20180102000000</VasCurrentCycleValidityDTTM>" +
                                        "<VasTotalCycle>10000</VasTotalCycle>" +
                                        "<VasOfferList>" +
                                            "<VasOfferRec>" +
                                                "<OfferID>15000611</OfferID>" +
                                                "<VasAccountList>" +
                                                    "<VasAccountRec>" +
                                                        "<AccountID>5380027917894</AccountID>" +
                                                        "<AccountTypeID>2618</AccountTypeID>" +
                                                        "<AccountTypeDesc>SMSจากแพ็กหลัก</AccountTypeDesc>" +
                                                        "<AccountBeginDTTM>20171202000000</AccountBeginDTTM>" +
                                                        "<AccountEndDTTM>20180102000000</AccountEndDTTM>" +
                                                        "<CurrentBalance>147.0</CurrentBalance>" +
                                                        "<MeasureTypeID>101</MeasureTypeID>" +
                                                    "</VasAccountRec>" +
                                                    "<VasAccountRec>" +
                                                        "<AccountID>5380027917896</AccountID>" +
                                                        "<AccountTypeID>2619</AccountTypeID>" +
                                                        "<AccountTypeDesc>MMSจากแพ็กหลัก</AccountTypeDesc>" +
                                                        "<AccountBeginDTTM>20171202000000</AccountBeginDTTM>" +
                                                        "<AccountEndDTTM>20180102000000</AccountEndDTTM>" +
                                                        "<CurrentBalance>150.0</CurrentBalance>" +
                                                        "<MeasureTypeID>101</MeasureTypeID>" +
                                                    "</VasAccountRec>" +
                                                    "<VasAccountRec>" +
                                                        "<AccountID>5380027917897</AccountID>" +
                                                        "<AccountTypeID>2622</AccountTypeID>" +
                                                        "<AccountTypeDesc>โทรทุกเครือข่าย</AccountTypeDesc>" +
                                                        "<AccountBeginDTTM>20171202000000</AccountBeginDTTM>" +
                                                        "<AccountEndDTTM>20180102000000</AccountEndDTTM>" +
                                                        "<CurrentBalance>1065.68</CurrentBalance>" +
                                                        "<MeasureTypeID>101</MeasureTypeID>" +
                                                    "</VasAccountRec>" +
                                                "</VasAccountList>" +
                                            "</VasOfferRec>" +
                                        "</VasOfferList>" +
                                        "<MeasureTypeID>101</MeasureTypeID>" +
                                        "<EffectiveTime>20141215125853</EffectiveTime>" +
                                        "<ExpireTime>20370101000000</ExpireTime>" +
                                    "</VasAdditionalPackageRec>" +
                                    "<VasAdditionalPackageRec>" +
                                        "<VasPackageType>GPRS time based without pocket</VasPackageType>" +
                                        "<VasPackageCode>21231214</VasPackageCode>" +
                                        "<VasPackageName>ฟรี เน็ตความเร็ว 64 Kbps</VasPackageName>" +
                                        "<VasCurrentCycle>1</VasCurrentCycle>" +
                                        "<VasCurrentCycleValidityDTTM>20180222000000</VasCurrentCycleValidityDTTM>" +
                                        "<VasTotalCycle>1</VasTotalCycle>" +
                                        "<VasOfferList>" +
                                            "<VasOfferRec>" +
                                                "<OfferID>20700450</OfferID>" +
                                                "<VasAccountList/>" +
                                            "</VasOfferRec>" +
                                        "</VasOfferList>" +
                                        "<EffectiveTime>20170221101641</EffectiveTime>" + 
                                        "<ExpireTime>20181220000000</ExpireTime>" + 
                                    "</VasAdditionalPackageRec>" + 
                                "</VasAdditionalPackageList>" + 
                            "</MessageBody>" + 
                        "</ReadVasBalanceResponse>" +
                    "</ns2:ReadVasBalanceResponse>" +
                "</S:Body>" +
            "</S:Envelope>";

    res.writeHead(statusCode, {'Content-Type': 'application/xop+xml'});
    res.end(body);
});

port = 8201;
host = '127.0.0.1';
server.listen(port, host);
   http = require('http');

server = http.createServer( function(req, res) {
    
     var statusCode = 200;
     var body = "<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">"
                    +"<S:Header/>"
                    +"<S:Body>"
                        +"<ns2:QryUsageSummResponse xmlns=\"http://www.dtac.co.th/esc/ws/dat/Common\" xmlns:ns2=\"http://www.dtac.co.th/esc/ws/sv/qus/dat\">"
                            +"<MessageHeader>"
                                +"<MessageID>ESMO1234567890</MessageID>"
                                +"<ReferenceKey>esvappm2[1125554701935607]</ReferenceKey>"
                                +"<BusinessEvent>QryUsage</BusinessEvent>"
                                +"<SourceSystemID>esc_test</SourceSystemID>"
                                +"<SentDttm>2018-01-16T11:15:14.898+07:00</SentDttm>"
                                +"<ResponseDttm>2018-11-14T11:55:12.950+07:00</ResponseDttm>"
                                +"<IsAsyncRequest>N</IsAsyncRequest>"
                                +"<ResponseURL/>"
                            +"</MessageHeader>"
                            +"<ResponseStatus>"
                                +"<StatusCode>E</StatusCode>"
                                +"<ResponseCode>ESB_14000</ResponseCode>"
                                +"<ResponseMessage>External: (CBS-0-405960029)Account route information does not exist.</ResponseMessage>"
                            +"</ResponseStatus>"
                            +"<ns2:ListUsageSumm xsi:nil=\"true\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/>"
                        +"</ns2:QryUsageSummResponse>"
                    +"</S:Body>"
                +"</S:Envelope>";
    
    res.writeHead(statusCode, {'Content-Type': 'application/xop+xml'});
    res.end(body);
});

port = 8201;
host = '127.0.0.1';
server.listen(port, host);
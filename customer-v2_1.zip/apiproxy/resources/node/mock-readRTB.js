http = require('http');

server = http.createServer( function(req, res) {
    
     var statusCode = 200;
     var body = "{"
        +  "\"data\": {"
		+  "\"subrNumb\": \"66942411620\","
		+  "\"custNumb\": \"1110953426\","
	    +  "\"monthData\": 5,"
		+  "\"yearData\": 2018,"
		+  "\"mou\": {"
			    +  "\"previous_1m\": 0,"
			    +  "\"previous_2m\": 2,"
			    +  "\"average_3m\": 2"
		+ "},"
		+  "\"internetUsage\": {"
			+  "\"previous_1m\": 0,"
			+  "\"previous_2m\": 0,"
			+  "\"average_3m\": 0"
		+ "},"
	    +  "\"refillAmount\": {"
			+  "\"previous_1m\": 0,"
			+  "\"previous_2m\": 0,"
			+  "\"average_3m\": 0"
		+ "}"
	+   "},"
	+  "\"status\": {"
		+  "\"statusType\": \"S\","
		+  "\"errorCode\": \"\","
		+  "\"errorMessage\": \"Success\","
		+  "\"server\": \"2e51e065ceaa\" "
	+ "}"
     +"}";
    
    res.writeHead(statusCode, {'Content-Type': 'application/json'});
    res.end(body);
});

port = 8201;
host = '127.0.0.1';
server.listen(port, host);
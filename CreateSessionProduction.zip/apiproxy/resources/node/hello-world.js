/* http = require('http');

server = http.createServer( function(req, res) {
    console.log ('RecommendPacks');
    
   
 var body = '<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/><S:Body><ns3:createsessionResponse xmlns=http://www.utiba.com/delirium/ws/TypedQuery" xmlns:ns2="http://www.utiba.com/delirium/ws/Misc" xmlns:ns3="urn:UMARKETSCWS" xmlns:ns4="http://www.utiba.com/delirium/ws/StdQuery"><ns3:createsessionReturn><ns3:sessionid>H7B8JH426C3YT0X8USHV</ns3:sessionid><ns3:result>0</ns3:result><ns3:result_namespace>session</ns3:result_namespace></ns3:createsessionReturn></ns3:createsessionResponse></S:Body></S:Envelope>';

 

// var body = '';

// var body = { "name":"gopi"};
    
    // Compose the body
// var body = "<urn:ReadSubrIACCWSResponse xmlns:urn=\"urn:pack.INReadSubrIACCWS_typedef.salt11\"><urn:outbuf><urn:CUST_NUMB>2333</urn:CUST_NUMB><urn:SUBR_NUMB>3333</urn:SUBR_NUMB><urn:TELP_TYPE>ttt</urn:TELP_TYPE><urn:SUBR_STTS>2334</urn:SUBR_STTS><urn:COMP_CODE>444</urn:COMP_CODE><urn:BLPD_INDC>445</urn:BLPD_INDC><urn:TBL_OCCR>5</urn:TBL_OCCR><urn:ID_NUMB>555</urn:ID_NUMB><urn:ID_TYPE>5556</urn:ID_TYPE><urn:SUBR_TYPE>778</urn:SUBR_TYPE><urn:GRUP_CODE>qwe</urn:GRUP_CODE><urn:SMS_LANG>th</urn:SMS_LANG><urn:CC_LANG>th</urn:CC_LANG><urn:LANG>rt</urn:LANG><urn:IVR_LANG>67</urn:IVR_LANG></urn:outbuf></urn:ReadSubrIACCWSResponse>";
 
    res.writeHead(200, {'Content-Type': 'application/soap+xml'});
    /*res.write(JSON.stringify(body));*/
   /* res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port);

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}*/

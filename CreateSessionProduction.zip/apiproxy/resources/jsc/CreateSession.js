var ResPayload = context.getVariable("ResPayload.content");
var ResPayload=context.getVariable("req.ResPayload");
/* var strUsername = "9790100063";
 var strPIN = "1234";
context.setVariable("req.strUsername","9790100063");
context.setVariable("req.strPIN", "1234");*/
var strUsername=context.getVariable("req.UserName");
context.setVariable("req.strUsername",strUsername);
print("username="+strUsername);
var strPIN=context.getVariable("req.Password");
context.setVariable("req.strPIN", strPIN);
 
 var strSessionID=context.getVariable("req.strSessionID");
context.setVariable("req.strSessionID", strSessionID); 
  var idValue=context.getVariable("req.strUsername");
context.setVariable("req.idValue", idValue);

 /*
 if(isEmpty(strUsername) || isEmpty(strPIN) ||  isEmpty(strSessionID)){
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.10.101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input.");
    throw "serviceException";
}


function isEmpty(input) {
    return (!input || 0 === input.length);
}

    if(ResPayload===null)
{
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.10.101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
    
}
else{
  //   var sessionid = context.getVariable("req.sessionid");
 //  context.setVariable("sessionid", sessionid);
    
}*/
var strSessionID=context.getVariable("req.strSessionID");
context.setVariable("req.strSessionID", strSessionID); 
var saltedPin=context.getVariable("saltedPin");
context.setVariable("req.saltedPin", saltedPin);
var idValue=context.getVariable("req.idValue");
context.setVariable("req.idValue", idValue);

var userAgent=context.getVariable('request.header.User-Agent');
context.setVariable("req.userAgent", userAgent);

 if(isEmpty(idValue) || isEmpty(saltedPin) ||  isEmpty(strSessionID)){
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.028.101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input.");
    throw "serviceException";
}
function isEmpty(input) {
    return (!input || 0 === input.length);
}

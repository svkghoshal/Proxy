var result = context.getVariable("result");
var apiNo = "028";
if((result=='0'))
    context.setVariable("status","Success");
else
{
	switch(result) {

	case "1":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","Badly formatted request");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "2":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","Invalid session");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "3":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".102");
			context.setVariable("errorMessage","The Agent attempting to access the system could not be found");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "4":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".103");
			context.setVariable("errorMessage","The Agent attempting to access the system must be registered before they can use any functionality");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "5":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".101");
			context.setVariable("errorMessage","The Agent is inactive and needs to contact Customer Service");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "6":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".102");
			context.setVariable("errorMessage","The Agent is suspended and needs to contact Customer Service");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "7":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".103");
			context.setVariable("errorMessage","Access is denied for this function to the requesting Agent");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "8":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".104");
			context.setVariable("errorMessage","Agent supplied an incorrect password");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "9":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".105");
			context.setVariable("errorMessage","Agent's password has expired. They must change to a new one");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
			
	case "10":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".104");
			context.setVariable("errorMessage","Agent's new password has been previously used and has been rejected");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";	
	case "11":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","Agent has made too many attempts to log in with a bad password. They need to contact Customer Service to get it reset.");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","400");
			throw "serviceException";	
	case "12":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".108");
			context.setVariable("errorMessage","The new password supplied is the same as the old one and has been rejected");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";	
	case "13":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".109");
			context.setVariable("errorMessage","The target Agent in a transaction does not exist");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "14":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".110");
			context.setVariable("errorMessage","The target Agent in a transaction is not registered as yet");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "15":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".111");
			context.setVariable("errorMessage","The target Agent in a transaction is inactive");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "16":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".112");
			context.setVariable("errorMessage","The target Agent in a transaction is suspended");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "17":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".113");
			context.setVariable("errorMessage","The amount requested is invalid");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "18":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".114");
			context.setVariable("errorMessage","Agent is already registered");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "19":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","Requesting Agent has been blacklisted. Please contact Customer Service");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "20":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".102");
			context.setVariable("errorMessage","Target Agent has been blacklisted. Please contact Customer Service");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "22":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".103");
			context.setVariable("errorMessage","The target Agent is the same as the requesting Agent");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "23":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".101");
			context.setVariable("errorMessage","Amount requested is too small");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "24":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".102");
			context.setVariable("errorMessage","Amount requested is too large");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "25":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".103");
			context.setVariable("errorMessage","The wrong amount was supplied in a confirm command");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "26":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".104");
			context.setVariable("errorMessage","No target Agent was supplied");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "27":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".105");
			context.setVariable("errorMessage","The requesting Agent has expired");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";	
			
	case "28":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".104");
			context.setVariable("errorMessage","The target Agent has expired");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";	
	case "29":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","User supplied an invalid password");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","400");
			throw "serviceException";	
	case "30":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".108");
			context.setVariable("errorMessage","Agent is already active");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";	
	case "32":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".109");
			context.setVariable("errorMessage","The original request has expired due to a timeout");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "33":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".110");
			context.setVariable("errorMessage","The transaction in question has been reversed");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "34":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".111");
			context.setVariable("errorMessage","Transaction is not a two party transaction");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "35":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".112");
			context.setVariable("errorMessage","Requested Agent status change is invalid");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "36":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".113");
			context.setVariable("errorMessage","Transaction is too old to complete");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "37":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".114");
			context.setVariable("errorMessage","Transaction was not completed");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "38":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","Agent has been stopped");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "39":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".102");
			context.setVariable("errorMessage","Target Agent has been stopped");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "40":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".103");
			context.setVariable("errorMessage","Agent is already started");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "41":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".101");
			context.setVariable("errorMessage","N/Topup system returned a system error");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "42":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".102");
			context.setVariable("errorMessage","N/Topup system returned rejected the target MSISDN");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "43":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".103");
			context.setVariable("errorMessage","N/Topup system was unavailable");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "44":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".104");
			context.setVariable("errorMessage","N/Topup system returned a “bad voucher” error");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "45":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".105");
			context.setVariable("errorMessage","N/Topup system timed out the request");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";	
			
	case "46":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".104");
			context.setVariable("errorMessage","Amount requested was not within a valid range");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";	
	case "47":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","Target Agent is not a special Agent");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","400");
			throw "serviceException";	
	case "48":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".108");
			context.setVariable("errorMessage","The supplied Billpay account is not valid");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";	
	case "49":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".109");
			context.setVariable("errorMessage","The Bank is currently offline");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "50":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".110");
			context.setVariable("errorMessage","The Bank returned an error");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	    case "1012":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".101");
            context.setVariable("errorMessage","AUTH_RETRY_EXCEED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
/*	case "51":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".111");
			context.setVariable("errorMessage","The target Agent in a transaction is inactive");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "52":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".112");
			context.setVariable("errorMessage","The target Agent in a transaction is suspended");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "53":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".113");
			context.setVariable("errorMessage","The amount requested is invalid");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "54":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".114");
			context.setVariable("errorMessage","Agent is already registered");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "55":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","Requesting Agent has been blacklisted. Please contact Customer Service");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "56":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".102");
			context.setVariable("errorMessage","Target Agent has been blacklisted. Please contact Customer Service");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "57":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".103");
			context.setVariable("errorMessage","The target Agent is the same as the requesting Agent");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "58":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".101");
			context.setVariable("errorMessage","Amount requested is too small");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "59":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".102");
			context.setVariable("errorMessage","Amount requested is too large");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "60":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".103");
			context.setVariable("errorMessage","The wrong amount was supplied in a confirm command");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			break;
	case "61":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".104");
			context.setVariable("errorMessage","No target Agent was supplied");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			break;
	case "62":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".105");
			context.setVariable("errorMessage","The requesting Agent has expired");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;	
			
	case "63":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".104");
			context.setVariable("errorMessage","The target Agent has expired");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;	
	case "64":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","User supplied an invalid password");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","400");
			break;	
	case "66":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".108");
			context.setVariable("errorMessage","Agent is already active");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;	
	case "68":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".109");
			context.setVariable("errorMessage","The original request has expired due to a timeout");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "69":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".110");
			context.setVariable("errorMessage","The transaction in question has been reversed");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "70":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".111");
			context.setVariable("errorMessage","Transaction is not a two party transaction");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "71":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".112");
			context.setVariable("errorMessage","Requested Agent status change is invalid");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "72":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".113");
			context.setVariable("errorMessage","Transaction is too old to complete");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "73":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".114");
			context.setVariable("errorMessage","Transaction was not completed");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;*/
		case "74":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".102");
			context.setVariable("errorMessage","Invalid password mismatch");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			 throw "serviceException";
/*	case "75":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".103");
			context.setVariable("errorMessage","Reversal Failed");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "76":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".101");
			context.setVariable("errorMessage","Group name already exists");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "77":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".102");
			context.setVariable("errorMessage","Group not empty");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "78":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".103");
			context.setVariable("errorMessage","Confirmer same as initiator");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "103":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".104");
			context.setVariable("errorMessage"," Confirmation was rejected  ");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "250":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".105");
			context.setVariable("errorMessage"," Confirm transfer");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";	
			
	case "251":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".104");
			context.setVariable("errorMessage"," Confirm cashout");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";	
	case "252":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage"," Confirm sell");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","400");
			throw "serviceException";	
	case "253":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".108");
			context.setVariable("errorMessage"," Confirm Billpay");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";	
	case "255":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".109");
			context.setVariable("errorMessage"," Confirm link");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "256":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".110");
			context.setVariable("errorMessage"," Confirm join parent");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "257":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".111");
			context.setVariable("errorMessage"," Confirm join child");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "312":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".112");
			context.setVariable("errorMessage"," Modify wallet ok");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "400":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".113");
			context.setVariable("errorMessage","Requested transaction cannot be found");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "401":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".114");
			context.setVariable("errorMessage","Transfer confirm rejected");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "423":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage"," Transaction has already been committed");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "424":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".102");
			context.setVariable("errorMessage"," Transaction has already been rolled back");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "415":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".103");
			context.setVariable("errorMessage"," Trace transaction was not found");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";
	case "425":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".101");
			context.setVariable("errorMessage"," Message was too long");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "501":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".102");
			context.setVariable("errorMessage","Cannot link to requested Sub-Agent");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "502":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".103");
			context.setVariable("errorMessage"," Cannot link to yourself");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "503":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".104");
			context.setVariable("errorMessage"," The linked Agent has been deleted");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			throw "serviceException";
	case "504":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".105");
			context.setVariable("errorMessage","Cannot join to self");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";	
			
	case "505":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".104");
			context.setVariable("errorMessage","Agents already joined");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			throw "serviceException";	
	case "506":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","Join agent is deleted");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","400");
			throw "serviceException";
			
	case "507":
           context.setVariable("exceptionName","exceptionName");
           context.setVariable("errorCode", "400." + apiNo + ".101");
           context.setVariable("errorMessage","Agents not joined");
           context.setVariable("errorDesc","Bad Request");
           context.setVariable("httpError","400");
           throw "serviceException";
    case "508":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".102");
            context.setVariable("errorMessage"," Purchase order number not unique");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";
    case "509":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".103");
            context.setVariable("errorMessage","Rebate amount not exact");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";
    case "510":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".101");
            context.setVariable("errorMessage","Rebate amount not multiple");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "520":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".102");
            context.setVariable("errorMessage","Voucher recipient not found");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "521":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".103");
            context.setVariable("errorMessage","Voucher expiry date passed");
            context.setVariable("errorDesc","Internal Srver Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "522":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".104");
            context.setVariable("errorMessage","Voucher does not exist");
            context.setVariable("errorDesc","Internal Srver Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "523":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".105");
            context.setVariable("errorMessage","Non-deleted voucher id or provider id exists");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "524":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".104");
            context.setVariable("errorMessage","Voucher is not in a deletable stated");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";           
    case "525":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
            context.setVariable("errorMessage","Matching voucher not found");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","400");
            throw "serviceException";
    case "530":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".108");
            context.setVariable("errorMessage"," Map agent group listener failed");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "540":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".109");
            context.setVariable("errorMessage","Coupon write failed");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "541":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".110");
            context.setVariable("errorMessage","Coupon in progress");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "542":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".111");
            context.setVariable("errorMessage","Coupon does not exists");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "543":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".112");
            context.setVariable("errorMessage","Invalid coupon user");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "544":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".113");
            context.setVariable("errorMessage","Coupon funds temporarily unavailable");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "545":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".114");
            context.setVariable("errorMessage","Coupon cancelled");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "546":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
            context.setVariable("errorMessage","Coupon id exists");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";
    case "547":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".102");
            context.setVariable("errorMessage","MULTIPLE_COUPONS_EXIST");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";
    case "550":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".103");
            context.setVariable("errorMessage","MISSING_INITIATOR_ATTRIBUTE");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";
    case "551":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".101");
            context.setVariable("errorMessage","MISSING_DEBTOR_ATTRIBUTE");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "552":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".102");
            context.setVariable("errorMessage","MISSING_CREDITOR_ATTRIBUTE");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
*/
  /*
    case "600":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".104");
            context.setVariable("errorMessage","TARGET_IS_NOT_INVOCABLE");
            context.setVariable("errorDesc","Internal Srver Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "700":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".105");
            context.setVariable("errorMessage","EXTERNAL_INSUFFICIENT_FUNDS");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "701":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".104");
            context.setVariable("errorMessage","EXTERNAL_EXCESS_FUNDS");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";           
    case "1001":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
            context.setVariable("errorMessage","INSUFFICIENT_FUNDS");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","400");
            throw "serviceException";           
    case "1002":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".108");
            context.setVariable("errorMessage","TRANSACTION_RECOVERED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "1003":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".109");
            context.setVariable("errorMessage","WALLET_BALANCE_EXCEEDED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "1004":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".110");
            context.setVariable("errorMessage","WALLET_CAP_EXCEEDED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "1005":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".111");
            context.setVariable("errorMessage","REQUEST_EXPIRED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";

    case "1007":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".113");
            context.setVariable("errorMessage","DB_ERROR");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "1008":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".114");
            context.setVariable("errorMessage","BAD_REQUEST");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "1009":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
            context.setVariable("errorMessage","DB_CONSTRAINT");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";
    case "1010":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".102");
            context.setVariable("errorMessage","DB_NO_RECORD");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";
    case "1011":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".103");
            context.setVariable("errorMessage","AUTH_BAD_TOKEN");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";
    case "1013":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".102");
            context.setVariable("errorMessage","AUTH_EXPIRED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "1014":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".103");
            context.setVariable("errorMessage","AUTH_BAD_PASSWORD");
            context.setVariable("errorDesc","Internal Srver Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "1015":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".104");
            context.setVariable("errorMessage","Voucher does not exist");
            context.setVariable("errorDesc","Internal Srver Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "1016":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".105");
            context.setVariable("errorMessage","AUTH_PASSWORD_PREV_USED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "1017":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".104");
            context.setVariable("errorMessage","AUTH_NO_PASSWORD_SET");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";           
    case "1020":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
            context.setVariable("errorMessage","PARAM_INVALID_REQUIRED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","400");
            throw "serviceException";           
    case "1021":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".108");
            context.setVariable("errorMessage","PARAM_INVALID_TOO_SHORTT");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "1022":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".109");
            context.setVariable("errorMessage","PARAM_INVALID_TOO_LONG");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";
    case "1023":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".110");
            context.setVariable("errorMessage","PARAM_INVALID_REGXP");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "1024":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".111");
            context.setVariable("errorMessage","LICENCE_EXPIRED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "1025":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".112");
            context.setVariable("errorMessage","RULE_MALFORMED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "1026":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".113");
            context.setVariable("errorMessage","ACCESS_DENIED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "1027":
              context.setVariable("exceptionName","exceptionName");
              context.setVariable("errorCode", "500." + apiNo + ".114");
              context.setVariable("errorMessage","BAD_PROXY_REQUEST");
              context.setVariable("errorDesc","Internal Server Error");
              context.setVariable("httpError","500");
              throw "serviceException";           
    case "1028":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
            context.setVariable("errorMessage","PROXY_OFFLINE");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";           
    case "3011":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".102");
            context.setVariable("errorMessage","INVALID_SECRET_LENGTH");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";           
    case "3012":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".103");
            context.setVariable("errorMessage","INVALID_SECRET_WORD");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";           
    case "6202":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".101");
            context.setVariable("errorMessage","AGENT_DATA_OBJECT_ID_EXISTS");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "6203":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".102");
            context.setVariable("errorMessage","AGENT_DATA_OBJECT_ID_NOT_EXISTS");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "6204":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".103");
            context.setVariable("errorMessage","GENERIC_RETRY");
            context.setVariable("errorDesc","AGENT_DATA_PROP_NOT_EXISTS");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "6205":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".104");
            context.setVariable("errorMessage","AGENT_DATA_PROP_EXISTSE");
            context.setVariable("errorDesc","Internal Srver Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "6206":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".105");
            context.setVariable("errorMessage","ADDRESS_BOOK_EMPTY");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "6207":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".104");
            context.setVariable("errorMessage","NICKNAME_NOT_EXISTS");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("httpError","400");
            throw "serviceException";           
    case "6208":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
            context.setVariable("errorMessage","INVALID_NICKNAME_LENGTH");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","400");
            throw "serviceException";           
    case "6211":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".108");
            context.setVariable("errorMessage","MAX_NICKNAMES_EXCEEDED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "20001":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".109");
            context.setVariable("errorMessage","SUBSCRIPTION_DELETED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "20101":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".110");
            context.setVariable("errorMessage","SUBSCRIPTION_FAILED");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "20201":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".111");
            context.setVariable("errorMessage","SUBSCRIPTION_ALREADY_EXISTS");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";           
    case "20252":
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".112");
            context.setVariable("errorMessage","SUBSCRIPTION_IN_PROGRESS");
            context.setVariable("errorDesc","Internal Server Error");
            context.setVariable("httpError","500");
            throw "serviceException";    
*/
	default :
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".100");
			context.setVariable("errorMessage","result:" + result);
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			throw "serviceException";	
			
				
	}
}
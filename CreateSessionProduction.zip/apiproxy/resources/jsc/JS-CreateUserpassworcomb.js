 var UserName=context.getVariable("req.UserName");
context.setVariable("UserName",UserName);
 var Password=context.getVariable("req.Password");
context.setVariable("Password",Password);
var UserPwdComb=UserName+"#"+Password;
context.setVariable("UserPwdComb",UserPwdComb);
print("UserPwdComb::"+UserPwdComb);
var respstatus = context.getVariable("resp.Status");
var detail = context.getVariable("resp.detail");
var faultcode = context.getVariable("resp.faultcode");
var faultstring = context.getVariable("resp.faultstring");
context.setVariable("isoTimestamp", ISODateString());
var referenceCode = getISODate().concat(getRandomNumber());
context.setVariable("referenceCode", referenceCode);
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());
var apiNo = "031";


if(respstatus=='Success'){
    context.setVariable("respStatus", respstatus);
}
/*else{
            context.setVariable("exceptionName", "InternalServerError");
            context.setVariable("errorCode", "500.000.101");
            context.setVariable("errorDesc", faultstring);
            context.setVariable("errorMessage", detail);
            context.setVariable("httpError", "500");
}*/

else
    {
      if(faultcode=='E101')
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", detail);
            context.setVariable("httpError", "500");
        }
     else if(faultcode=='E100')
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".102");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", detail);
            context.setVariable("httpError", "500");
        }
    else if(faultcode=='E0001')
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".103");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", detail);
            context.setVariable("httpError", "500");
        }
    else if(faultcode=='E0002')
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".104");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", detail);
            context.setVariable("httpError", "500");
        }
    else if(faultcode=='E0003')
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".105");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", detail);
            context.setVariable("httpError", "500");
        }
    else if(faultcode=='E0004')
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".106");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", detail);
            context.setVariable("httpError", "500");
        }
    else
        {
                context.setVariable("exceptionName", "exceptionName");    
                context.setVariable("errorCode", "500."+apiNo+".100");
                context.setVariable("errorDesc", "Internal Server Error");
                context.setVariable("errorMessage", faultString);
                context.setVariable("httpError", "500");
        }
    }
    
    
    
/*else
{
   switch(faultcode) {
    
                case "2":
                    context.setVariable("exceptionName", "InternalServerError");
                    context.setVariable("errorCode", "500."+apiNo+".101");
                    context.setVariable("errorDesc", faultstring);
                    context.setVariable("errorMessage",detail);
                    context.setVariable("httpError", "500");
                    break;
                    
                default:
                    context.setVariable("exceptionName", "exceptionName");
            		context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".100");
            		context.setVariable("errorDesc", "Internal Server Error");
            		context.setVariable("errorMessage",  "");
            		context.setVariable("httpError", "500");
            		break;
                
            }  
}*/





function getISODate() {
    var d = new Date();
    var n = d.toISOString();
    return n;
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
function getRandomNumber()
{
  var val = Math.floor(100000 + Math.random() * 900000);
  return val;
}

function getTargetStartTime() {
    if (isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.sent.start.timestamp"));
    }
}

function getTargetEndTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.received.end.timestamp"));
    }
}

function getTargetElaspTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp")) || isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        var targetElapsTime = context.getVariable("target.received.end.timestamp") - context.getVariable("target.sent.start.timestamp");
        return "" + targetElapsTime;
    }
}
function isEmpty(input) {
    return (!input || 0 === input.length);
}

function getTimePattern(dateTime) {
    var today = new Date(dateTime);
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second + "," + milliSecond;
}

function checkLengthDateFormat(today) {
    if (today.length == 1) {
        today = "0" + today;
    }
    return today;
}


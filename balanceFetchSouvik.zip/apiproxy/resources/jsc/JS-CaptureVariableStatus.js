var status1 = context.getVariable("apigee.status");
context.setVariable("status1",status1);
print(status1);
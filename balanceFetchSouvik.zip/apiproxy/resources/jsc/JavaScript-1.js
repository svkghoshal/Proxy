/*print(context.getVariable("id"));
print(context.getVariable("day"));*/

var data=context.getVariable("apigee.id");
var day=context.getVariable("apigee.day");
var jsonData = {'Path extracted id': data,'Query extracted day': day};



context.setVariable('message.header.Content-Type', "application/json");
context.setVariable('message.content', JSON.stringify(jsonData));

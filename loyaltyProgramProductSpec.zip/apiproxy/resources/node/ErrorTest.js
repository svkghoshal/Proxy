 var http = require('http');
var apigee = require('apigee-access');

server = http.createServer( function(req, res) {
    console.log ('subscribers-v1 sandbox');
	console.log ('Request ::: '+JSON.stringify(req.Body));
	var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
    
	var bodyProfile = "";
	
	
	res.writeHead(200, {'Content-Type': 'application/json'});

	var bodyBurnn = '{ "resCode": "0", "resMsg": "SUCCESS", "customerMsisdn": "9790122440", "adjustmentType": "debit", "adjustedPoints": "50", "availablePoints": "400" }';
    var bodyEarn = '{ "resCode": "0", "resMsg": "SUCCESS", "customerMsisdn": "9790122440", "adjustmentType": "credit", "adjustedPoints": "50", "availablePoints": "400" }';


	res.end(bodyEarn);
	
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port);
 /*
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
*/
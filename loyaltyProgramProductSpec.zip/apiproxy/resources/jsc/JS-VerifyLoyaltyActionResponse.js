//print(context.getVariable("response.content"));
var resMsg = context.getVariable("resp.resMessage");
var resCode = context.getVariable("resp.resCode");
var apiNo = "065";

context.setVariable("isoTimestamp", ISODateString());
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());

if(resCode =='0' || resCode =='1' || resCode =='2')
{
    context.setVariable("respStatus", "Success");
}
else if(resCode =='E007')
{
    	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".101");
	context.setVariable("errorDesc", "No Points Information Available");
	context.setVariable("errorMessage", "Internal Server Error");
	context.setVariable("httpError", "500");
}
else{

switch (resCode) {

case "E001":
case "E002":
case "E004":
case "E005":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400."+apiNo+".101");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Invalid Input");
	context.setVariable("httpError", "400");
	break;
case "E003":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".102");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Customer Information Not Found");
	context.setVariable("httpError", "500");
	break;
default:
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage",resMsg);
	context.setVariable("httpError", "500");
	break;

    }
}
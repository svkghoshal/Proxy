var msisdn = context.getVariable("req.msisdn");
var userId = context.getVariable("req.userId");
var password = context.getVariable("req.password");
var channelId = context.getVariable('message.queryparam.channel.id');
var transactionId = context.getVariable("req.Id");

context.setVariable("msisdn",msisdn);
context.setVariable("channelId",channelId);
context.setVariable("transactionId", transactionId);
context.setVariable("isoTimestamp", ISODateString());

var apiNo = "065";
var msisdnLength = msisdn.length;

if (isEmpty(msisdn) ||isEmpty(userId) || isEmpty(password) ) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
if ((!msisdn.startsWith("97")) || (msisdnLength != 10))  {
   
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
var record = context.getVariable("res.record");
var resultMessage = context.getVariable("res.resMsg");
context.setVariable("isoTimestamp", ISODateString());
var telcoRewardsDetails = context.getVariable("res.telcoRewardsDetails");
//context.setVariable("referenceCode", referenceCode);
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());
var apiNo = "065";
try{
if ((telcoRewardsDetails == "[]")) {
    var response_flag = "true";
    context.setVariable("response_flag", response_flag);
}
else{
    var response_flag = "false";
    context.setVariable("response_flag", response_flag);
}}
catch(e){
    var response_flag = "false";
    context.setVariable("response_flag", response_flag);
}


if(resultMessage=='SUCCESS'){
    context.setVariable("respStatus", "SUCCESS");
}
else
    {
      if(record=='E101' || record=='E102' || record=='E104')
        {	
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400."+apiNo+".101");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid Input");
            context.setVariable("httpError", "400");
        }
    else if(record=='E103')
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".102");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Customer Information Not Found");
            context.setVariable("httpError", "500");
        }
    else if(record=='E105')
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".102");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "No rewards details found");
            context.setVariable("httpError", "500");
        }
    else
        {
                context.setVariable("exceptionName", "exceptionName");    
                context.setVariable("errorCode", "500."+apiNo+".100");
                context.setVariable("errorDesc", "Internal Server Error");
                context.setVariable("errorMessage", resultMessage);
                context.setVariable("httpError", "500");
        }
    }
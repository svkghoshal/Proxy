   var payload = context.getVariable("res.record");


    var jsonResponse = String(payload).replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "").replace(/~STR~/g, "");
     var vpayload = String(jsonResponse).replace(/null/g, '""');
    //var jsonResponse = String(payload).replace(/"offers:"/g, "").replace(/"~ARRAY~"/g, "").replace(/"~ARRAY~",/g, "");
    context.setVariable("res.record",vpayload);
 
 
  
var json_response = context.getVariable("response.content");
//var myJSON = JSON.stringify(json_response);
var formated_payload = '{"a":'+json_response+'}';
//var json_response_1 = JSON.stringify(formated_payload);
context.setVariable("response.content", formated_payload);
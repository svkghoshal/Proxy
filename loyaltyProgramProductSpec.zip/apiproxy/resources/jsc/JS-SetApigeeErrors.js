var faultName = context.getVariable("fault.name");
context.setVariable("isoTimestamp", ISODateString()); 
var apiNo = "065";

var id = context.getVariable("req.id");
context.setVariable("msisdn", id);
var faultString = context.getVariable("faultString");
var faultCode = context.getVariable("faultCode");
var targetStartTime,targetEndTime,targetElapsTime;

context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());

//var d = new Date();
//var n = d.getTime();
//var random = Math.ceil(Math.random()*n);
//var transactionId = (id+random).substring(0,20);


context.setVariable("transactionId",  transactionDateTime() + randomString(6));
//context.setVariable("transactionId",transactionId);

switch (faultName) {

case "SpikeArrestViolation":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "429."+apiNo+".001");
	context.setVariable("errorDesc", "Too Many Requests");
	context.setVariable("errorMessage", "Spike arrest violation");
	context.setVariable("httpError", "429");
	break;
	
case "ErrorResponseCode":
case "ServiceUnavailable":
case "UnexpectedEOFAtTarget":
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("errorCode", "503."+apiNo+".101");
    context.setVariable("errorDesc", "Service Unavailable");
    context.setVariable("errorMessage", "The service is unavailable");
    context.setVariable("httpError", "503");
    break;
    
case "GatewayTimeout":
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("errorCode", "504."+apiNo+".102");
    context.setVariable("errorDesc", "Gateway Timeout");
    context.setVariable("errorMessage", "The service is unavailable");
    context.setVariable("httpError", "504");
    break;
    
case "RequestTimeout":
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("errorCode", "408."+apiNo+".103");
    context.setVariable("errorDesc", "Request Timeout");
    context.setVariable("errorMessage", "The service is unavailable");
    context.setVariable("httpError", "408");
    break;
    
case "access_token_expired":
case "invalid_access_token":
case "InvalidAccessToken":
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("errorCode", "401."+apiNo+".006");
    context.setVariable("errorDesc", "Unauthorized");
    context.setVariable("errorMessage", "Access token is invalid or expired");
    context.setVariable("httpError", "401");
    break;

case "QuotaViolation":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "429."+apiNo+".002");
	context.setVariable("errorDesc", "Too Many Requests");
	context.setVariable("errorMessage", "Rate limit quota violation. Quota limit exceeded");
	context.setVariable("httpError", "429");
	break;

case "ConcurrentRatelimtViolation":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "429."+apiNo+".003");
	context.setVariable("errorDesc", "Too Many Requests");
	context.setVariable("errorMessage", "Concurrent rate limit connection exceeded");
	context.setVariable("httpError", "429");
	break;

case "ScriptExecutionFailed":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".001");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "JavaScript runtime error");
	context.setVariable("httpError", "500");
	break;

case "InvalidApiKeyForGivenResource":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".002");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Invalid ApiKey for given resource");
	context.setVariable("httpError", "500");
	break;

case "NoActiveTargets":
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("errorCode", "503."+apiNo+".101");
    context.setVariable("errorDesc", "Service Unavailable");
    context.setVariable("errorMessage", "The service is unavailable");
    context.setVariable("httpError", "503");
    break;

case "ExecutionFailed":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".003");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Request input is malformed or invalid");
	context.setVariable("httpError", "500");
	break;

case "InvalidJSONPath":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".004");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Invalid JSON path");
	context.setVariable("httpError", "500");
	break;

case "RaiseFault":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "404."+apiNo+".001");
	context.setVariable("errorDesc", "Resource not found");
	context.setVariable("errorMessage", "Resource not found/Invalid resource");
	context.setVariable("httpError", "404");
	break;

default:
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", faultName);
	context.setVariable("httpError", "500");
	break;

}

var id = context.getVariable("req.id");
var userId = context.getVariable("req.userId");
var password = context.getVariable("req.password");
var reqid = context.getVariable("req.reqid");
var type = context.getVariable("req.type");
var couponTypeId = context.getVariable("req.couponTypeId");
var channelId = context.getVariable("req.channelId"); 
context.setVariable("msisdn",id);
var apiNo = "065";
var msisdnLength = id.length;
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);
var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
context.setVariable("transactionId", apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

context.setVariable("isoTimestamp", ISODateString());

if (isEmpty(id) ||isEmpty(userId) || isEmpty(password) 
|| isEmpty(reqid) ||isEmpty(type) || isEmpty(channelId) ) {
   
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
if ((!id.startsWith("97")) || (msisdnLength != 10))  {
   
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
if ((reqid.length > 25))  {
   
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
var resMsg = context.getVariable("resp.resMsg");
var redeemPoints = context.getVariable("resp.redeemPoints");
var couponCode = context.getVariable("resp.couponCode");
var resCode = context.getVariable("resp.resCode");
var apiNo = "065";

context.setVariable("isoTimestamp", ISODateString());
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());

if(resMsg != "SUCCESS")
{

switch (resCode) {

case "E201":
case "E202":
case "E204":
case "E206":
case "E207":
case "E208":
case "E210":
case "E211":
case "E215":
case "E216":
case "E221":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400."+apiNo+".101");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Invalid Input");
	context.setVariable("httpError", "400");
	break;
case "E220":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Customer is not eligible");
	context.setVariable("httpError", "500");
	break;
case "E203":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".102");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Customer Information Not Found");
	context.setVariable("httpError", "500");
	break;
case "E205":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".103");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "No rewards details found");
	context.setVariable("httpError", "500");
	break;
case "E213":
case "E214":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".104");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Insufficient Points");
	context.setVariable("httpError", "500");
	break;
case "E212":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".105");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Points could not be redeemed");
	context.setVariable("httpError", "500");
	break;
case "E209":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".106");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "No Coupons found");
	context.setVariable("httpError", "500");
	break;
case "E217":
case "E218":
case "E219":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".107");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Reached Redemption Limit");
	context.setVariable("httpError", "500");
	break;
default:
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage",resMsg);
	context.setVariable("httpError", "500");
	break;

}
}else{
     context.setVariable("respStatus", "Success");
}
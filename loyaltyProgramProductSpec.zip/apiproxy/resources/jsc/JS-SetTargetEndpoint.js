var proxy = context.getVariable("proxy.pathsuffix");
var SourceSystem = context.getVariable("req.channelId");
var startDateTime = context.getVariable("req.startDateTime");
var endDateTime = context.getVariable("req.endDateTime");
var endpoint = "/cxf/GetStarRewardsDetailsSynchPS/?";
var verb = context.getVariable("request.verb");
var sourceId = context.getVariable("request.queryparam.channelId");
var id = context.getVariable("req.id");
var lan = context.getVariable("req.lan");
var partnerId = context.getVariable("request.queryparam.partnerId");
var list = context.getVariable("request.queryparam.list");
var apiNo = "065";
context.setVariable("isoTimestamp", ISODateString());
//var msisdnLength = id.length;
if (lan == "en"){
    var Lan = "EN";
}
else if (lan == "mm"){
    var Lan = "MM";
}
else if (lan == "un"){
    var Lan = "UN";
}
else{
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}


if (!isEmpty(partnerId)){
    var ptid_flag = "true";
}
else{
    var ptid_flag = "false";
}



if (proxy == "/loyaltyProgramProduct") {
    if (ptid_flag == "true"){
        if(!isEmpty(list)){
            path = endpoint+"MSISDN="+id+"&PartnerID="+partnerId+"&SourceSystemID="+sourceId+"&Language="+Lan+"&Type=Telco";
            context.setVariable("path", path);
        }
        else{
            path = endpoint+"MSISDN=&PartnerID="+partnerId+"&SourceSystemID="+sourceId+"&Language="+Lan+"&Type=Telco";
            context.setVariable("path", path);
        }
    }
    else if(ptid_flag == "false"){
        if(!isEmpty(list)){
            path = endpoint+"MSISDN="+id+"&PartnerID=&SourceSystemID="+sourceId+"&Language="+Lan+"&Type=Telco";
            context.setVariable("path", path);
        }
        else{
            path = endpoint+"MSISDN=&PartnerID=&SourceSystemID="+sourceId+"&Language="+Lan+"&Type=Telco"; 
            context.setVariable("path", path);
        }
    }    
}else if(proxy == "/loyaltyAffiliateProduct"){
       if (ptid_flag == "true"){
        if(!isEmpty(list)){
            path = endpoint+"MSISDN="+id+"&PartnerID="+partnerId+"&SourceSystemID="+sourceId+"&Language="+Lan+"&Type=nonTelco";
            context.setVariable("path", path);
        }
        else{
            path = endpoint+"MSISDN=&PartnerID="+partnerId+"&SourceSystemID="+sourceId+"&Language="+Lan+"&Type=nonTelco";
            context.setVariable("path", path);
        }
    }
    else if(ptid_flag == "false"){
        if(!isEmpty(list)){
            path = endpoint+"MSISDN="+id+"&PartnerID=&SourceSystemID="+sourceId+"&Language="+Lan+"&Type=nonTelco";
            context.setVariable("path", path);
        }
        else{
            path = endpoint+"MSISDN=&PartnerID=&SourceSystemID="+sourceId+"&Language="+Lan+"&Type=nonTelco"; 
            context.setVariable("path", path);
        }
    } 
}
else if(proxy == "/loyaltyAction"){
    
    if(verb == "POST")
    {
        path = "/cxf/RedeemRewardsPointsSynchPS";
        context.setVariable("path", path);
    
    }else{
        
        path = "/cxf/GetStarTypeAndStatusSynchPS/?"+"MSISDN="+id+"&DETAILS=ALL&SourceSystem="+SourceSystem+"&startDate="+startDateTime+"&endDate="+endDateTime;
        context.setVariable("path", path);
    }


}
else if((proxy == "/loyaltyBurn") || (proxy == "/loyaltyEarn")){
    
    if(verb == "POST")
    {
        path = "/ALMS/adjust/adjustPointsService";
        context.setVariable("path", path);
    
    }

}else{
    
    if(verb == "GET")
    {
        path = "/cxf/getALMSPoints";
        context.setVariable("path", path);
    
    }

}
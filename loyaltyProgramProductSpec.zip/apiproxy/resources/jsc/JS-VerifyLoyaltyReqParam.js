var id = context.getVariable("req.id");
var productSpecId = context.getVariable("req.productSpecId");
context.setVariable("msisdn",id);
var apiNo = "065";
var msisdnLength = id.length;
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);
var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
context.setVariable("transactionId", apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

context.setVariable("isoTimestamp", ISODateString());

if (isEmpty(id)) {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
if (isEmpty(productSpecId)) {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
if ((!id.startsWith("97")) || (msisdnLength != 10))  {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
var id = context.getVariable("req.id");
var language = context.getVariable("req.lan");
var sourceId = context.getVariable("request.queryparam.channelId");
var partnerId = context.getVariable("request.queryparam.partnerId");
var list = context.getVariable("request.queryparam.list");
var apiNo = "065";
var msisdnLength = id.length;
if (!isEmpty(sourceId)){
context.setVariable("transactionId",  extractSourceId(sourceId) + transactionDateTime() + randomString(3));
}
else {
 context.setVariable("transactionId",  transactionDateTime()+ randomString(6));   
}
context.setVariable("isoTimestamp", ISODateString());

if (isEmpty(id)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}

if (isEmpty(sourceId)) {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}

if ((!id.startsWith("97")) || (msisdnLength != 10))  {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
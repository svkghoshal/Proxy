var id = context.getVariable("req.id");
context.setVariable("msisdn", id);
var productSpecId = context.getVariable("req.productSpecId");
context.setVariable("productSpecId", productSpecId);
var respstatus = context.getVariable("resp.status");
var CouponDesc = context.getVariable("resp.CouponDesc");
var IdRef = context.getVariable("resp.IdRef");
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());
var StateID = context.getVariable("req.newMSISDN_StateID");
var faultstring = context.getVariable("resp.faultstring");
var faultcode = context.getVariable("resp.faultcode");

context.setVariable("href","/loyaltyManagement/loyaltyProgramProductSpec/"+context.getVariable("productSpecId"));
var apiNo = "065";

switch (faultcode) {

case "E0001":
case "E0002":
case "E0003":
case "E0004":
case "E0005":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400."+apiNo+".101");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Invalid Input");
	context.setVariable("httpError", "400");
	break;
case "E0006":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Customer is not eligible for loyalty benefits");
	context.setVariable("httpError", "500");
	break;
case "E0007":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".102");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "You have reached your daily/weekly/monthly limit of x");
	context.setVariable("httpError", "500");
	break;
case "E0008":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".103");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Exception Occured:"+faultstring);
	context.setVariable("httpError", "500");
	break;
case "E0009":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400."+apiNo+".101");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Invalid Input");
	context.setVariable("httpError", "400");
	break;
default:
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage","Exception Occured :"+faultstring);
	context.setVariable("httpError", "500");
	break;

}
    
if(respstatus=='Success'){
    context.setVariable("respStatus", respstatus);
}
var modifiedCouponDesc = CouponDesc.replace(/[^\x20-\x7E]/g,'');
context.setVariable("modifiedCouponDesc", modifiedCouponDesc);

var id = context.getVariable("req.id");
var startDateTime = context.getVariable("req.startDateTime");
var endDateTime = context.getVariable("req.endDateTime");
var channelId = context.getVariable("req.channelId");
context.setVariable("msisdn",id);
var apiNo = "065";
var msisdnLength = id.length;

var d = new Date();
var n = d.getTime();
var random = Math.ceil(Math.random()*n);
var transactionId = (id+random).substring(0,20);
context.setVariable("transactionId",transactionId);

context.setVariable("isoTimestamp", ISODateString());

if (isEmpty(id)) {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
if (isEmpty(startDateTime)) {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
if (isEmpty(endDateTime)) {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
if ((!id.startsWith("97")) || (msisdnLength != 10))  {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}

if (channelId === null)
{
    context.setVariable("channelId", "APIGW");
}
var resMsg = context.getVariable("resp.resMsg");
var resCode = context.getVariable("resp.resCode").trim();
var sourceSystem = context.getVariable("resp.sourceSystem");
var transactionId = context.getVariable("resp.transactionId");
var httpResCode = context.getVariable("message.status.code");
var customerLoyaltyPoints = context.getVariable("resp.customerLoyaltyPoints");
var apiNo = "065";

context.setVariable("isoTimestamp", ISODateString());
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());

if(resCode == '0' && httpResCode == '200'){
    context.setVariable("respStatus", "Success");
}else{
	
	if(resCode=='E0002' || resCode=='E0003' || resCode=='E0006' 
	|| resCode=='E0007' || resCode=='E0008' || resCode=='E0009'
	|| resCode=='E0010')
    {	
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400."+apiNo+".101");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Invalid Input");
	context.setVariable("httpError", "400");
    }else if(resCode=='E0005')
    {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Loyalty points are unavailable for the requested customer");
	context.setVariable("httpError", "500");
    }else
    {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage",resMsg);
	context.setVariable("httpError", "500");
    }
}

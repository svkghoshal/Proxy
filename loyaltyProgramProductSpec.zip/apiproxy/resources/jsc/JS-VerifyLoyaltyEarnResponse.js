var resMsg = context.getVariable("resp.resMsg");
var redeemPoints = context.getVariable("resp.redeemPoints");
var couponCode = context.getVariable("resp.couponCode");
var resCode = context.getVariable("resp.resCode").trim();
var apiNo = "065";

context.setVariable("isoTimestamp", ISODateString());
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());

if(resMsg=='SUCCESS'){
    context.setVariable("respStatus", "Success");
}else{
	
	if(resCode=='E101' || resCode=='E102' || resCode=='E103' 
	|| resCode=='E104' || resCode=='E105' || resCode=='E106'
	|| resCode=='E107' || resCode=='E108' || resCode=='E110'
	|| resCode=='E111' || resCode=='E116' || resCode=='E117' || resCode=='E118')
    {	
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400."+apiNo+".101");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Invalid Input");
	context.setVariable("httpError", "400");
    }else if(resCode=='E119')
    {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Customer is not eligible");
	context.setVariable("httpError", "500");
    }
	else if(resCode=="E113")
    {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".102");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Customer Information Not Found");
	context.setVariable("httpError", "500");
    }else if(resCode=='E109' || resCode=='E115')
    {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".104");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Insufficient Points");
	context.setVariable("httpError", "500");
    }else if(resCode=='E114')
    {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".105");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Points could not be redeemed");
	context.setVariable("httpError", "500");
    }else if(resCode=='E112')
    {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".106");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Operation is not allowed");
	context.setVariable("httpError", "500");
    }
	else
    {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage",resMsg);
	context.setVariable("httpError", "500");
    }
}

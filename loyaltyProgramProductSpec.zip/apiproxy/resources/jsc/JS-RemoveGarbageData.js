var payload = context.getVariable("TransformDataJson");
var jsonObject = JSON.parse(payload);
var jsonObjecttr = JSON.stringify(jsonObject.A.tr);
print(jsonObjecttr);
if(!isEmpty(jsonObjecttr))
{
    if (jsonObjecttr == '"~ARRAY~"')
    {
    context.setVariable("TransformDataJson","[]");
    }else{
    var jsonResponse = jsonObjecttr.replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "").replace(/"~ARRAY~",/g, "").replace(/~STR~/g, "");
    var vpayload = jsonResponse.replace(/null/g, '""');
    context.setVariable("TransformDataJson",vpayload);
    }

}
else
{
 context.setVariable("TransformDataJson","[]");   
}
 
 
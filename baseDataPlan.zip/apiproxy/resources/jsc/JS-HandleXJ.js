var fee = context.getVariable("response.content");
var DataSaver = context.getVariable("kvm.DataSaver");
var SRVName = context.getVariable("resp.SRVName");
context.setVariable("DataSaver", DataSaver);
var dataStatus = 'Non_Data_Saver';

if(!fee)
    context.setVariable("response.content", "[]");
 else{
    var jsonObject = JSON.parse(fee);
	var sbc=jsonObject.Envelope.Body.QueryPCRFSubscriberAllServiceResponse.QuerySubscribedPCRFServiceRes.SubscribedServices;
    var dataStatus = "Non_Data_Saver";
    if(Array.isArray(sbc))
    {
    for (i=0;i<sbc.length;i++)
        {
        if(sbc[i].SRVNAME === DataSaver)
            {
            dataStatus=DataSaver;
            }
        }
        context.setVariable("Name", dataStatus);
    }else
    {
        if(sbc.SRVNAME === DataSaver)
            {
                dataStatus=DataSaver;
            }
        context.setVariable("Name", dataStatus);
    }
 
 }
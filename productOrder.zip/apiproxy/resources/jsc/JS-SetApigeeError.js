var faultName = context.getVariable("fault.name");
var UrlData = context.getVariable("clientUriRequest");
var relatedPartyId = UrlData.substring(39,49);
context.setVariable("relatedPartyId", relatedPartyId);
context.setVariable("isoTimestamp", ISODateString());
var apiNo = context.getVariable("apiNo");

var transactionIdseq = (context.getVariable("ratelimit.Q-TransactionSeq.used.count"));
if(transactionIdseq === null)
{
    transactionIdseq=0;
}
context.setVariable("transactionDateTime",transactionDateTime());
context.setVariable("transactionId",apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

switch (faultName) {

case "SpikeArrestViolation":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "429."+apiNo+".001");
	context.setVariable("errorDesc", "Too Many Requests");
	context.setVariable("errorMessage", "Spike arrest violation");
	context.setVariable("httpError", "429");
	break;
case "invalid_access_token":
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "401."+apiNo+".006");
	context.setVariable("errorDesc", "Unauthorized");
	context.setVariable("errorMessage", "Access token is invalid or expired");
	context.setVariable("httpError", "401");
	break;
case "access_token_expired":
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "401."+apiNo+".006");
	context.setVariable("errorDesc", "Unauthorized");
	context.setVariable("errorMessage", "Access token is invalid or expired");
	context.setVariable("httpError", "401");
	break;
case "InvalidAccessToken": 
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "401."+apiNo+".006");
	context.setVariable("errorDesc", "Unauthorized");
	context.setVariable("errorMessage", "Access token is invalid or expired");
	context.setVariable("httpError", "401");
	break;
case "QuotaViolation":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "429."+apiNo+".002");
	context.setVariable("errorDesc", "Too Many Requests");
	context.setVariable("errorMessage", "Rate limit quota violation. Quota limit exceeded");
	context.setVariable("httpError", "429");
	break;

case "ConcurrentRatelimtViolation":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "429."+apiNo+".003");
	context.setVariable("errorDesc", "Too Many Requests");
	context.setVariable("errorMessage", "Concurrent rate limit connection exceeded");
	context.setVariable("httpError", "429");
	break;

case "ScriptExecutionFailed":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".001");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "JavaScript runtime error");
	context.setVariable("httpError", "500");
	break;

case "InvalidApiKeyForGivenResource":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".002");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Invalid ApiKey for given resource");
	context.setVariable("httpError", "500");
	break;
case "ExecutionFailed":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".003");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Request input is malformed or invalid");
	context.setVariable("httpError", "500");
	break;
case "GatewayTimeout":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "504."+apiNo+".003");
	context.setVariable("errorDesc", "Gateway Timeout");
	context.setVariable("errorMessage", "Gateway Timeout");
	context.setVariable("httpError", "504");
	break;
case "InvalidJSONPath":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".004");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Invalid JSON path");
	context.setVariable("httpError", "500");
	break;

case "RaiseFault":
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "404."+apiNo+".001");
	context.setVariable("errorDesc", "Resource not found");
	context.setVariable("errorMessage", "Resource not found/Invalid resource");
	context.setVariable("httpError", "404");
	break;

default:
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500."+apiNo+".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", faultName);
	context.setVariable("httpError", "500");
	break;

}
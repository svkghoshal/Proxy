var channelId = context.getVariable("req.channelId");
var externalId = context.getVariable("req.externalId");
var billingAccountId = context.getVariable("req.billingAccountId");
var orderItemAction = context.getVariable("req.orderItemAction");
var orderItemProductOfferingId = context.getVariable("req.orderItemProductOfferingId");
var referredType = context.getVariable("req.referredType");
var referredTypeId = context.getVariable("req.referredTypeId");
var verb = context.getVariable("request.verb");
context.setVariable("verb", verb);

var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
var apiNo = context.getVariable('apiNo');
 
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionDateTime",transactionDateTime());
context.setVariable("transactionId",apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

var tempTransactionId = context.getVariable("transactionId");
context.setVariable("newtransactionId", tempTransactionId.substr(3));


 if (isEmpty(channelId) || isEmpty(externalId)
 || isEmpty(billingAccountId) || isEmpty(orderItemAction) || isEmpty(orderItemProductOfferingId)
 || isEmpty(referredType) || isEmpty(referredTypeId)
 || (!billingAccountId.startsWith("97") || ((billingAccountId.length != 10))))
 {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input.");
    throw "serviceException";
 }
 if(verb == "POST" && orderItemAction !== "ADD")
  {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input.");
    throw "serviceException";
  }
  if(verb == "DELETE" && orderItemAction !== "DELETE")
  {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input.");
    throw "serviceException";
  }
 
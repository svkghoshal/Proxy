var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var target = '/cxf/ManageOfferSyncPS';
context.setVariable('targetPath',target);


   
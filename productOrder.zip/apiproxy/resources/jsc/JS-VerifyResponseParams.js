var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("res.faultString");
var statusCode = context.getVariable("res.resultCode");
var apiNo = context.getVariable('apiNo');

if(statusCode == "Success")
    context.setVariable("Status","Success");
 else
    {
      if(faultString.toUpperCase().includes("VALIDATIONERROR")
      || faultString.toUpperCase().includes("PLEASE ENTER THE VALID INPUT")
      || faultString.toUpperCase().includes("INVALID PARAMETER")
      || faultString.toUpperCase().includes("INCORRECT SETTING OF")
      || faultString.toUpperCase().includes("INVALID PARAMETER VALUE")
      || faultString.toUpperCase().includes("INCORRECT NUMBER TYPE")
      || faultString.toUpperCase().includes("INCORRECT FORMAT OF THE NUMBER")
      || faultString.toUpperCase().includes("CANNOT BE BLANK")
      || faultString.toUpperCase().includes("FAILED TO VERIFY THE COUNTRY CODE") )
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400."+apiNo+".101");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid Input");
            context.setVariable("httpError", "400");
        } 
    else if(faultString.toUpperCase().includes("QUERY OFFER FAILURE")
      || faultString.toUpperCase().includes("QUERY OFFER CATEGORY FAILURE")
      || faultString.toUpperCase().includes("QUERY OFFER FAILED")
      || faultString.toUpperCase().includes("QUERY SUBSCRIBER FAILED") )
        {
           context.setVariable("exceptionName", "exceptionName");
           context.setVariable("errorCode", "500."+apiNo+".101");
           context.setVariable("errorDesc", "Internal Server Error");
           context.setVariable("errorMessage", "Query VAS Offer Failure");
           context.setVariable("httpError", "500");
        }
    else if(faultString.toUpperCase().includes("THE SUBSCRIBER'S ACCOUNT BALANCE IS SMALLER THAN THE THRESHOLD FOR ACTIVATION")
      || faultString.toUpperCase().includes("ACTIVATION IS NOT ALLOWED") )
        {
          context.setVariable("exceptionName", "exceptionName");
          context.setVariable("errorCode", "500."+apiNo+".102");
          context.setVariable("errorDesc", "Internal Server Error");
          context.setVariable("errorMessage", "In-sufficient Balance of Subscriber");
          context.setVariable("httpError", "500");
        }
      else if(faultString.toUpperCase().includes("THE SYSTEM DOES NOT SUPPORT THE QUERY TYPE"))
      { 
          context.setVariable("exceptionName", "exceptionName");
          context.setVariable("errorCode", "500."+apiNo+".103");
          context.setVariable("errorDesc", "Internal Server Error");
          context.setVariable("errorMessage", "Invalid Query");
          context.setVariable("httpError", "500");
      }
      else if(faultString.toUpperCase().includes("THE NUMBER SEGMENT ROUTE DOES NOT EXIST"))
      { 
          context.setVariable("exceptionName", "exceptionName");
          context.setVariable("errorCode", "500."+apiNo+".104");
          context.setVariable("errorDesc", "Internal Server Error");
          context.setVariable("errorMessage", "The number segment route does not exist");
          context.setVariable("httpError", "500");
      }
      else if(faultString.toUpperCase().includes("THE CUSTOMER DOES NOT SUBSCRIBE TO THE OFFER"))
      { 
          context.setVariable("exceptionName", "exceptionName");
          context.setVariable("errorCode", "500."+apiNo+".105");
          context.setVariable("errorDesc", "Internal Server Error");
          context.setVariable("errorMessage", "The customer does not subscribe to the offer");
          context.setVariable("httpError", "500");
      }
      else if(faultString.toUpperCase().includes("THE PHONE NUMBER IS DUPLICATE"))
      { 
          context.setVariable("exceptionName", "exceptionName");
          context.setVariable("errorCode", "500."+apiNo+".106");
          context.setVariable("errorDesc", "Internal Server Error");
          context.setVariable("errorMessage", "The phone number is duplicate");
          context.setVariable("httpError", "500");
      }
      else if(faultString.toUpperCase().includes("IS NOT ACTIVATED")
      || faultString.toUpperCase().includes("THE ROUTING INFORMATION ABOUT THE SUBSCRIBER")
      || faultString.toUpperCase().includes("THE SUBSCRIBER DOES NOT EXIST")
      || faultString.toUpperCase().includes("CANNOT BE FOUND IN THE SUBSCRIBER NUMBER LIST FOR REGISTRATION")
      || faultString.toUpperCase().includes("EXISTS AND CANNOT BE REGISTERED AGAIN"))
      { 
          context.setVariable("exceptionName", "exceptionName");
          context.setVariable("errorCode", "500."+apiNo+".107");
          context.setVariable("errorDesc", "Internal Server Error");
          context.setVariable("errorMessage", "The subscriber is not valid");
          context.setVariable("httpError", "500");
      }
      else if(faultString.toUpperCase().includes("IS NOT OF THE SUBSCRIPTION TYPE")
      || faultString.toUpperCase().includes("DOES NOT EXIST")
      || faultString.toUpperCase().includes("INVALID OFFER")
      || faultString.toUpperCase().includes("THE OFFER INSTANCE")
      || faultString.toUpperCase().includes("INVALID OFFER"))
      { 
          context.setVariable("exceptionName", "exceptionName");
          context.setVariable("errorCode", "500."+apiNo+".108");
          context.setVariable("errorDesc", "Internal Server Error");
          context.setVariable("errorMessage", "The offer is not valid");
          context.setVariable("httpError", "500");
      }
      else if(faultString.toUpperCase().includes("CANNOT BE SUBSCRIBED TO REPEATEDLY")
      || faultString.toUpperCase().includes("SUBSCRIPTION ALREADY EXISTS"))
      { 
          context.setVariable("exceptionName", "exceptionName");
          context.setVariable("errorCode", "500."+apiNo+".109");
          context.setVariable("errorDesc", "Internal Server Error");
          context.setVariable("errorMessage", "The phone number is duplicate");
          context.setVariable("httpError", "500");
      }
    else{
          context.setVariable("exceptionName", "exceptionName");    
          context.setVariable("errorCode", "500."+apiNo+".100");
          context.setVariable("errorDesc", "Internal Server Error");
          context.setVariable("errorMessage", faultString);
          context.setVariable("httpError", "500");
        }
            
    } 
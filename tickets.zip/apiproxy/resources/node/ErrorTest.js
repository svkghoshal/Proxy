var http = require('http');
var apigee = require('apigee-access');

server = http.createServer( function(req, res) {
    console.log ('tickets sandbox');
    console.log ('Request ::: '+JSON.stringify(req.Body));
    var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
    res.writeHead(200, {'Content-Type': 'application/json'});
    
    var GET_1 = '{ "resCode":"0", "resMessage":"SUCCESS", "starInfo":{ "catgExpDate":"10-04-2020", "catgName":"Gold", "connType":"PREPAID", "membershipId":"70286600", "starType":"NORMAL", "msisdn":"9876543210" }, "pointsInfo":{ "pointBalance":"50", "validity":"22-04-2020", "pointsTransactionInfo":[ { "transactionDate":"25-01-2020", "transactionType":"Redemption", "transactionInfo":"CT7343847", "transactionPoints":"10", "pointsId":"1112", "pointsStatus":"VALID", "originalPoints":"30", "availablePoints":"20", "pointsValidToDate":"22-04-2020" }, { "transactionDate":"26-01-2020", "transactionType":"Redemption", "transactionInfo":"CT73438343", "transactionPoints":"10", "pointsId":"1111", "pointsStatus":"VALID", "originalPoints":"20", "availablePoints":"10", "pointsValidToDate":"22-04-2020" }, { "transactionDate":"24-01-2020", "transactionType":"Points Created", "transactionInfo":"OFR121377", "transactionPoints":"40", "pointsId":"1110", "pointsStatus":"VALID", "originalPoints":"40", "availablePoints":"40", "pointsValidToDate":"22-04-2020" }, { "transactionDate":"23-01-2020", "transactionType":"Points Created", "transactionInfo":"OFR121345", "transactionPoints":"30", "pointsId":"1109", "pointsStatus":"VALID", "originalPoints":"30", "availablePoints":"30", "pointsValidToDate":"22-04-2020" } ] }, "pointsExpiryInfo":[ { "points":"10", "expiryDate":"22-04-2020" }, { "points":"40", "expiryDate":"23-04-2020" } ] }';
    var GET_Er = '';   
    res.end(GET_Er);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port); 
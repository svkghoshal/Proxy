var proxy = context.getVariable("proxy.pathsuffix");
var SourceSystem = context.getVariable("req.channelId");
var startDateTime = context.getVariable("req.startDateTime");
var endDateTime = context.getVariable("req.endDateTime");
var endpoint = "/cxf/GetStarRewardsDetailsSynchPS/?";
var verb = context.getVariable("request.verb");
var sourceId = context.getVariable("request.queryparam.channelId");
var id = context.getVariable("req.id");
var lan = context.getVariable("requst.queryparam.lan");
var partnerId = context.getVariable("request.queryparam.partnerId");
var list = context.getVariable("requst.queryparam.list");
var apiNo = "065";
//var msisdnLength = id.length;

if (lan == "en"){
    //context.setVariable("Lan", "EN");
    var Lan = "EN";
}
else{
    var Lan = "MM";
}

context.setVariable("isoTimestamp", ISODateString());

if (proxy == "/loyaltyProgramProduct") {
    if(!isEmpty(list)){
        path = endpoint+"MSISDN="+id+"&PartnerID="+partnerId+"&SourceSystemID="+sourceId+"&Language="+Lan+"&Type=Telco";
        context.setVariable("path", path);
    }
    else{
        path = endpoint+"MSISDN=&PartnerID="+partnerId+"&SourceSystemID="+sourceId+"&Language="+Lan+"&Type=Telco";        
        context.setVariable("path", path);
    }
}
else if(proxy == "/loyaltyAfiliateProduct"){
    path = endpoint+"MSISDN="+id+"&PartnerID="+partnerId+"&SourceSystemID="+sourceId+"&Language="+Lan+"&Type=nonTelco";
        context.setVariable("path", path);
}else if(proxy == "/loyaltyAction"){
    
    if(verb == "POST")
    {
        path = "/cxf/RedeemRewardsPointsSynchPS";
        context.setVariable("path", path);
    
    }else{
        
        path = "/cxf/GetStarTypeAndStatusSynchPS/?"+"MSISDN="+id+"&DETAILS=ALL&SourceSystem="+SourceSystem+"&startDate="+startDateTime+"&endDate="+endDateTime;
        context.setVariable("path", path);
    }

}




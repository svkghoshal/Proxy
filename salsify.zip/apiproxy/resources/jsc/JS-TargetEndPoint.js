var proxypath = context.getVariable('proxy.pathsuffix');
var verb = context.getVariable('verb');
var orgId = context.getVariable('req.orgId');
var exportId = context.getVariable("req.exportId");
var target;

var token = "T_f5Ozc-PpMdK2DFlzqLlQeAtYZXJycIEWLpafQblSY";
context.setVariable("BearerToken", token);

if(verb == "POST")
{
    target = '/api/orgs/'+orgId+'/export_runs';
    context.setVariable('targetPath',target);
}else{
    target = '/api/orgs/'+orgId+'/export_runs/'+exportId;
    context.setVariable('targetPath',target); 
}

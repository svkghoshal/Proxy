var orgId = context.getVariable("req.orgId");
var exportId = context.getVariable("req.exportId");

var entityType = context.getVariable("req.entityType");
var filter = context.getVariable("req.filter");
var includeAllColumns = context.getVariable("req.includeAllColumns");
var sortOrder = context.getVariable("req.sortOrder");
var sortProperty = context.getVariable("req.sortProperty");


var verb = context.getVariable("verb");

var apiNo = context.getVariable('apiNo');
context.setVariable("isoTimestamp", ISODateString());

if(verb == "POST")
{
     if (isEmpty(orgId) || isEmpty(entityType) || isEmpty(filter) || isEmpty(includeAllColumns)
     || isEmpty(sortOrder) || isEmpty(sortProperty))
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }
}else{
    if (isEmpty(orgId) || isEmpty(exportId))
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }
}
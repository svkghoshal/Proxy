var statusCode = context.getVariable("message.status.code");
var url = context.getVariable("res.url");

if (isEmpty(url)){
    context.setVariable("url","Fetching Data,Please Wait...");
}else{
    context.setVariable("url",url);
}

var apiNo = context.getVariable('apiNo');
if(statusCode == "200" || statusCode == "201")
    context.setVariable("Status","Success");
else
    {
     context.setVariable("exceptionName", "exceptionName");    
     context.setVariable("errorCode", "500."+apiNo+".100");
     context.setVariable("errorDesc", "Internal Server Error");
     context.setVariable("errorMessage", "Internal Server Error");
     context.setVariable("httpError", "500");
    }


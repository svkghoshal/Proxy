var apiiNo;
var reqVerb = context.getVariable("request.verb");

var d = new Date();
var n = d.getTime();
var random = Math.ceil(Math.random()*n);
var transactionId = (random).toString().substring(0,20);
context.setVariable("transactionId",transactionId);

context.setVariable("apiNo","101");
context.setVariable("verb",reqVerb);

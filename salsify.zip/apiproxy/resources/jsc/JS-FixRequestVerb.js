var reqVerb = context.getVariable("verb");
context.setVariable("request.verb",reqVerb);
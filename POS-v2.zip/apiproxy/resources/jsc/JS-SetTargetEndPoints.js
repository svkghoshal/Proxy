var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var list = context.getVariable('req.list');
var offerType = context.getVariable('req.offerType');
var target;
/*
if(list===null)
    list='';*/

if(reqVerb=='GET')
{
    target = '/Middleware/api/v1/update-customer-msisdn';
    context.setVariable('targetPath',target);
}
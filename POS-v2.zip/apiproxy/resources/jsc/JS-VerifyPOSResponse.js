var statusCode = context.getVariable("res.statusCode");
var message = context.getVariable("res.statusMessage");
var status_code= context.getVariable("response.status.code");
var requestVerb = context.getVariable('reqVerb');
var apiNo = context.getVariable('apiNo');

if(status_code =='200')
    context.setVariable("Status","Success");
else
{
   switch(statusCode) {
    
                case "FL0009":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "400."+apiNo+".101");
                    context.setVariable("errorDesc", "Bad Request");
                    context.setVariable("errorMessage","Invalid Input");
                    context.setVariable("httpError", "400");
                    break;
                
                case "FLQRCODE012":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "400."+apiNo+".102");
                    context.setVariable("errorDesc", "Bad Request");
                    context.setVariable("errorMessage", "Invalid Ip");
                    context.setVariable("httpError", "400");
                    break;
                
                case "FL0000":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".100");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Internal Server Error");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FL0005":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "400."+apiNo+".101");
                    context.setVariable("errorDesc", "Bad Request");
                    context.setVariable("errorMessage", "Invalid Input");
                    context.setVariable("httpError", "400");
                    break;
                
                case "FL0004":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".101");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage",  "QR code already scanned");
                    context.setVariable("httpError", "500");
                    break;
                
                default:
                    context.setVariable("exceptionName", "exceptionName");
            		context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".100");
            		context.setVariable("errorDesc", "Internal Server Error");
            		context.setVariable("errorMessage", statusCode);
            		context.setVariable("httpError", "500");
            		break;
                
            }  
}
   
       

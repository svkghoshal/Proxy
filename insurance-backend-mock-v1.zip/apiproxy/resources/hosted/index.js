const  express = require('express');
const  fs = require("fs");
const  path = require("path");
const  app = express();
var bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(express.urlencoded({
  extended: true
}));

const utf8 = "utf8";

app.post('/', function(req, res) {
	//console.log("Body--->"+JSON.parse('{ "username": "pmpTaxFee", "psw": "hello" }'));
//	req = JSON.parse('{ "username": "pmpTaxFee", "psw": "hello" }');
    var queryString;
    var customerCode = req.body.authorization.customerCode;
    var state = req.body.quote.Insured.address.state;
    var name = req.body.quote.Insured.name;
    var effectiveDate = req.body.quote.policies[0].effectiveDate;
    var entityCode = req.body.quote.agent.entityCode;
    var carrierEntityCode = req.body.quote.policies[0].carrier.entityCode;
    var taxes = req.body.quote.policies[0].taxes;
    var fees = req.body.quote.policies[0].fees;
    var minimumearnedPercentage = req.body.quote.policies[0].MinimumearnedPercentage;
    var daysToCancel = req.body.quote.policies[0].DaysToCancel;
    var premium = req.body.quote.policies[0].premium;
    var expirationDate = req.body.quote.policies[0].expirationDate;
    var coverageCode = req.body.quote.policies[0].coverageCode;
    var broker = req.body.quote.policies[0].broker;
    var generalAgency = req.body.quote.policies[0].generalAgency;
    var HasBankruptcy = req.body.quote.Insured.HasBankruptcy;
    
    // var monthDiff = monthDiff(new Date(effectiveDate), new Date(expirationDate));
    var emailAddress = req.body.quote.agent.emailAddress;
    var agedDate = agedDate(new Date(effectiveDate), new Date());
// function monthDiff(effectiveDate, expirationDate) {
//     var months;
//     months = (expirationDate.getFullYear() - effectiveDate.getFullYear()) * 12;
//     months -= effectiveDate.getMonth();
//     months += expirationDate.getMonth();
//     return months; 
    
// }
function agedDate(effectiveDate, presentDate) {
    var months;
    months = (presentDate.getFullYear() - effectiveDate.getFullYear()) * 12;
    months -= effectiveDate.getMonth();
    months += presentDate.getMonth();
    return months; 
    
}
    if(agedDate > 12 ){
			queryString = "agedDate";
			
		}
    else if (coverageCode === "EQPFL123")
   {
       queryString = "coverCode";
   }
   	else if( coverageCode === "AUTOP"){
		    queryString = "coverCodeMapToPIF";
		}
	else if( HasBankruptcy === true){
		    
		    queryString = "HasBankruptcy";
		}
	else if(daysToCancel > 60){
		    queryString = "daysToCancelExceeded";
		}
		else if(carrierEntityCode === undefined){
		    queryString = "noCarrierEntityCode";
		}
		else if (customerCode == "1TST99")
		{
		    queryString = "invalidCustomerCode";
		}
		else if (premium < 100) {
			queryString = "lessPremium";
			
		}
		else if (minimumearnedPercentage > 1)  {
			queryString = "moreMinimumEarnedPercent";
			
		}
		var x = state.match(/[A-Z]/g);

        if(x==null || x.length != 2){
    
            queryString = "invalidStateFormat";
        } 
        else if(state == "AB"){
    
            queryString = "invalidState";
        } 
        else if(effectiveDate === undefined && expirationDate === undefined){
		    queryString = "noEffectiveDate";
		    
		}
		else if(coverageCode == "EQPFL11")
		{
		    queryString = "noCoverSheetPIF";
		}
		else if(name == "Test Insured only PFA"){
		    queryString = "onlyPFA";
		}
		else if(premium == 15000){
		    queryString = "signedPFACoversheet";
		}
		
    //var queryString = req.body.username;
	//var req = JSON.parse(req.body);
    //var queryString = req.username;
    console.log("queryString-->"+ queryString);
    var fileName = fileNameMapping(queryString);
   res.json(getJsonFile(fileName));
});

function getJsonFile(fileName){
    var filePath = path.resolve(fileName);
    var jsonFile = fs.readFileSync(filePath, utf8);
    return JSON.parse(jsonFile);
}
 
function fileNameMapping(queryString){
    var filePath = path.resolve("fileNameMapping.json");
    var jsonFile = fs.readFileSync(filePath, utf8);
    console.log("JSON.parse(jsonFile).queryString  " + JSON.parse(jsonFile)[queryString]);
    return JSON.parse(jsonFile)[queryString];
}


var server = app.listen(process.env.PORT || 9000, function() {
    console.log('Listening on port %d', server.address().port);
});
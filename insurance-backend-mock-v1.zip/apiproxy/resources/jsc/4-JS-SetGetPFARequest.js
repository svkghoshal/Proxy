  var req =context.getVariable('request.content');
 var req2 = JSON.parse(req);
 var customerCode = req2.authorization.customerCode;
 var state = req2.quote.Insured.address.state;
 var effectiveDate = req2.quote.policies[0].effectiveDate;
 var entityCode = req2.quote.agent.entityCode;
 var carrierEntityCode = req2.quote.policies[0].carrier.entityCode;
 var taxes = req2.quote.policies[0].taxes;
 var fees = req2.quote.policies[0].fees;
 var minimumearnedPercentage = req2.quote.policies[0].MinimumearnedPercentage;
 var daysToCancel = req2.quote.policies[0].DaysToCancel;
 var premium = req2.quote.policies[0].premium;
 var expirationDate = req2.quote.policies[0].expirationDate;
var coverageCode = req2.quote.policies[0].coverageCode;
var broker = req2.quote.policies[0].broker;
var generalAgency = req2.quote.policies[0].generalAgency;
var HasBankruptcy = req2.quote.Insured.HasBankruptcy;
print("sv1"+HasBankruptcy);
// print("svk"+broker);
// print("svk1"+generalAgency);
var monthDiff = monthDiff(new Date(effectiveDate), new Date(expirationDate));
var emailAddress = req2.quote.agent.emailAddress;
var agedDate = agedDate(new Date(effectiveDate), new Date());
function monthDiff(effectiveDate, expirationDate) {
    var months;
    months = (expirationDate.getFullYear() - effectiveDate.getFullYear()) * 12;
    months -= effectiveDate.getMonth();
    months += expirationDate.getMonth();
    return months; 
    
}
function agedDate(effectiveDate, presentDate) {
    var months;
    months = (presentDate.getFullYear() - effectiveDate.getFullYear()) * 12;
    months -= effectiveDate.getMonth();
    months += presentDate.getMonth();
    return months; 
    
}
print("svk2"+agedDate);
if(agedDate > 12 ){
			agedDate = 'true';
			context.setVariable("agedEffectiveDate",agedDate);
			
		}

if (monthDiff <12) {
			monthDiff = 'true';
			context.setVariable("lessMonth",monthDiff);
			
		}

else if((monthDiff == 12) && (daysToCancel !== 0 && fees !== 0) && (premium == "1000")){
            oneYearEffectiveDate = 'true';
            context.setVariable("oneYearOldEffectiveDate",oneYearEffectiveDate);
}
else if (emailAddress === undefined){
            noEmail = 'true';
			context.setVariable("emailNotPresent",noEmail);
}
else if ((broker)&&(generalAgency) && (premium > 250) && (taxes == 0) && (fees == 0)){
			presentBrokerAgency = 'true';
			context.setVariable("broker",presentBrokerAgency);
			
		}

 else if (premium < 250) {
			Premium = 'true';
			context.setVariable("lessPremium",Premium);
			
		}
 else if ((taxes == 0) && (fees == 0) && ((minimumearnedPercentage == undefined) && (daysToCancel == undefined))) {
			WithoutTaxesFess = 'true';
			context.setVariable("noTaxesFess",WithoutTaxesFess);
			
		}
//  else if (((minimumearnedPercentage == "") && (minimumearnedPercentage == 0))&&((daysToCancel == "") && (daysToCancel == 0)))  {
// 			isMinPerDays = 'false';
// 			context.setVariable("IsEarnedPercentage",isMinPerDays);
			
// 		}
//  else if (((minimumearnedPercentage !== "") && (minimumearnedPercentage !== 0)) &&((daysToCancel !== "") && (daysToCancel !== 0)) && ((broker == undefined) && (generalAgency == undefined)) &&  (minimumearnedPercentage !== undefined) && (daysToCancel != undefined))  {
// 			IsMinPerDays = 'true';
// 			context.setVariable("IsEarnedPercentage",IsMinPerDays);
			
// 		}
		else if (minimumearnedPercentage > 1)  {
			isMinPercentMore = 'true';
			context.setVariable("IsEarnedPercentageMore",isMinPercentMore);
			
		}
 
 
		var stateCode = 'true';
var x = state.match(/[A-Z]/g);

if(x==null || x.length != 2){
    
    state = 'false';
 			context.setVariable("stateCode",state);
} 
else if ((coverageCode === "EQPFL123") && (stateCode == 'true') && (entityCode != undefined) && (effectiveDate != undefined)) {
     
			coverageCode = 'true';
			context.setVariable("pfaCoverCode",coverageCode);
			
		}
		else if( coverageCode === "AUTOP"){
		    mappedToPIF = 'true';
		    context.setVariable("mapToPIF",mappedToPIF);
		}
		else if( HasBankruptcy === true){
		    
		    context.setVariable("HasBankruptcy",'true');
		}
		else if(daysToCancel > 60){
		    daysToCancel = 'true';
		    context.setVariable("daysToCancelExceeded",daysToCancel);
		}
		else if( entityCode === undefined){
		    entityCode = 'false';
		    context.setVariable("agentCode",entityCode);
		}
		else if(carrierEntityCode === undefined){
		    carrierEntityCode = 'false';
		    context.setVariable("carrierEntityCode",carrierEntityCode);
		}
		else if(effectiveDate === undefined){
		    effectiveDate = 'false';
		    context.setVariable("effectDate",effectiveDate);
		}
		else if(((minimumearnedPercentage == undefined) && (daysToCancel == undefined)) && (taxes !== 0) &&(fees !== 0)&&(broker == undefined)&&(generalAgency ==undefined) && (customerCode !== "1TST99")) {
		    getPFA = 'true';
		    context.setVariable("getPFAHappyPath",getPFA);
		}
		else if (customerCode == "1TST99")
		{
		    customerCode = 'true';
		    context.setVariable("invalidCustomerCode",customerCode);
		   
		    
		}
 

 


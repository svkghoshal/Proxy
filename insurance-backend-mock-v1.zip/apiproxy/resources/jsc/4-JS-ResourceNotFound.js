 var basePath = context.getVariable("proxy.basepath");
var pathSuffix = context.getVariable("proxy.pathsuffix");
var path = basePath + pathSuffix;

try {
    ResourceNotFound();  
} catch (err) {
	throw err;
}

function ResourceNotFound() { 
    try{
        var customizedErrorMessage = {
	        "path": path,
            "code": "Resource Not Found",
            "x-fapi-interaction-id": context.getVariable("messageid"),
            "description":"URI does not represent a recognised resource",
            "statusCode": "404",
            "type": "INVALID RESOURCE"
	};
    		
    	if (customizedErrorMessage) {
    			context.setVariable("errorJSON", "customizedErrorMessage");
    			context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage));
    			throw "requestBodyException";
    	}
    	
} catch (err) {
		throw err;
	}
}
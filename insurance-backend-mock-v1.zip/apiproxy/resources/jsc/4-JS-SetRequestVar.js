 var req =context.getVariable('request.content');
 var req2 = JSON.parse(req);
 var state = req2.quote.insured.address.state;
 var effectiveDate = req2.quote.policies[0].effectiveDate;
 var entityCode = req2.quote.agent.entityCode;
 var taxes = req2.quote.policies[0].taxes;
 var fees = req2.quote.policies[0].fees;
 var minimumearnedPercentage = req2.quote.policies[0].minimumearnedPercentage;
 var daysToCancel = req2.quote.policies[0].daysToCancel;
 var Premium = req2.quote.policies[0].Premium;
 var expirationDate = req2.quote.policies[0].expirationDate;
var coverageCode = req2.quote.policies[0].coverageCode;

var monthDiff = monthDiff(new Date(effectiveDate), new Date(expirationDate));

function monthDiff(effectiveDate, expirationDate) {
    var months;
    months = (expirationDate.getFullYear() - effectiveDate.getFullYear()) * 12;
    months -= effectiveDate.getMonth();
    months += expirationDate.getMonth();
    return months; 
    
}

if (monthDiff <12) {
			monthDiff = 'true';
			context.setVariable("lessMonth",monthDiff);
			
		}

else if((monthDiff == 12) && (coverageCode !== "TESTEQPFL") && (daysToCancel !== 0 && fees !== "0") && (Premium != "1400") && (Premium == "2009")){
            oneYearEffectiveDate = 'true';
            context.setVariable("oneYearOldEffectiveDate",oneYearEffectiveDate);
}

 else if (Premium < 250) {
			Premium = 'true';
			context.setVariable("lessPremium",Premium);
			
		}
 else if (((minimumearnedPercentage !== "") && (minimumearnedPercentage !== 0)) &&((daysToCancel !== "") && (daysToCancel !== 0)) && (entityCode != undefined) && (Premium == "1400"))  {
			minPerDays = 'true';
			context.setVariable("earnedPercentage",minPerDays);
			
		}
 
 else if ((taxes != 0) && (fees != 0) && ((minimumearnedPercentage == 0) && (daysToCancel == 0))){
			taxesFess = 'true';
			context.setVariable("presentTaxesFess",taxesFess);
			
		}
		var stateCode = 'true';
var x = state.match(/[A-Z]/g);

if(x==null || x.length != 2){
    
    state = 'false';
 			context.setVariable("stateCode",state);
} 
else if ((coverageCode === "TESTEQPFL") && (stateCode == 'true') && (entityCode != undefined) && (effectiveDate != undefined)) {
     
			coverageCode = 'true';
			context.setVariable("coverCode",coverageCode);
			
		}
		
		else if( entityCode === undefined){
		    entityCode = 'false';
		    context.setVariable("agentCode",entityCode);
		}
		else if(effectiveDate === undefined){
		    effectiveDate = 'false';
		    context.setVariable("effectDate",effectiveDate);
		}
		else if(daysToCancel == 0 && fees == "0"){
		    calcTerm = 'true';
		    context.setVariable("calculateTerm",calcTerm);
		}
 

 


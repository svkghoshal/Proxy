  var req =context.getVariable('request.content');
 var req2 = JSON.parse(req);
 var PmpUrlResp = "https://uat.paymypremiums.com/InvoiceLogin/InvitationAutoLogin?invoicenumber=AOmOMZ%2flcEikCiMpSscuXQEAAADmeuPdA%2fC5BArGBw%2bK%2bfQ2egqq2731IDmv9omzbQZgUQcd%2fFJbeovzb%2f1eLoQU2qk%3d&paymentid=AOmOMZ%2flcEikCiMpSscuXQEAAACh9g5r6EhXEtEswXv36jq8rDjpcMDwPrN7Ynj6fgxi8g%3d%3d";
 context.setVariable("pmpEncodedUrl",PmpUrlResp);
 var coverageCode1 = "https://uat.paymypremiums.com/InvoiceLogin/InvitationAutoLogin?invoicenumber=AOmOMZ%2flcEikCiMpSscuXQEAAABqCcdsL9pxDv7LLkO0YIEwojQqGGj9yPpjDq8Kt6B8ZGxN%2bo8gFDO3wnVTomb5VI0%3d&paymentid=AOmOMZ%2flcEikCiMpSscuXQEAAAAGsIkC%2f%2bPCxZSTSZKjuibXY%2bPxDkjWRz22nolKjnzq4w%3d%3d";
 context.setVariable("coverageEncodedUrl1",coverageCode1);
 var coverageCode2 = "https://uat.paymypremiums.com/InvoiceLogin/InvitationAutoLogin?invoicenumber=AOmOMZ%2flcEikCiMpSscuXQEAAABqCcdsL9pxDv7LLkO0YIEwojQqGGj9yPpjDq8Kt6B8ZGxN%2bo8gFDO3wnVTomb5VI0%3d&paymentid=AOmOMZ%2flcEikCiMpSscuXQEAAAAGsIkC%2f%2bPCxZSTSZKjuibXY%2bPxDkjWRz22nolKjnzq4w%3d%3d";
 context.setVariable("coverageEncodedUrl2",coverageCode2);
 var taxFeesUrl = "https://uat.paymypremiums.com/InvoiceLogin/InvitationAutoLogin?invoicenumber=AOmOMZ%2flcEikCiMpSscuXQEAAAA7PYObRXX86bmqNEgyvMWOtU8WnhXh0GGa5I246w4IQzrTp9xJsLrwkjEwOfQab8A%3d&paymentid=AOmOMZ%2flcEikCiMpSscuXQEAAADYjitznibuppzh9nYF0d1%2bR1CGJotD9fT8%2bFg5sPj4UA%3d%3d";
 context.setVariable("withouTaxFessUrl",taxFeesUrl);
 var withoutMinEarnedUrl = "https://uat.paymypremiums.com/InvoiceLogin/InvitationAutoLogin?invoicenumber=AOmOMZ%2flcEikCiMpSscuXQEAAADQZ1nsL1PQPpwsmDFpT5L%2buoMwAbam63ACS8zvkNJZZ1TRNJlEPBfLgV2gm0%2bbxEM%3d&paymentid=AOmOMZ%2flcEikCiMpSscuXQEAAACo2CLnjevo%2fruxQm4vtpTKHW8lwJTt4BfBNPpiVXBu%2fw%3d%3d";
 context.setVariable("withoutminEarnPer",withoutMinEarnedUrl);
 var withMinEarnUrl = "https://uat.paymypremiums.com/InvoiceLogin/InvitationAutoLogin?invoicenumber=AOmOMZ%2flcEikCiMpSscuXQEAAABFhj%2b7kYxH%2bZuP2TsETNIhMtuhe%2bL%2fZ%2byBVw587N2X0mLTHbj2kTCOWS0oqHRCuXA%3d&paymentid=AOmOMZ%2flcEikCiMpSscuXQEAAACjLB5PQou7z8DsHy0jBzCGjI9%2b3SGrGmoi5bHUoW2kVA%3d%3d";
 context.setVariable("withMinEarnPer",withMinEarnUrl);
 var withBrokerUrl = "https://uat.paymypremiums.com/InvoiceLogin/InvitationAutoLogin?invoicenumber=AOmOMZ%2flcEikCiMpSscuXQEAAACg00%2few9BwJDikmclsdHJu7HYeCjWn%2baGWfucfoYGw2fW8K52%2fp1tXH8JIAbXBnFc%3d&paymentid=AOmOMZ%2flcEikCiMpSscuXQEAAAB%2b9HJTv1rYLnRRkh3jsyWhJlO%2fx8oRQ%2b%2bPOaXMIWgmCw%3d%3d";
  context.setVariable("withBrokerGenUrl",withBrokerUrl);
 var state = req2.quote.insured.address.state;
 var effectiveDate = req2.quote.policies[0].effectiveDate;
 var entityCode = req2.quote.agent.entityCode;
 var customerCode = req2.authorization.customerCode;
 var taxes = req2.quote.policies[0].taxes;
 var fees = req2.quote.policies[0].fees;
 var minimumearnedPercentage = req2.quote.policies[0].minimumearnedPercentage;
 var daysToCancel = req2.quote.policies[0].daysToCancel;
 var Premium = req2.quote.policies[0].premium;
 var expirationDate = req2.quote.policies[0].expirationDate;
var coverageCode = req2.quote.policies[0].coverageCode;
var broker = req2.quote.policies[0].broker;
var generalAgency = req2.quote.policies[0].generalAgency;
var emailAddress = req2.quote.agent.emailAddress;


var diffInMonth = monthDiff(new Date(effectiveDate), new Date(expirationDate));

function monthDiff(effectiveDate, expirationDate) {
    var months;
    months = (expirationDate.getFullYear() - effectiveDate.getFullYear()) * 12;
    months -= effectiveDate.getMonth();
    months += expirationDate.getMonth();
    return months; 
    
}

if (diffInMonth < 12) {
			diffInMonth = 'true';
			context.setVariable("lessMonth",diffInMonth);
			
		}

	else if((diffInMonth == 12) && (emailAddress != undefined) && (customerCode !== "1TST99") && (minimumearnedPercentage !== undefined) && (generalAgency !== undefined) && (daysToCancel == 60)){
            oneYearEffectiveDate = 'true';
            context.setVariable("oneYearOldEffectiveDate",oneYearEffectiveDate);
}
else if (emailAddress === undefined){
            noEmail = 'true';
			context.setVariable("emailNotPresent",noEmail);
}
else if ((broker)&&(generalAgency) && (Premium > 250)){
			presentBrokerAgency = 'true';
			context.setVariable("broker",presentBrokerAgency);
			
		}
  else if (coverageCode === "Test12346") {
      
			coverageCode = 'true';
			context.setVariable("coverCode",coverageCode);
			
		}
 else if (Premium < 250) {
			Premium = 'true';
			context.setVariable("lessPremium",Premium);
			
		}
		
 
		else if ((taxes == 0) && (fees == 0) && ((minimumearnedPercentage == undefined) && (daysToCancel == undefined))) {
			WithoutTaxesFess = 'true';
			context.setVariable("noTaxesFess",WithoutTaxesFess);
			
		}
		else if (((minimumearnedPercentage == "") && (minimumearnedPercentage == 0)) &&((daysToCancel == "") && (daysToCancel == 0)) && (entityCode != undefined) && (Premium >= 250))  {
			isMinPerDays = 'false';
			context.setVariable("IsEarnedPercentage",isMinPerDays);
			
		}
 else if (((minimumearnedPercentage !== "") && (minimumearnedPercentage !== 0)) &&((daysToCancel !== "") && (daysToCancel !== 0)) && (entityCode != undefined) && (Premium >= 250) && ((minimumearnedPercentage !== undefined) && (daysToCancel !== undefined)))  {
			IsMinPerDays = 'true';
			context.setVariable("IsEarnedPercentage",IsMinPerDays);
			
		}
 
        var x = state.match(/[A-Z]/g);

        if(x==null || x.length != 2){
            state = 'false';
 			context.setVariable("stateCode",state);
        } 
		else if( entityCode === undefined){
		    entityCode = 'false';
		    context.setVariable("agentCode",entityCode);
		}
		else if(effectiveDate === undefined){
		    effectiveDate = 'false';
		    context.setVariable("effectDate",effectiveDate);
		}
		
		else if(((minimumearnedPercentage == undefined) && (daysToCancel == undefined)) && ((taxes !== 0) &&(fees !== 0)) && (coverageCode != "Test12346") && (customerCode !== "1TST99")){
		    
		    pmUrl = 'true';
		    context.setVariable("pmpUrl",pmUrl);
		}
		else if (customerCode == "1TST99")
		{
		    customerCode = 'true';
		    context.setVariable("invalidCustomerCode",customerCode);
		   
		    
		}
 

 


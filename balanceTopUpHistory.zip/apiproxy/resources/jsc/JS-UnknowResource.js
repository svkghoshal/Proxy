context.setVariable("isoTimestamp", ISODateString());
/*var referenceCode = getISODate().concat(getRandomNumber());
context.setVariable("referenceCode", referenceCode);*/
var id = context.getVariable("req.id");
context.setVariable("msisdn", id);
var apiNo = "072";


function getISODate() {
    var d = new Date();
    var n = d.toISOString();
    return n;
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
function getRandomNumber()
{
  var val = Math.floor(100000 + Math.random() * 900000);
  return val;
}


   
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "404");
    context.setVariable("errorCode", "404."+apiNo+".001");
    context.setVariable("errorDesc", "Resource not found/Invalid resource");
    context.setVariable("errorMessage", "Invalid URL");
    throw "serviceException";
    

    
    
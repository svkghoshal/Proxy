var id = context.getVariable("req.id");
context.setVariable("msisdn", id);
var fee = context.getVariable("response.content");

if(!fee)
    context.setVariable("response.content", "[]");
 else
 {
    var jsonResponse = String(fee).replace(/"~ARRAY~",/g, "");
    var jsonObject = JSON.parse(jsonResponse);
    
     for (var i in jsonObject.BalanceRechargeList.BalanceRechargeDetails)
    {
    var oldDate =jsonObject.BalanceRechargeList.BalanceRechargeDetails[i].validFor.startDateTime;
    var validfor =jsonObject.BalanceRechargeList.BalanceRechargeDetails[i].validFor.endDateTime;
    
    var dd = oldDate.split("/");
    
    var data = new Date(parseInt(dd[2],10),parseInt(dd[1],10)-1,Number(dd[0]));
    var newDate = data.setDate(data.getDate() +validfor);
    
    jsonObject.BalanceRechargeList.BalanceRechargeDetails[i].validFor.endDateTime =("0"+data.getDate()).slice(-2)+"/"+("0"+(data.getMonth()+1)).slice(-2)+"/"+data.getFullYear()+" 00:00:00";
    
    
    context.setVariable("response.content",JSON.stringify(jsonObject));
    }
 
 }
 
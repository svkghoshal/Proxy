  var uriRequest = context.getVariable("clientUriRequest");
var clientUriRequest = uriRequest;
context.setVariable("clientUriRequest", clientUriRequest);
var id = context.getVariable("req.id");
context.setVariable("msisdn", id);

// Request Body from external Client
var bodyRequest = context.getVariable("clientBodyRequest");
try {
    var clientBodyParse = JSON.parse(bodyRequest);
    var clientBodyRequest = JSON.stringify(clientBodyParse);
    context.setVariable("clientBodyRequest", clientBodyRequest);
} catch (e) {
    context.setVariable("e", 1);
}

// If Body is empty, use URI as Body request
if (isEmpty(bodyRequest)) {
    context.setVariable("clientBodyRequest", clientUriRequest);
}

// Response body to external client
var bodyResponse = context.getVariable("clientBodyResponse");
try {
    var clientBodyParse = JSON.parse(bodyResponse);
    var clientBodyResponse = JSON.stringify(clientBodyParse);
    context.setVariable("clientBodyResponse", clientBodyResponse);
} catch (e) {
    context.setVariable("e", 1);
}

// Request payload to target/downstream
var bck_req_content = context.getVariable("backendRequestContent");
if (!isEmpty(bck_req_content)) {
    var targetPayloadRequest = xml2flat(bck_req_content);
    context.setVariable("targetPayloadRequest", targetPayloadRequest);
}

var bck_res_content = context.getVariable("backendResponseContent");
if (!isEmpty(bck_res_content)) {
    var targetPayloadResponse = xml2flat(bck_res_content);
    context.setVariable("targetPayloadResponse", targetPayloadResponse);
}


// Response payload from target/downstream

function isEmpty(input) {
    return (!input || 0 === input.length);
}
function xml2flat(str) {
    str = str.replace(/>\s*/g, '>');  // Remove space after >
    str = str.replace(/\s*</g, '<');  // Remove space before <
    str = str.replace(/[\n\r]/g, ''); // Remove all newlines
    return str;
}

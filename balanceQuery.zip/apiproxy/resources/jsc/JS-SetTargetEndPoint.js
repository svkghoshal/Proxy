var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var target = '/services/QueryMgrService';
context.setVariable('targetPath',target);


   
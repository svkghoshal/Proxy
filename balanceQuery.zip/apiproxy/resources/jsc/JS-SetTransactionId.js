var apiNo =115;
/*var url = context.getVariable("message.uri").substring(0,35);*/
var urlLength = context.getVariable("message.uri");
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);
context.setVariable("isoTimestamp", ISODateString());
var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

var messageId = context.getVariable("messageid");
context.setVariable("reqMessageID",messageId);
context.setVariable("apiNo","115");


/*if(url.startwith("/v4/mm/en/balanceManagement/balance"))*/
if(!urlLength.includes("/v4/mm/en/balanceManagement/balance"))
/*if(url !== '/v4/mm/en/balanceManagement/balance' || urlLength.length != 62)*/
 {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "404."+apiNo+".001");
	context.setVariable("errorDesc", "Resource not found");
	context.setVariable("errorMessage", "Resource not found/Invalid resource");
	context.setVariable("httpError", "404");
	throw "serviceException";
 }
var AccountTypeList=context.getVariable("AccountTypeList");
var AccountType;
if(AccountTypeList.includes("2000",183))
    {
        context.setVariable("AccountType", "PREPAID"); 
    }else{
        context.setVariable("AccountType", "POSTPAID");
    }



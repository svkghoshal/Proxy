var relatedPartyId = context.getVariable("message.queryparam.partyAccount.id");
var accountType = context.getVariable("req.accountType");

var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
var apiNo = context.getVariable('apiNo');
 
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionDateTime",transactionDateTime());
context.setVariable("transactionId",apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

var tempTransactionId = context.getVariable("transactionId");
context.setVariable("newtransactionId", tempTransactionId.substr(3));


 if ( isEmpty(relatedPartyId) ||  !relatedPartyId.startsWith("97") || relatedPartyId.length != 10 )
 {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input.");
    throw "serviceException";
 }
context.setVariable("relatedPartyId", relatedPartyId);
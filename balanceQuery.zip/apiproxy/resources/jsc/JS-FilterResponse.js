var JsonData=context.getVariable("TransformDataJson");
var AvailableCredit = context.getVariable("res.AvailableCredit").toString();
var relatedPartyId = context.getVariable("relatedPartyId");
var jsonObject = JSON.parse(JsonData);
var jsonObjecttr = JSON.stringify(jsonObject.QueryBalanceResult.tr);

if ( isEmpty(AvailableCredit) ||  AvailableCredit === null || AvailableCredit == "0")
{
   
    context.setVariable("response.content",jsonObjecttr);
}else
{
    
    var addOnString = ',{ "id":"3000", "bucketType":"3000", "remainedAmount":{ "amount":"'+AvailableCredit+'" }, "validFor":{ "startDateTime":"", "endDateTime":"" }, "partyAccount":{ "id":"'+relatedPartyId+'", "name":"POSTPAID" } }';
    if(typeof jsonObjecttr  !== 'undefined')
    {
        jsonObjecttr = jsonObjecttr.replace(']','')+addOnString+']';
        
    }else
    {
        jsonObjecttr = addOnString.replace(',','[')+']';
    }
    
    context.setVariable("response.content",jsonObjecttr);
}

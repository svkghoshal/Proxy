var memberDetails = context.getVariable("memberDetails");
var jsonToStringMember = JSON.parse(memberDetails);
var modifiedmemberDetails = JSON.stringify(jsonToStringMember);
context.setVariable("memberDetails", modifiedmemberDetails);


var toneDetails = context.getVariable("toneDetails");
var jsonToStringToneDetails = JSON.parse(toneDetails);
var modifiedmemberToneDetails = JSON.stringify(jsonToStringToneDetails);
context.setVariable("toneDetails", modifiedmemberToneDetails);


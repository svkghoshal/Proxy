var reqVerb = context.getVariable('request.verb');
var path = context.getVariable('message.path');

/********************REQUEST DATA EXTRACT****************/

var path_variable_Array = [];

if(!isEmpty(path)) {
    path_variable_Array = path.split("/");
    
}

var msisdn = path_variable_Array[5];
var serviceSpecification = context.getVariable('req.serviceSpecificationId');
var serviceId = path_variable_Array[8];
if(!isEmpty(serviceSpecification))
{
	context.setVariable("serviceSpecification", serviceSpecification.toUpperCase());
}


var requestname = context.getVariable("req.name");
var description = context.getVariable("req.description");
var serviceType = context.getVariable("req.serviceType");
var state = context.getVariable("req.state");
var packName,toneId;
var relatedParty = context.getVariable("req.relatedParty");
var serviceCharacteristic = context.getVariable("req.serviceCharacteristic");


var fee = context.getVariable("request.content");
if(!isEmpty(fee)){
var jsonObject = JSON.parse(fee);
var serviceCharacteristicRequest = jsonObject.serviceCharacteristic;
var relatedPartyRequest = jsonObject.relatedParty;

	if(isEmpty(serviceCharacteristicRequest))
	{
		serviceCharacteristicRequest = '';
	}
	if(isEmpty(relatedPartyRequest))
	{
		relatedPartyRequest='';
	}

for(i = 0; i<serviceCharacteristicRequest.length; i++){
		var nameRequest = serviceCharacteristicRequest[i].name;
			if(nameRequest === "packName")
			{
			   packName = serviceCharacteristicRequest[i].value;
			}
			if(nameRequest === "toneId")
			{
			   toneId = serviceCharacteristicRequest[i].value;
			}
	}
}


/********************REQUEST DATA EXTRACT****************/

/********************KVM DATA EXTRACT****************/

var RRBT = context.getVariable("kvm.RRBT");

var CRBT = context.getVariable("kvm.CRBT");

/********************KVM DATA EXTRACT****************/

/********************GENERATE TRANSACTION IDT****************/

var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
var apiNo = context.getVariable('apiNo');
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionDateTime",transactionDateTime());
context.setVariable("transactionId",apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

/********************GENERATE TRANSACTION IDT****************/

if (reqVerb == "DELETE")
{
    if (isEmpty(serviceId)|| typeof path_variable_Array[5] == 'undefined'
     || (!msisdn.startsWith("97") || ((msisdn.length != 10))))
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else{
		 context.setVariable("msisdn", msisdn); 
		 context.setVariable("serviceId", serviceId);   		 
     }
}

if (reqVerb == "POST" || reqVerb == "PATCH")
{
    if (typeof path_variable_Array[5] == 'undefined'|| isEmpty(serviceSpecification)
	 || isEmpty(serviceType) || isEmpty(serviceCharacteristic)
     || (!msisdn.startsWith("97") || ((msisdn.length != 10))))
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (checkData(serviceSpecification) != '1')
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (checkPriority(serviceType) != '1')
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (isEmpty(requestname) 
		 && serviceSpecification.toUpperCase() === "GROUPCALLERSETTING")
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (reqVerb == "POST" && isEmpty(description) 
		 && serviceSpecification.toUpperCase() === "GROUPCALLERSETTING")
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (isEmpty(relatedParty) 
		 && serviceSpecification.toUpperCase() === "GROUPCALLERSETTING")
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (relatedPartyRequest.length <= 1  
		&& serviceSpecification.toUpperCase() === "GROUPCALLERSETTING")
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (serviceCharacteristicRequest.length <= 1  
		&& serviceSpecification.toUpperCase() === "GROUPCALLERSETTING")
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (serviceSpecification.toUpperCase() === "CALLERSETTING" 
		 && isEmpty(packName))
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (reqVerb == "PATCH" && isEmpty(state))
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (serviceSpecification.toUpperCase() === "SPECIALCALLERSETTING"
		 && isEmpty(packName))
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (reqVerb == "PATCH" && isEmpty(toneId)  
		&& serviceSpecification.toUpperCase() === "SPECIALCALLERSETTING" 
	|| reqVerb == "PATCH" && isEmpty(toneId)  
		&& serviceSpecification.toUpperCase() === "GROUPCALLERSETTING")
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (reqVerb == "PATCH" && typeof path_variable_Array[8] == 'undefined' 
	 && serviceSpecification.toUpperCase() === "GROUPCALLERSETTING" 
	 || isEmpty(serviceId) && reqVerb == "PATCH"  
	 && serviceSpecification.toUpperCase() === "GROUPCALLERSETTING")
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else{
         
         if(serviceType.toUpperCase().includes("CRBT"))
        {
            context.setVariable("priority", CRBT);
            
        }if(serviceType.toUpperCase().includes("RRBT"))
        {
            context.setVariable("priority", RRBT);
            
        }
         context.setVariable("msisdn", msisdn);
		 context.setVariable("serviceId", serviceId);
		 context.setVariable("packName", packName);
		 context.setVariable("toneId", toneId);
     }
}

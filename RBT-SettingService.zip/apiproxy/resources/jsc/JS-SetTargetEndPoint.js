var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var serviceSpecificationId = context.getVariable('req.serviceSpecificationId');

if(isEmpty(serviceSpecificationId))
{
   serviceSpecificationId = ''; 
}
if (serviceSpecificationId.toUpperCase() === "GROUPCALLERSETTING" )
{
    if(reqVerb == "POST")
    {
        var target = '/crbt/create-group';
        
    }else{
        
        var target = '/crbt/edit-group';
        
    }
   
}else if(serviceSpecificationId.toUpperCase() === "CALLERSETTING" )
{
   
    if(reqVerb == "POST")
    {
        var target = '/crbt/add-callerSettings';
        
    }else{
        
         var target = '/crbt/delete-callerSettings';
    }
    
}else if (serviceSpecificationId.toUpperCase() === "SPECIALCALLERSETTING"){
    
    if(reqVerb == "POST")
    {
        var target = '/crbt/activate-special-caller';
        
    }else{
        
         var target = '/crbt/deactivate-special-caller';
    }
}else{
    var target = '/crbt/delete-group';
}

context.setVariable('targetPath',target);
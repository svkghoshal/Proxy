// Request URI from external client
var uriRequest = context.getVariable("clientUriRequest");
var clientUriRequest = uriRequest;
context.setVariable("clientUriRequest", clientUriRequest);

// Request Body from external Client
var bodyRequest = context.getVariable("clientBodyRequest");
try {
    var clientBodyParse = JSON.parse(bodyRequest);
    var clientBodyRequest = JSON.stringify(clientBodyParse);
    context.setVariable("clientBodyRequest", clientBodyRequest);
} catch (err) {
    context.setVariable("clientBodyRequest_error", err);
}

// If Body is empty, use URI as Body request
if (isEmpty(bodyRequest)) {
    context.setVariable("clientBodyRequest", clientUriRequest);
}

// Response body to external client
var bodyResponse = context.getVariable("clientBodyResponse");
try {
    var clientBodyParse = JSON.parse(bodyResponse);
    var clientBodyResponse = JSON.stringify(clientBodyParse);
    context.setVariable("clientBodyResponse", clientBodyResponse);
} catch (err) {
    context.setVariable("clientBodyResponse_error", err);
}

/****************************************************************/

// Calculate the total elapsed time
// Time request is received from client to time response is sent back to client
var client_start = context.getVariable("client.received.start.timestamp");
var system_timestamp = context.getVariable("system.timestamp");
var totalElapsedTime = context.setVariable("totalElapsedTime", ""+(system_timestamp-client_start));

var targetElapsedTime = context.getVariable("targetElapsedTime");
if (!targetElapsedTime) {
    context.setVariable("targetElapsedTime", "X");
}

/****************************************************************/

// For SC-StatCollector
switch (context.getVariable("statusCode")) {
    case "1":
    case "Successful":
        var statStatusCode = "OK";
        break;
    default:
        var statStatusCode = "FAIL";
}
var statErrorCode = context.getVariable("errorCode");
var statErrorMessage = context.getVariable("errorMessage");
context.setVariable("statStatusCode", statStatusCode);
context.setVariable("statErrorCode", statErrorCode);
context.setVariable("statErrorMessage", statErrorMessage);

// Return the backend environment as Header for Sandbox
var envType = context.getVariable("envType");
var envTarget = context.getVariable("envTarget");
var rmp_ip = context.getVariable("system.interface.ens192");
if (envType != "PRODUCTION") {
    context.setVariable("message.header.Backend-Environment", envTarget);
    switch (rmp_ip) {
        case "10.88.1.20":
            var rmp_hostname = "a0110papirmp01";
            break;
        case "10.88.1.21":
            var rmp_hostname = "a0110papirmp02";
            break;
        default:
            var rmp_hostname = rmp_ip;
    }
    context.setVariable("message.header.Router-Message-Processor", rmp_hostname);
}

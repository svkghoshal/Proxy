var pathSuffix = context.getVariable("proxy.pathsuffix");
var QueryValueimsi = context.getVariable("req.imsi");
var target;
var apiNo = 080;
switch (pathSuffix) {
    case "/serviceConfig":
       /* var target = "/cxf/v4/crm/subscriber?IMSI="+QueryValueimsi;*/
        /*var targetFinal = target.replace("=null","");*/
        var targetFinal = "/cxf/v4/crm/subscriber";
        context.setVariable("targetUrl", targetFinal);
       /* context.setVariable("target.url", "10.89.20.180:9000"+targetFinal);*/
        break;
    default:
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "404");
    	context.setVariable("errorCode", "404."+apiNo+".001");
        context.setVariable("errorDesc", "Resource Not Found");
        context.setVariable("errorMessage", "Resource not found/Invalid resource");
        context.setVariable("logType", "TECHNICAL");
        throw "ResourceNotFound";
}

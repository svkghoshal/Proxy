var sourceId = context.getVariable("req.serviceName").trim().toUpperCase();
var imsi = context.getVariable("req.imsi");

var transactionIdSeq = randomString(6);
context.setVariable("transactionIdSeq", transactionIdSeq);
context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);


if (isEmpty(sourceId) || sourceId != "RCS") {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".008");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid request received");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidSourceID";
}

if (isEmpty(imsi) || imsi.length != 15) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid request received");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidImsiID";
}

context.setVariable("sourceId", (sourceId.trim()).toUpperCase());
var pathSuffix = context.getVariable("proxy.pathsuffix");
var requestVerb = "";
// Set the timestamp after receiving response from target
context.setVariable("isoTimestamp", ISODateString());

switch (pathSuffix) {
    case "/serviceConfig":
        requestVerb = "GET";
        context.setVariable("requestVerb", requestVerb);
        break;
    default:
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "404");
    	context.setVariable("errorCode", "404."+apiNo+".001");
        context.setVariable("errorDesc", "Resource Not Found");
        context.setVariable("errorMessage", "Resource not found/Invalid resource");
        context.setVariable("logType", "TECHNICAL");
        throw "VerbNotSet";
}

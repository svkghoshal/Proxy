// Add "environment" flag for Sandbox APIs
// Acceptable values: production (default), preproduction, staging
var envName = context.getVariable("environment.name");
var pathSuffix = context.getVariable("proxy.pathsuffix");
var envParam = context.getVariable("message.queryparam.environment");
var envTarget = "DISABLED";

if (envName == "SANDBOX") {
    switch (pathSuffix) {
        case "/serviceConfig":
            switch (envParam) {
                case "preproduction":
                case "preprod":
                case "staging":
                case "stage":
                    envTarget = "PREPRODUCTION";
                    break;
                default:
                    // Only the above APIs are defaulted to Production
                    envTarget = "PRODUCTION";
            }
            break;
        default:
            // All others will be defaulted to staging
            envTarget = "STAGING";
    }
}
context.setVariable("envTarget", envTarget);

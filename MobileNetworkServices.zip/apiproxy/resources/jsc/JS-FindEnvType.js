var envName = context.getVariable("environment.name");

// Set the initial timestamp
context.setVariable("isoTimestamp", ISODateString());

if (envName == "sandbox") {
    context.setVariable("envType", "SANDBOX");
} else {
    context.setVariable("envType", "PRODUCTION");
}
// Quick fix for flows with JS-SetVerb
var requestVerb = context.getVariable("request.verb");
context.setVariable("requestVerb", requestVerb);
// Also set in JS-SetApigeeError.js
pathSuffix = context.getVariable("proxy.pathsuffix");
/*switch (pathSuffix) 
{
    case "/serviceConfig":
        context.setVariable("errorResponseType", "V1");
        break;
}*/

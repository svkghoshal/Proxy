var status_code = context.getVariable("Status");
var error_code = context.getVariable("ErrorCode");
var error_desc = context.getVariable("ErrorDescription");
var error_more = context.getVariable("MoreInfo");
var SubscriberStatus = context.getVariable("SubscriberStatus");


if (status_code != "Successful") {
    switch (error_code) {
        case "CRM:00005":
        case "CRM:00009":
        case "CRM:60010":
        case "SMO:20025":
        case "SMO:60006":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "404."+apiNo+".011");
            context.setVariable("errorDesc", "Not Found");
            context.setVariable("errorMessage", "IMSI is not valid");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        default:
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".010");
            context.setVariable("errorDesc", "Service Unavailable");
            context.setVariable("errorMessage", "Requested service is unavailable. Please retry later");
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
    }
} 
else if( (SubscriberStatus != "BARRED") && (SubscriberStatus != "SUSPENDED") && (SubscriberStatus != "ACTIVE") )
    {
	       
			context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "503."+apiNo+".011");
            context.setVariable("errorDesc", "Service Unavailable");
            context.setVariable("errorMessage", "Number is not eligible for RCS");
            context.setVariable("httpError", "503");
            context.setVariable("logType", "BUSINESS");
	
    }
 else{
	
	context.setVariable("statusCode","Successful");
    }
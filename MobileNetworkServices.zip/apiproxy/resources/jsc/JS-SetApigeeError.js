var faultName = context.getVariable("fault.name");

// Set the timestamp if there's an error
context.setVariable("isoTimestamp", ISODateString());

// Populate the transactionId if it's empty
var sourceId = context.getVariable("req.sourceId");
var transactionId = context.getVariable("transactionId");
if (isEmpty(transactionId)) {
    var transactionIdSeq = randomString(6);
    context.setVariable("transactionIdSeq", transactionIdSeq);
    context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);
}

switch(faultName) {
    
    case "RaiseFault":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "404."+apiNo+".001");
        context.setVariable("errorDesc", "Resource Not Found");
        context.setVariable("errorMessage", "Resource not found/Invalid resource");
        context.setVariable("httpError", "404");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "ServiceUnavailable":
    case "ErrorResponseCode":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "503."+apiNo+".101");
        context.setVariable("errorDesc", "Service Unavailable");
        context.setVariable("errorMessage", "The service is unavailable ("+faultName+")");
        context.setVariable("httpError", "503");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "GatewayTimeout":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "504."+apiNo+".102");
        context.setVariable("errorDesc", "Gateway Timeout");
        context.setVariable("errorMessage", "The service is unavailable");
        context.setVariable("httpError", "504");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    // chungss-20180115
    case "RequestTimeout":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "408."+apiNo+".103");
        context.setVariable("errorDesc", "Request Timeout");
        context.setVariable("errorMessage", "The service is unavailable");
        context.setVariable("httpError", "408");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "SpikeArrestViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429."+apiNo+".002");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Spike arrest violation");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "QuotaViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429."+apiNo+".003");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Quota limit exceeded");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "ConcurrentRatelimtViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429."+apiNo+".004");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Concurrent rate limit connection exceeded");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "ExecutionFailed":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apiNo+".005");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Request input is malformed or invalid");
        context.setVariable("httpError", "500");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "access_token_expired":
    case "invalid_access_token":
    case "InvalidAccessToken":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "401."+apiNo+".006");
        context.setVariable("errorDesc", "Unauthorized");
        context.setVariable("errorMessage", "Access token is invalid or expired");
        context.setVariable("httpError", "401");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    default:
		context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apiNo+".007");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Internal Server Error: " + faultName);
		context.setVariable("httpError", "500");
		context.setVariable("logType", "TECHNICAL");
		break;
}

// Also set in JS-FindEnvType.js
pathSuffix = context.getVariable("proxy.pathsuffix");
/*switch (pathSuffix) {
    case "/device":
    case "/operator":
    case "/info":
    case "/routingNumber":
        context.setVariable("errorResponseType", "V2");
        break;
    default:
        context.setVariable("errorResponseType", "V1");
}*/

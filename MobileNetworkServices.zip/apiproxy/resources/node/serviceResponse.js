 var http = require('http');
var apigee = require('apigee-access');

server = http.createServer( function(req, res) {
    console.log ('communicationMessageNotify-v1 sandbox');
    console.log ('Request ::: '+JSON.stringify(req.Body));
    var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
                
    res.writeHead(200, {'Content-Type': 'application/json'});
    var body ='{"RetrieveSubscriberResponse": {"SubscriberList": {"SubscriberRecord": [{ "ICCID": "89601699011300004061", "BillType": "0", "ExpiryDate": "2020-08-09T23:59:59", "MSISDN": "607000051504", "UserName": "userName", "TelecomType": "1", "ActiveDate": "2019-08-13T19:11:35", "CustomerId": "1000021824637", "PayType": "PREPAID", "SubscriberType": "1", "CreateDate": "2019-08-13T19:10:42", "Tenure": "45", "DefaultAccountId": "4000021966699", "SubscriberId": "2000021527766", "IMSI": "502160000004061", "SubscriberSegment": "2", "SubscriberStatus": "ACTIVE", "SubscriberLanguage": "2", "EffectiveDate": "2019-08-13T19:10:43" }]}}}';
    res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port); 
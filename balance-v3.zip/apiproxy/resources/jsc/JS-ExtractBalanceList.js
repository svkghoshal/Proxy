 var activeBalanceList = context.getVariable("res.activeBalanceList");
 var inactiveBalanceList = context.getVariable("res.inactiveBalanceList");
 var mainBalance = context.getVariable("res.mainBalance");

 if(!activeBalanceList)
    context.setVariable("res.activeBalanceList", "[]");
 else
 {
    var jsonResponse = String(activeBalanceList).replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
    context.setVariable("res.activeBalanceList",jsonResponse);
 }
 
 if(!inactiveBalanceList)
    context.setVariable("res.inactiveBalanceList", "[]");
 else
 {
    var jsonResponsePrimary = String(inactiveBalanceList).replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
    context.setVariable("res.inactiveBalanceList",jsonResponsePrimary);
 }
 
 /*if(!mainBalance)
    context.setVariable("res.mainBalance", "");
 else
 {
    var tempMainBalance = mainBalance.toString().slice(1,-1);
    //var jsonResponsePrimary = String(mainBalance).replace(/~STR~/g, "").replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
    context.setVariable("res.mainBalance",tempMainBalance);
 }*/
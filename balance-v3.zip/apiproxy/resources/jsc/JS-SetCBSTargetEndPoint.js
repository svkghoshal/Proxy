var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var target;

if (reqVerb == "PUT")
    {
        target = '/services/TransferAccountMgrService';
        context.setVariable('targetPath',target);
    }
else 
    if (reqVerb == "GET")
    {
        target = '/services/QueryMgrService';
            context.setVariable('targetPath',target);
    }
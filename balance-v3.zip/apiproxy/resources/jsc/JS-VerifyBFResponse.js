var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("res.faultString");
//var faultMsg = context.getVariable("faultMessage");
//var status_code= context.getVariable("response.status.code");
var statusCode = context.getVariable("res.resultCode");
var apiNo = context.getVariable('apiNo');

if(statusCode == "405000000")
    context.setVariable("Status","Success");
else
    {
      if(faultString.toUpperCase().includes("THE NUMBER SEGMENT ROUTING INFORMATION ABOUT THE SUBSCRIBER"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".102");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The number segment route does not exist");
            context.setVariable("httpError", "500");
        }
     else if(faultString.toUpperCase().includes("INCORRECT NUMBER FORMAT"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Invalid Input");
            context.setVariable("httpError", "400");
        }
    else
        {
                context.setVariable("exceptionName", "exceptionName");    
                context.setVariable("errorCode", "500."+apiNo+".100");
                context.setVariable("errorDesc", "Internal Server Error");
                context.setVariable("errorMessage", faultString);
                context.setVariable("httpError", "500");
        }
    }
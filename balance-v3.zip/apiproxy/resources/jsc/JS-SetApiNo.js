var app_name = context.getVariable("developer.app.name"); 
context.setVariable("app_name",app_name); 

var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

if(reqVerb == "PUT")
    var apiNo = context.setVariable("apiNo","066");
else if (reqVerb == "GET")
     var apiNo = context.setVariable("apiNo","065");
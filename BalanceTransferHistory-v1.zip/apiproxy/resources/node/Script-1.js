http = require('http');
var apigee = require('apigee-access');
server= http.createServer( function(req,res) { 
var responseBody="<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
   "<soap:Body>"+
      "<ns3:BalanceTransferResponse xmlns:ns3=\"http://telenor.com.mm//cdsservice\" xmlns:ns2=\"http://telenor.com.mm//input\">"
            +"<return>" 
                +"<balanceTransferList>"
                    +"<TNMChargeAmount>631.5</TNMChargeAmount>"
                    +"<TNMChargingPartyNumber>959795040615</TNMChargingPartyNumber>"
                    +"<TNMDiameterSessionID></TNMDiameterSessionID>"
                    +"<TNMOperationID>4052101</TNMOperationID>"
                    +"<TNMOperationType>Transferor</TNMOperationType>"
                    +"<TNMOtherPartyNumber>9788364703</TNMOtherPartyNumber>"
                    +"<TNMRequestAction>0</TNMRequestAction>"
                    +"<TNMSPID></TNMSPID>"
                    +"<TNMServiceBeginTime>20180726002944</TNMServiceBeginTime>"
                    +"<TNMServiceEndTime>20180726002944</TNMServiceEndTime>"
                    +"<TNMServiceID></TNMServiceID>"
                    +"<TNMServiceType>0</TNMServiceType>"
                    +"<TNMTranferAmount>600</TNMTranferAmount>"
                    +"<TNMTransitionFee>30</TNMTransitionFee>"
                    +"<TNMTransitionID>70000000541926948</TNMTransitionID>"
                    +"<XVoi00000020001></XVoi00000020001>"
                    +"<XVoi00000020002></XVoi00000020002>"
                    +"<XVoi00000020003></XVoi00000020003>"
                    +"<XVoi00000020004></XVoi00000020004>"
                    +"<XVoi00000020005></XVoi00000020005>"
                    +"<XVoi00000020006></XVoi00000020006>"
                    +"<XVoi00000020007></XVoi00000020007>"
                    +"<XVoi00000020008></XVoi00000020008>"
                +"</balanceTransferList>"
                +"<balanceTransferList>"
                    +"<TNMChargeAmount>421</TNMChargeAmount>"
                    +"<TNMChargingPartyNumber>959795040615</TNMChargingPartyNumber>"
                    +"<TNMDiameterSessionID></TNMDiameterSessionID>"
                    +"<TNMOperationID>4052101</TNMOperationID>"
                    +"<TNMOperationType>Transferor</TNMOperationType>"
                    +"<TNMOtherPartyNumber>9788364703</TNMOtherPartyNumber>"
                    +"<TNMRequestAction>0</TNMRequestAction>"
                    +"<TNMSPID></TNMSPID>"
                    +"<TNMServiceBeginTime>20180726002944</TNMServiceBeginTime>"
                    +"<TNMServiceEndTime>20180726002944</TNMServiceEndTime>"
                    +"<TNMServiceID></TNMServiceID>"
                    +"<TNMServiceType>0</TNMServiceType>"
                    +"<TNMTranferAmount>400</TNMTranferAmount>"
                    +"<TNMTransitionFee>30</TNMTransitionFee>"
                    +"<TNMTransitionID>70000000541926948</TNMTransitionID>"
                    +"<XVoi00000020001></XVoi00000020001>"
                    +"<XVoi00000020002></XVoi00000020002>"
                    +"<XVoi00000020003></XVoi00000020003>"
                    +"<XVoi00000020004></XVoi00000020004>"
                    +"<XVoi00000020005></XVoi00000020005>"
                    +"<XVoi00000020006></XVoi00000020006>"
                    +"<XVoi00000020007></XVoi00000020007>"
                    +"<XVoi00000020008></XVoi00000020008>"
                +"</balanceTransferList>"
                +"<status>Success</status>"
            +"</return>"
      +"</ns3:BalanceTransferResponse>"
   +"</soap:Body>"
+"</soap:Envelope>";

res.writeHead(200, {'Content-Type': 'application/xop+xml'});
 
 res.end(responseBody)
    
});
 
console.log("Node js response generated");

port = 3000;

host = '127.0.0.1';

server.listen(port, host);

console.log ('Listening at http://' + host + ':' + port);
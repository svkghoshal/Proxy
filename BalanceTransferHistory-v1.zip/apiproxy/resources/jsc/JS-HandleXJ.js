var fee = context.getVariable("response.content");
 
 if(!fee)
    context.setVariable("response.content", "[]");
 else
 {
    var jsonResponse = String(fee).replace(/"~ARRAY~",/g, "");
    context.setVariable("response.content",jsonResponse);
 } 
 

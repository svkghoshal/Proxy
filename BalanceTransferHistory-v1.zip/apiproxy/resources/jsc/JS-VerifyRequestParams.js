var id = context.getVariable("req.id");
var day = context.getVariable("req.day");
var apiNo = "030";
var msisdnLength = id.length;


context.setVariable("isoTimestamp", ISODateString());

if ((!id.startsWith("97")) || (msisdnLength != 10))  {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".102");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid MSISDN");
    throw "serviceException";
}

/*if (msisdnLength != 10) {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".005");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid MSISDN");
    throw "serviceException";
}*/

if (isEmpty(id)) {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: ID");
    throw "serviceException";
}
if (isEmpty(day)) {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".103");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing parameter");
    throw "serviceException";
}

if ((day != 'CURRENT') && (day != 'PREVIOUS')) {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}





function getISODate() {
    var d = new Date();
    var n = d.toISOString();
    return n;
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}



function isEmpty(input) {

    return (!input || 0 === input.length);

}


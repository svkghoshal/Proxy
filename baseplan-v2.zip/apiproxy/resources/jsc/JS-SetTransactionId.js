
var proxypath = context.getVariable('proxy.pathsuffix');

var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);

var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);
/*var apiNo = "009";
context.setVariable("apiNo", apiNo);
*/

					
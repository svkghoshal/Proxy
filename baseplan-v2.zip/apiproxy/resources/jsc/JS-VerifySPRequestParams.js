 var sourceId = context.getVariable('req.sourceId');
// var idType = context.getVariable('req.MSISDN');
 var idValue = context.getVariable('req.idValue');
 var planName = context.getVariable('req.planName');
 //var offerId = context.getVariable('req.offerId');
 var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
 var apiNo = context.getVariable('apiNo');
 
 context.setVariable("isoTimestamp", ISODateString());
 context.setVariable("transactionDateTime",transactionDateTime());
 //context.setVariable("idValueLength",idValue.length);
 //context.setVariable("sourceIdLength",sourceId.length);
 //context.setVariable("offerIdLength",offerId.length);
 context.setVariable("transactionId", apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));
 
 if (isEmpty(idValue) || isEmpty(planName) || isEmpty(sourceId))
 {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".101");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid Input");
	        throw "serviceException";  
 }

function isEmpty(input) {
    return (!input || 0 === input.length);
}

function transactionDateTime() {
    var now = new Date(),
                pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
         + pad(now.getMonth()+1)
         + pad(now.getDate())
         + pad(now.getHours())
         + pad(now.getMinutes()) 
         + pad(now.getSeconds());
}

function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}

function padLeadingZeros(input) {
    var step;
    var output=input;
    for(step=input.length; step<6; step++)
        output="0"+output;
    return output;
}
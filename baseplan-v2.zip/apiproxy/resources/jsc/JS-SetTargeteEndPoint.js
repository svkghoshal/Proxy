var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var list = context.getVariable('req.list');
var offerType = context.getVariable('req.offerType');
var target;

if(list===null)
    list='';

if(reqVerb=='PUT')
    {
        target = '/cxf/ChangePrimaryPlanSyncPS';
        context.setVariable('targetPath',target);
    }
else
    if(reqVerb=='GET')
        {
            if(offerType=='VAS' && list.equals("subscribed"))
                target = '/cxf/VASSubscriptionDetailsSyncPS';
            else
                target = '/cxf/PrepaidAccountSyncPS';
            context.setVariable('targetPath',target);
        }
       
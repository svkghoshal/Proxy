var statusCode = context.getVariable("res.statusCode");
var message = context.getVariable("res.statusMessage");
var status_code= context.getVariable("response.status.code");
var requestVerb = context.getVariable('reqVerb');
var apiNo = context.getVariable('apiNo');

if(status_code =='200')
    context.setVariable("Status","Success");
else
{
   switch(statusCode) {
    
                case "FL0014":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".101");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage"," Upload Failure");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FL0013":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".101");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", " Upload Failure");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FL0012":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".101");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", " Upload Failure");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FL0000":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".101");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", " Upload Failure");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FL0009":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".101");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage",  " Upload Failure");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FL0017":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "400."+apiNo+".101");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Invalid Input");
                    context.setVariable("httpError", "500");
                    break;
                    
                default:
                    context.setVariable("exceptionName", "exceptionName");
            		context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".100");
            		context.setVariable("errorDesc", "Internal Server Error");
            		context.setVariable("errorMessage", statusCode);
            		context.setVariable("httpError", "500");
            		break;
                
            }  
}
   
       

 var cafStatus = context.getVariable("cafStatus");
 
 if(cafStatus!==null)
    cafStatus = cafStatus.toUpperCase();
 
 switch(cafStatus){
     
    case "APPROVED":
        context.setVariable("cafStatus", "REGISTERED");
		break;
	
	case "IN-PROGRESS":
	case "CAF-RECEIVED-COMPLETED":
	case "CAF-SCANNED-COMPLETE":
	case "Approved-TV":
	    context.setVariable("cafStatus", "INPROGRESS");
		break;
	
	case "PENDING":
	case "V_IN-PROGRESS":
	case "C_IN-PROGRESS":
	    context.setVariable("cafStatus", "UNREGISTERED");
		break;
	case "REJECTED":
	case "CAF-RECEIVED-INCOMPLETE":
	    context.setVariable("cafStatus", "REJECTED");
		break;
		
    default:
	    context.setVariable("cafStatus", "UNREGISTERED");
		break;
 }
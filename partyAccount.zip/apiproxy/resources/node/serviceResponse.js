var http = require('http');
var apigee = require('apigee-access');

server = http.createServer( function(req, res) {
    console.log ('balanceTransfer sandbox');
    console.log ('Request ::: '+JSON.stringify(req.Body));
    var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
                
    res.writeHead(200, {'Content-Type': 'application/xml'});
    var body = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"> <soapenv:Body> <com:QueryGroupMemberInfoResultMsg xmlns:com="http://www.huawei.com/bme/cbsinterface/communitymgr" xmlns:com1="http://www.huawei.com/bme/cbsinterface/common" xmlns:com2="http://www.huawei.com/bme/cbsinterface/community" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"> <ResultHeader> <com1:CommandId>QueryGroupMemberInfo</com1:CommandId> <com1:Version>1</com1:Version> <com1:TransactionId>1</com1:TransactionId> <com1:SequenceId>1</com1:SequenceId> <com1:ResultCode>405000000</com1:ResultCode> <com1:ResultDesc>Operation is successful.</com1:ResultDesc> <com1:OperationTime>20170929164610</com1:OperationTime> </ResultHeader> <QueryGroupMemberInfoResult> <com2:GroupMember> <com2:ParentGroupNumber>100002812</com2:ParentGroupNumber> <com2:TopGroupNumber>100002812</com2:TopGroupNumber> <com2:GrpMemberNo>9777041482</com2:GrpMemberNo> <com2:GrpMemberShortNo>10376178</com2:GrpMemberShortNo> <com2:GrpMemberType>0</com2:GrpMemberType> <com2:GrpMemberStatus>0</com2:GrpMemberStatus> <com2:AllocatedQuota>2048000</com2:AllocatedQuota> <com2:UsedQuota>2047320</com2:UsedQuota> <com2:LeftQuota>680</com2:LeftQuota> <com2:JoinedMaxCUG>0</com2:JoinedMaxCUG> <com2:MaxCountOfGroupOut>5</com2:MaxCountOfGroupOut> <com2:PBXDisplayNumber xsi:nil="true" /> <com2:SimpleProperty> <com1:Id>DISPLAYMODE</com1:Id> <com1:Value>0</com1:Value> </com2:SimpleProperty> <com2:QuotaType>1</com2:QuotaType> </com2:GroupMember> </QueryGroupMemberInfoResult> </com:QueryGroupMemberInfoResultMsg> </soapenv:Body> </soapenv:Envelope>';
    res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port); 
 


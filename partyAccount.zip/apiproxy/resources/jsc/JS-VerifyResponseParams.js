 var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("res.faultString");
var statusCode = context.getVariable("res.resultCode");
var apiNo = context.getVariable('apiNo');

if(statusCode == "405000000")
    context.setVariable("Status","Success");
 else
    {
      if(faultString.toUpperCase().includes("THE MEMBER GROUPMEMBERNO"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".107");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The subscriber is not valid");
            context.setVariable("httpError", "500");
        } 
    else
        {
                context.setVariable("exceptionName", "exceptionName");    
                context.setVariable("errorCode", "500."+apiNo+".100");
                context.setVariable("errorDesc", "Internal Server Error");
                context.setVariable("errorMessage", faultString);
                context.setVariable("httpError", "500");
        }
            
    } 
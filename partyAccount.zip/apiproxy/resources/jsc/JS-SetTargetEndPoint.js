var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var target = '/services/CommunityMgrService.CommunityMgrServicePort';
context.setVariable('targetPath',target);


   
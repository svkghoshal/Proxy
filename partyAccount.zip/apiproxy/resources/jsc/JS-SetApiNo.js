var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

var transactionId;
var isoTimestamp;
if(reqVerb == "POST")
{
  var apiNo = context.setVariable("apiNo","112");
}

var transactionIdseq = (context.getVariable("ratelimit.Q-TransactionSeq.used.count"));
if(transactionIdseq === null)
{
    transactionIdseq=0;
}
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionId",apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

http = require('http');

server= http.createServer( function(req, res) {
    console.log ('balanceDeduct sandbox');
    

    
    var body = "<one:OneOffDeductionResponse xmlns:one=\"http://www.telenor.com.mm/OneOffDeduction\"> <com:TransactionReference xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\"> <com:SourceSystemId>CMP</com:SourceSystemId> <com:IdRef>561566514511<\/com:IdRef> <\/com:TransactionReference> <one:Status>Success<\/one:Status> <one:OneOffDeductionResponseBody> <one:AcctChgRec> <one:CurrAcctBal>238595<\/one:CurrAcctBal> <one:ChgAcctBal>-2625<\/one:ChgAcctBal> <one:CurrExpTime>20370101000000<\/one:CurrExpTime> <one:ChgExpTime>0<\/one:ChgExpTime> <one:AccountType>2000<\/one:AccountType> <one:AccountTypeDescription>PrepaidBalanceSubaccount<\/one:AccountTypeDescription> <one:ApplyTime>20150928162143<\/one:ApplyTime> <one:BalanceId>999000000000100469<\/one:BalanceId> <one:MinMeasureId>101<\/one:MinMeasureId> <\/one:AcctChgRec> <\/one:OneOffDeductionResponseBody> <\/one:OneOffDeductionResponse>";
    res.writeHead(200, {'Content-Type': 'text/xml;charset=UTF-8'});
    res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port);
var msisdn = context.getVariable("req.idValue");
var TransId = context.getVariable("req.TransId");
var Type = context.getVariable("req.Type");
var Reason = context.getVariable("req.Reason");
var DeductAmount = context.getVariable("req.DeductAmount");
var DeductUnit = context.getVariable("req.DeductUnit");
var RequestorId = context.getVariable("req.RequestorId");
var RequestorName = context.getVariable("req.RequestorName");
var apiNo = 078;

context.setVariable("TransId", TransId);
context.setVariable("Type", Type);
context.setVariable("msisdn", msisdn);
context.setVariable("Reason", Reason);
context.setVariable("TransId", TransId);
context.setVariable("DeductAmount", DeductAmount);
context.setVariable("RequestorId", RequestorId);
context.setVariable("RequestorName", RequestorName);
print(msisdn);
context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00



if (isEmpty(msisdn) || isEmpty(RequestorId)|| isEmpty(RequestorId)|| isEmpty(Type)
|| isEmpty(RequestorName)|| isEmpty(DeductAmount) ||isEmpty(Reason)||isEmpty(TransId)) {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400."+apiNo+".101");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Invalid Input");
    throw "serviceException";
}  

if ((DeductAmount === "0"))  {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}

if ((Type != 4))  {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}

if ((!msisdn.startsWith("97")) || (msisdn.length != 10))  {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}

var transactionId = context.getVariable("IdRef");
context.setVariable("transactionId",transactionId);
var apiNo = "078";
var Status = context.getVariable("Status");
var faultCode = context.getVariable("faultCode");
var TempAcctBal = context.getVariable("ChgAcctBal");
var faultString = context.getVariable("faultString");
var faultMsg = context.getVariable("faultMessage");




context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());

if (faultCode === null || (faultCode !== null && faultString !== null && faultString.toUpperCase().includes("NO DATA FOUND")))
	context.setVariable("Status", "Success");
else if (faultMsg.toUpperCase().includes("SOURCE CHANNEL IS BLANK")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Invalid Input.");
	context.setVariable("httpError", "400");
} else if (faultMsg.toUpperCase().includes("EXCEPTION OCCURRED AT AVAM")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Exception occurred at backend server.");
	context.setVariable("httpError", "500");
}else if ((faultCode === "405914012")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".102");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "In-sufficient Balance of Subscriber");
	context.setVariable("httpError", "500");
}else if ((faultCode === "102011206")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".107");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "The Subscriber is not valid");
	context.setVariable("httpError", "500");
} else {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", faultMsg);
	context.setVariable("httpError", "500");
}


var modifyChgAcctBal = TempAcctBal.replace("-", '');
context.setVariable("ChgAcctBal", modifyChgAcctBal);

function getTargetStartTime() {
    if (isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.sent.start.timestamp"));
    }
}

function getTargetEndTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.received.end.timestamp"));
    }
}

function getTargetElaspTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp")) || isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        var targetElapsTime = context.getVariable("target.received.end.timestamp") - context.getVariable("target.sent.start.timestamp");
        return "" + targetElapsTime;
    }
}

function getTimePattern(dateTime) {
    var today = new Date(dateTime);
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second + "," + milliSecond;
}

function checkLengthDateFormat(today) {
    if (today.length == 1) {
        today = "0" + today;
    }
    return today;
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}
 //Error code mapping for Payment
var status_code = context.getVariable("statusCode");
var status_res =context.getVariable("message.status.code");
var status_msg = context.getVariable("status");
var action = context.getVariable("req.action");
var clientTransactionId = context.getVariable("req.clientTransactionId");
var chargeMsisdn = context.getVariable("req.chargeMsisdn");
var apiNo = context.getVariable('apiNo');
    //context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00
    context.setVariable("clientTransactionId",clientTransactionId);
    context.setVariable("recipientMsisdn",chargeMsisdn);
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());

/*if(action == "REDIRECT"){
	var new_str = status_msg.replace("&amp;", "&");
print ("new_str"+new_str);
	context.setVariable("status",new_str);
}*/
var res = context.getVariable("res");
context.setVariable("res",res);

var res = status_msg.match(/lifeCycle=A/g)
print ("res"+res);

//REDIRECT URL

if((status_code =='0011') || (status_code=='3000')  || (status_code=='779') || ((status_code=='1224') && (res=="lifeCycle=A")))
    context.setVariable("status","Success");
else if ((status_code=='782'))
{
var new_str = status_msg.replace("&amp;", "&");
print ("new_str"+new_str);
context.setVariable("status",new_str);
context.setVariable("status_code",status_code);
print ("status_code"+status_code);
}
/*else if ((status_code=='1224') && ((status_msg=="lifeCycle=null") || (status_msg=="lifeCycle=NULL") || (status_msg=="lifeCycle=Null") ))*/
else if ((status_code=='1224') && ((res!="lifeCycle=A")))
{
    		context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".115");
			context.setVariable("errorMessage","Failure");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
}
else
{
	switch(status_code) {
	
		
	//error code 400
	case "1225":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".116");
			context.setVariable("errorMessage","No History Available");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "783":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".115");
			context.setVariable("errorMessage","Redirect URL feature not enabled/Error in generating redirect URL");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "788":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".116");
			context.setVariable("errorMessage","Normal activation is restricted as redirection URL feature enabled for the offer");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "784":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".115");
			context.setVariable("errorMessage","Wrong OTP");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "780":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".116");
			context.setVariable("errorMessage","OTP request is failed");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "781":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".117");
			context.setVariable("errorMessage","OTP is not enabled for the requested offer ");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "787":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".118");
			context.setVariable("errorMessage","CP blacklisted subscriber");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "652":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","Invalid Input");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0010":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".102");
			context.setVariable("errorMessage","Parameter missing");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0012":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".103");
			context.setVariable("errorMessage","Invalid BillingText");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0001":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".101");
			context.setVariable("errorMessage","Subscription does not exists");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "0002":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".102");
			context.setVariable("errorMessage","Subscription already exists");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "0003":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".103");
			context.setVariable("errorMessage","Product Expired");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			break;
	case "0004":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".104");
			context.setVariable("errorMessage","Product does not exists");
			context.setVariable("errorDesc","Internal Srver Error");
			context.setVariable("httpError","500");
			break;
	case "0005":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".105");
			context.setVariable("errorMessage","Product is not active");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;	
			
	case "0006":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".104");
			context.setVariable("errorMessage","Subscriber number invalid");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;	
	case "0007":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400." + apiNo + ".101");
			context.setVariable("errorMessage","Invalid Input");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;	
	case "0008":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".108");
			context.setVariable("errorMessage","Price Point/Charge amount is not matching with the configured value");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;	
	case "0009":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".109");
			context.setVariable("errorMessage","Authentication Failure");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "0013":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".110");
			context.setVariable("errorMessage","TPS limit exceeded");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "0014":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".111");
			context.setVariable("errorMessage","Price Point not Configured");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "0015":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".112");
			context.setVariable("errorMessage","Charge Amount not matching");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "0017":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".113");
			context.setVariable("errorMessage","Subscriber Already Deactivated");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "4007":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".114");
			context.setVariable("errorMessage","Subscriber number not belongs to IN");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "3001":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".115");
			context.setVariable("errorMessage","Event charging failure/Direct Debit Failed");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "4008":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".116");
			context.setVariable("errorMessage","Debit does not exit");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "787":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".117");
			context.setVariable("errorMessage","CP blacklisted subscriber");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	default :
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500." + apiNo + ".100");
			context.setVariable("errorMessage", status_msg);
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;	
	}
}


function getTargetStartTime() {
    if (isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.sent.start.timestamp"));
    }
}

function getTargetEndTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.received.end.timestamp"));
    }
}

function getTargetElaspTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp")) || isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        var targetElapsTime = context.getVariable("target.received.end.timestamp") - context.getVariable("target.sent.start.timestamp");
        return "" + targetElapsTime;
    }
}

function getTimePattern(dateTime) {
    var today = new Date(dateTime);
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second + "," + milliSecond;
}

function checkLengthDateFormat(today) {
    if (today.length == 1) {
        today = "0" + today;
    }
    return today;
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}


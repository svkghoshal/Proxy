var chargeMsisdn = context.getVariable("req.chargeMsisdn");
var productCode = context.getVariable("req.productCode");
var clientTransId = context.getVariable("req.clientTransactionId");
var username = context.getVariable("req.loginName");
var action = context.getVariable("req.action");
var password = context.getVariable("req.password");
var cpID = context.getVariable("req.Cpid");
var channelId = context.getVariable("kvm.channelId");
var apiNo = context.getVariable('apiNo');
var consentOTP = context.getVariable("req.transactionPin");
var chargeAmount= context.getVariable("req.chargeAmount");
var billingTextString = "";
var ExpProdCode = "^[a-zA-Z0-9_]*$";
var ExpPasswd = "^[a-zA-Z0-9]*$";
/*var requestVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",requestVerb);*/
/*var requestVerb = context.getVariable("req.action");
context.setVariable("reqVerb",requestVerb);
*/
context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00
context.setVariable("recipientMsisdn",chargeMsisdn);

if (isEmpty(chargeMsisdn) || isEmpty(productCode) || isEmpty(username) ||isEmpty(cpID)
    || isEmpty(password) || isEmpty(clientTransId) || isEmpty(action)) {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400."+apiNo+".102");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Parameter Missing");
    throw "serviceException";
} 

if(clientTransId.length > 20){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400."+apiNo+".101");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Invalid Input");
    throw "serviceException";
}


if(!password.match(ExpPasswd)){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400."+apiNo+".101");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Invalid Input");
    throw "serviceException";
}

if(!productCode.match(ExpProdCode)){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400."+apiNo+".101");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Invalid Input");
    throw "serviceException";
}

if(action == "CHARGE" && isEmpty(chargeAmount)){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400."+apiNo+".101");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Invalid Input");
    throw "serviceException";
}

if((action != "subscribe") && (action != "unsubscribe") && (action != "OTP") && (action != "REDIRECT") && (action != "VALIDATE")&& (action != "CHARGE"))
{ 
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400."+apiNo+".101");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Invalid action parameter");
    throw "serviceException";
}



var billingTextString = "msisdn="+chargeMsisdn+"|"+"productCode="+productCode+"|"+"channelID="+channelId+"|"+"clientTransId="+clientTransId+"|"+"username="+username+"|"+"password="+password+"|"+"cpID="+cpID+"|"+"consentOTP="+consentOTP+"|"+"chargeAmount="+chargeAmount;
    context.setVariable("billingText",billingTextString);
    
print("billingTextString ::" + billingTextString);
//function createBillingText(){
    
    
//}
    /* */
    /*}else
    {
        if(!isEmpty(cpID)){
            billingText1=billingTextString.concat("|"+"cpID="+cpID);    
        }
        
    }*/
  
    
    
   /* if(!isEmpty(shortCode)){
        billingText2 = billingText1.concat("|"+"shortCode="+shortCode);
    }
    else
    {
        billingText2 = billingText1;
    }
    if(!isEmpty(reason)){
        billingText3=billingText2.concat("|"+"reason="+reason);
    }
    else
    {
        billingText3=billingText2;
    }
    if(!isEmpty(language)){
        billingText4=billingText3.concat("|"+"language="+language);
    }
    else
    {
        billingText4=billingText3;
    }
    if(!isEmpty(sourceNode)){
        billingText5=billingText4.concat("|"+"sourceNode="+sourceNode);
    }
    else
    {
        billingText5=billingText4;
    }
   */ /*if(!isEmpty(isContentProvider)){
        billingText6=billingText5.concat("|"+"isContentProvider="+isContentProvider);
    }
    else
    {
        billingText6=billingText5;
    }*/
    //TO-DO add it to billing text paramters in future
    //if(!isEmpty(accountType)){
    //    context.setVariable("accountType",type);
    //}
 /*   return billingText6;
}*/
function isEmpty(input) {
    return (!input || 0 === input.length);
}

function isInteger(value) {
  var x;
  return isNaN(value) ? !1 : (x = parseFloat(value), (0 | x) === x);
}
    
function padWithZero(number, strLength) {

    var newString = '' + number;
    while (newString.length < strLength) {
        newString = '0' + newString;
    }

    return newString;
}

/* Use a function for the exact format desired... */
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
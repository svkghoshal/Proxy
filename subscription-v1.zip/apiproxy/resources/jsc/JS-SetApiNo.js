var requestVerb = context.getVariable("request.verb");


if(requestVerb == "POST")
    var apiNo = context.setVariable("apiNo","023");
else if (requestVerb == "DELETE")
     var apiNo = context.setVariable("apiNo","024"); 
//var verb = context.getVariable('request.verb')
var action = context.getVariable('req.action')
if (action == "subscribe")
{
    context.setVariable("operationcode", "ACTIVATE");
} 
else if (action == "unsubscribe")
{
    context.setVariable("operationcode", "DEACTIVATE");
}
else if (action == "OTP")
{
    context.setVariable("operationcode", "GETOTP");
}
else if (action == "REDIRECT")
{
    context.setVariable("operationcode", "GET_REDIRECT_URL");
}
else if (action == "CHARGE")
{
    context.setVariable("operationcode", "DEBIT");
}
else 
{
    context.setVariable("operationcode", "REDIRECT_URL_HISTORY");
}

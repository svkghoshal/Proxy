http = require('http');

server= http.createServer( function(req, res) {
    console.log ('payments-v1 sandbox');
    
    //var body = "Payment Charge";
    //var body = "------=_Part_0_22402548.1467562719058 Content-Type: application/xop+xml; charset=UTF-8; type=\"application/soap+xml\"; Content-Transfer-Encoding: binary Content-ID: <root.message@cxf.apache.org> <soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\"><soap:Body><ValidateAndBillResponse xmlns=\"http://xsd.gateway.sdp.digi.com\"><return><transaction_id>9999999999</transaction_id><error_code>1</error_code><error_desc></error_desc><error_list></error_list><success_list>0146690306%2C</success_list></return></ValidateAndBillResponse></soap:Body></soap:Envelope> ------=_Part_0_22402548.1467562719058--";
var body = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
            "<soapenv:Body>"+
                "<ns:ServiceExecutorResponse xmlns:ns=\"http://ws.apache.org/axis2/com/sixdee/imp/axis2 /dto/Request/xsd/\">"+
                "<ns:return xmlns:ax21=\"http://dto.axis2.imp.sixdee.com/xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"ax21:Response\">"+
                "<ax21:status>Success</ax21:status>"+
                "<ax21:statusCode>3000</ax21:statusCode>"+
                "<ax21:clientTransactionId>1234567</ax21:clientTransactionId>"+
                "</ns:return>"+
                "</ns:ServiceExecutorResponse>"+
            "</soapenv:Body>"+
        "</soapenv:Envelope>";
    res.writeHead(200, {'Content-Type': 'application/xop+xml'});
    res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port);

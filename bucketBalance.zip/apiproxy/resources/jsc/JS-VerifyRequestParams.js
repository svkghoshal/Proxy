var clientip = context.getVariable("client.ip");
context.setVariable("client.ip", "10.101.255.126" );
var id = context.getVariable("req.idValue");
var bucketType = context.getVariable("req.bucketType");
var PassCode = context.getVariable("req.partnerPin");
context.setVariable("recipientId", id);

context.setVariable("isoTimestamp", ISODateString());
var SessionId = context.getVariable("req.SessionId");

context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00

var msisdnLength = id.length;

var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);
var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
context.setVariable("transactionId", "091" + transactionDateTime() + padLeadingZeros(transactionIdseq));

if (isEmpty(id) || isEmpty(bucketType)) 
{
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.091.101");
    context.setVariable("errorMessage","Invalid Input");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";
}
if (isEmpty(PassCode)) 
{
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.091.101");
    context.setVariable("errorMessage","Invalid Input");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";
}

if ((id.length > 10) ||(id.length < 10)) 
{
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.091.101");
    context.setVariable("errorMessage","Invalid Input");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";
} 

if((!id.startsWith("97") && id.length === 10))
    {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.091.101");
    context.setVariable("errorMessage","Invalid Partner Id");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";   
    }

if (bucketType.toUpperCase().includes("DIGITALWALLET"))
{
 context.setVariable("type", "2");   
}else{
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.091.101");
    context.setVariable("errorMessage","Invalid Input");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}

function padLeadingZeros(input) {
    var step;
    var output=input;
    for(step=input.length; step<6; step++)
        output="0"+output;
    return output;
}
function transactionDateTime() {
    var now = new Date(),
                pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
         + pad(now.getMonth()+1)
         + pad(now.getDate())
         + pad(now.getHours())
         + pad(now.getMinutes()) 
         + pad(now.getSeconds());
}

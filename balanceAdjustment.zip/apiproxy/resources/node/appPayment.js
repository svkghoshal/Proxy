http = require('http');

server= http.createServer( function(req, res) {
    console.log ('balanceAdjustment sandbox');
    

    
    var body = "<?xml version='1.0' encoding='UTF-8'?> <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" > Service Delivery Platform 29 <soapenv:Body> <ns:ServiceExecutorResponse xmlns:ns=\"http://ws.apache.org/axis2/com/sixdee/imp/axis2 /dto/Request/xsd/\"> <ns:return xmlns:ax21=\"http://dto.axis2.imp.sixdee.com/xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"ax21:Response\"> <ax21:status>Refund Success</ax21:status> <ax21:statusCode>4000</ax21:statusCode> <ax21:clientTransId>1234567</ax21:clientTransId> </ns:return> </ns:ServiceExecutorResponse> </soapenv:Body> </soapenv:Envelope>";
    res.writeHead(200, {'Content-Type': 'text/xml;charset=UTF-8'});
    res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port);
var status_code = context.getVariable("statusCode");
var clientTransId = context.getVariable("clientTransId");
context.setVariable("clientTransId",clientTransId);
var Msisdn = context.getVariable("req.id");
context.setVariable("Msisdn",Msisdn);
var status_res =context.getVariable("message.status.code");

    
context.setVariable("clientTransId",clientTransId);
context.setVariable("recipientMsisdn",Msisdn);
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());

if(status_code !=4000) {

	switch(status_code) {
	
		
	
	case "0007":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.073.101");
			context.setVariable("errorMessage","Invalid Input");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0010":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.073.102");
			context.setVariable("errorMessage","Parameter Missing");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0012":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.073.103");
			context.setVariable("errorMessage","Invalid Billing Text");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0003":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.101");
			context.setVariable("errorMessage","Product Expired");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "0004":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.102");
			context.setVariable("errorMessage","Product Does Not Exist");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "0005":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.103");
			context.setVariable("errorMessage","Product Not Active");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "0008":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.104");
			context.setVariable("errorMessage","Price Point/Charge amount is not matching with the configured value");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","401");
			break;
	case "0009":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.105");
			context.setVariable("errorMessage","Authentication Failure");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;	
			
	case "0013":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.106");
			context.setVariable("errorMessage","TPS limit exceeded");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "0014":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.107");
			context.setVariable("errorMessage","Price Point not Configured");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "0015":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.108");
			context.setVariable("errorMessage","Charge Amount not matching");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "4007":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.109");
			context.setVariable("errorMessage","Subscriber number not belongs to IN");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;				
	case "4001":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.110");
			context.setVariable("errorMessage","Refund Failed");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	//This is a future error scenario		
	case "4004":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.111");
			context.setVariable("errorMessage","Refund Internal Error");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	//This is a future error scenario		
	case "4005":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.112");
			context.setVariable("errorMessage","Refund Invalid Transaction Id");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "4006":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.113");
			context.setVariable("errorMessage","Refund Invalid Request");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "4008":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.114");
			context.setVariable("errorMessage","Debit Does not Exist");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "4009":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.115");
			context.setVariable("errorMessage","Refund already done");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	case "762":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.116");
			context.setVariable("errorMessage","Refund is not Enabled");
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;
	default :
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.073.117");
			context.setVariable("errorMessage","Internal Server Error : " + status_code);
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;	
			
				
	}
}
function getTargetStartTime() {
    if (isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.sent.start.timestamp"));
    }
}

function getTargetEndTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.received.end.timestamp"));
    }
}

function getTargetElaspTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp")) || isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        var targetElapsTime = context.getVariable("target.received.end.timestamp") - context.getVariable("target.sent.start.timestamp");
        return "" + targetElapsTime;
    }
}

function getTimePattern(dateTime) {
    var today = new Date(dateTime);
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second + "," + milliSecond;
}

function checkLengthDateFormat(today) {
    if (today.length == 1) {
        today = "0" + today;
    }
    return today;
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}
var Msisdn = context.getVariable("req.id");
var type = context.getVariable("req.type");
var correlatorId = context.getVariable("req.correlatorId");
var reason = context.getVariable("req.reason");
var requestorid = context.getVariable("req.requestorid");
var requestorname = context.getVariable("req.requestorname");
var requestorpassCode = context.getVariable("req.requestorpassCode");
context.setVariable("requestorpassCode", requestorpassCode);
var amount = context.getVariable("req.amount");
var amountunits = context.getVariable("req.amountunits");
var productid = context.getVariable("req.productid");
var partyAccount = context.getVariable("req.partyAccount");

//var clientTransId=Date.now()+Math.random().toString().slice(2);
//var clientTransId = clientTrans.substring(1,8);
var clientTransId="";
context.setVariable("clientTransId",correlatorId);


var channelID = context.getVariable("kvm.APIGW");
context.setVariable("channelID", channelID);

var billingText="";
var billingTextString = "";
var ExpPasswd = "^[a-zA-Z0-9]*$";
if(type === "VAS")
{
    context.setVariable("operationCode","REFUND");
}else
{
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.073.102");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Invalid input Type parameters");
    throw "serviceException";
}

if(type === "VAS" && isEmpty(requestorpassCode))
{
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.073.102");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Missing input passcode parameters");
    throw "serviceException";
}


context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00
context.setVariable("recipientMsisdn",partyAccount);

if (isEmpty(type) || isEmpty(reason)
    || isEmpty(requestorid) || isEmpty(requestorname)
	|| isEmpty(amount)|| isEmpty(correlatorId)||isEmpty(productid)|| isEmpty(partyAccount)) {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.073.102");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Missing input parameters");
    throw "serviceException";
} 

if (isEmpty(Msisdn)) {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","404");
    context.setVariable("errorCode","404.073.102");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Missing input parameters");
    throw "serviceException";
} 

if (isInteger(Msisdn) || isInteger(partyAccount)) {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.073.101");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Invalid input");
    throw "serviceException";
} 

if((!Msisdn.startsWith("97") && Msisdn.length === 10))
    {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.073.101");
    context.setVariable("errorMessage","Invalid input");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";   
    }
if((!partyAccount.startsWith("97") && partyAccount.length === 10))
    {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.073.101");
    context.setVariable("errorMessage","Invalid input");
    context.setVariable("errorDesc","Bad Request");
    throw "serviceException";   
    }

if(Msisdn.length > 10 || Msisdn.length < 10){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.073.101");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Input Parameter Msisdn is invalid");
    throw "serviceException";
}
if(partyAccount.length > 10 || partyAccount.length < 10){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.073.101");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Input Parameter Party Account is invalid");
    throw "serviceException";
}


if(!requestorpassCode.match(ExpPasswd)){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.073.003");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Password is invalid");
    throw "serviceException";
}

context.setVariable("billingText",createBillingText());
    
function createBillingText(){
    
    var billingTextString = "msisdn="+Msisdn+"|"+"productCode="+productid+"|"+"channelID="+channelID+"|"+"chargeAmount="+amount+"|"+"clientTransId="+correlatorId+"|"+"cpID="+requestorid+"|"+"username="+requestorname+"|"+"password="+requestorpassCode+"|"+"reason="+reason+"|"+"sourceNode="+type+"|"+"isContentProvider=FALSE";
    
    
    if(isEmpty(requestorpassCode)){
        var billingText1 = "msisdn="+Msisdn+"|"+"productCode="+productid+"|"+"channelID="+channelID+"|"+"chargeAmount="+amount+"|"+"clientTransId="+correlatorId+"|"+"cpID="+requestorid+"|"+"username="+requestorname+"|"+"password=null"+"|"+"reason="+reason+"|"+"sourceNode="+type+"|"+"isContentProvider=FALSE";
        return billingText1;
    }
    else
    {
        return billingTextString;
    }
   
    return billingTextString;
}
function isEmpty(input) {
    return (!input || 0 === input.length);
}

function isInteger(value) {
  var x;
  return isNaN(value) ? !1 : (x = parseFloat(value), (0 | x) === x);
}
    
/* Use a function for the exact format desired... */
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}

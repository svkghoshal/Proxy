 var status_code = context.getVariable("statusCode");
 var clientTransId = context.getVariable("clientTransId");
 var Msisdn = context.getVariable("req.id");
 var Error_Response="";
 
 if (isEmpty(status_code) || isEmpty(clientTransId) || isEmpty(Msisdn)) {
   context.setVariable("Error_Response","Empty response");
 }
 
 
 
 function isEmpty(input) {
    return (!input || 0 === input.length);
}
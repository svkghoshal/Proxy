// This has been demonstrated to route calls to sandbox target by assuming "stage" environment as Sandbox
envName = context.getVariable("environment.name") 
if (envName.indexOf("Sandbox") >= 0) {
    context.setVariable ("envType", "SANDBOX");
    print("setting the envtype : sandbox");

} else {
    print("setting the envtype : production");
    context.setVariable ("envType","PRODUCTION");
}


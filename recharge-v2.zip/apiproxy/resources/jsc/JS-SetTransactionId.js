var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);

var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

var messageId = context.getVariable("messageid");
context.setVariable("reqMessageID",messageId);


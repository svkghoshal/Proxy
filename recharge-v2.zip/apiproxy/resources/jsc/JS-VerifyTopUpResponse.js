var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("res.faultString");
//var faultMsg = context.getVariable("faultMessage");
//var status_code= context.getVariable("response.status.code");
var statusCode = context.getVariable("res.resultCode");
var apiNo = context.getVariable('apiNo');
if (statusCode == "405000000")
	context.setVariable("Status", "Success");
else {
	if ((faultString.toUpperCase().includes("STRING LENGTH (25) IS GREATER THAN MAXLENGTH FACET (24)")) || (faultString.toUpperCase().includes("INCORRECT NUMBER FORMAT"))) {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "400."+apiNo+".101");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Invalid Input.");
		context.setVariable("httpError", "400");
	}  else if (faultString.toUpperCase().includes("INCORRECT VOUCHER NUMBER")) {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "400."+apiNo+".102");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Incorrect voucher number.");
		context.setVariable("httpError", "400");
	} else if (faultString.toUpperCase().includes("THE SUBSCRIBER DOES NOT EXIST OR")) {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".101");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "The subscriber is not valid.");
		context.setVariable("httpError", "500");
	} else if (faultString.toUpperCase().includes("THE DIGIT OF CARD IS INCORRECT") || (faultString.toUpperCase().includes("THE CARD IS USED"))) {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".102");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "The voucher is already used.");
		context.setVariable("httpError", "500");
	} else if (faultString.toUpperCase().includes("THE NUMBER SEGMENT ROUTING INFORMATION")) {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".103");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "The number segment route does not exist.");
		context.setVariable("httpError", "500");
	}
	 else {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".100");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", faultString);
		context.setVariable("httpError", "500");
	}
}

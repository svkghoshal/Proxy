 var oauthV2FailStatus = context.getVariable("oauthV2.failed");
 var responseContent = response.content.replace("{", "").replace("}", "").replace(/["']/g, "");
 var responseArray = responseContent.split(",");
 var responseMessage = "";
 
 if (oauthV2FailStatus === true)
 {
    if (responseArray.length > 0)
        responseMessage = responseArray[1].trim();
    else
        responseMessage = responseArray[0].trim();
    
    context.setVariable("exceptionName","Unauthorized");
    context.setVariable("errorMessage", responseMessage);
    context.setVariable("errorCode","401.000.2001");
    throw "serviceException";
 }
var clientId = context.getVariable("request.formparam.client_id");
var refreshtoken = context.getVariable("request.formparam.refreshtoken");
var grant_type = context.getVariable("request.formparam.grant_type");
var expiresIn = context.getVariable("request.formparam.expires_in");


//validate client_id
if (isEmpty(clientId)) {
    context.setVariable("exceptionName","Missing Input");
    context.setVariable("errorMessage","Missing input parameter: client_id");
    context.setVariable("errorCode","400.000.0001");
    throw "serviceException";
}

//validate grant_type
if (isEmpty(grant_type)) {
    context.setVariable("exceptionName","Missing Input");
    context.setVariable("errorMessage","Missing input parameter: grant_type");
    context.setVariable("errorCode","400.000.0003");
    throw "serviceException";
}

//validate expires_in
if (isEmpty(expiresIn)) {
    context.setVariable("request.formparam.expires_in","3600000");
}
else 
{
    expiresIn = parseInt(expiresIn) * 1000;
    context.setVariable("request.formparam.expires_in",String(expiresIn));
    if (expiresIn > 86400000){
        context.setVariable("exceptionName","Invalid Input");
        context.setVariable("errorMessage","Expiry time cannot be more than 24 hours.");
        context.setVariable("errorCode","400.000.0004");
        throw "serviceException";
    }
    else if (expiresIn <= 0){
        context.setVariable("exceptionName","Invalid Input");
        context.setVariable("errorMessage","Expiry time cannot be 0 second or lesser.");
        context.setVariable("errorCode","400.000.0005");
        throw "serviceException";
    }
}



context.setVariable("request.formparam.client_id",clientId.trim());
context.setVariable("request.formparam.refreshtoken",refreshtoken.trim());
context.setVariable("request.formparam.grant_type",grant_type.trim());

function isEmpty(strIn)
{
    if (strIn === undefined)
    {
        return true;
    }
    else if(strIn === null)
    {
        return true;
    }
    else if(strIn === "")
    {
        return true;
    }
    else
    {
        return false;
    }
}


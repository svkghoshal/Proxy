var productArray = context.getVariable("app.apiproducts");
var productArrayString = "";

if (productArray.length > 0) {
    productArrayString = productArray[0];
    for (var i = 1; i < productArray.length; i++) {
        productArrayString += ", " + productArray[i]
    }
}

productArrayString = "[" + productArrayString + "]"
context.setVariable("apiproducts", productArrayString);
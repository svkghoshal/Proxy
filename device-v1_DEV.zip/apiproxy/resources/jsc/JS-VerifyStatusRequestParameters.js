var imei = context.getVariable("req.idValue");
var idtype = context.getVariable("req.idType");
var sourceId = context.getVariable("req.sourceId");
var requestId = context.getVariable("req.requestId");
var action = context.getVariable("req.action");
var reason = context.getVariable("req.reason");
var date = context.getVariable("req.date");
var proxypath = context.getVariable("proxy.pathsuffix");
var target = context.getVariable("req.target");
var str_target = String(target);
var str_length = str_target.length;
var final_target = str_target.slice(1,(str_length - 1));


// Prints something like 2009-09-28T19:03:12+08:00
context.setVariable("isoTimestamp", ISODateString());

var transactionIdSeq = randomString(6);
context.setVariable("transactionIdSeq", transactionIdSeq);
context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);

if (isEmpty(sourceId)) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

if (isEmpty(requestId)) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Request ID");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

if (isEmpty(idtype) || isEmpty(imei)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: ID Type or ID Value");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

if(proxypath == "/status"){
if (isEmpty(action)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Action");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}
}

if (isEmpty(reason)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Reason");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

if (isEmpty(date)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Date");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

if(action == "UNBLOCK"){
    if ((isEmpty(target))) {
        context.setVariable("req.target","ALL");
        context.setVariable("req.target1","CELCOM");
        context.setVariable("req.target2","MAXIS");
        context.setVariable("req.target3","UMOBILE");
    }
    else if (!isEmpty(target)) 
    { 
        var flag1 = final_target.includes("CELCOM");
		var flag2 = final_target.includes("MAXIS");
		var flag4 = final_target.includes("UMOBILE");
		var flag5 = final_target.includes("YES");
		var flag6 = final_target.includes("WEBE");
		var flag3 = final_target.includes("ALL");
        print(flag1);
		print(flag2);
		print(flag3);
		print(flag4);
		
		if(flag1 === true){
			context.setVariable("req.target1","CELCOM");
		}
		else{
		    context.setVariable("req.target1","Skipped");
		}
		if(flag2 === true){
			context.setVariable("req.target2","MAXIS");
		}
		else{
		    context.setVariable("req.target2","Skipped");
		}
		if(flag5 === true){
			context.setVariable("req.target4","YES");
		}
		else{
		    context.setVariable("req.target4","Skipped");
		}
		if(flag6 === true){
			context.setVariable("req.target5","WEBE");
		}
		else{
		    context.setVariable("req.target5","Skipped");
		}
		if(flag4 === true){
			context.setVariable("req.target3","UMOBILE");
		}
		else{
		    context.setVariable("req.target3","Skipped");
		}
            /*if((flag1 === true) && (flag2 !== true) && (flag4 === true)){
              context.setVariable("req.target1","CELCOM");
			  context.setVariable("req.target3","UMOBILE");
            } 
            else if((flag2 === true) && (flag1 !== true) && (flag4 === true){
               context.setVariable("req.target2","MAXIS");
               context.setVariable("req.target3","UMOBILE");			   
            }
			else if((flag2 === true) && (flag1 === true) && (flag4 === true)){
			    context.setVariable("req.target1","CELCOM");
				context.setVariable("req.target2","MAXIS");
				context.setVariable("req.target3","UMOBILE");
			}
			else if(flag3 === true){
			    context.setVariable("req.target","ALL");   
			}
            else{
                context.setVariable("exceptionName", "Bad Request");
                context.setVariable("httpError", "400");
                context.setVariable("errorCode", "400.009");
                context.setVariable("errorDesc", "Bad Request");
                context.setVariable("errorMessage", "Invalid input parameter: Target");
                context.setVariable("logType", "TECHNICAL");
                throw "serviceException";
            }*/
    }
}
else{
    context.setVariable("req.target","ALL");
}
/****************************************************************/

var sourceIdlength = sourceId.length;
if (sourceIdlength > 8) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}


if (idtype != 'IMEI') {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Type");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

var imeiLength = imei.length;
if (((imeiLength <= 32))) {
    context.setVariable("imei", imei);
} else {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Value (Invalid IMEI format)");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

/****************************************************************/

 
var envName = context.getVariable("environment.name");
var envTarget;

if (envName == "SANDBOX"){
     envTarget = "SANDBOX";
     context.setVariable("envTarget", "SANDBOX");
}else{
     envTarget = "PRODUCTION";
     context.setVariable("envTarget", "PRODUCTION");
}

switch (envTarget) {
    case "SANDBOX":
        context.setVariable("BlockDigitoCELCOM", "https://igw.apistg.celcom.com.my/device/v1/status");
        context.setVariable("BlockDigitoMAXIS", "https://apigwtst.maxis.com.my/device/v1/status");
        context.setVariable("BlockDigitoUMOBILE", "https://umtest.u.com.my/device/v1/status");
        context.setVariable("BlockDigitoYES", "https://integrationuat.ytlcomms.my/device/v1/status");
        context.setVariable("DigiToCelcomTargetServer1", "https://igw.apistg.celcom.com.my/device/v1/verify");
        context.setVariable("DigiToMaxisTargetServer2", "https://apigwtst.maxis.com.my/device/v1/verify");
        context.setVariable("DigiToUmobileTargetServer3", "https://umtest.u.com.my/device/v1/verify");
        context.setVariable("DigiToYESTargetServer4", "https://integrationuat.ytlcomms.my/device/v1/verify");
        context.setVariable("UnBlockDigitoCELCOM", "https://igw.apistg.celcom.com.my/device/v1/status");
        context.setVariable("UnBlockDigitoMAXIS", "https://apigwtst.maxis.com.my/device/v1/status");
        context.setVariable("UnBlockDigitoUMOBILE", "https://umtest.u.com.my/device/v1/status");
        context.setVariable("UnBlockDigitoYES", "https://integrationuat.ytlcomms.my/device/v1/status");
        context.setVariable("GetOauthCelcomClient_id", "wLbcTop5OHBxSXZM6DOVsAkvH_ka");
        context.setVariable("GetOauthCelcomClient_secret", "GOV3ijwSGkQB2Jm1UIq0B91R_g4a");
        context.setVariable("GetOauthCelcom", "https://igw.apistg.celcom.com.my/oauth/v2/token");
        context.setVariable("GetOauthUmobile", "https://umtest.u.com.my/oauth/device/token");
        context.setVariable("GetOauthYESClient_id", "592bef6273222cef98152ed338a2d647");
        context.setVariable("GetOauthYESClient_secret", "378688028d3085a2fc582fb5fe513ae1");
        context.setVariable("GetOauthYES", "https://integrationuat.ytlcomms.my/oauth/device/token");
        context.setVariable("OauthMAXISClient_id", "25ecc50d-cba6-4df8-80e5-e806a3bc52b0");
        context.setVariable("OauthMAXISClient_secret", "63bf4ae1-3dd2-4188-b857-989a0f168b54");
        context.setVariable("OauthMAXIS", "https://apigwtst.maxis.com.my/oauth/device/token");
        break;
    case "PRODUCTION":
        context.setVariable("BlockDigitoCELCOM", "https://celcom-prod.apigee.net/device/v1/status");
        context.setVariable("BlockDigitoMAXIS", "https://apigateway.maxis.com.my/device/v1/status");
        context.setVariable("BlockDigitoUMOBILE", "https://pcbs.u.com.my/device/v1/status");
        context.setVariable("BlockDigitoYES", "https://integration.yes.my/device/v1/status");
        context.setVariable("DigiToCelcomTargetServer1", "https://celcom-prod.apigee.net/device/v1/verify");
        context.setVariable("DigiToMaxisTargetServer2", "https://apigateway.maxis.com.my/device/v1/verify");
        context.setVariable("DigiToUmobileTargetServer3", "https://pcbs.u.com.my/device/v1/verify");
        context.setVariable("DigiToYESTargetServer4", "https://integration.yes.my/device/v1/verify");
        context.setVariable("UnBlockDigitoCELCOM", "https://celcom-prod.apigee.net/device/v1/status");
        context.setVariable("UnBlockDigitoMAXIS", "https://apigateway.maxis.com.my/device/v1/status");
        context.setVariable("UnBlockDigitoUMOBILE", "https://pcbs.u.com.my/device/v1/status");
        context.setVariable("UnBlockDigitoYES", "https://integration.yes.my/device/v1/status");
        context.setVariable("GetOauthCelcomClient_id", "x2VCdzspi68DlF8zu63nTx4e9frP3Igk");
        context.setVariable("GetOauthCelcomClient_secret", "GqcOKBl6XGrtQs6w");
        context.setVariable("GetOauthCelcom", "https://celcom-prod.apigee.net/oauth/device/token");
        context.setVariable("GetOauthUmobile", "https://pcbs.u.com.my/oauth/device/token");
        context.setVariable("GetOauthYESClient_id", "238e320053f991b6a453d57a25ed6481");
        context.setVariable("GetOauthYESClient_secret", "224f4f81ddcd695e3bdf3e5b2d38a7af");
        context.setVariable("GetOauthYES", "https://integration.yes.my/oauth/device/token");
        context.setVariable("OauthMAXISClient_id", "8e9a6f62-e031-4a96-8db5-5d306d162546");
        context.setVariable("OauthMAXISClient_secret", "abf9c3f0-ebf9-495b-85c6-9825c2a0f29c");
        context.setVariable("OauthMAXIS", "https://apigateway.maxis.com.my/oauth/device/token");
        break;
}
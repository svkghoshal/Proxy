  var digi = context.getVariable("dig.DIGI");
  var proxypath = context.getVariable('proxy.pathsuffix');
  var action = context.getVariable("req.action");
  var digi_target_request, digi_target_response;
  if ((proxypath.equals("/status"))){
      if(action == "BLOCK"){
      var target_request = context.getVariable("myRequest1_BlockOLOtoDigi.content");
      try{
      var target_request1 = JSON.parse(target_request);
        var target_request = JSON.stringify(target_request1);
      context.setVariable("digi_target_request",target_request);
      }catch (e) {
    context.setVariable("e", 1);
}
      
      var target_response = context.getVariable("ServiceCallout.response");
      try{
      var target_response1 = JSON.parse(target_response);
    var target_response = JSON.stringify(target_response1);
      context.setVariable("digi_target_response",target_response);
      }catch (e) {
    context.setVariable("e", 1);
}
      }
      else{
        var target_request = context.getVariable("myRequest1_UnblockOLOtoDigi.content");
        try{
        var target_request1 = JSON.parse(target_request);
        var target_request = JSON.stringify(target_request1);
        context.setVariable("digi_target_request",target_request); 
        }catch (e) {
    context.setVariable("e", 1);
}
        
        var target_response = context.getVariable("ServiceCallout.response");
        try{
        var target_response1 = JSON.parse(target_response);
    var target_response = JSON.stringify(target_response1);
      context.setVariable("digi_target_response",target_response);
        }catch (e) {
    context.setVariable("e", 1);
}
      }
  }
  else{
      var target_request = context.getVariable("myRequest1_VerifyOLOtoDigi.content");
      try{
      var target_request1 = JSON.parse(target_request);
        var target_request = JSON.stringify(target_request1);
      context.setVariable("digi_target_request",target_request);
      }catch (e) {
    context.setVariable("e", 1);
}
      
      var target_response = context.getVariable("ServiceCallout.response");
      try{
      var target_response1 = JSON.parse(target_response);
    var target_response = JSON.stringify(target_response1);
      context.setVariable("digi_target_response",target_response);
      }catch (e) {
    context.setVariable("e", 1);
}
  }
  
  if (proxypath.equals("/verify")){
if (digi == "NO_DUPLICATE") {
    var cont_flag = 'true';
    context.setVariable("DIGI","NO_DUPLICATE");
    context.setVariable("cont_flag",cont_flag);
}
else if (digi == "IMEI_DUPLICATE"){
    var cont_flag = 'false';
    context.setVariable("DIGI","IMEI_DUPLICATE");
    context.setVariable("cont_flag",cont_flag);
}
else if(digi == "FAIL"){
    var cont_flag = 'true';
    context.setVariable("DIGI","FAIL");
    context.setVariable("cont_flag",cont_flag); 
}
else{
    var cont_flag = 'true';
    context.setVariable("DIGI","FAIL");
    context.setVariable("cont_flag",cont_flag); 
}
  }
else {
if(digi == "OK"){
    var cont_flag = 'true';
    context.setVariable("DIGI",digi);
    context.setVariable("cont_flag",cont_flag);
}
else if(digi == "IMEI_DUPLICATE"){
   var cont_flag = 'false';
    context.setVariable("DIGI","IMEI_DUPLICATE");
    context.setVariable("cont_flag",cont_flag); 
}
else if(digi == "FAIL"){
    var cont_flag = 'true';
    context.setVariable("DIGI","FAIL");
    context.setVariable("cont_flag",cont_flag); 
}
else{
    var cont_flag = 'true';
    context.setVariable("DIGI","FAIL");
    context.setVariable("cont_flag",cont_flag); 
}
 }
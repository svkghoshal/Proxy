var imei = context.getVariable("req.idValue");
var idtype = context.getVariable("req.idType");
var sourceId = context.getVariable("req.sourceId");
var requestId = context.getVariable("req.requestId");

// Prints something like 2009-09-28T19:03:12+08:00
context.setVariable("isoTimestamp", ISODateString());

var transactionIdSeq = randomString(6);
context.setVariable("transactionIdSeq", transactionIdSeq);
context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);
if (isEmpty(sourceId)) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

if (isEmpty(requestId)) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Request ID");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

if (isEmpty(idtype)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: ID Type");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

if (isEmpty(imei)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: ID Value");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}


/****************************************************************/

var sourceIdlength = sourceId.length;
if (sourceIdlength > 8) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}


if (idtype != 'IMEI') {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Type");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

var imeiLength = imei.length;
if (((imeiLength <= 32))) {
    context.setVariable("imei", imei);
} else {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Value (Invalid IMEI format)");
    context.setVariable("logType", "TECHNICAL");
    throw "serviceException";
}

/****************************************************************/


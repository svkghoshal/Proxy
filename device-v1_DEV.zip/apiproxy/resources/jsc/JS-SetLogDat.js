 var bodyRequest = context.getVariable("clientBodyRequest");
try {
    var clientBodyParse = JSON.parse(bodyRequest);
    var clientBodyRequest = JSON.stringify(clientBodyParse);
    context.setVariable("clientBodyRequest", clientBodyRequest);
} catch (e) {
    context.setVariable("e", 1);
}

// Response body to external client
var bodyResponse = context.getVariable("clientBodyResponse");
try {
    var clientBodyParse = JSON.parse(bodyResponse);
    var clientBodyResponse = JSON.stringify(clientBodyParse);
    context.setVariable("clientBodyResponse", clientBodyResponse);
} catch (e) {
    context.setVariable("e", 1);
}

var client_receive_time = parseInt(context.getVariable("client.received.start.timestamp"));
print(client_receive_time);
var client_end_time = new Date().getTime();
print(client_end_time);

var total_latancy = client_end_time - client_receive_time;
print(total_latancy);
context.setVariable("tot_lat", total_latancy);
  var webe = context.getVariable("fiv.WEBE");
 var error = context.getVariable("fir.error");
if (webe == "OK") {
    var cont_flag = 'true';
    context.setVariable("WEBE",celcom);
    context.setVariable("cont_flag",cont_flag);
}
else if (webe == "IMEI_DUPLICATE"){
    var cont_flag = 'false';
    context.setVariable("WEBE","IMEI_DUPLICATE");
    context.setVariable("cont_flag",cont_flag);
}
else{
   var cont_flag = 'true';
    context.setVariable("WEBE","FAIL");
    context.setVariable("cont_flag",cont_flag); 
}

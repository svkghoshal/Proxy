  var yes = context.getVariable("four.YES");
 var error = context.getVariable("fir.error");
 var action = context.getVariable("req.action");
if (yes == "OK") {
    var cont_flag = 'true';
    context.setVariable("YES",yes);
    context.setVariable("cont_flag",cont_flag);
}
else if (yes == "IMEI_DUPLICATE"){
    var cont_flag = 'false';
    context.setVariable("YES","IMEI_DUPLICATE");
    context.setVariable("cont_flag",cont_flag);
}
else{
   var cont_flag = 'true';
    context.setVariable("YES","FAIL");
    context.setVariable("cont_flag",cont_flag); 
}

if(action == "BLOCK"){
    var target_request = context.getVariable("myRequest_BlockDigitoYes.content");
    try{
    var target_request1 = JSON.parse(target_request);
    var target_request2 = JSON.stringify(target_request1);
    context.setVariable("yes_target_request",target_request2);
    }catch (e) {
    context.setVariable("e", 1);
    }
    var target_response = context.getVariable("ServiceCallout.response");
    try{
    var target_response1 = JSON.parse(target_response);
    var target_response2 = JSON.stringify(target_response1);
    context.setVariable("yes_target_response",target_response2); 
    }catch (e) {
    context.setVariable("e", 1);
    }
 }
 else{
    var target_request = context.getVariable("myRequest_UnblockDigitoYes.content");
    try{
    var target_request1 = JSON.parse(target_request);
    var target_request2 = JSON.stringify(target_request1);
    context.setVariable("yes_target_request",target_request2);
     }catch (e) {
    context.setVariable("e", 1);
    }
    var target_response = context.getVariable("ServiceCallout.response");
    try{
    var target_response1 = JSON.parse(target_response);
    var target_response2 = JSON.stringify(target_response1);
    context.setVariable("yes_target_response",target_response2);
    }catch (e) {
    context.setVariable("e", 1);
    }
 }


 var faultName = context.getVariable ("fault.name");

// Prints something like 2009-09-28T19:03:12+08:00
context.setVariable("isoTimestamp", ISODateString());

switch (faultName) {
    case "RaiseFault":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "404.003");
        context.setVariable("errorDesc", "Resource Not Found");
        context.setVariable("errorMessage", "Resource not found/Invalid resource");
        context.setVariable("httpError", "404");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    /*case "ServiceUnavailable":
    case "ErrorResponseCode":
        context.setVariable("exceptionName", "exceptionName");
	    context.setVariable("errorCode", "503.004.101");
        context.setVariable("errorDesc", "Service Unavailable");
        context.setVariable("errorMessage", "The service is unavailable ("+faultName+")");
        context.setVariable("httpError", "503");
        context.setVariable("logType", "TECHNICAL");
        break;  
    
    case "GatewayTimeout":
        context.setVariable("exceptionName", "exceptionName");
	    context.setVariable("errorCode", "504.004.102");
        context.setVariable("errorDesc", "Gateway Timeout");
        context.setVariable("errorMessage", "The service is unavailable");
        context.setVariable("httpError", "504");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    // chungss-20171114
    case "RequestTimeout":
        context.setVariable("exceptionName", "exceptionName");
	    context.setVariable("errorCode", "408.004.103");
        context.setVariable("errorDesc", "Request Timeout");
        context.setVariable("errorMessage", "The service is unavailable");
        context.setVariable("httpError", "408");
        context.setVariable("logType", "TECHNICAL");
        break; */
        
    case "SpikeArrestViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429.004");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Spike arrest violation");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "QuotaViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429.005");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Quota limit exceeded");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "ConcurrentRatelimtViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429.006");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Concurrent rate limit connection exceeded");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    case "access_token_expired":
    case "invalid_access_token":
    case "InvalidAccessToken":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "401.002");
        context.setVariable("errorDesc", "Unauthorized");
        context.setVariable("errorMessage", "Access token is invalid or expired");
        context.setVariable("httpError", "401");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    case "ExecutionFailed":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.007");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Request input is malformed or invalid");
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
        break;   
        
     case "IPDeniedAccess":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.007");
            context.setVariable("errorDesc", "Forbidden");
            context.setVariable("errorMessage", "Access is denied");
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
        break; 
        
    default:
		context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500.008");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Internal Server Error: " + faultName);
		context.setVariable("httpError", "500");
		context.setVariable("logType", "TECHNICAL");
		break;
}

/****************************************************************/


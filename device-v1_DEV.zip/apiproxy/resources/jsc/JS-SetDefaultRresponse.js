context.setVariable("CELCOM","SKIPPED"); 
context.setVariable("MAXIS","SKIPPED");
context.setVariable("UMOBILE","SKIPPED");
context.setVariable("WEBE","FAIL");
context.setVariable("YES","FAIL");
  var maxis = context.getVariable("snd.MAXIS");
  var error = context.getVariable("snd.error");

    var target_request = context.getVariable("myRequest_VerifyDigitoMaxis.content");
    try{
    var target_request1 = JSON.parse(target_request);
    var target_request2 = JSON.stringify(target_request1);
    context.setVariable("maxis_target_request",target_request2);
    }catch (e) {
    context.setVariable("e", 1);
}
  
    var target_response = context.getVariable("ServiceCallout.response");
    try{
    var target_response1 = JSON.parse(target_response);
    var target_response2 = JSON.stringify(target_response1);
    context.setVariable("maxis_target_response",target_response2);
    }catch (e) {
    context.setVariable("e", 1);
}

if (maxis == "NO_DUPLICATE") {
    var cont_flag = 'true';
    context.setVariable("MAXIS",maxis);
    context.setVariable("cont_flag",cont_flag);
}
else if (maxis == "IMEI_DUPLICATE"){
    var cont_flag = 'false';
    context.setVariable("MAXIS","IMEI_DUPLICATE");
    context.setVariable("cont_flag",cont_flag);
}
else{
   var cont_flag = 'true';
    context.setVariable("MAXIS","FAIL");
    context.setVariable("cont_flag",cont_flag); 
}

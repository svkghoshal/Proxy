 var sourceid = context.getVariable("req.sourceId");

 
 context.setVariable("username","apiUser");
 context.setVariable("password","Av7d4J4aZKYo1dfmJnvz");
 var celcom = context.getVariable("fir.CELCOM");
 var error = context.getVariable("fir.error");
 var accesstoken2 = context.getVariable("accesstoken2");
 print("accesstoken2:-----------"+accesstoken2);
 
    var target_request = context.getVariable("myRequest_VerifyDigitoCelcom.content");
    try{
    var target_request1 = JSON.parse(target_request);
    var target_request2 = JSON.stringify(target_request1);
    context.setVariable("celcom_target_request",target_request2);
    }catch (e) {
    context.setVariable("e", 1);
}
    var target_response = context.getVariable("ServiceCallout.response");
  try{
    
    var target_response1 = JSON.parse(target_response);
    var target_response2 = JSON.stringify(target_response1);
    context.setVariable("celcom_target_response",target_response2);
  }catch (e) {
    context.setVariable("e", 1);
}
    
  if (celcom == "NO_DUPLICATE") {
    var cont_flag = 'true';
    context.setVariable("CELCOM",celcom);
    context.setVariable("cont_flag",cont_flag);
}
else if (celcom == "IMEI_DUPLICATE"){
    var cont_flag = 'false';
    context.setVariable("CELCOM","IMEI_DUPLICATE");
    context.setVariable("cont_flag",cont_flag);
}
else{
   var cont_flag = 'true';
    context.setVariable("CELCOM","FAIL");
    context.setVariable("cont_flag",cont_flag); 
}  

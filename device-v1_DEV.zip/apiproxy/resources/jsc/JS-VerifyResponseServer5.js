 var webe = context.getVariable("fiv.WEBE");
 var error = context.getVariable("fiv.error");

/*var target_request = context.getVariable("myRequest_VerifyDigitoWebe.content");
    context.setVariable("webe_target_request",target_request);
    
  
var target_response = context.getVariable("ServiceCallout.response");
    context.setVariable("webe_target_response",target_response);
*/

  if (webe == "NO_DUPLICATE") {
    var cont_flag = 'true';
    context.setVariable("WEBE",celcom);
    context.setVariable("cont_flag",cont_flag);
}
else if (webe == "IMEI_DUPLICATE"){
    var cont_flag = 'false';
    context.setVariable("WEBE","IMEI_DUPLICATE");
    context.setVariable("cont_flag",cont_flag);
}
else{
   var cont_flag = 'true';
    context.setVariable("WEBE","FAIL");
    context.setVariable("cont_flag",cont_flag); 
}  

 
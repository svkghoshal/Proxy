var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var target;

var token = "T_f5Ozc-PpMdK2DFlzqLlQeAtYZXJycIEWLpafQblSY";
context.setVariable("BearerToken", token);

var statusCode = context.getVariable("message.status.code");
var FileURL = context.getVariable("res.url").substring(8);
context.setVariable("FileURL", FileURL);

var queryparams = FileURL.split('?');
var queryparam = queryparams[1];
print("queryparam");


var apiNo = context.getVariable('apiNo');
if(statusCode == "200")
    context.setVariable("Status","Success");
else
    {
     context.setVariable("exceptionName", "exceptionName");    
     context.setVariable("errorCode", "500."+apiNo+".100");
     context.setVariable("errorDesc", "Internal Server Error");
     context.setVariable("errorMessage", "Internal Server Error");
     context.setVariable("httpError", "500");
    }


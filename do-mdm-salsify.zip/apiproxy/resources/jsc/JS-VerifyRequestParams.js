var orgId = context.getVariable("req.orgId");

var apiNo = context.getVariable('apiNo');
context.setVariable("isoTimestamp", ISODateString());


 if (isEmpty(orgId))
 {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input.");
    throw "serviceException";
 }
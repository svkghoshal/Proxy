var statusCode = context.getVariable("res.status");
var rescode = context.getVariable("res.rescode");
var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
var apiNo = context.getVariable('apiNo');
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionDateTime",transactionDateTime());
context.setVariable("transactionId", apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));
context.setVariable("DateTime", ISODateString().substring(0,11)+"00:00:00+06:30");

if(statusCode == "Success" || rescode == '0')
{
    context.setVariable("Status","Success");
    context.setVariable("Acknowledged","Acknowledged");
}
else
{
    context.setVariable("exceptionName", "exceptionName");    
    context.setVariable("errorCode", "500."+apiNo+".100");
    context.setVariable("errorDesc", "Internal Server Error");
    context.setVariable("errorMessage", faultString);
    context.setVariable("httpError", "500");
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}

function transactionDateTime() {
    var now = new Date(),
                pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
         + pad(now.getMonth()+1)
         + pad(now.getDate())
         + pad(now.getHours())
         + pad(now.getMinutes()) 
         + pad(now.getSeconds());
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
function padLeadingZeros(input) {
    var step;
    var output=input;
    for(step=input.length; step<6; step++)
        output="0"+output;
    return output;
}
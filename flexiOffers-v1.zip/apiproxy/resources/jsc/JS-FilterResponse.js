var JsonData=context.getVariable("response.content");
var jsonObject = JSON.parse(JsonData);
var final_string = jsonObject.productOfferingList;
var final = JSON.stringify(final_string).replace(/"~ARRAY~",/g, "");
context.setVariable("response.content",final);
var apiiNo;

var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);

var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

var messageId = context.getVariable("messageid");
context.setVariable("reqMessageID",messageId);

if (reqVerb == "GET") 
    context.setVariable("apiNo","108");
else
    context.setVariable("apiNo","109");

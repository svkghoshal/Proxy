var targetPath = context.getVariable('targetPath');
var offercode = context.getVariable('req.offercode');

var FinalTarget = targetPath+"?_Product_Code="+offercode;

context.setVariable('targetPath',FinalTarget);
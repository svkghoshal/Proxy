var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var target;

if(reqVerb == 'GET')
{
    target = '/cxf/GetFlexiOfferSyncPS';
    context.setVariable('targetPath',target);
}
else 
{
    target = '/cxf/PurchaseFlexiOffer';
    context.setVariable('targetPath',target);
}
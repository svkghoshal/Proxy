var statusCode = context.getVariable("res.status");
var apiNo = context.getVariable('apiNo');
var remarks = context.getVariable("res.remarks");
var faultString = context.getVariable("res.faultString");

if(statusCode == "SUCCESS")
{
    context.setVariable("Status","Success");
}
/*if(!isEmpty(remarks))
{
    context.setVariable("exceptionName", "exceptionName");    
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    context.setVariable("httpError", "400");
}
else
{
    context.setVariable("exceptionName", "exceptionName");    
    context.setVariable("errorCode", "500."+apiNo+".100");
    context.setVariable("errorDesc", "Internal Server Error");
    context.setVariable("errorMessage", faultString);
    context.setVariable("httpError", "500");
}*/

function isEmpty(input) {
    return (!input || 0 === input.length);
}
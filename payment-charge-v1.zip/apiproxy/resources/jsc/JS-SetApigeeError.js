var faultName = context.getVariable ("fault.name");
var clientTransId = context.getVariable("req.clientTransId");
var Msisdn = context.getVariable("req.Msisdn");

    context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00
    context.setVariable("clientTransId",clientTransId);
    context.setVariable("recipientMsisdn",Msisdn);
        context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());


switch(faultName) {
    
    case "SpikeArrestViolation":
                	context.setVariable("exceptionName","exceptionName");
                    context.setVariable("errorCode", "500.002.2001");
        			context.setVariable("errorMessage","Internal Server Error : Spike arrest violation");
        			context.setVariable("errorDesc","Internal Server Error");
        			context.setVariable("httpError","400");
        			break;
    
    case "QuotaViolation":
                	context.setVariable("exceptionName","exceptionName");
                    context.setVariable("errorCode", "429.002.002");
        			context.setVariable("errorMessage","Too Many Requests");
        			context.setVariable("errorDesc","Rate limit quota violation. Quota limit exceeded");
        			context.setVariable("httpError","429");
        			break;
        			
    case "ConcurrentRatelimtViolation":
                	context.setVariable("exceptionName","exceptionName");
                    context.setVariable("errorCode", "500.002.2003");
        			context.setVariable("errorMessage","Internal Server Error : ConcurrentRatelimit connection exceeded");
        			context.setVariable("errorDesc","Internal Server Error");
        			context.setVariable("httpError","500");
        			break;
        			
    case "ScriptExecutionFailed":
                	context.setVariable("exceptionName","exceptionName");
                    context.setVariable("errorCode", "500.002.2004");
        			context.setVariable("errorMessage","Internal Server Error : Javascript runtime error");
        			context.setVariable("errorDesc","Internal Server Error");
        			context.setVariable("httpError","500");
        			break;
        			
    case "InvalidApiKeyForGivenResource":
                	context.setVariable("exceptionName","exceptionName");
                    context.setVariable("errorCode", "500.002.2005");
        			context.setVariable("errorMessage","Internal Server Error : Invalid ApiKey for given resource");
        			context.setVariable("errorDesc","Internal Server Error");
        			context.setVariable("httpError","500");
        			break;
        			
    case "ExecutionFailed":
                	context.setVariable("exceptionName","exceptionName");
                    context.setVariable("errorCode", "500.002.2006");
        			context.setVariable("errorMessage","Run Time Error : Request input is malformed or in valid");
        			context.setVariable("errorDesc","Internal Server Error");
        			context.setVariable("httpError","500");
        			break;
    
    case "InvalidJSONPath":   			
        			context.setVariable("exceptionName","exceptionName");
                    context.setVariable("errorCode", "500.002.2007");
        			context.setVariable("errorMessage","Internal Server Error : Invalid JSON path");
        			context.setVariable("errorDesc","Internal Server Error");
        			context.setVariable("httpError","500");
        			break;
        			
    default:
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.002.2000");
			context.setVariable("errorMessage","Internal Server Error : " + faultName);
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;	
    
}

function padWithZero(number, strLength) {

    var newString = '' + number;
    while (newString.length < strLength) {
        newString = '0' + newString;
    }

    return newString;
}

/* Use a function for the exact format desired... */
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
function getTargetStartTime() {
    if (isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.sent.start.timestamp"));
    }
}

function getTargetEndTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.received.end.timestamp"));
    }
}

function getTargetElaspTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp")) || isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        var targetElapsTime = context.getVariable("target.received.end.timestamp") - context.getVariable("target.sent.start.timestamp");
        return "" + targetElapsTime;
    }
}

function getTimePattern(dateTime) {
    var today = new Date(dateTime);
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second + "," + milliSecond;
}

function checkLengthDateFormat(today) {
    if (today.length == 1) {
        today = "0" + today;
    }
    return today;
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}



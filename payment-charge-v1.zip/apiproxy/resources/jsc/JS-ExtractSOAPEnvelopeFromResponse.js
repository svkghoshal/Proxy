var response = context.getVariable("backendResponseContent");
var start = response.indexOf("soapenv:Envelope");
var end = response.lastIndexOf("soapenv:Envelope");

var revisedResponse = response.substring(start-1, end + 17);
context.setVariable("revisedResponse", revisedResponse);

context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00

/* Use a function for the exact format desired... */
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
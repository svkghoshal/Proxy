var chargeMsisdn = context.getVariable("req.Msisdn");
var productCode = context.getVariable("req.productCode");
var clientTransId = context.getVariable("req.clientTransId");
var username = context.getVariable("req.username");
var password = context.getVariable("req.password");
var cpID = context.getVariable("req.cpID");
var chargeAmount = context.getVariable("req.chargeAmount");
var shortCode = context.getVariable("req.shortCode");
var reason = context.getVariable("req.reason");
var sourceNode = context.getVariable("req.sourceNode");
var isContentProvider = context.getVariable("req.isContentProvider");
var language=context.getVariable("req.language");
var accountType=context.getVariable("request.queryparam.type");
var billingTextString = "";
var ExpProdCode = "^[a-zA-Z0-9_]*$";
var ExpPasswd = "^[a-zA-Z0-9]*$";

context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00
context.setVariable("recipientMsisdn",chargeMsisdn);

if (isEmpty(chargeMsisdn) || isEmpty(productCode) || isEmpty(username)
    || isEmpty(password) || isEmpty(clientTransId)) {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.002.0001");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Bad Request : Missing input parameters");
    throw "serviceException";
} 

if(clientTransId.length > 20){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.002.0002");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Bad Request: Input Parameter clientTransId is invalid");
    throw "serviceException";
}


if(!password.match(ExpPasswd)){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.002.0003");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Bad Request: Password is invalid");
    throw "serviceException";
}

if(!productCode.match(ExpProdCode)){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.002.0004");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Bad Request: Product Code is invalid");
    throw "serviceException";
}
    context.setVariable("billingText",createBillingText());
    
    
function createBillingText(){
    
    var billingTextString = "productCode="+productCode+"|"+"msisdn="+chargeMsisdn+"|"+"channelID=17"+"|"+"chargeAmount="+chargeAmount+"|"+"clientTransId="+clientTransId+"|"+"username="+username+"|"+"password="+password+"|";
    var billingText1="";
    var billingText2="";
    var billingText3="";
    var billingText4="";
    var billingText5="";
    var billingText6="";
    
    if(isContentProvider!==null && isContentProvider){
        if(isEmpty(cpID)){
            context.setVariable("exceptionName","exceptionName");
            context.setVariable("httpError","400");
            context.setVariable("errorCode","400.002.0005");
            context.setVariable("errorDesc","Bad Request");
            context.setVariable("errorMessage","Bad Request: Missing Input Parameter : cpID");
            throw "serviceException";
        }
        else
        {
            billingText1=billingTextString.concat("|"+"cpID="+cpID);
        }
    }else
    {
        if(!isEmpty(cpID)){
            billingText1=billingTextString.concat("|"+"cpID="+cpID);    
        }
        
    }
  
    
    
    if(!isEmpty(shortCode)){
        billingText2 = billingText1.concat("|"+"shortCode="+shortCode);
    }
    else
    {
        billingText2 = billingText1;
    }
    if(!isEmpty(reason)){
        billingText3=billingText2.concat("|"+"reason="+reason);
    }
    else
    {
        billingText3=billingText2;
    }
    if(!isEmpty(language)){
        billingText4=billingText3.concat("|"+"language="+language);
    }
    else
    {
        billingText4=billingText3;
    }
    if(!isEmpty(sourceNode)){
        billingText5=billingText4.concat("|"+"sourceNode="+sourceNode);
    }
    else
    {
        billingText5=billingText4;
    }
    if(!isEmpty(isContentProvider)){
        billingText6=billingText5.concat("|"+"isContentProvider="+isContentProvider);
    }
    else
    {
        billingText6=billingText5;
    }
    //TO-DO add it to billing text paramters in future
    //if(!isEmpty(accountType)){
    //    context.setVariable("accountType",type);
    //}
    return billingText6;
}
function isEmpty(input) {
    return (!input || 0 === input.length);
}

function isInteger(value) {
  var x;
  return isNaN(value) ? !1 : (x = parseFloat(value), (0 | x) === x);
}
    
function padWithZero(number, strLength) {

    var newString = '' + number;
    while (newString.length < strLength) {
        newString = '0' + newString;
    }

    return newString;
}

/* Use a function for the exact format desired... */
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
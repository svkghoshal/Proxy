 var status_code = context.getVariable("statusCode");
 var clientTransId = context.getVariable("req.clientTransId");
 var Msisdn = context.getVariable("req.Msisdn");
 var error;
 
 if (isEmpty(status_code) || isEmpty(clientTransId) || isEmpty(Msisdn)) {
    context.setVariable("error","Empty response");
 }
 
 
 
 function isEmpty(input) {
    return (!input || 0 === input.length);
}
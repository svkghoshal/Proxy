var chargeMsisdn = context.getVariable("req.chargeMsisdn");
var productCode = context.getVariable("req.productCode");
var clientTransId = context.getVariable("req.clientTransId");
var username = context.getVariable("req.username");
var password = context.getVariable("req.password");
var clientTransId = context.getVariable("req.clientTransId");
var cpId = context.getVariable("req.cpId");
var chargeAmount = context.getVariable("req.chargeAmount");
var reason = context.getVariable("req.reason");
var sourceNode = context.getVariable("req.sourceNode");
var isContentprovider = context.getVariable("req.isContentprovider");




context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00

if (isEmpty(chargeMsisdn) || isEmpty(productCode) || isEmpty(cpId) || isEmpty(clientTransId) || isEmpty(username)
    || isEmpty(password) || isEmpty(chrageAmount) || isEmpty(reason)) {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.002.0001");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Bad Request : Missing input parameters");
    throw "serviceException";
} 

if(isContentProvider && isEmpty(cpId)){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.002.0002");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Bad Request : Missing input parameters");
    throw "serviceException";
    
}

if(!isContentProvider && isEmpty(sourceNode)){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.002.0003");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Bad Request : Missing input parameters");
    throw "serviceException";
}
//var chargeMsisdn = context.getVariable("req.chargeMsisdn");
var chargeMsisdnLength = chargeMsisdn.length;
var clientTransId = clientTransId.length;


//var chargeAmount = context.getVariable("req.chargeAmount");
var chargeAmountLength = chargeAmount.length;

if(clientTransId.length > 20){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.002.0004");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Bad Request: Input Parameters are invalid");
    throw "serviceException";
}

var Exp = /^[0-9a-z]+$/;
if(!password.match(Exp) || !productCode.match(Exp)){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.002.0005");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Bad Request: Input Parameters are invalid");
    throw "serviceException";
}

function createBilliningText(){
    
var billingTextString = "msisdn="+chargeMsisdn+"|"+"productCode="+productCode+"|"+"channelID=17"+"|"+"chargeAmount="+chargeAmount+"|"+"clientTransId="+clientTransId;
var billingTextStringDebit='';
    if(isContentProvider!==null && !isContendProvider){
        if(cpId!==null){
            billingTextStringDebit=billingTextString+"|"+"cpId="+cpId+"|"+"username="+username+"|"+"password="+password+"|"+"reason="+reason+"|";
        }
    }
    
    if(sourceNode!==nul){
        billingTextStringDebit.concat("sourceNode="+sourceNode+"|");
    }
    if(isContentprovider!==nul){
        billingTextStringDebit.concat("isContentprovider="+isContentprovider);
    }
    context.setVariable("billingText","billingTextStringDebit");
}
/*if(chargeMsisdn.startsWith("6") && ((chargeMsisdnLength == 11) || (chargeMsisdnLength == 12))) {
    revisedMsisdn = chargeMsisdn.substring(1);
    context.setVariable("chargeMsisdn", chargeMsisdn);
    context.setVariable("revisedMsisdn", revisedMsisdn);
} else {
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.002.0002");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Bad Request: Input Parameters are invalid");
    throw "serviceException";
}*/

/*var chargeAmountLength = chargeAmount.length;
var chargeAmtPrefix = "CBS22";
if (((chargeAmountLength > 0) && (chargeAmountLength < 6)) && isInteger(chargeAmount))
{
    revisedAmount = chargeAmtPrefix.concat(padWithZero(chargeAmount,5));  
    context.setVariable("price", chargeAmount);
    context.setVariable("revisedAmount", revisedAmount);
}
else
{
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.002.0003");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Bad Request : Invalid charge amount");
    throw "serviceException";
}*/

if (isEmpty(chargeStatus)) {
    chargeStatus = 1;
} 

function isEmpty(input) {
    return (!input || 0 === input.length);
}

function isInteger(value) {
  var x;
  return isNaN(value) ? !1 : (x = parseFloat(value), (0 | x) === x);
}
    
function padWithZero(number, strLength) {

    var newString = '' + number;
    while (newString.length < strLength) {
        newString = '0' + newString;
    }

    return newString;
}

/* Use a function for the exact format desired... */
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
 //Error code mapping for Payment
var status_code = context.getVariable("statusCode");
var clientTransId = context.getVariable("req.clientTransId");
var Msisdn = context.getVariable("req.Msisdn");
var status_res =context.getVariable("message.status.code");

    //context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00
    context.setVariable("clientTransId",clientTransId);
    context.setVariable("recipientMsisdn",Msisdn);
    context.setVariable("targetStartTime", getTargetStartTime());
    context.setVariable("targetEndTime", getTargetEndTime());
    context.setVariable("targetElapsTime", getTargetElaspTime());

if(status_code !=3000) {

	switch(status_code) {
	 
	//error code 400
	case "0003":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1001");
			context.setVariable("errorMessage","Bad Request : Product Expired");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0004":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1002");
			context.setVariable("errorMessage","Bad Request : Product does not exists");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0005":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1003");
			context.setVariable("errorMessage","Bad Request : Product is not active");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0006":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1004");
			context.setVariable("errorMessage","Bad Request : Subscriber number invalid");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0007":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1005");
			context.setVariable("errorMessage","Bad Request : Content Provider not valid");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0008":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1006");
			context.setVariable("errorMessage","Bad Request : Price Point/Charge amount is not matching with the configured value");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0009":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1007");
			context.setVariable("errorMessage","Bad Request : Authentication Failure - userid/password invalid");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","401");
			break;
	case "0010":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1008");
			context.setVariable("errorMessage","Bad Request : Parameter missing ");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;	
			
	case "0012":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1009");
			context.setVariable("errorMessage","Bad Request : Invalid BillingText");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0013":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1010");
			context.setVariable("errorMessage","Bad Request : TPS limit exceeded");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "0014":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1011");
			context.setVariable("errorMessage","Bad Request : Price Point not Configured");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "652":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1012");
			context.setVariable("errorMessage","Bad Request : Input parameters missing or invalid");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;				
	case "3001":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1013");
			context.setVariable("errorMessage","Bad Request : Event charging failure/Direct Debit Failed");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	//This is a future error scenario		
	case "4007":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1014");
			context.setVariable("errorMessage","Bad Request : Subscriber number not belongs to IN");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	//This is a future error scenario		
	case "4008":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1015");
			context.setVariable("errorMessage","Bad Request : Debit does not exists");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "4009":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1016");
			context.setVariable("errorMessage","Bad Request : Refund already done");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;
	case "4010":
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "400.002.1017");
			context.setVariable("errorMessage","Bad Request : Charge amount not matching");
			context.setVariable("errorDesc","Bad Request");
			context.setVariable("httpError","400");
			break;	
	default :
			context.setVariable("exceptionName","exceptionName");
            context.setVariable("errorCode", "500.002.1018");
			context.setVariable("errorMessage","Internal Server Error : " + status_code);
			context.setVariable("errorDesc","Internal Server Error");
			context.setVariable("httpError","500");
			break;	
			
				
	}
}
function getTargetStartTime() {
    if (isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.sent.start.timestamp"));
    }
}

function getTargetEndTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.received.end.timestamp"));
    }
}

function getTargetElaspTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp")) || isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        var targetElapsTime = context.getVariable("target.received.end.timestamp") - context.getVariable("target.sent.start.timestamp");
        return "" + targetElapsTime;
    }
}

function getTimePattern(dateTime) {
    var today = new Date(dateTime);
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second + "," + milliSecond;
}

function checkLengthDateFormat(today) {
    if (today.length == 1) {
        today = "0" + today;
    }
    return today;
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}



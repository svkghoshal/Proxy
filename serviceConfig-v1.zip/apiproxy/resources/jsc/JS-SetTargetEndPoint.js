var proxypath = context.getVariable('proxy.pathsuffix');
var verb = context.getVariable('verb');

if (verb == "POST")
{
	var target = '/cxf/ReceiveMessage/ReceiveSMSAsynchPS';
}else{
	
	var target = '/BL/services/SDP';
}

context.setVariable('targetPath',target);
var apiNo =context.getVariable("apiNo");
var url = context.getVariable("message.uri");
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);
context.setVariable("isoTimestamp", ISODateString());
var reqVerb = context.getVariable("request.verb");
//context.setVariable("reqVerb",reqVerb);
context.setVariable("request.verb","PATCH");

var messageId = context.getVariable("messageid");
context.setVariable("reqMessageID",messageId);

if (reqVerb == "POST")
{
    context.setVariable("apiNo","120");
}

if(!url.startsWith("/v1/mm/en/users"))
 {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "404."+apiNo+".001");
	context.setVariable("errorDesc", "Resource not found");
	context.setVariable("errorMessage", "Resource not found/Invalid resource");
	context.setVariable("httpError", "404");
	throw "serviceException";
 }
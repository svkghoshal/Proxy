var statusCode = context.getVariable("message.status.code");
var apiNo = context.getVariable('apiNo');
var verb = context.getVariable('verb');
var statusCodeDND = context.getVariable('res.statusCode');
var statusValueDND = context.getVariable('res.statusValue');

if (verb == "POST")
{

	if(statusCode == "200")
	{
		context.setVariable("Status","Success");
	}
	else
    {
         context.setVariable("exceptionName", "exceptionName");    
         context.setVariable("errorCode", "500."+apiNo+".100");
         context.setVariable("errorDesc", "Internal Server Error");
         context.setVariable("errorMessage", "Internal Server Error");
         context.setVariable("httpError", "500");
    }
}else{
	
	if(statusCodeDND == "791" || statusCodeDND == "792")
	{
		context.setVariable("Status","Success");
	}
	else
    {
         context.setVariable("exceptionName", "exceptionName");    
         context.setVariable("errorCode", "500."+apiNo+".100");
         context.setVariable("errorDesc", "Internal Server Error");
         context.setVariable("errorMessage", "Internal Server Error - "+statusValueDND);
         context.setVariable("httpError", "500");
    }
}
/********************REQUEST DATA EXTRACT****************/
var MSISDN = context.getVariable("req.id");
var serviceType = context.getVariable("req.serviceType");
var state = context.getVariable("req.state");
var CharacteristicValue = context.getVariable("req.serviceCharacteristicValue");
var CharacteristicName = context.getVariable("req.serviceCharacteristicName");
var verb = context.getVariable("request.verb");
context.setVariable("verb", verb);

var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
var apiNo = context.getVariable('apiNo');

/********************REQUEST DATA EXTRACT****************/

/********************KVM DATA EXTRACT****************/

var language = context.getVariable("kvm.language");
var cpID = context.getVariable("kvm.cpID");
var operationCode = context.getVariable("kvm.operationCode");
var channelID = context.getVariable("kvm.channelID");
var username = context.getVariable("kvm.username");
var password = context.getVariable("kvm.password");
var productCode = context.getVariable("kvm.productCode");
var chargeAmount = context.getVariable("kvm.chargeAmount");

/********************KVM DATA EXTRACT****************/
/********************GENERATE TRANSACTION IDT****************/
 
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionDateTime",transactionDateTime());
var transactionId = apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq);
context.setVariable("transactionId",transactionId);


/********************GENERATE TRANSACTION IDT****************/

var billingText = "msisdn="+MSISDN+"|productCode=ALL |channelID="+channelID+"|chargeAmount="+chargeAmount+
"|clientTransId="+transactionId+"|cpID="+cpID+"|username="+username+"|password="+password+"|language="+
language+"| sourceNode=APIGW|isContentprovider=FALSE|DeleteIdentifier=2";
var operationCode = "DEACTIVATE";

if (verb == "POST")
{

	 if (isEmpty(MSISDN) || isEmpty(CharacteristicName)
	 || isEmpty(CharacteristicValue) || isEmpty(serviceType)
	 || (!serviceType.toUpperCase().includes("CONFIGURATION"))
	 || (!MSISDN.startsWith("9597") || ((MSISDN.length != 12))))
	 {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("httpError", "400");
		context.setVariable("errorCode", "400."+apiNo+".101");
		context.setVariable("errorDesc", "Bad Request");
		context.setVariable("errorMessage", "Invalid Input.");
		throw "serviceException";
	 }
}else{
	
	if (isEmpty(MSISDN) || isEmpty(state) || isEmpty(serviceType)
	 || (!serviceType.toUpperCase().includes("VAS"))
	 || (!state.toUpperCase().includes("SUSPENDED"))
	 || (checkPhoneNumber(MSISDN) != '1'))
	 {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("httpError", "400");
		context.setVariable("errorCode", "400."+apiNo+".101");
		context.setVariable("errorDesc", "Bad Request");
		context.setVariable("errorMessage", "Invalid Input.");
		throw "serviceException";
	 }else{
		 context.setVariable("billingText",billingText);
		 context.setVariable("operationCode",operationCode);
	 }
}
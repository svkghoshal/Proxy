var statusCode = context.getVariable('SCresp.statusCode');
var apiNo = context.getVariable('apiNo');
if (statusCode == "0011")
{
	var StatusSC = 'Success';
	context.setVariable("StatusSC", StatusSC);
}else{
	
	context.setVariable("exceptionName", "exceptionName");    
    context.setVariable("errorCode", "500."+apiNo+".101");
    context.setVariable("errorDesc", "Internal Server Error");
    context.setVariable("errorMessage", "The request is not successful");
    context.setVariable("httpError", "500");
}

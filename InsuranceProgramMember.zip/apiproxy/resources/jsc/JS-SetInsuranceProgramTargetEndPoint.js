var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var target;

if(reqVerb == 'GET')
{
    context.setVariable("target.url", "https://api.cbinsurance.com.mm/uat/tnm/statuscheck");
}
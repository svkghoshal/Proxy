var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("res.faultString");
//var faultMsg = context.getVariable("faultMessage");
//var status_code= context.getVariable("response.status.code");
var statusCode = context.getVariable("res.resultCode");
var serviceStatus = context.getVariable("res.serviceStatus");
var payBackTime = context.getVariable("res.payBackTime");
var loanTime = context.getVariable("res.loanTime");

var apiNo = context.getVariable('apiNo');

if(serviceStatus == "0")
{
    context.setVariable("serviceStatus","Inactive");
    
}
if(serviceStatus == "1")
{
    context.setVariable("serviceStatus","Active");
    
}

if(!isEmpty(payBackTime))
{
payBackTime.toString();
context.setVariable("res.payBackTime",payBackTime.substring(0,4)+
    "-"+payBackTime.substring(4,6)+
    "-"+payBackTime.substring(6,8)+
    "T"+payBackTime.substring(8,10)+
    ":"+payBackTime.substring(10,12)+
    ":"+payBackTime.substring(12,14)+
    "+06:30");
} 

if(!isEmpty(loanTime))
{
loanTime.toString();
context.setVariable("res.loanTime",loanTime.substring(0,4)+
    "-"+loanTime.substring(4,6)+
    "-"+loanTime.substring(6,8)+
    "T"+loanTime.substring(8,10)+
    ":"+loanTime.substring(10,12)+
    ":"+loanTime.substring(12,14)+
    "+06:30");
} 

if(statusCode == "405000000")
    context.setVariable("Status","Success");
else
    {
    if(faultString.toUpperCase().includes("THE SUBSCRIBER DOES NOT EXIST OR"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The subscriber is not valid");
            context.setVariable("httpError", "500");
        }
    if(faultString.toUpperCase().includes("A POSTPAID SUBSCRIBER CANNOT APPLY FOR THIS SERVICE"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The subscriber is not valid");
            context.setVariable("httpError", "500");
        }
    else if(faultString.toUpperCase().includes("THE NUMBER SEGMENT ROUTING INFORMATION"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".102");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The number segment route does not exist");
            context.setVariable("httpError", "500");
        }
        else if(faultString.toUpperCase().includes("INCORRECT NUMBER FORMAT"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Invalid Input");
            context.setVariable("httpError", "400");
        }
        else
        {
                    context.setVariable("exceptionName", "exceptionName");    
                    context.setVariable("errorCode", "500."+apiNo+".100");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", faultString);
                    context.setVariable("httpError", "500");
        }
}

function isEmpty(input) {
    return (!input || 0 === input.length);
}
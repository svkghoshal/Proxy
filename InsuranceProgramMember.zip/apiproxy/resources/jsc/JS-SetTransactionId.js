var apiiNo;
var reqVerb = context.getVariable("request.verb");
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);

if (reqVerb == "GET") 
{
    context.setVariable("apiNo","107");
}


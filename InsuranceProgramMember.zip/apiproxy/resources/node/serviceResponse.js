var http = require('http');
var apigee = require('apigee-access');

server = http.createServer( function(req, res) {
    console.log ('communicationMessageNotify-v1 sandbox');
    console.log ('Request ::: '+JSON.stringify(req.Body));
    var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
                
    res.writeHead(200, {'Content-Type': 'application/json'});
    var body ='{ "msisdn": "9791000631", "productcode": "CBI_30OB2L", "productname": "MicroPA 30 Days 2L", "permonth": 199, "insurancepayment": 200000, "startdate": "2019-08-29", "enddate": "2019-11-29", "status": "Success" }';
    var body1 ='{ "msisdn": "9791000123", "message": "No active offer", "status": "Failure" }';
    //var body ='Gateway Timeout';
    res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port); 
 


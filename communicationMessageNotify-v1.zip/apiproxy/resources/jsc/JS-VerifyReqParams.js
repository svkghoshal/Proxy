var transid = context.getVariable('req.eventCommunicationMessageId');
var src_addr = context.getVariable('req.eventCommunicationMSssageSenderId');
var dest_addr = context.getVariable('req.eventCommunicationMSssageReceiverId');
var eventCommunicationMessageType = context.getVariable('req.eventCommunicationMessageType');


var callbackurl = context.getVariable('req.callbackurl');
context.setVariable("req.callbackurl", callbackurl);


apiNo="101";

var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("transactionId", apiNo + transactionDateTime() +"00"+ transactionIdseq);

context.setVariable("isoTimestamp", ISODateString());

var proxypath = context.getVariable('proxy.pathsuffix');

var apiNo='101';
if (isEmpty(eventCommunicationMessageType))
 {
            context.setVariable("exceptionName", "Bad Request");
            context.setVariable("httpError", "400");
            context.setVariable("errorCode", "400."+apiNo+".101");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid Input");
            throw "serviceException";
 }
 
context.setVariable("requestcontent",request.content);

context.setVariable("nbrequestcontent",JSON.stringify(request.content));
context.setVariable("NBRequestQryString",request.uri);

function isEmpty(input) {
    return (!input || 0 === input.length);
}
function padLeadingZeros(input) {
    var step;
    var output=input;
    for(step=input.length; step<6; step++)
        output="0"+output;
    return output;
}
function transactionDateTime() {
    var now = new Date(),
                pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
         + pad(now.getMonth()+1)
         + pad(now.getDate())
         + pad(now.getHours())
         + pad(now.getMinutes()) 
         + pad(now.getSeconds());
}
function ISODateString() {
	var now = new Date(),
	tzo = -now.getTimezoneOffset(),
	dif = tzo >= 0 ? '+' : '-',
	pad = function (num) {
		var norm = Math.abs(Math.floor(num));
		return (norm < 10 ? '0' : '') + norm;
	};
	return now.getFullYear()
	 + '-' + pad(now.getMonth() + 1)
	 + '-' + pad(now.getDate())
	 + 'T' + pad(now.getHours())
	 + ':' + pad(now.getMinutes())
	 + ':' + pad(now.getSeconds())
	 + dif + pad(tzo / 60)
	 + ':' + pad(tzo % 60);
}
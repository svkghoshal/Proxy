var queryStr =  context.getVariable("request.querystring");
var JsonData =  context.getVariable("request.content").toString();
var callabckurl = context.getVariable("req.callbackurl"); 

context.setVariable("target.url", callabckurl);

var jsonObject = JSON.parse(JsonData);
var jsonCharacteristic = jsonObject.event.CommunicationMessage.characteristic;
   if(Array.isArray(jsonCharacteristic))
    {
        for(i = 0; i<jsonCharacteristic.length; i++){
            var value =jsonCharacteristic[i].value;
            //print(value);
            if(value === null || value === '')
            {
               // print("delete");
                delete jsonCharacteristic[i].name;
                delete jsonCharacteristic[i].value;
                
            }
        }
        
        var Final_Json = JSON.stringify(jsonCharacteristic);
        var unwanted_string = "{},";
        var Final = Final_Json.replace(/{},/g, "");
        context.setVariable("Final", Final);
    }

print(Final);

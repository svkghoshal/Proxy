/*var http = require('http');
var apigee = require('apigee-access');

server = http.createServer( function(req, res) {
    console.log ('subscribers-v1 sandbox');
                console.log ('Request ::: '+JSON.stringify(req.Body));
                var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
                
                res.writeHead(500, {'Content-Type': 'application/soap+xml'});
    var body="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><soapenv:Fault><faultcode>soapenv:Server</faultcode><faultstring>BEA-382505: OSB Validate action failed validation</faultstring><detail><con:fault xmlns:con=\"http://www.bea.com/wli/sb/context\"><con:errorCode>BEA-382505</con:errorCode><con:reason>OSB Validate action failed validation</con:reason><con:details><con1:ValidationFailureDetail xmlns:con1=\"http://www.bea.com/wli/sb/stages/transform/config\"><con1:message>string value 'my' is not a valid enumeration value for ChannelType in namespace com/gp/lta/Common/1.0</con1:message><con1:xmlLocation><ns:ChannelId xmlns:ns=\"com/gp/lta/ProvisioningManagement/1.0/\">my</ns:ChannelId></con1:xmlLocation></con1:ValidationFailureDetail></con:details><con:location><con:node>PipelinePairNode11</con:node><con:pipeline>PipelinePairNode11_request</con:pipeline><con:stage>GetProductMigrationDetailsValidate</con:stage><con:path>request-pipeline</con:path></con:location></con:fault></detail></soapenv:Fault></soapenv:Body></soapenv:Envelope>";
     res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port);
*/

 var http = require('http');
var apigee = require('apigee-access');

server = http.createServer( function(req, res) {
    console.log ('subscribers-v1 sandbox');
                console.log ('Request ::: '+JSON.stringify(req.Body));
                var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
                
                res.writeHead(200, {'Content-Type': 'text/html'});
    //var body='{ "question_set_no": 300, "survey_sample_percentage": null, "questions": [ { "question_id": 1, "question_no": 1, "question_type": "CES", "question_text": "How satisfied or dissatisfied were you with your experience using Grameenphone web-chat service?", "answer_type": "Option", "child_questions": [ ], "options": [ { "option_id": 1, "option_rating": 1, "option_text": "Very Satisfied" }, { "option_id": 2, "option_rating": 2, "option_text": "Satisfied" }, { "option_id": 3, "option_rating": 3, "option_text": "Neither satisfied nor dissatisfied" }, { "option_id": 4, "option_rating": 4, "option_text": "Dissatisfied" }, { "option_id": 5, "option_rating": 5, "option_text": "Very Dissatisfied" } ] }, { "question_id": 2, "question_no": 2, "question_type": "CES", "question_text": "How satisfied or dissatisfied are you with the agent‘s helpful & courteous behavior?", "answer_type": "Option", "child_questions": [ ], "options": [ { "option_id": 6, "option_rating": 1, "option_text": "Very Satisfied" }, { "option_id": 7, "option_rating": 2, "option_text": "Satisfied" }, { "option_id": 8, "option_rating": 3, "option_text": "Neither satisfied nor dissatisfied" }, { "option_id": 9, "option_rating": 4, "option_text": "Dissatisfied" }, { "option_id": 10, "option_rating": 5, "option_text": "Very Dissatisfied" } ] }, { "question_id": 3, "question_no": 3, "question_type": "CES", "question_text": "How satisfied or dissatisfied are you with the solution provided by the agent?", "answer_type": "Option", "child_questions": [ ], "options": [ { "option_id": 11, "option_rating": 1, "option_text": "Very Satisfied" }, { "option_id": 12, "option_rating": 2, "option_text": "Satisfied" }, { "option_id": 13, "option_rating": 3, "option_text": "Neither satisfied nor dissatisfied" }, { "option_id": 14, "option_rating": 4, "option_text": "Dissatisfied" }, { "option_id": 15, "option_rating": 5, "option_text": "Very Dissatisfied" } ] }, { "question_id": 4, "question_no": 4, "question_type": "CES", "question_text": "How satisfied or dissatisfied are you with the time it took to reach an agent?", "answer_type": "Option", "child_questions": [ ], "options": [ { "option_id": 16, "option_rating": 1, "option_text": "Very Satisfied" }, { "option_id": 17, "option_rating": 2, "option_text": "Satisfied" }, { "option_id": 18, "option_rating": 3, "option_text": "Neither satisfied nor dissatisfied" }, { "option_id": 19, "option_rating": 4, "option_text": "Dissatisfied" }, { "option_id": 20, "option_rating": 5, "option_text": "Very Dissatisfied" } ] }, { "question_id": 5, "question_no": 5, "question_type": "MCQ", "question_text": "What is your preferred channel to avail customer service?", "answer_type": "Option", "child_questions": [ ], "options": [ { "option_id": 21, "option_rating": 1, "option_text": "Web Chat" }, { "option_id": 22, "option_rating": 2, "option_text": "Facebook" }, { "option_id": 23, "option_rating": 3, "option_text": "E-mail" }, { "option_id": 24, "option_rating": 4, "option_text": "GPC" }, { "option_id": 25, "option_rating": 5, "option_text": "121" } ] }, { "question_id": 6, "question_no": 6, "question_type": "Adhoc", "question_text": "Is there anything else you would like to add?", "answer_type": "Text", "child_questions": [ ], "options": [ ] } ] }';
    var body ='status=FAUILURE,transid=9545415011,reasoncode=201';
     res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port);

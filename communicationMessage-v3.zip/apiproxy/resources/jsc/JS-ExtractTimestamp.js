 context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00


function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
function isEmpty(input) {
    return (!input || 0 === input.length);
}

/* Use a function for the exact format desired... */

function getISODate() {
    var d = new Date();
    var n = d.toISOString();
    return n;
}
function getRandomNumber()
{
  var val = Math.floor(100000 + Math.random() * 900000);
  return val;
}

context.setVariable("requestcontent",JSON.stringify(request.content));

context.setVariable("nbrequestcontent",JSON.stringify(request.content));
context.setVariable("NBRequestQryString",request.uri);
 
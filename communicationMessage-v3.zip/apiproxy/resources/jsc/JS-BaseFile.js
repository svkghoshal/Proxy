 // All Common Methods.

var referenceCode = getISODate().concat(getRandomNumber());
context.setVariable("referenceCode", referenceCode);
context.setVariable("isoTimestamp", ISODateString()); 

function isEmpty(input) {
    return (!input || 0 === input.length);
}

function transactionDateTime() {
    var now = new Date(),
                pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
         + pad(now.getMonth()+1)
         + pad(now.getDate())
         + pad(now.getHours())
         + pad(now.getMinutes()) 
         + pad(now.getSeconds());
}

function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
function isEmpty(data) {
     return (data === "" || data === "null" || data === "undefined" || 
            data === null || data === undefined || 0 === data.length);
}

/* Use a function for the exact format desired... */

function getISODate() {
    var d = new Date();
    var n = d.toISOString();
    return n;
}
function getRandomNumber()
{
  var val = Math.floor(100000 + Math.random() * 900000);
  return val;
} 
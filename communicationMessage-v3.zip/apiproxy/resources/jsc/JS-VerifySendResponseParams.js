  var nbrequestcontent =context.getVariable("requestcontent");
  print("nbrequestcontent::"+nbrequestcontent);
 var responsecontent=context.getVariable("response.content");
 
 var JSONObj= JSON.parse(nbrequestcontent);
 //response format
 //status=FAUILURE,transid=9545415011,reasoncode=201
 var respArray = responsecontent.split(",");
var firstElement  = respArray[0] ;
var secondElement  = respArray[1] ;
var thirdElement  = respArray[2] ;
print("firstElement="+firstElement ,":::secondElement="+secondElement+":::thirdElement" +thirdElement);

var statusCode=firstElement.split("=")[1];
var transactionId=secondElement.split("=")[1];
var responseCode=thirdElement.split("=")[1];
print("statusCode="+statusCode);
print("transactionId="+transactionId);
print("responseCode="+responseCode);

context.setVariable("statusCode",statusCode) ;
context.setVariable("transactionId",transactionId) ;
 var body = nbrequestcontent;
 JSONObj["status"] =statusCode;
  JSONObj["id"]=transactionId;
 JSONObj["sendTime"]=context.getVariable("isoTimestamp");
 context.setVariable("response.content",JSON.stringify(JSONObj));
 var apiNo=".030.";
 if(responseCode == "200")
 {
     
 }

 if ((responseCode == "201")||(responseCode == "202")||(responseCode == "203")||
    (responseCode == "204")||(responseCode == "205") ||(responseCode == "206") 
    ||(responseCode == "207") ||(responseCode == "208")||(responseCode == "212")||
    (responseCode == "213")||(responseCode == "214") ||(responseCode == "215")||
    (responseCode == "218")||(responseCode == "220"))
{
            context.setVariable("exceptionName", "exceptionName");
			context.setVariable("errorCode", "400"+apiNo +responseCode);
			context.setVariable("errorDesc", "Bad Request");
			context.setVariable("errorMessage", "Invalid Input");
			context.setVariable("httpError", "400");
			throw new Exception();
}
 else if((responseCode == "209"))
 {
            context.setVariable("exceptionName", "exceptionName");
			context.setVariable("errorCode", "403"+apiNo + responseCode);
			context.setVariable("errorDesc", "Forbidden");
			context.setVariable("errorMessage", "Access Denied");
			context.setVariable("httpError", "400");
			throw new Exception();
 }
  else if((responseCode == "211"))
 {
            context.setVariable("exceptionName", "exceptionName");
			context.setVariable("errorCode", "500"+apiNo + responseCode);
			context.setVariable("errorDesc", "Internal Server Error");
			context.setVariable("errorMessage", "System Error");
			context.setVariable("httpError", "500");
			throw new Exception();
 }
   else if((responseCode == "216"))
 {
            context.setVariable("exceptionName", "exceptionName");
			context.setVariable("errorCode", "503"+apiNo + responseCode);
			context.setVariable("errorDesc", "Service Unavailable");
			context.setVariable("errorMessage", "Service Unavailable");
			context.setVariable("httpError", "503");
			throw new Exception();
 }
    else if((responseCode == "217"))
 {
            context.setVariable("exceptionName", "exceptionName");
			context.setVariable("errorCode", "500"+apiNo + responseCode);
			context.setVariable("errorDesc", "Internal Server Error");
			context.setVariable("errorMessage", "System Busy, Please Try later");
			context.setVariable("httpError", "500");
			throw new Exception();
 }
  else if(responseCode !== "200")
 {
            context.setVariable("exceptionName", "exceptionName");
			context.setVariable("errorCode", "500"+apiNo + responseCode);
			context.setVariable("errorDesc", "Internal Server Error");
			context.setVariable("errorMessage", "Internal Server Please Try later:"+responseCode);
			context.setVariable("httpError", "500");
			throw new Exception();
 }

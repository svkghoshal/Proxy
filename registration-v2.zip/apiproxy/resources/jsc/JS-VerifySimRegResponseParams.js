var Status = context.getVariable("Status");
var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("faultString");
var faultMsg = context.getVariable("faultMessage");
var apiNo = context.getVariable('apiNo');

if (faultCode === null || (faultCode !== null && faultString !== null && faultString.toUpperCase().includes("NO DATA FOUND")))
	context.setVariable("Status", "Success");
else if (faultMsg.toUpperCase().includes("SOURCE CHANNEL IS BLANK")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Invalid Input.");
	context.setVariable("httpError", "400");
} else if (faultMsg.toUpperCase().includes("EXCEPTION OCCURRED AT AVAM")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Exception occurred at backend server.");
	context.setVariable("httpError", "500");
} else {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", faultMsg);
	context.setVariable("httpError", "500");
}

var reqVerb = context.getVariable('request.verb');
 var target;
if(reqVerb=='POST')
{
     target = '/Middleware/api/v1/ecaf-selfcare';
     context.setVariable('targetPath',target);
}
else if(reqVerb=='PUT')
{
      target = '/Middleware/api/v1/ecaf-upload-selfcare';
      context.setVariable('targetPath',target);   
}

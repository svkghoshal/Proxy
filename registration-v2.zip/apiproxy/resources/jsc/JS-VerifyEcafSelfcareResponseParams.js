var statusCode = context.getVariable("res.statusCode");
var message = context.getVariable("res.statusMessage");
var status_code= context.getVariable("response.status.code");
var requestVerb = context.getVariable('reqVerb');
var apiNo = context.getVariable('apiNo');


if(status_code =='200')
    context.setVariable("Status","Success");
else
{
   switch(statusCode) {
    
                case "FLECAF001":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".103");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage","CAF Acknowledgement failed");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FLECAF002":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".101");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "No data found");
                    context.setVariable("httpError", "500");
                    break;
                
                 case "FLECAF003":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "400."+apiNo+".101");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Invalid Input");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FLECAF004":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".102");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Exception occurred at backend server");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FLECAF005":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".102");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage","Exception occurred at backend server");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FLECAF006":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".102");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Exception occurred at backend server");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FLECAF007":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".101");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "No data found");
                    context.setVariable("httpError", "500");
                    break;
                    
                case "FLECAF008":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".104");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Subscriber has not been activated yet");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FLECAF009":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".105");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "CAF has been already acknowledged");
                    context.setVariable("httpError", "500");
                    break;

                case "FLECAF010":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".102");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Exception occurred at backend server");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FLECAF011":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".106");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Invalid status of CAF");
                    context.setVariable("httpError", "500");
                    break;

                case "FLECAF012":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".102");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Exception occurred at backend server");
                    context.setVariable("httpError", "500");
                    break;
                    
                case "FLECAF013":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".102");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Exception occurred at backend server");
                    context.setVariable("httpError", "500");
                    break;
                
                case "FLECAF014":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".106");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Invalid status of CAF");
                    context.setVariable("httpError", "500");
                    break;

                 case "FLECAF015":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".102");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Exception occurred at backend server");
                    context.setVariable("httpError", "500");
                    break;
                    
                 case "FLECAF016":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".102");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Exception occurred at backend server");
                    context.setVariable("httpError", "500");
                    break;
                    
                 case "FLECAF017":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".107");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Duplicate request");
                    context.setVariable("httpError", "500");
                    break;
                    
                 case "FLECAF018":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "400."+apiNo+".101");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Invalid Input");
                    context.setVariable("httpError", "500");
                    break;
                 
                  case "FL0009":
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".100");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "INTERNAL_ERROR");
                    context.setVariable("httpError", "500");
                    break;
                    
                default:
                    context.setVariable("exceptionName", "exceptionName");
            		context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500."+apiNo+".100");
            		context.setVariable("errorDesc", "Internal Server Error");
            		context.setVariable("errorMessage",  statusCode + "-"+ message);
            		context.setVariable("httpError", "500");
            		break;
                
            }  
}

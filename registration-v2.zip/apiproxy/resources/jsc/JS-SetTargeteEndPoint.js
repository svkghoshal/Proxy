var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var list = context.getVariable('req.list');
var offerType = context.getVariable('req.offerType');
var target;

if(list===null)
    list='';

if(reqVerb=='GET')
{
    target = '/cxf/subscriberECAFDetails';
    context.setVariable('targetPath',target);
}
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);

var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

//var transactionIdseq = parseInt(context.getVariable("transactionIdseq")) + 1;
//context.setVariable("req.transactionIdseq", transactionIdseq.toString());

/*if (reqVerb == "GET") 
    context.setVariable("apiNo","010");
else if (reqVerb == "POST")
    context.setVariable("apiNo","011");
else if (reqVerb == "PUT")
    context.setVariable("apiNo","012");*/
 var cafStatus = context.getVariable("cafStatus");
 
 if(cafStatus!==null)
    cafStatus = cafStatus.toUpperCase();
 
 switch(cafStatus){
     
    case "APPROVED":
        context.setVariable("cafStatus", "REGISTERED");
		break;
	
	case "IN-PROGRESS":
	case "CAF-RECEIVED-COMPLETED":
	case "CAF-SCANNED-COMPLETE":
	    context.setVariable("cafStatus", "INPROGRESS");
		break;
	
	case "PENDING":
	case "REJECTED":
	case "CAF-RECEIVED-INCOMPLETE":
	case "V_IN-PROGRESS":
	case "C_IN-PROGRESS":
	    context.setVariable("cafStatus", "UNREGISTERED");
		break;
	
    default:
	    context.setVariable("cafStatus", "UNREGISTERED");
		break;
 }
http = require('http');

server= http.createServer( function(req, res) {
    console.log ('Customer-Eligibility sandbox');
    
    var body="";
      res.writeHead(200, {'Content-Type': 'text/xml;charset=UTF-8'});
    res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port);
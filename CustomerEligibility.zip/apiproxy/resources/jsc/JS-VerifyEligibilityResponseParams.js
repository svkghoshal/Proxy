var id = context.getVariable("req.id");
context.setVariable("msisdn", id);
var respstatus = context.getVariable("resp.status");
var Category = context.getVariable("req.newMSISDN_Category");
var SubCategory = context.getVariable("req.newMSISDN_SubCategory");
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("targetElapsTime", getTargetElaspTime());
var StateID = context.getVariable("req.newMSISDN_StateID");
var faultString = context.getVariable("faultString");
var faultCode = context.getVariable("faultCode");

context.setVariable("href","/users/"+context.getVariable("msisdn")+"/eligibility");
var apiNo = "062";

if (Category !== null && SubCategory !== null){

        if(Category.toUpperCase().includes("POSTPAID") || SubCategory.toUpperCase().includes("POSTPAID")){
            context.setVariable("PREPAID_POSTPAID","POSTPAID");
        }else{
        context.setVariable("PREPAID_POSTPAID","PREPAID");
        }
}else{
context.setVariable("PREPAID_POSTPAID","PREPAID");
}
if(StateID=='6'){
    context.setVariable("ACTIVE_INACTIVE","ACTIVE");
}else{
context.setVariable("ACTIVE_INACTIVE","INACTIVE");
}
/*if(faultCode !== '' || faultString !== '')
{
            context.setVariable("exceptionName", "InternalServerError");
            context.setVariable("errorCode", "500."+apiNo+".100");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage",faultstring);
            context.setVariable("httpError", "500");
}*/
if(respstatus=='Success'){
    context.setVariable("respStatus", respstatus);
}else{
            context.setVariable("exceptionName", "InternalServerError");
            context.setVariable("errorCode", "500."+apiNo+".100");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage",faultstring);
            context.setVariable("httpError", "500");
}

function getISODate() {
    var d = new Date();
    var n = d.toISOString();
    return n;
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
function getRandomNumber()
{
  var val = Math.floor(100000 + Math.random() * 900000);
  return val;
}

function getTargetStartTime() {
    if (isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.sent.start.timestamp"));
    }
}

function getTargetEndTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.received.end.timestamp"));
    }
}

function getTargetElaspTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp")) || isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        var targetElapsTime = context.getVariable("target.received.end.timestamp") - context.getVariable("target.sent.start.timestamp");
        return "" + targetElapsTime;
    }
}
function isEmpty(input) {
    return (!input || 0 === input.length);
}

function getTimePattern(dateTime) {
    var today = new Date(dateTime);
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second + "," + milliSecond;
}

function checkLengthDateFormat(today) {
    if (today.length == 1) {
        today = "0" + today;
    }
    return today;
}
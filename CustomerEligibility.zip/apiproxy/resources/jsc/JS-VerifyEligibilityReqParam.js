var id = context.getVariable("req.id");
context.setVariable("msisdn",id);
var apiNo = "062";
var msisdnLength = id.length;
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);
var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
context.setVariable("transactionId", apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

context.setVariable("isoTimestamp", ISODateString());

if ((!id.startsWith("97")) || (msisdnLength != 10))  {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}


if (isEmpty(id)) {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}
function getISODate() {
    var d = new Date();
    var n = d.toISOString();
    return n;
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}

function padLeadingZeros(input) {
    var step;
    var output=input;
    for(step=input.length; step<6; step++)
        output="0"+output;
    return output;
}
function transactionDateTime() {
    var now = new Date(),
                pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
         + pad(now.getMonth()+1)
         + pad(now.getDate())
         + pad(now.getHours())
         + pad(now.getMinutes()) 
         + pad(now.getSeconds());
}

function isEmpty(input) {

    return (!input || 0 === input.length);

}


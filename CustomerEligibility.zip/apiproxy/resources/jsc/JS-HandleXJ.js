var fee = context.getVariable("response.content");
var Product_ID = context.getVariable("kvm.ProductID");
context.setVariable("Product_ID", Product_ID);

if(!fee)
    context.setVariable("response.content", "[]");
 else{
     /*var jsonResponse = String(fee).replace(/"~ARRAY~",/g, "");*/
     var jsonObject = JSON.parse(fee);
     /*context.setVariable("response.content",JSON.stringify(response.content));*/
    /* print(response.content);*/
     /*var resp= JSON.parse(jsonObject);*/
     var products = jsonObject.Envelope.Body.BarringStatusResponse.Product;
    
    var status_new =true;
	for(i = 0; i<products.length; i++){
		var productElement =products[i];
		var innerProduct = productElement.Product;
		if(innerProduct && Array.isArray(innerProduct)){
			for(j=0;j<innerProduct.length;j++){
				if(innerProduct[j].ProductID == Product_ID && innerProduct[j].Status === "Unbarred")
				{ 
				    status_new = false;
				    if(innerProduct[j].ProductID == Product_ID && innerProduct[j].Status === "Active")
				    {
				        status_new = false;
				    }
				    
				}
			}
		}else{
			if(productElement.ProductID == Product_ID && productElement.Status === "Unbarred")
			{
			    status_new = false;
				    if(productElement.ProductID == Product_ID && productElement.Status === "Active")
				    {
				        status_new = false;
				    }
			}
				
		}
	}
	context.setVariable("productStatus", status_new);
	/*print("Status :::: "+ status_new);*/

 }
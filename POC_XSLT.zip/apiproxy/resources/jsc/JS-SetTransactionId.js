var apiNo =112;
var url = context.getVariable("message.uri");
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);
context.setVariable("isoTimestamp", ISODateString());
var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

var messageId = context.getVariable("messageid");
context.setVariable("reqMessageID",messageId);

if (reqVerb == "GET")
{
    context.setVariable("apiNo","112");
}

if(!url.startsWith("/v5/mm/en/balanceManagement/balance"))
/*if(url !== '/v4/mm/en/balanceManagement/balance')*/
 {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "404."+apiNo+".001");
	context.setVariable("errorDesc", "Resource not found");
	context.setVariable("errorMessage", "Resource not found/Invalid resource");
	context.setVariable("httpError", "404");
	throw "serviceException";
 }
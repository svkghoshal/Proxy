var quota_allow = context.getVariable("app.quota_allow");
var quota_interval = context.getVariable("app.quota_interval");
var quota_unit = context.getVariable("app.quota_unit");
var app_name = context.getVariable("developer.app.name");

context.setVariable("quota_allow",quota_allow);
context.setVariable("quota_interval",quota_interval);
context.setVariable("quota_unit",quota_unit); 
context.setVariable("app_name",app_name); 

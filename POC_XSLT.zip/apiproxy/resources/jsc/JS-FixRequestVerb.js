var reqVerb = context.getVariable("reqVerb");
context.setVariable("request.verb","GET");
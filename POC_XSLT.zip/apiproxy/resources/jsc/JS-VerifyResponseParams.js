 var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("res.faultString");
var statusCode = context.getVariable("res.resultCode");
var AvailableCredit = context.getVariable("res.AvailableCredit");
context.setVariable("AvailableCredit",AvailableCredit);
var apiNo = context.getVariable('apiNo');

if(statusCode == "405000000")
    context.setVariable("Status","Success");
 else
    {
      if(faultString.toUpperCase().includes("THE ACCOUNT TYPE IS NOT FOUND"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".107");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The subscriber is not valid");
            context.setVariable("httpError", "500");
        }
    else
        {
                context.setVariable("exceptionName", "exceptionName");    
                context.setVariable("errorCode", "500."+apiNo+".100");
                context.setVariable("errorDesc", "Internal Server Error");
                context.setVariable("errorMessage", faultString);
                context.setVariable("httpError", "500");
        }
            
    } 
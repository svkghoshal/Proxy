 var backendresponseContent = context.getVariable("response.content");
print("backendresponseContent ::" + backendresponseContent);
context.setVariable("backendresponse.content", backendresponseContent); 
var content = context.getVariable("request.content");
if(!content) {
    context.setVariable("request.content", "[]");
} else {
    var jsonRequest = String(content).replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "");
    context.setVariable("request.content", jsonRequest);
}

// print("JSON Request ::" +context.getVariable("request.content"));
var proxypath = context.getVariable('proxy.pathsuffix');
var cfsurl;
var sms_sb_url;
 print("proxypath:"+proxypath);
if(proxypath.includes("/send") )
{
   
}
 sms_sb_url= context.getVariable('sms_sb_url');
     print("sms_sb_url:"+sms_sb_url);
  
  var UserName = context.getVariable('UserName');
  var Password = context.getVariable('Password');
  var FromAddr = context.getVariable('req.FromAddr');
  var DestNo = context.getVariable('req.DestNo');
  var content =context.getVariable('req.content');
  var SrcAddrTON = context.getVariable('req.SrcAddrTON');
  var SrcAddrNPI = context.getVariable('SrcAddrNPI');//From KVM
  var DestAddrTON = context.getVariable('req.DestAddrTON');
  var DestAddrNPI = context.getVariable('DestAddrNPI');//From KVM
  var type = context.getVariable('req.type');
  var Dcs='';
  var msgVar ="";
  var apiNo='032';
if(isEmpty(content) || content.trim()=== '')
 {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".001");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid content.");
	        throw "serviceException";
 }
 
  
 if (isEmpty(FromAddr))
 {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".002");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid sender name.");
	        throw "serviceException";
 }
 if(FromAddr.length > 9)
 {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".003");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid sender name.");
	        throw "serviceException";
 }
  
 if (isEmpty (DestNo))
 {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".004");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid phoneNumber.");
	        throw "serviceException";
 }
 
 if (!DestNo.startsWith("95"))  {
    
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".005");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid phoneNumber");
    throw "serviceException";
}
 
LetterNumber(FromAddr);
function LetterNumber(inputtext) {
var LetterExpression = /^[0-9A-Za-z]+$/;
if (!LetterExpression.test(inputtext))
{
    context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".005");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid sender name");
	        throw "serviceException";

}
}

 if (isEmpty (type))
 {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".006");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid type.");
	        throw "serviceException";
 }
 
  if (isEmpty (SrcAddrTON))
 {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".007");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid sender type.");
	        throw "serviceException";
 }
 
 
  if (isEmpty (DestAddrTON))
 {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".008");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid receiver type.");
	        throw "serviceException";
 }
 
 
// var chargeMsisdn = idValue;
// var chargeMsisdnLength = chargeMsisdn.length;
 
/* if( (chargeMsisdn.indexOf("e") >=0) )
{
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.15.001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "MSISDN not found");
    throw "serviceException"; 
}


if( (isNaN(chargeMsisdn) === true ) )
{
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.15.001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "MSISDN not found");
    throw "serviceException"; 
}


// 31-March-2017 : Validate MSISDN prefix Starts
// Get the MSISDN length
if(chargeMsisdnLength > 13){
    // MSISDN length cannot be more than 13
   context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.15.001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "MSISDN not found");
    throw "serviceException";
}
if(chargeMsisdnLength < 13){
    // MSISDN length cannot be less than 10
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.15.001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "MSISDN not found");
    throw "serviceException";
}

 
 if (isEmpty(chennelID))
 {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400.15.002");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "wrong channel, please contact system admin");
	        throw "serviceException";
 }
 */
 /* Field validations */
  if (type.toUpperCase() =='TEXT')
  {
      Dcs ='0';
      msgVar ="msg";
  }
  else if (type.toUpperCase() =='BINARY')
  {
      Dcs ='4'; 
      msgVar ="bin_msg";
  }
   else if (type.toUpperCase() =='MULTILINGUAL')
  {
      Dcs ='8'; 
      msgVar ="bin_msg";
     if( isEmpty(content) == 'false')
      {
      content='\\u'+content;
      }
  }
   else if (type.toUpperCase() =='FLASH')
  {
      Dcs ='240'; 
       msgVar ="msg";
  }/* else 
  {
      Dcs ='0';
       msgVar ="msg";
  }
  */
  var Udhi=context.getVariable("req.Udhi");
  if(Udhi === '' || (Udhi === null ))
  {
     Udhi='' ;
  }
  else
  {
      Udhi='&udhi='+Udhi ;
  }
  
  if ((type.toUpperCase() =='MULTILINGUAL') && Udhi === '')
  {
       Udhi='&udhi=1' ;//default
  }
  print("Udhi="+Udhi);
  
  
  
 var finaltargeturl=sms_sb_url +"?UserName="+UserName+"&Password="+Password+"&FromAddr="+FromAddr+"&DestNo="+DestNo+"&"+msgVar+"="+content+"&SrcAddrTON="+SrcAddrTON+"&SrcAddrNPI="+SrcAddrNPI+"&DestAddrTON="+DestAddrTON+"&DestAddrNPI="+DestAddrNPI+"&Dcs="+Dcs+Udhi;
print("finaltargeturl="+finaltargeturl);
 context.setVariable("target.url",finaltargeturl);
 
 print("content==::"+content)

 
 
 
 function isEmpty(input) {
    return (!input || 0 === input.length);
}

function transactionDateTime() {
    var now = new Date(),
                pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
         + pad(now.getMonth()+1)
         + pad(now.getDate())
         + pad(now.getHours())
         + pad(now.getMinutes()) 
         + pad(now.getSeconds());
}

function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
function isEmpty(input) {
    return (!input || 0 === input.length);
}

/* Use a function for the exact format desired... */

function getISODate() {
    var d = new Date();
    var n = d.toISOString();
    return n;
}
function getRandomNumber()
{
  var val = Math.floor(100000 + Math.random() * 900000);
  return val;
}

  var UserName = context.getVariable('UserName');
  var Password = context.getVariable('Password');
  var FromAddr = context.getVariable('req.FromAddr');
  var DestNo = context.getVariable('req.DestNo');
  var content =context.getVariable('req.content');
  var SrcAddrTON = context.getVariable('req.SrcAddrTON');
  var SrcAddrNPI = context.getVariable('SrcAddrNPI');//From KVM
  var DestAddrTON = context.getVariable('req.DestAddrTON');
  var DestAddrNPI = context.getVariable('DestAddrNPI');//From KVM
  var type = context.getVariable('req.type');
      
   
/* var pathArray = context.getVariable("message.uri").split("/");
context.setVariable( "firstPathElement", pathArray[1] );
context.setVariable( "secondPathElement", pathArray[2] );
context.setVariable( "thirdPathElement", pathArray[3] );
context.setVariable( "fourthPathElement", pathArray[4] );*/
 context.setVariable("isoTimestamp", ISODateString()); // Prints something like 2009-09-28T19:03:12+08:00

var referenceCode = getISODate().concat(getRandomNumber());
context.setVariable("referenceCode", referenceCode);

// Request URI is not valid
var proxypath = context.getVariable('proxy.pathsuffix');
print("proxypath ::" +proxypath); 
 var apiNo='030';
 
// if ((content === '') || (content === undefined) || (content.length === 0))

 
// var chargeMsisdn = idValue;
// var chargeMsisdnLength = chargeMsisdn.length;
 
/* if( (chargeMsisdn.indexOf("e") >=0) )
{
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.15.001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "MSISDN not found");
    throw "serviceException"; 
}


if( (isNaN(chargeMsisdn) === true ) )
{
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.15.001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "MSISDN not found");
    throw "serviceException"; 
}


// 31-March-2017 : Validate MSISDN prefix Starts
// Get the MSISDN length
if(chargeMsisdnLength > 13){
    // MSISDN length cannot be more than 13
   context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.15.001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "MSISDN not found");
    throw "serviceException";
}
if(chargeMsisdnLength < 13){
    // MSISDN length cannot be less than 10
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.15.001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "MSISDN not found");
    throw "serviceException";
}

 
 if (isEmpty(chennelID))
 {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400.15.002");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "wrong channel, please contact system admin");
	        throw "serviceException";
 }
 */
 

function isEmpty(input) {
    return (!input || 0 === input.length);
}

function transactionDateTime() {
    var now = new Date(),
                pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
         + pad(now.getMonth()+1)
         + pad(now.getDate())
         + pad(now.getHours())
         + pad(now.getMinutes()) 
         + pad(now.getSeconds());
}

function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
function isEmpty(input) {
    return (!input || 0 === input.length);
}

/* Use a function for the exact format desired... */

function getISODate() {
    var d = new Date();
    var n = d.toISOString();
    return n;
}
function getRandomNumber()
{
  var val = Math.floor(100000 + Math.random() * 900000);
  return val;
}

context.setVariable("requestcontent",request.content);

context.setVariable("nbrequestcontent",JSON.stringify(request.content));
context.setVariable("NBRequestQryString",request.uri);
 
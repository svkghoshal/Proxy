var http = require('http');
var apigee = require('apigee-access');

server = http.createServer( function(req, res) {
    console.log ('balanceTransfer sandbox');
    console.log ('Request ::: '+JSON.stringify(req.Body));
    var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
                
    res.writeHead(200, {'Content-Type': 'application/xml'});
    var body = '<soapenv:Envelope xmlns:soapenv="https://clicktime.symantec.com/3SuEDnMc5S16pYWGCAJ6gFw7Vc?u=http%3A%2F%2Fschemas.xmlsoap.org%2Fsoap%2Fenvelope%2F%2522%253E"> <soapenv:Body> <tran:TransferAccountResultMsg xmlns:tran="https://clicktime.symantec.com/32r1QcCPQuw1KbsomGzg62b7Vc?u=http%3A%2F%2Fwww.huawei.com%2Fbme%2Fcbsinterface%2Ftransferaccountmgr%26quot;" xmlns:com="https://clicktime.symantec.com/34y6tr1wr5JmEvsqQqv1N8R7Vc?u=http%3A%2F%2Fwww.huawei.com%2Fbme%2Fcbsinterface%2Fcommon%26quot;" xmlns:tran1="https://clicktime.symantec.com/3Vs6PEBrKsd9SN2BAUpQg9m7Vc?u=http%3A%2F%2Fwww.huawei.com%2Fbme%2Fcbsinterface%2Ftransferaccount%2522%253E"> <ResultHeader> <com:CommandId>TransferAccount</com:CommandId> <com:Version>1</com:Version> <com:TransactionId>1</com:TransactionId> <com:SequenceId>1</com:SequenceId> <com:ResultCode>405000000</com:ResultCode> <com:ResultDesc>Operation is successful.</com:ResultDesc> <com:OrderId>1302080000002307216</com:OrderId> <com:OperationTime>20190822155400</com:OperationTime> </ResultHeader> <TransferAccountResult> <tran1:TransfereeHandlingCharge>0</tran1:TransfereeHandlingCharge> <tran1:TransferorHandlingCharge>4762</tran1:TransferorHandlingCharge> <tran1:TransfereeAcctChgList> <tran1:AcctChgRec> <com:CurrAcctBal>97637108814</com:CurrAcctBal> <com:ChgAcctBal>400</com:ChgAcctBal> <com:CurrExpTime>20370101000000</com:CurrExpTime> <com:ChgExpTime>0</com:ChgExpTime> <com:AccountType>5145</com:AccountType> <com:BalanceId>1020000127959</com:BalanceId> <com:MinMeasureId>2</com:MinMeasureId> <com:AccountTypeDescription>Data Suboo Balance</com:AccountTypeDescription> <com:ApplyTime>20181018170608</com:ApplyTime> </tran1:AcctChgRec> </tran1:TransfereeAcctChgList> <tran1:TransferorAcctChgList> <tran1:AcctChgRec> <com:CurrAcctBal>284002</com:CurrAcctBal> <com:ChgAcctBal>-5000</com:ChgAcctBal> <com:CurrExpTime>20370101000000</com:CurrExpTime> <com:ChgExpTime>0</com:ChgExpTime> <com:AccountType>2000</com:AccountType> <com:BalanceId>999000000000232228</com:BalanceId> <com:MinMeasureId>101</com:MinMeasureId> <com:AccountTypeDescription>Main Balance</com:AccountTypeDescription> <com:ApplyTime>20190614102425</com:ApplyTime> </tran1:AcctChgRec> <tran1:AcctChgRec> <com:CurrAcctBal>17395875440</com:CurrAcctBal> <com:ChgAcctBal>-400</com:ChgAcctBal> <com:CurrExpTime>20370101000000</com:CurrExpTime> <com:ChgExpTime>0</com:ChgExpTime> <com:AccountType>5145</com:AccountType> <com:BalanceId>1020000204063</com:BalanceId> <com:MinMeasureId>2</com:MinMeasureId> <com:AccountTypeDescription>Data Suboo Balance</com:AccountTypeDescription> <com:ApplyTime>20190806000000</com:ApplyTime> </tran1:AcctChgRec> </tran1:TransferorAcctChgList> <tran1:LoanAmount>0</tran1:LoanAmount> <tran1:LoanPoundage>0</tran1:LoanPoundage> <tran1:TransfereeOldActiveStop>20290819</tran1:TransfereeOldActiveStop> <tran1:TransfereeNewActiveStop>20290819</tran1:TransfereeNewActiveStop> <tran1:TransferorOldActiveStop>20240821</tran1:TransferorOldActiveStop> <tran1:TransferorNewActiveStop>20240821</tran1:TransferorNewActiveStop> </TransferAccountResult> </tran:TransferAccountResultMsg> </soapenv:Body> </soapenv:Envelope>';
    res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port); 
 


var Type = context.getVariable("req.type");

if(Type == "DATA")
{
    context.setVariable("acctType", "5145");
}
else{

    var accountType = context.getVariable("req.accountType");
    
    if (accountType == "POSTPAID")
    {
    context.setVariable("acctType", "3000");
    }
    else{
    context.setVariable("acctType", "2000");
    }
}

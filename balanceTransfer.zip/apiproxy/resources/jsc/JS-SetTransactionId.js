var apiNo =101;
var url = context.getVariable("message.uri");
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);
context.setVariable("isoTimestamp", ISODateString());
var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

var messageId = context.getVariable("messageid");
context.setVariable("reqMessageID",messageId);

if (reqVerb == "POST")
{
    context.setVariable("apiNo","111");
}
else
{
    context.setVariable("apiNo","111");
}

if(url != "/v1/mm/en/users/balanceManagement/balanceTransfer")
 {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "404."+apiNo+".001");
	context.setVariable("errorDesc", "Resource not found");
	context.setVariable("errorMessage", "Resource not found/Invalid resource");
	context.setVariable("httpError", "404");
	throw "serviceException";
 }
 function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
var reqVerb = context.getVariable('request.verb');
var path = context.getVariable('message.path');
var uri = context.getVariable('clientUriRequest').split("?");

/********************REQUEST DATA EXTRACT****************/

var path_variable_Array = [];

if(!isEmpty(path)) {
    path_variable_Array = path.split("/");
    
}

var language = path_variable_Array[3];
var subscriberMsisdn = path_variable_Array[5];
var category = context.getVariable('message.queryparam.category.name');
var productOffering = context.getVariable('message.queryparam.productOffering.name');

var perPage = context.getVariable('message.queryparam.per_page');
var page = context.getVariable("req.page");


if(uri[1].includes('%'))
{   
    if(alpha(productOffering))
    {
      context.setVariable("productOffering", productOffering.toString().replace(/\s/g, '+'));
    }else{
      context.setVariable("productOffering", encodeURIComponent(productOffering));
    }
}
else{
    print("3");
    context.setVariable("productOffering", productOffering); 
}


if(isEmpty(page))
{
   context.setVariable("req.page", "1"); 
   
}if(isEmpty(perPage))
{
    context.setVariable("perPage", "10"); 
}else{
    context.setVariable("perPage", perPage); 
}



/********************REQUEST DATA EXTRACT****************/

/********************KVM DATA EXTRACT****************/
var languageEn = context.getVariable("kvm.en");

var languageMm = context.getVariable("kvm.mm");

/********************KVM DATA EXTRACT****************/

/********************GENERATE TRANSACTION IDT****************/

var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
var apiNo = context.getVariable('apiNo');
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionDateTime",transactionDateTime());
context.setVariable("transactionId",apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

/********************GENERATE TRANSACTION IDT****************/


if (reqVerb == "GET")
{
    if (isEmpty(language)|| isEmpty(subscriberMsisdn)
     || (!subscriberMsisdn.startsWith("97") || ((subscriberMsisdn.length != 10))))
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (!isEmpty(category))
     {
         if(checkData(category) != '1')
         {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("httpError", "400");
            context.setVariable("errorCode", "400."+apiNo+".102");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid Input.");
            throw "serviceException";
         }else{
             
            context.setVariable("msisdn", subscriberMsisdn);
            context.setVariable("category", category);
            if(language.toUpperCase().includes("EN"))
            {
                context.setVariable("language", languageEn);
                
            }if(language.toUpperCase().includes("MM"))
            {
                context.setVariable("language", languageMm);
                
            }
         }
         
     }else if (checklang(language) != '1')
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".103");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else{
        
        context.setVariable("msisdn", subscriberMsisdn);
        context.setVariable("category", category);
        if(language.toUpperCase().includes("EN"))
        {
            context.setVariable("language", languageEn);
            
        }if(language.toUpperCase().includes("MM"))
        {
            context.setVariable("language", languageMm);
            
        }
     }
}else{
    
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input.");
    throw "serviceException";
}
var payload = context.getVariable("TransformDataJson");
var jsonObject = JSON.parse(payload);
var jsonObjecttr = JSON.stringify(jsonObject.Result);
if(!isEmpty(jsonObjecttr))
{
    if (jsonObjecttr == "{}"){
    context.setVariable("TransformDataJson",'{ "productOffering": [] }');   
    }else{
    /*var jsonResponse = jsonObjecttr.replace(/"~string~",/g, "").replace(/"~string~"/g, "").replace(/"~Array~",/g, "");*/
    var jsonResponse = jsonObjecttr.replace(/"~Array~",/g, "").replace(/~STR~/g, "");
    var vpayload = jsonResponse.replace(/null/g, '');
    
    context.setVariable("TransformDataJson",vpayload);
    }
}
else
{
    context.setVariable("TransformDataJson",'{ "productOffering": [] }');   
}

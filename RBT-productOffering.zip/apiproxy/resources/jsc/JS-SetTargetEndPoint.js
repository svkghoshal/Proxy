var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var category = context.getVariable('message.queryparam.category.name');

if(isEmpty(category))
{
   category = ''; 
}



if (category.toUpperCase().includes("TOPTEN")
    || category.toUpperCase().includes("RECOMMENDATIONS")
    || category.toUpperCase().includes("TOPARTISTS") )
{
   
    var target = '/crbt/tones';
    var action = 'tones';
    
}else if(category.toUpperCase().includes("MYANMAR") 
    || category.toUpperCase().includes("ENGLISH") 
    || category.toUpperCase().includes("THAI")
    || category.toUpperCase().includes("TONES"))
{
   
    var target = '/crbt/search-tones';
    if(category.toUpperCase().includes("TONES"))
    {
        var action = 'search-tones-two';
    }else{
        var action = 'search-tones-one';
    }
    
}else{
   
    var target = '/crbt/cdp-specific-language-search';
    var action = 'search-tones-two';
}

context.setVariable('targetPath',target);
context.setVariable('action',action);


   
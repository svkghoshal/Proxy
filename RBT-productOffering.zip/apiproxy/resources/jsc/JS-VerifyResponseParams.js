var faultString = context.getVariable("res.faultString");
var httpStatusCode = context.getVariable("message.status.code");
var reqVerb = context.getVariable('request.verb');
var message = context.getVariable("res.message");
var statusCode = context.getVariable("res.statusCode");
var apiNo = context.getVariable('apiNo');

if (reqVerb == "GET")
{
    if(statusCode == "SC0000" && httpStatusCode == 200)
        context.setVariable("Status","Success");
     else
        {
          if(statusCode.toUpperCase().includes("FL0009"))
            {
               context.setVariable("SpecialResponse", '{ "productOffering": [] }');
	           context.setVariable("SpecialError", "1");
            } 
        else{
              context.setVariable("exceptionName", "exceptionName");    
              context.setVariable("errorCode", "500."+apiNo+".100");
              context.setVariable("errorDesc", "Internal Server Error");
              context.setVariable("errorMessage", faultString);
              context.setVariable("httpError", "500");
            }
                
        }
}
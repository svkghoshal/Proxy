key = "432jfe92390ndj23i";
context.setVariable("private.secretkey", key);
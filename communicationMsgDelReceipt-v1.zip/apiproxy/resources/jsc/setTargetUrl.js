var queryStr =  context.getVariable("request.querystring");
var callabckurl = context.getVariable("req.callbackurl"); 

context.setVariable("target.url", callabckurl);

var statusCode= context.getVariable("message.status.code").toString();
var ErrorMessage= context.getVariable("backendResponseContent");
var targetURL = context.getVariable("target.url");
var callbackurl = context.getVariable("req.callbackurl");
print(ErrorMessage+statusCode);

var apino = "101";

if (statusCode == '400')
 {
            context.setVariable("statusCode", "Failure");
            context.setVariable("exceptionName", "exceptionName");    
            context.setVariable("errorCode", "400."+apino+".101");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid Input");
            context.setVariable("httpError", "400");
            throw "serviceException";
 }
 if (statusCode == '404') 
{
    context.setVariable("exceptionName", "exceptionName");    
    context.setVariable("errorCode", "404."+apino+".001");
    context.setVariable("errorDesc", "Not Found");
    context.setVariable("errorMessage", "Resource not found/Invalid resource");
    context.setVariable("httpError", "404");
    throw "serviceException";
}
if (statusCode == '500') 
{
    context.setVariable("exceptionName", "exceptionName");    
    context.setVariable("errorCode", "500."+apino+".100");
    context.setVariable("errorDesc", "Internal Server Error");
    context.setVariable("errorMessage", "Internal Server Error:"+ErrorMessage);
    context.setVariable("httpError", "500");
    throw "serviceException";
}
if (statusCode == '403' ) 
{
    context.setVariable("exceptionName", "exceptionName");    
    context.setVariable("errorCode", "403."+apino+".101");
    context.setVariable("errorDesc", "Forbidden");
    context.setVariable("errorMessage", ErrorMessage);
    context.setVariable("httpError", "403");
    throw "serviceException";
}
if (statusCode == '502') 
{
    context.setVariable("exceptionName", "exceptionName");    
    context.setVariable("errorCode", "502."+apino+".101");
    context.setVariable("errorDesc", "Bad Gateway");
    context.setVariable("errorMessage", ErrorMessage);
    context.setVariable("httpError", "502");
    throw "serviceException";
}
if (statusCode == '503') 
{
    context.setVariable("exceptionName", "exceptionName");    
    context.setVariable("errorCode", "503."+apino+".101");
    context.setVariable("errorDesc", "Service Unavailable");
    context.setVariable("errorMessage", ErrorMessage);
    context.setVariable("httpError", "503");
    throw "serviceException";
}
if (statusCode == '504') 
{
    context.setVariable("exceptionName", "exceptionName");    
    context.setVariable("errorCode", "504."+apino+".101");
    context.setVariable("errorDesc", "Gateway Timeout");
    context.setVariable("errorMessage", ErrorMessage);
    context.setVariable("httpError", "504");
    throw "serviceException";
}
if (statusCode == '200' || statusCode == '201' ) 
{
     context.setVariable("statusCode", "Success");
}
function isEmpty(input) {
    return (!input || 0 === input.length);
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}

function padLeadingZeros(input) {
    var step;
    var output=input;
    for(step=input.length; step<6; step++)
        output="0"+output;
    return output;
}
function transactionDateTime() {
    var now = new Date(),
                pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
         + pad(now.getMonth()+1)
         + pad(now.getDate())
         + pad(now.getHours())
         + pad(now.getMinutes()) 
         + pad(now.getSeconds());
}

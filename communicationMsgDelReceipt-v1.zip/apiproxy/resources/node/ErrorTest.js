var http = require('http');
var apigee = require('apigee-access');

server = http.createServer( function(req, res) {
    console.log ('communicationMessageNotify-v1 sandbox');
    console.log ('Request ::: '+JSON.stringify(req.Body));
    var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
                
    res.writeHead(201, {'Content-Type': 'text/html'});
    var body ='status=OK';
    //var body ='Gateway Timeout';
    res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port);

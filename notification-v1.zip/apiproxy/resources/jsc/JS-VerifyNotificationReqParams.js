var msisdn = context.getVariable("req.msisdn");
var callbackURL = context.getVariable("req.callbackURL");
//var transactionId = context.getVariable("req.transactionId");
/*var productCode = context.getVariable("req.productCode");
var lifeCycle = context.getVariable("req.lifeCycle");
var chargingType = context.getVariable("req.chargingType");
var processedTime = context.getVariable("req.processedTime");
var clientTransactionId = context.getVariable("req.clientTransactionId");
var billingId = context.getVariable("req.billingId");*/
var queryStr =  context.getVariable("request.querystring");
var transactionIdseq = "1".toString();/*(context.getVariable("req.transactionIdseq")).toString();*/

/*context.setVariable("currentDate", currentDate());

context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionDateTime", transactionDateTime());
context.setVariable("transactionId", transactionDateTime() + padLeadingZeros(transactionIdseq));*/

if (isEmpty(callbackURL)) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("httpError", "400");
	context.setVariable("errorCode", "400.025.101");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Missing input parameters");
	throw "serviceException";
}
//var tempTargetURL = callbackURL.slice(18);
//print(tempTargetURL);
//print(tempTargetURL.substring(7));

//var targetURL=  callbackURL.slice(callbackURL.indexOf('://') + 3);
//print(targetURL);
/*if(!(callbackURL.includes("http://") || callbackURL.includes("https://"))){
    print("http check:::" + callbackURL);
    callbackURL = "https://" + callbackURL;
    
}*/

if((callbackURL.includes("http://")) && (callbackURL.includes("http://wapshop.gameloft.com"))){
    print("http check:::" + callbackURL);
    tempurl = callbackURL.substring(7);
    print("http check:::" + tempurl);
    var callbackURL1 = tempurl;
    callbackURL = "https://" + callbackURL1;
    print("http check:::" + callbackURL);
    
}

/*if((callbackURL.includes("http://"))){
    print("http check:::" + callbackURL);
    tempurl = callbackURL.substring(7);
    print("http check:::" + tempurl);
    var callbackURL1 = tempurl;
    callbackURL = "https://" + callbackURL1;
    print("http check:::" + callbackURL);
    
}*/


/*if(!callbackURL.endsWith("/"))
callbackURL = callbackURL + "/";*/

context.setVariable("target.url", callbackURL + "?" + queryStr);
/*context.setVariable("targetURL", decodeURI(callbackURL + "?" + queryStr));*/

function isEmpty(input) {
	return (!input || 0 === input.length);
}

/*
function currentDate() {
	var now = new Date(),
	pad = function (num) {
		var norm = Math.abs(Math.floor(num));
		return (norm < 10 ? '0' : '') + norm;
	};
	return now.getFullYear()
	 + "-" + pad(now.getMonth() + 1)
	 + "-" + pad(now.getDate())
}



function transactionDateTime() {
	var now = new Date(),
	pad = function (num) {
		var norm = Math.abs(Math.floor(num));
		return (norm < 10 ? '0' : '') + norm;
	};
	return now.getFullYear()
	 + pad(now.getMonth() + 1)
	 + pad(now.getDate())
	 + pad(now.getHours())
	 + pad(now.getMinutes())
	 + pad(now.getSeconds());
}

function ISODateString() {
	var now = new Date(),
	tzo = -now.getTimezoneOffset(),
	dif = tzo >= 0 ? '+' : '-',
	pad = function (num) {
		var norm = Math.abs(Math.floor(num));
		return (norm < 10 ? '0' : '') + norm;
	};
	return now.getFullYear()
	 + '-' + pad(now.getMonth() + 1)
	 + '-' + pad(now.getDate())
	 + 'T' + pad(now.getHours())
	 + ':' + pad(now.getMinutes())
	 + ':' + pad(now.getSeconds())
	 + dif + pad(tzo / 60)
	 + ':' + pad(tzo % 60);
}

function padLeadingZeros(input) {
	var step;
	var output = input;
	for (step = input.length; step < 6; step++)
		output = "0" + output;
	return output;
}
*/
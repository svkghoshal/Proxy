var statusCode= context.getVariable("response.status.code");
var targetURL = context.getVariable("target.url");
context.setVariable("statusCode",statusCode);
if (statusCode == '200') 
{
    if(targetURL.includes("apigw.mytelenor.com.mm")){
        context.setVariable("exceptionName", "exceptionName");    
        context.setVariable("errorCode", "500.025.100");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Failure");
        context.setVariable("httpError", "500");
    }
    else {
        context.setVariable("statusCode", "Success");
    }
}
else {
    context.setVariable("exceptionName", "exceptionName");    
    context.setVariable("errorCode", "500.025.100");
    context.setVariable("errorDesc", "Internal Server Error");
    context.setVariable("errorMessage", "Failure");
    context.setVariable("httpError", "500");
}


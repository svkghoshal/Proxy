 http = require('http');
 var apigee = require('apigee-access');

server= http.createServer( function(req, res) 
{
//console.log ('user'+req);
//console.log ('Request ::: '+JSON.stringify(req.Body));
var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
console.log('proxypath : '+proxypath);
//var reqVerb = apigee.getVariable(req,'request.verb');
var statusCode = apigee.getVariable(res, 'response.status.code');
console.log('statusCode : '+statusCode);
//console.log('requestVerb : '+reqVerb);
var bodySuccess ="{\"status\": \"Success\"}";

var bodyFailure ="{\"status\": \"Failure\"}";

res.writeHead(200, {'Content-Type': 'application/json'});
res.end(bodySuccess);

});


port = 3000;

host = '127.0.0.1';

server.listen(port, host);

console.log ('Listening at http://' + host + ':' + port); 
var sourceId = context.getVariable("req.sourceId");
var idType = context.getVariable("req.idType");
var idValue = context.getVariable("req.idValue");
var UserAgent = context.getVariable("req.UserAgent");
var detailsFlag = context.getVariable("req.detailsFlag");

var transactionIdSeq = randomString(6);
context.setVariable("transactionIdSeq", transactionIdSeq);
context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);

/**********************************************************************/

if (isEmpty(sourceId)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.006.008");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingSourceID";
}

if (isEmpty(idType) || isEmpty(idValue)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.006.008");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: ID Type or ID Value");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingIDTypeIDValue";
}

/**********************************************************************/

var sourceIdlength = sourceId.length;
if (sourceIdlength > 8) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.006.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidSourceID";
}

switch (idType) {
    case "MSISDN":
        var msisdnLength = idValue.length;
        var revisedMsisdn = "";
        if (idValue.startsWith("6") && ((msisdnLength == 11) || (msisdnLength == 12))) {
            revisedMsisdn = idValue.substring(1);
            context.setVariable("msisdn", idValue);
            context.setVariable("revisedMsisdn", revisedMsisdn);
        } else {
            context.setVariable("exceptionName", "Bad Request");
            context.setVariable("httpError", "400");
            context.setVariable("errorCode", "400.006.009");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid input parameter: ID Value (Invalid MSISDN format)");
            context.setVariable("logType", "TECHNICAL");
            throw "InvalidMSISDN";
        }
        break;
    case "ACCOUNT_CODE":
        var accountCodeLength = idValue.length;
        if (accountCodeLength > 24) {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("httpError", "400");
            context.setVariable("errorCode", "400.006.009");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid input parameter: ID Value (Invalid Account Code)");
            context.setVariable("logType", "TECHNICAL");
            throw "InvalidAccountCode";
        }
        break;
    default:
        context.setVariable("exceptionName", "Bad Request");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.006.009");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid input parameter: ID Type");
        context.setVariable("logType", "TECHNICAL");
        throw "InvalidIDType";
}

// "details" flag, default=0
// Acceptable values=0,1
if (!detailsFlag && detailsFlag !== 0) {
    // If "more" flag is not passed in, default to 0
    context.setVariable("detailsFlag", "0");
} else {
    // Convert to string
    detailsFlag = "" + detailsFlag;
    
    switch (detailsFlag) {
        case "0":
        case "1":
           context.setVariable("detailsFlag", detailsFlag);
           break;
        default:
            // Invalid values
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("httpError", "400");
            context.setVariable("errorCode", "400.006.009");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid input parameter: Details");
            context.setVariable("logType", "TECHNICAL");
            throw "InvalidDetailsFlag";
    }
}

var status_code = context.getVariable("statusCode");
var error_code = context.getVariable("error_code");
var error_desc = context.getVariable("error_desc");
var error_more = context.getVariable("error_more");

// Convert amount values to cent
var NewBalance = context.getVariable("NewBalance");
var VoucherFaceValue = context.getVariable("VoucherFaceValue");
var NewBalanceCent = NewBalance * 100;
var VoucherFaceValueCent = VoucherFaceValue * 100;
// For some reason, toString is required to remove decimal
context.setVariable("NewBalanceCent", NewBalanceCent.toString());
context.setVariable("VoucherFaceValueCent", VoucherFaceValueCent.toString());

/**********************************************************************/

if (status_code != "Successful") {
    switch (error_code) {
        case "BRM:20010":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.011");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Subscriber not found (BRM:20010)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "CRM:60011":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.009");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid input parameter: Source ID (CRM:60011)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
        case "BRM:20052":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.017");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "The reload PIN is already used (BRM:20052)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "BRM:20060":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.018");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "The reload PIN is invalid or reload PIN does not exist (BRM:20060)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "BRM:20072":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.019");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Incorrect length of the reload PIN number (BRM:20072)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "BRM:20055":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.020");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "The subscriber is blacklisted because the number of reload attempts exceeds the maximum (BRM:20055)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "BRM:20075":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.021");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Incorrect account type (BRM:20075)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        // chungss-20180209_start
        case "BRM:20057":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.050");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "The reload PIN has expired (BRM:20057)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "BRM:20182":
        case "102011534":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.051");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Simultaneous actions detected ("+error_code+")");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        // chungss-20180209_end
        // chungss-20180222_start
        case "BRM:20051":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.052");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "The reload PIN is locked (BRM:20051)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "BRM:20073":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.053");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "The reload card type is not supported (BRM:20073)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        // chungss-20180222_end
        default:
            if (!isEmpty(error_more)) {
                var error_default = error_desc.trim()+" (MoreInfo: "+error_more.trim()+") ("+error_code+")";
            } else {
                var error_default = error_desc.trim()+" ("+error_code+")";
            }
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.006.010");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Internal Server Error: "+error_default);
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
    }
} else {
    context.setVariable("logType", "OK");
}

/**********************************************************************/

// Trishit
// Target Elapse Time
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());

// Target Elapsed Time
context.setVariable("targetElapsedTime", getTargetElaspedTime());

var pathSuffix = context.getVariable("proxy.pathsuffix");
var requestVerb = "";

// Set the timestamp after receiving response from target
context.setVariable("isoTimestamp", ISODateString());

switch (pathSuffix) {
    case "/profile":
    case "/device":
    case "/operator":
    case "/info":
    case "/routingNumber":
        requestVerb = "GET";
        context.setVariable("requestVerb", requestVerb);
        break;
    case "/reload":
        requestVerb = "POST";
        context.setVariable("requestVerb", requestVerb);
        break;
    default:
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "404");
    	context.setVariable("errorCode", "404.006.001");
        context.setVariable("errorDesc", "Resource Not Found");
        context.setVariable("errorMessage", "Resource not found/Invalid resource");
        context.setVariable("logType", "TECHNICAL");
        throw "VerbNotSet";
}

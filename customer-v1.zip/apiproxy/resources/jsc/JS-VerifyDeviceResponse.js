var status_code = context.getVariable("statusCode");
var error_code = context.getVariable("error_code");
var error_desc = context.getVariable("error_desc");
var error_more = context.getVariable("error_more");

// chungss-20180221_start
// Eligibility check
var eligibilityFlag = context.getVariable("eligibilityFlag");

// Retrieve values from Developer App (Custom Attributes)
var cusAttrEligiblePayType = context.getVariable("app.EligibleCheck_PayType");
var cusAttrEligibleCustomerType = context.getVariable("app.EligibleCheck_CustomerType");
var cusAttrEligibleStatus = context.getVariable("app.EligibleCheck_Status");
var cusAttrEligibleTenure = context.getVariable("app.EligibleCheck_Tenure");

// Retrieve values from backend (CRM)
var crmPayType = context.getVariable("payType");
var crmCustomerType = context.getVariable("subscriberType");
var crmStatus = context.getVariable("subscriberStatus");
var crmTenure = context.getVariable("tenure");
// chungss-20180221_end

/**********************************************************************/

// Trishit
// Target Elapse Time
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());

// Target Elapsed Time
context.setVariable("targetElapsedTime", getTargetElaspedTime());

/**********************************************************************/

if (status_code != "Successful") {
    switch (error_code) {
        case "CRM:00005":
        case "CRM:00009":
        case "CRM:60010":
        case "SMO:20025":
        case "SMO:60006":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.011");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Subscriber not found ("+error_code+")");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "CRM:60011":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.009");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid input parameter: Source ID (CRM:60011)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
        default:
            if (!isEmpty(error_more)) {
                var error_default = error_desc.trim()+" (MoreInfo: "+error_more.trim()+") ("+error_code+")";
            } else {
                var error_default = error_desc.trim()+" ("+error_code+")";
            }
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.006.010");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Internal Server Error: "+error_default);
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
    }
} else {
    context.setVariable("logType", "OK");
}

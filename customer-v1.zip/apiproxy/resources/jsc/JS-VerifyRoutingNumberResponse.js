var routingNumber= context.getVariable("RN");
var referenceId = context.getVariable("transactionId");
context.setVariable("ReferenceId", referenceId);

/**********************************************************************/

switch (routingNumber) {
    case "9997":
        var status_code = "Fail";
        context.setVariable("statusCode", status_code);
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "400.006.015");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "MSISDN and prefix error (9997)");
        context.setVariable("httpError", "400");
        context.setVariable("logType", "BUSINESS");
        break;
    case "9998":
        var status_code = "Fail";
        context.setVariable("statusCode", status_code);
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "400.006.011");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Subscriber not found (9998)");
        context.setVariable("httpError", "400");
        context.setVariable("logType", "BUSINESS");
        break;
    case "9999":
        var status_code = "Fail";
        context.setVariable("statusCode", status_code);
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "400.006.016");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Unknown/Default return value (9999)");
        context.setVariable("httpError", "400");
        context.setVariable("logType", "BUSINESS");
        break;
    default:
        var status_code = "Successful";
        context.setVariable("statusCode", status_code);
        context.setVariable("logType", "OK");
}

/**********************************************************************/

// Trishit
// Target Elapse Time
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());

// Target Elapsed Time
context.setVariable("targetElapsedTime", getTargetElaspedTime());

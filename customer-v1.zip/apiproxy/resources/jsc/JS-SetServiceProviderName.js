var RN = context.getVariable("RN");
var routingNumber = RN.substring(0,3);
var serviceProvider;

switch (routingNumber) {
    case "202":
        serviceProvider = "Maxis";
        break;
    case "203":
        serviceProvider = "YTL";
        break;
    case "204":
        serviceProvider = "P1";
        break;
    case "205":
        serviceProvider = "Altel";
        break;
    case "206":
        serviceProvider = "Digi";
        break;
    case "208":
        serviceProvider = "U Mobile";
        break;
    case "209":
        serviceProvider = "Celcom";
        break;
    case "302":
        serviceProvider = "PavaCom";
        break;
    case "303":
        serviceProvider = "MyEvo";
        break;
    case "304":
        serviceProvider = "Talk Focus";
        break;
    case "305":
        serviceProvider = "ASN";
        break;
    default:
        serviceProvider = "Others";
        
}
context.setVariable("serviceProviderName", serviceProvider);

var response = context.getVariable("backendResponseContent");
context.setVariable("revisedResponse", response);

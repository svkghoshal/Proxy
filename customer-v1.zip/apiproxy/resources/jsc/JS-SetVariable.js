var sourceId = context.getVariable("message.queryparam.sourceId");
context.setVariable("req.sourceId", sourceId);

var idType = context.getVariable("message.queryparam.idType");
context.setVariable("req.idType", idType);

var idValue = context.getVariable("message.queryparam.idValue");
context.setVariable("req.idValue", idValue);

// chungss-20171220
// Add "more" flag to /profile
var moreFlag = context.getVariable("message.queryparam.more");
context.setVariable("req.moreFlag", moreFlag);

// chungss-20180221
// Add "eligibility" flag to /profile
var eligibilityFlag = context.getVariable("message.queryparam.eligibility");
context.setVariable("req.eligibilityFlag", eligibilityFlag);

// "details" flag (hidden, not documented)
var moreFlag = context.getVariable("message.queryparam.details");
context.setVariable("req.detailsFlag", moreFlag);

// Fix issue with CSG2.0 require Header User-Agent to be populated
var UserAgent = context.getVariable("message.header.User-Agent");
context.setVariable("UserAgent", (isEmpty(UserAgent)) ? "APIGW" : UserAgent);

var status_code = context.getVariable("statusCode");
var error_code = context.getVariable("error_code");
var error_desc = context.getVariable("error_desc");
var error_more = context.getVariable("error_more");
var idType = context.getVariable("req.idType");

// chungss-20180221_start
// Eligibility check
var eligibilityFlag = context.getVariable("eligibilityFlag");

// Retrieve values from Developer App (Custom Attributes)
var cusAttrEligiblePayType = context.getVariable("app.EligibleCheck_PayType");
var cusAttrEligibleCustomerType = context.getVariable("app.EligibleCheck_CustomerType");
var cusAttrEligibleStatus = context.getVariable("app.EligibleCheck_Status");
var cusAttrEligibleTenure = context.getVariable("app.EligibleCheck_Tenure");

// Retrieve values from backend (CRM)
var crmPayType = context.getVariable("payType");
var crmCustomerType = context.getVariable("subscriberType");
var crmStatus = context.getVariable("subscriberStatus");
var crmTenure = context.getVariable("tenure");
// chungss-20180221_end

// chungss-20190807
// Calculate tenure based on ActiveDate for Postpaid
var activeDate = context.getVariable("activeDate");

/**********************************************************************/

// Trishit
// Target Elapse Time
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());

// Target Elapsed Time
context.setVariable("targetElapsedTime", getTargetElaspedTime());

/**********************************************************************/

if (status_code != "Successful") {
    switch (error_code) {
        case "CRM:00005":
        case "CRM:00009":
        case "CRM:60010":
        case "SMO:20025":
        case "SMO:60006":
            switch (idType) {
                case "ACCOUNT_CODE":
                case "ACCOUNT_ID":
                    var msg = "Account not found ("+error_code+")";
                    break;
                default:
                    var msg = "Subscriber not found ("+error_code+")";
            }
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.011");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", msg);
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "CRM:60011":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.009");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid input parameter: Source ID (CRM:60011)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
        default:
            if (!isEmpty(error_more)) {
                var error_default = error_desc.trim()+" (MoreInfo: "+error_more.trim()+") ("+error_code+")";
            } else {
                var error_default = error_desc.trim()+" ("+error_code+")";
            }
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.006.010");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Internal Server Error: "+error_default);
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
    }
} else {
    context.setVariable("logType", "OK");
    
    // chungss-20180221_start
    // "eligible" result:
    // "YES" = Eligible
    // "NO" = Not eligible
    // "N/A" = Unknown/Not defined (default)
    context.setVariable("eligibleResult", "N/A");
    
    if (eligibilityFlag == "1") {
        // Check if Eligibility matrix is defined in Customer Attributes
        if (!isEmpty(cusAttrEligiblePayType)
            && !isEmpty(cusAttrEligibleCustomerType)
            && !isEmpty(cusAttrEligibleStatus)
            && !isEmpty(cusAttrEligibleTenure)) {
            var eligiblePayType = false;
            var eligibleCustomerType = false;
            var eligibleStatus = false;
            var eligibleTenure = false;
            
            // Loop through Pay Type from Custom Attributes matrix
            var arrPayType = cusAttrEligiblePayType.split(",");
            for (var i = 0; i < arrPayType.length; i++) {
                if (i in arrPayType) {
                    // If customer's Pay Type matches the matrix, consider as eligible
                    if (crmPayType.toUpperCase() == arrPayType[i].toUpperCase()) {
                        eligiblePayType = true;
                        break;
                    }
                }
            }
            
            // Loop through Customer Type from Custom Attributes matrix
            var objCustomerType = [];
            objCustomerType["1"] = "MASS";
            objCustomerType["2"] = "PCI";
            objCustomerType["3"] = "AMBASSADOR";
            objCustomerType["4"] = "USP";
            objCustomerType["5"] = "CI";
            objCustomerType["6"] = "CORPORATE";
            objCustomerType["7"] = "DEALER_DEMO";
            objCustomerType["8"] = "DEALER_STK_FLEXI";
            objCustomerType["9"] = "STAFF";
            objCustomerType["10"] = "TEST";
            objCustomerType["11"] = "DEALER_AMBASSADOR";
            
            if (crmCustomerType in objCustomerType) {
                var crmCustomerTypeStr = objCustomerType[crmCustomerType];
            } else {
                var crmCustomerTypeStr = "UNKNOWN";
            }
            
            var arrCustomerType = cusAttrEligibleCustomerType.split(",");
            for (var i = 0; i < arrCustomerType.length; i++) {
                if (i in arrCustomerType) {
                    // If customer's Customer Type matches the matrix, consider as eligible
                    if (crmCustomerTypeStr.toUpperCase() == arrCustomerType[i].toUpperCase()) {
                        eligibleCustomerType = true;
                        break;
                    }
                }
            }
            
            // Loop through Status from Custom Attributes matrix
            var arrStatus = cusAttrEligibleStatus.split(",");
            for (var i = 0 ; i < arrStatus.length; i++) {
                if (i in arrStatus) {
                    // If customer's Customer Type matches the matrix, consider as eligible
                    if (crmStatus.toUpperCase() == arrStatus[i].toUpperCase()) {
                        eligibleStatus = true;
                        break;
                    }
                }
            }
            
            // Check if customer tenure is more than matrix
            if (isInt(cusAttrEligibleTenure)) {
                if (crmTenure >= cusAttrEligibleTenure) {
                    eligibleTenure = true;
                }
            }
            
            // For Trace UI purposes
            context.setVariable("crmPayType", crmPayType);
            context.setVariable("crmCustomerType", crmCustomerType);
            context.setVariable("crmCustomerTypeStr", crmCustomerTypeStr);
            context.setVariable("crmStatus", crmStatus);
            context.setVariable("crmTenure", crmTenure);
            context.setVariable("eligiblePayType", eligiblePayType);
            context.setVariable("eligibleCustomerType", eligibleCustomerType);
            context.setVariable("eligibleStatus", eligibleStatus);
            context.setVariable("eligibleTenure", eligibleTenure);
            
            // If all values are matched, then consider the profile as eligible
            if (eligiblePayType && eligibleCustomerType && eligibleStatus && eligibleTenure) {
                context.setVariable("eligibleResult", "YES");
            } else {
                context.setVariable("eligibleResult", "NO");
            }
        }
    }
    // chungss-20180221_end
    
    // chungss-20190807
    // Calculate tenure based on ActiveDate for Postpaid
    if (!isEmpty(activeDate)) {
        try {
            // Trim the activeDate, removing the time
            // Assuming time starts at 00:00:00
            startDate = activeDate.substring(0,10);
            
            var tenureDiff = (new Date()) - (new Date(startDate));
            var tenureCalc = tenureDiff / (1000 * 60 * 60 * 24);
            var tenureDays = Math.floor(tenureCalc);
            
            context.setVariable("tenureActiveDate", activeDate);
            context.setVariable("tenureStartDate", startDate);
            context.setVariable("tenureDiff", tenureDiff);
            context.setVariable("tenureCalc", tenureCalc);
        } catch (err) {
            context.setVariable("tenureError", err);
            var tenureDays = crmTenure;
        }
    } else {
        var tenureDays = crmTenure;
    }
    context.setVariable("tenureDays", tenureDays);
}

var status_code = context.getVariable("statusCode");
var error_code = context.getVariable("error_code");
var error_desc = context.getVariable("error_desc");
var error_more = context.getVariable("error_more");
var beid = context.getVariable("BEID");

/**********************************************************************/

// Trishit
// Target Elapse Time
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("isoTimestamp", ISODateString());

// Target Elapsed Time
context.setVariable("targetElapsedTime", getTargetElaspedTime());

/**********************************************************************/

if (status_code != "Successful") {
    switch (error_code) {
        case "SCE:20039":
        case "SCE:60005":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.011");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Subscriber not found ("+error_code+")");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "SCE:20013":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.047");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "The operator does not belong to the current Business Entity (SCE:20013)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
        case "SCE:20015":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.048");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "The Business Entity ID does not exist (SCE:20015)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
        case "SCE:60004":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.049");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid Source ID (SCE:60004)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
        default:
            if (!isEmpty(error_more)) {
                var error_default = error_desc.trim()+" (MoreInfo: "+error_more.trim()+") ("+error_code+")";
            } else {
                var error_default = error_desc.trim()+" ("+error_code+")";
            }
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.006.010");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Internal Server Error: "+error_default);
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
    }
} else {
    context.setVariable("statusCode", "Successful");
    context.setVariable("logType", "OK");
    
    switch (beid) {
        case "102":
            context.setVariable("operator", "Digi");
            break;
        case "103":
            context.setVariable("operator", "TalkFocus");
            break;
        case "104":
            context.setVariable("operator", "MyEvo");
            break;
        case "105":
            context.setVariable("operator", "Pavacom");
            break;
        case "106":
            context.setVariable("operator", "Samata");
            break;
        default:
            context.setVariable("operator", "Others");
    }
}

var sourceId = context.getVariable("req.sourceId");
var idType = context.getVariable("req.idType");
var idValue = context.getVariable("req.idValue");

var transactionIdSeq = randomString(6);
context.setVariable("transactionIdSeq", transactionIdSeq);
context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);

/**********************************************************************/

if (isEmpty(sourceId)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.006.008");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingSourceID";
}

if (isEmpty(idType) || isEmpty(idValue)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.006.008");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: ID Type or ID Value");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingIDTypeIDValue";
}

/**********************************************************************/

var sourceIdlength = sourceId.length;
if (sourceIdlength > 8) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.006.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidSourceID";
}

if (idType != "MSISDN") {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.006.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Type");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidIDType";
}

var msisdnLength = idValue.length;
var revisedMsisdn = "";
if (idValue.startsWith("6") && ((msisdnLength == 11) || (msisdnLength == 12))) {
    revisedMsisdn = idValue.substring(1);
    context.setVariable("msisdn", idValue);
    context.setVariable("revisedMsisdn", revisedMsisdn);
} else {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.006.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Value (Invalid MSISDN format)");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidMSISDN";
}

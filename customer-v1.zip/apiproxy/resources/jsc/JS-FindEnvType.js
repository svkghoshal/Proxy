var envName = context.getVariable("environment.name");

// Set the initial timestamp
context.setVariable("isoTimestamp", ISODateString());

if (envName.indexOf("sandbox") >= 0) {
    context.setVariable("envType", "SANDBOX");
} else {
    context.setVariable("envType", "PRODUCTION");
}

// Quick fix for flows with JS-SetVerb
var requestVerb = context.getVariable("request.verb");
context.setVariable("requestVerb", requestVerb);

// Also set in JS-SetApigeeError.js
pathSuffix = context.getVariable("proxy.pathsuffix");
switch (pathSuffix) {
    case "/device":
    case "/operator":
    case "/info":
    case "/routingNumber":
        context.setVariable("errorResponseType", "V2");
        break;
    default:
        context.setVariable("errorResponseType", "V1");
}

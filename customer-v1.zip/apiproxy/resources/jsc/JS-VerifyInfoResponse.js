var status_code = context.getVariable("statusCode");
var error_code = context.getVariable("error_code");
var error_desc = context.getVariable("error_desc");
var error_more = context.getVariable("error_more");
var idType = context.getVariable("req.idType");

/**********************************************************************/

// Target Elapse Time
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());

// Target Elapsed Time
context.setVariable("targetElapsedTime", getTargetElaspedTime());

/**********************************************************************/

if (status_code != "Successful") {
    switch (error_code) {
        case "CRM:60010":
            switch (idType) {
                case "ACCOUNT_CODE":
                    var msg = "Account not found ("+error_code+")";
                    break;
                default:
                    var msg = "Subscriber not found ("+error_code+")";
            }
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.011");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", msg);
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "CRM:60011":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.006.009");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid input parameter: Source ID (CRM:60011)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
        default:
            if (!isEmpty(error_more)) {
                var error_default = error_desc.trim()+" (MoreInfo: "+error_more.trim()+") ("+error_code+")";
            } else {
                var error_default = error_desc.trim()+" ("+error_code+")";
            }
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.006.010");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Internal Server Error: "+error_default);
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
    }
} else {
    context.setVariable("logType", "OK");
}

var pathSuffix = context.getVariable("proxy.pathsuffix");
var target;

switch (pathSuffix) {
    case "/profile":
        // REST (GET)
        target = "/cxf/v4/crm/subscriber";
        context.setVariable("targetUrl", target);
        break;
    case "/device":
        // SOAP
        target = "/cxf/v1/smo/RetrieveDeviceSettings";
        context.setVariable("targetUrl", target);
        context.setVariable("isSOAP", true);
        break;
    case "/operator":
        // SOAP
        target = "/cxf/v1/crm/retrieveBeID";
        context.setVariable("targetUrl", target);
        context.setVariable("isSOAP", true);
        break;
    case "/info":
        // REST (GET)
        target = "/cxf/v1/crm/customer";
        context.setVariable("targetUrl", target);
        break;
    case "/reload":
        // REST (PUT)
        target = "/cxf/v1/brm/prepaidAccount";
        context.setVariable("targetUrl", target); 
        break;
    default:
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "404");
    	context.setVariable("errorCode", "404.006.001");
        context.setVariable("errorDesc", "Resource Not Found");
        context.setVariable("errorMessage", "Resource not found/Invalid resource");
        context.setVariable("logType", "TECHNICAL");
        throw "ResourceNotFound";
}

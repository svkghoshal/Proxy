var envType = context.getVariable("envType");
var envTarget = context.getVariable("envTarget");
var isSOAP = context.getVariable("isSOAP");

/**********************************************************************/

// Configure CSG2.0 username/password (credentials)
// Production
var prodUsername = "APIGW";
var prodPassword = "Apigw*&^%12";

// Non-Production (Staging)
var nonProdUsername = "APIGW";
var nonProdPassword = "weblogic";

/**********************************************************************/

// Configure CSG username/password (credentials)
if (envType == "SANDBOX") {
    if (envTarget == "PRODUCTION") {
        var userName = prodUsername;
        var password = prodPassword;
    } else {
        // PREPRODUCTION, STAGING
        var userName = nonProdUsername;
        var password = nonProdPassword;
    }
} else {
    // PRODUCTION
    var userName = prodUsername;
    var password = prodPassword;
}

// For debugging purpose
context.setVariable("DEBUG_userName", userName);
context.setVariable("DEBUG_password", password);

if (isSOAP === true) {
    // SOAP authentication
    var nonce = generateNonce(16);
    var nonce64 = base64encode(nonce);
    var created = getW3CDate(new Date());
    var passwordDigest = b64_sha1(nonce + created + password);
    
    context.setVariable("userName", userName);
    context.setVariable("password", passwordDigest);
    context.setVariable("nonce", nonce64);
    context.setVariable("CreatedDate", created);
} else {
    // REST authentication
    context.setVariable("userName", userName);
    context.setVariable("password", password);
}

var clientEndTimeStamp = new Date().getTime();

context.setVariable("clientStartTime", getClientStartTime());
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());
context.setVariable("clientEndTime", getClientEndTime());
context.setVariable("clientElapsTime", getClientElaspTime());
context.setVariable("targetElapsTime", getTargetElaspTime());
context.setVariable("apigw.txId", getApigwTransactionId());


function getApigwTransactionId() {
    var proxyName = context.getVariable("apiproxy.name");
    var suffixPath = context.getVariable("proxy.pathsuffix");
    var verb = context.getVariable("request.verb");
    var timestamp = new Date().getTime();
    var randomNumber = Math.floor(100000 + Math.random() * 900000);
    
    var useProxyName = proxyName.substring(0, 1).toUpperCase() + proxyName.substring(1);
    var useSuffixPath = suffixPath.substring(1, 2).toUpperCase() + suffixPath.substring(2);
    
    return useProxyName + useSuffixPath + verb + timestamp + randomNumber;
}

function getClientElaspTime() {
    var clientElapsTime = (clientEndTimeStamp - context.getVariable("client.received.start.timestamp"));

    return "" + clientElapsTime;
}

function getTargetElaspTime() {
    if(isEmpty(context.getVariable("target.received.end.timestamp")) || isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        var targetElapsTime = context.getVariable("target.received.end.timestamp") - context.getVariable("target.sent.start.timestamp");
        return "" + targetElapsTime;
    }
}

function getClientStartTime() {
    return getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(context.getVariable("client.received.start.timestamp"));
}

function getTargetStartTime() {
    if(isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        return getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(context.getVariable("target.sent.start.timestamp"));
    }
}

function getTargetEndTime() {
    if(isEmpty(context.getVariable("target.received.end.timestamp"))) {
        return "";
    } else {
        return getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(context.getVariable("target.received.end.timestamp"));
    }
}

function getClientEndTime() {
    return getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(clientEndTimeStamp);
}

function errorQueryCustomerResultMapping(errorCode, errorDesc){
    switch(errorCode){
        case "14000":
            setResponse("400", "400.160.0001", "Bad Request", errorDesc.substring(17).replace(/[0-9]/g, ''));
            break;
        case "12001":
            setResponse("400", "400.160.0002", "Bad Request", errorDesc);
            break;
        default:
            setResponse("500", "500.160.0000", "Internal Server Error", "Internal System Error: {" + errorDesc + "}");
            break;
    }
}
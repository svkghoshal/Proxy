function checkLengthArray (arrayList) {
    if(isEmpty(arrayList.length)) {
        var array_item = [];
        array_item[0] = arrayList;
        arrayList = array_item;   
    }
    
    return arrayList;
}

function checkDataString(data) {
    if(!isEmpty(data)) {
        return data;
    } else {
        return "";
    }
}

function mapQueryEmergencyBalanceToJson(){
    var emergencyAbleRate = JSON.parse(context.getVariable("resp.emergencyAbleRate"));
    var emergencyAbleList = [];
    //Success without data
    if(!isEmpty(emergencyAbleRate)){
        emergencyAbleList = checkLengthArray(JSON.parse(context.getVariable("resp.emergencyAbleList")));
    }
    context.setVariable("resp.listEmergencyRate", setListEmergencyRate(emergencyAbleList));
}

function setListEmergencyRate(emergencyAbleList){

    var listResponse = [];
    for(index = 0; index < emergencyAbleList.length; index++) {
        var idObj = {
            "id"  : parseInt(emergencyAbleList[index].EmergencyMoneyRate),
            "fee" : {
                "amount" : parseInt(emergencyAbleList[index].EmergencyMoneyFee)
            }
        };
        listResponse.push(idObj);
    }
    return JSON.stringify(listResponse);
}


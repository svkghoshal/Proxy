var path = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb");
var requestContent = context.getVariable("request.content");
var requestQuerystring = context.getVariable("request.querystring");

print("requestQuerystring : " +requestQuerystring );
print("requestContent : " +requestContent );

context.setVariable("clientIP", context.getVariable("client.ip"));
context.setVariable("appID", context.getVariable("system.uuid"));
context.setVariable("northboundRequestDatetime", "" + getDatetime());

switch(verb) {
    case "GET":
        context.setVariable("northbound.request", "" + requestQuerystring);
        switch(path) {
            case "/WHT":
                validateCustomerWithholdingTax();
                break;
            default:
                context.setVariable("validateError", "ResourceNotFound");
                break;
        }
        break;
    default:
        context.setVariable("validateError", "ResourceNotFound");
        break;
}

function validateCustomerWithholdingTax(){
    var id = "" + context.getVariable("message.queryparam.id");
    var accountId = "" + context.getVariable("message.queryparam.account.id");
    var isEnableHttps = (context.getVariable("customerWithholdingTaxIsEnableHttps") === "true");
   
    var now = new Date();
    
    
    var developerName = context.getVariable("apigee.developer.app.name");
    var subNum = "";
    var devName = "";
    var createTime = "";
    var timeExpire = "";
    
    print("validateCustomerWithholdingTax:param(mandatory):"
        + ", id = " + id
        + ", accountId = " + accountId);
    
    if(isEmpty(id) || isEmpty(accountId) ){
             context.setVariable("validateError", "BusinessValidationFailed");
		}
	}
	var now = new Date();
	var accountId = "" + context.getVariable("message.queryparam.account.id");
	var id = "" + context.getVariable("message.queryparam.id");
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("targetPath", context.getVariable("customerWithholdingTaxPath"));
    context.setVariable("req.verbProxy", "GET");
    context.setVariable("req.requestDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(now));
    context.setVariable("req.accountId", accountId);
    context.setVariable("req.id", id);
    print("req.messageId : " + context.getVariable("req.messageId"));


    var id = "" + context.getVariable("message.queryparam.id");
    var isEnableHttps = (context.getVariable("customerWithholdingTaxIsEnableHttps") === "true");
    
    
    var developerName = context.getVariable("apigee.developer.app.name");
    var subNum = "";
    var devName = "";
    var createTime = "";
    var timeExpire = "";
var faultName = context.getVariable("fault.name");
var validateError = context.getVariable("validateError");
var path = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb");
var errorMsgEN = "" + context.getVariable("resp.userAuthenResp.errorEN");

print("faultName = " + faultName);

if(!isEmpty(validateError)) {
    faultName = validateError;
    print("override faultName = " + faultName);
}

try {
    switch(verb) {
        case "GET":
            switch(path) {
                case "/WHT":
                    switch(faultName) {
                        case "SpikeArrestViolation":
                            setResponse("429", "429.160.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.160.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.160.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.160.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.160.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.160.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.160.2007", "Internal Server Error", "Invalid JSON path.");
                            break;
                        case "MissingCustomAttributes":
                            setResponse("400", "400.160.0000", "Bad Request", "Missing custom attributes");
                            break;
                        case "InvalidRefToken":
                            setResponse("400", "400.160.0012", "Bad Request", "Invalid reference token");
                            break;
                        default:
                            setResponse("500", "500.160.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                    }
                    break;			
                default:
                    setResponse("404", "404.160.0001", "Resource not found", "Resource not found/Invalid resource");
                    break;    
            }
            break;
				default:
                    setResponse("404", "404.091.0001", "Resource not found", "Resource not found/Invalid resource");
                    break;
			}
    }
catch(ex){
    switch(verb){
        case "GET":
            switch(path) {
                case "/WHT":
                    setResponse("500", "500.160.2004", "Internal Server Error", "JavaScript runtime error");
                    break;
                default:
                    setResponse("404", "404.160.0001", "Resource not found", "Resource not found/Invalid resource");
					break;
                }
            break;		
    }
}

context.setVariable("resp.responseDttm", getDatetime());
setReasonPhrase(context.getVariable("resp.httpStatusCode"));
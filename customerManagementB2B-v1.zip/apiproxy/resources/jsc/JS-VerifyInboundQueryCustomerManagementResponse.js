var errorCode = "" + context.getVariable("message.status.code");
var errorMessage = "" + context.getVariable("message.transport.message");
var Status = "" +context.getVariable("resp.Status");
var endpointErrorCode = ""+ context.getVariable("resp.ErrorCode");
var endpointErrorMessage = ""+ context.getVariable("resp.ErrorDescription");

var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");
var WHTServiceFlag = context.getVariable("resp.WHTServiceFlag");


context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.target.server", getSBTargetServer());
context.setVariable("southbound.request", setNorthSouthSoapRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthSoapRequestResponse(responseContent));
context.setVariable("request.verb", "GET");


printProxyRequest(requestContent);
printTargetResponse(responseContent);

if(Status !== "Success"){
	 
    if(!isEmpty(endpointErrorCode) && !isEmpty(endpointErrorMessage)){
        errorQueryCustomerResultMapping(endpointErrorCode.substring(4), trimErrorMessageOm(endpointErrorMessage));
    }else{
        errorQueryCustomerResultMapping(errorCode, errorMessage);
    }
}
else{
	if(isEmpty(WHTServiceFlag))
	{
		context.setVariable("WHTServiceFlag","0");
	}else{
		context.setVariable("WHTServiceFlag",WHTServiceFlag);
	}
    setResponse("200", "200", "", "");
   
}

function getSBTargetServer(){
    if(!isEmpty(context.getVariable("targetPath"))){
        return  context.getVariable("target.scheme") + "://" + context.getVariable("target.host") + context.getVariable("targetPath");
    } else {
        return context.getVariable("endpointUrl");
    }
}
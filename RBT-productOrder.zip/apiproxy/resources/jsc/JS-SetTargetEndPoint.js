var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');

if (reqVerb == "GET")
{
    var target = '/crbt/list-tones';
    
}else if (reqVerb == "POST")
{
   var target = '/crbt/set-tone';
    
}else if (reqVerb == "DELETE"){
    var target = '/crbt/delete-tone';
}

context.setVariable('targetPath',target);


   
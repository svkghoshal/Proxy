var faultString = context.getVariable("res.faultString");
var httpStatusCode = context.getVariable("message.status.code");
var reqVerb = context.getVariable('request.verb');
var message = context.getVariable("res.message");
var statusCode = context.getVariable("res.statusCode");
var apiNo = context.getVariable('apiNo');

if (reqVerb == "GET")
{
    if((message == "Success") && (httpStatusCode == "200"))
        context.setVariable("Status","Success");
     else
        {
          if(faultString.toUpperCase().includes("INVALID MSISDN")
          || faultString.toUpperCase().includes("INVALID FIELD")
          || faultString.toUpperCase().includes("INVALID STATUSCODE") 
          || faultString.toUpperCase().includes("LANGUAGEID SHOULD BE AN INTEGER"))
            {
                context.setVariable("exceptionName", "exceptionName");
                context.setVariable("errorCode", "400."+apiNo+".101");
                context.setVariable("errorDesc", "Bad Request");
                context.setVariable("errorMessage", "Invalid Input");
                context.setVariable("httpError", "400");
            } 
        else if(faultString.toUpperCase().includes("INSUFFICIENT BALANCE"))
            {
               context.setVariable("exceptionName", "exceptionName");
               context.setVariable("errorCode", "500."+apiNo+".101");
               context.setVariable("errorDesc", "Internal Server Error");
               context.setVariable("errorMessage", "Insufficient balance");
               context.setVariable("httpError", "500");
            }
        else if(faultString.toUpperCase().includes("RBT NOT EXIST"))
            {
                context.setVariable("exceptionName", "exceptionName");
            	context.setVariable("errorCode", "500."+apiNo+".102");
                context.setVariable("errorDesc", "Internal Server Error");
                context.setVariable("errorMessage", "RBT does not exist");
            	context.setVariable("httpError", "500");
            }
        else{
              context.setVariable("exceptionName", "exceptionName");    
              context.setVariable("errorCode", "500."+apiNo+".100");
              context.setVariable("errorDesc", "Internal Server Error");
              context.setVariable("errorMessage", faultString);
              context.setVariable("httpError", "500");
            }
                
        }
}

if (reqVerb == "POST" || reqVerb == "DELETE")
{
    if(statusCode == "SC0000" && httpStatusCode == 200)
        context.setVariable("Status","Success");
     else
        {
          if(faultString.toUpperCase().includes("INVALID MSISDN")
          || faultString.toUpperCase().includes("INVALID FIELD")
          || faultString.toUpperCase().includes("INVALID STATUSCODE") 
          || faultString.toUpperCase().includes("LANGUAGEID SHOULD BE AN INTEGER"))
            {
                context.setVariable("exceptionName", "exceptionName");
                context.setVariable("errorCode", "400."+apiNo+".101");
                context.setVariable("errorDesc", "Bad Request");
                context.setVariable("errorMessage", "Invalid Input");
                context.setVariable("httpError", "400");
            } 
        else if(faultString.toUpperCase().includes("INSUFFICIENT BALANCE"))
            {
               context.setVariable("exceptionName", "exceptionName");
               context.setVariable("errorCode", "500."+apiNo+".101");
               context.setVariable("errorDesc", "Internal Server Error");
               context.setVariable("errorMessage", "Insufficient balance");
               context.setVariable("httpError", "500");
            }
        else if(faultString.toUpperCase().includes("RBT NOT EXIST"))
            {
                context.setVariable("exceptionName", "exceptionName");
            	context.setVariable("errorCode", "500."+apiNo+".102");
                context.setVariable("errorDesc", "Internal Server Error");
                context.setVariable("errorMessage", "RBT does not exist");
            	context.setVariable("httpError", "500");
            }
        else{
              context.setVariable("exceptionName", "exceptionName");    
              context.setVariable("errorCode", "500."+apiNo+".100");
              context.setVariable("errorDesc", "Internal Server Error");
              context.setVariable("errorMessage", faultString);
              context.setVariable("httpError", "500");
            }
                
        }
}
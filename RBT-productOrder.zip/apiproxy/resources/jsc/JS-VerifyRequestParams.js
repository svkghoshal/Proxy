var reqVerb = context.getVariable('request.verb');
var path = context.getVariable('message.path');

/********************REQUEST DATA EXTRACT****************/

var path_variable_Array = [];

if(!isEmpty(path)) {
    path_variable_Array = path.split("/");
    
}

var language = path_variable_Array[3];
var billingAccountId = path_variable_Array[5];
var category = context.getVariable('req.category');
var productOfferingId = context.getVariable('req.productOfferingId');
if(isEmpty(productOfferingId))
{
   var productOfferingId = path_variable_Array[8]; 
}


var channelId = context.getVariable("req.channelId");
var externalId = context.getVariable("req.externalId");
var action = context.getVariable("req.action");


/********************REQUEST DATA EXTRACT****************/

/********************KVM DATA EXTRACT****************/
var languageEn = context.getVariable("kvm.en");

var languageMm = context.getVariable("kvm.mm");

var All = context.getVariable("kvm.All");

var AllCaller = context.getVariable("kvm.AllCaller");

var RAllCaller = context.getVariable("kvm.RAllCaller");

var GroupCallerSetting = context.getVariable("kvm.GroupCallerSetting");

var PURCHASED_TONES = context.getVariable("kvm.PURCHASED_TONES");

/********************KVM DATA EXTRACT****************/

/********************GENERATE TRANSACTION IDT****************/

var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
var apiNo = context.getVariable('apiNo');
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionDateTime",transactionDateTime());
context.setVariable("transactionId",apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

/********************GENERATE TRANSACTION IDT****************/


if (reqVerb == "GET")
{
    if (isEmpty(language)|| isEmpty(billingAccountId) || isEmpty(category)
     || (!billingAccountId.startsWith("97") || ((billingAccountId.length != 10))))
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (checkData(category) != '1')
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else if (checklang(language) != '1')
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else{
        
        context.setVariable("msisdn", billingAccountId);
        if(language.toUpperCase().includes("EN"))
        {
            context.setVariable("language", languageEn);
            
        }if(language.toUpperCase().includes("MM"))
        {
            context.setVariable("language", languageMm);
            
        }if(category.toUpperCase().includes("ALL"))
        {
            context.setVariable("rbtMode", All);
            
        }if(category.toUpperCase().includes("ALLCALLER"))
        {
            context.setVariable("rbtMode", AllCaller);
            
        }if(category.toUpperCase().includes("RALLCALLER"))
        {
            context.setVariable("rbtMode", RAllCaller);
            
        }if(category.toUpperCase().includes("GROUPCALLERSETTING"))
        {
            context.setVariable("rbtMode", GroupCallerSetting);
            
        }if(category.toUpperCase().includes("PURCHASED"))
        {
            context.setVariable("rbtMode", PURCHASED_TONES);
            
        }
     }
}

if (reqVerb == "POST")
{
    if (isEmpty(language)|| isEmpty(billingAccountId) || isEmpty(productOfferingId)
	 || isEmpty(channelId) || isEmpty(externalId) || (!action.toUpperCase().includes("ADD"))
     || (!billingAccountId.startsWith("97") || ((billingAccountId.length != 10))))
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else{
         
         if(language.toUpperCase().includes("EN"))
        {
            context.setVariable("language", languageEn);
            
        }if(language.toUpperCase().includes("MM"))
        {
            context.setVariable("language", languageMm);
            
        }
         context.setVariable("toneId", productOfferingId);
         context.setVariable("msisdn", billingAccountId);
         
     }
}

if (reqVerb == "DELETE")
{
    if (isEmpty(language)|| isEmpty(billingAccountId) || isEmpty(productOfferingId)
     || (!billingAccountId.startsWith("97") || ((billingAccountId.length != 10))))
     {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input.");
        throw "serviceException";
     }else{
         
         if(language.toUpperCase().includes("EN"))
        {
            context.setVariable("language", languageEn);
            
        }if(language.toUpperCase().includes("MM"))
        {
            context.setVariable("language", languageMm);
            
        }
         context.setVariable("toneId", productOfferingId);
         context.setVariable("msisdn", billingAccountId);
         
     }
}
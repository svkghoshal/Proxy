var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

var transactionId;
var isoTimestamp;
if (reqVerb == "GET")
{
    var apiNo = 121;
    context.setVariable("apiNo","121");
    
}else if (reqVerb == "POST")
{
    var apiNo = 122;
    context.setVariable("apiNo","122");
    
}else{
    var apiNo = 123;
    context.setVariable("apiNo","123");
}

var transactionIdseq = (context.getVariable("ratelimit.Q-TransactionSeq.used.count"));
if(transactionIdseq === null)
{
    transactionIdseq=0;
}
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionId",apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

var apiNo =context.getVariable("apiNo");
var url = context.getVariable("message.uri");
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);
context.setVariable("isoTimestamp", ISODateString());
var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);
var path = context.getVariable('message.path');

if(!isEmpty(path)) {
    path_variable_Array = path.split("/");
    
}

if (reqVerb == "GET")
{
    context.setVariable("apiNo","122");
    
}else if (reqVerb == "POST")
{
    context.setVariable("apiNo","123");
    
}else{
    
    context.setVariable("apiNo","124");
}

if(path_variable_Array[1] != "v1" || path_variable_Array[2] != "mm"
||path_variable_Array[4] != "users" || path_variable_Array[6] != "rbt" 
|| path_variable_Array[7] != "productOrder")
 {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "404."+apiNo+".001");
	context.setVariable("errorDesc", "Resource not found");
	context.setVariable("errorMessage", "Resource not found/Invalid resource");
	context.setVariable("httpError", "404");
	throw "serviceException";
 }
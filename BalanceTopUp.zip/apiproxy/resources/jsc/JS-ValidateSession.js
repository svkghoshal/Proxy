 var sessionStatus= context.getVariable("response.status.code");
 if (sessionStatus != 200)
 {}
 var result=context.getVariable("result");
 var flag;
 if(result===0)
 {
     flag=0;
     context.setVariable("flag", flag);
     context.setVariable("value", "0");
 }
 
 else{
 
     flag=1;
     context.setVariable("flag", flag);
     context.setVariable("value", "1");
 
 }
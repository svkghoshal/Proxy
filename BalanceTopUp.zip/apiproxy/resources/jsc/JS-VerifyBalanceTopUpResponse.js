 
/*var status_code = context.getVariable("statusCode");*/
var status_code = context.getVariable("newstatusCode");
var transactionId = context.getVariable("newTransactionId");
context.setVariable("transactionId",transactionId);
var faultCode = context.getVariable("newfaultCode");
var faultString = context.getVariable("newfaultString");
var faultMsg = context.getVariable("newfaultMessage");
var apiNo = "028";

if((status_code =='0'))
{
    context.setVariable("status","Success");
}
else if ((status_code =='2')) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".101");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Badly formatted request");
	context.setVariable("httpError", "400");
}
/*else if ((status_code =='4')){
    context.setVariable("newstatus","Recreate");
}*/

else if ((status_code =='3')
|| (status_code =='5')
|| (status_code =='6')
|| (status_code =='7')
|| (status_code =='13')
|| (status_code =='14')
|| (status_code =='15')
||(status_code =='16')
|| (status_code =='20')
|| (status_code =='22')
|| (status_code =='28')
|| (status_code =='19')
|| (status_code =='27') 
|| (status_code =='26')
|| (status_code =='35')
|| (status_code =='25')
||(status_code =='55')
|| (status_code =='56')
|| (status_code =='57')
||(status_code =='58')
|| (status_code =='59')
|| (status_code =='32'))	
{
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".014");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Invalid User");
	context.setVariable("httpError", "500");
    
}
else if ((status_code =='8')
|| (status_code =='9')
|| (status_code =='10')
|| (status_code =='11')
|| (status_code =='12')
|| (status_code =='30') )

{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".003");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Invalid Input");
	context.setVariable("httpError", "400");
}
else if ((status_code =='17')
|| (status_code =='23')
|| (status_code =='29')
|| (status_code =='24') )
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".004");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Requested amount is Invalid");
	context.setVariable("httpError", "400");
}
else if ((status_code =='18'))
{
  context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".015");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "User is already registered");
	context.setVariable("httpError", "500");  
}

else if ((status_code =='33'))
{
   context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".016");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "The original request has expired due to a timeout");
	context.setVariable("httpError", "500");  
}
else if ((status_code =='34')
|| (status_code =='36')
|| (status_code =='37')
||(status_code =='38'))
{
 context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".017");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Transaction is not able to complete");
	context.setVariable("httpError", "500");   
}
else if ((status_code =='42')
|| (status_code =='43')
|| (status_code =='44')
|| (status_code =='45')
|| (status_code =='46'))
{
  context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".018");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Error from Topup system");
	context.setVariable("httpError", "500");  
}
else if ((status_code =='47'))
{
 context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".011");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Amount requested was not within a valid range");
	context.setVariable("httpError", "400");   
}
else if ((status_code =='49'))
{
  context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".020");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "The supplied Billpay account is not valid");
	context.setVariable("httpError", "500");   
}
else if ((status_code =='50')
||(status_code =='51'))
{
  context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".021");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Error from Bank");
	context.setVariable("httpError", "500");  
}
else if ((status_code =='52'))
{
  context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".022");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Synchronization is not required at this time");
	context.setVariable("httpError", "500");  
}
else if ((status_code =='53'))
{
   context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".012");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "The requested device is already active");
	context.setVariable("httpError", "400");   
}
else if ((status_code =='60'))
{
  context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".026");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "User cannot use the requested wallet type");
	context.setVariable("httpError", "500");   
}
else if ((status_code =='61')
|| (status_code =='62'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".027");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Schedule Payment failed");
	context.setVariable("httpError", "500");
}
else if ((status_code =='63'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".016");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Requested confirmation would potentially");
	context.setVariable("httpError", "400");
}

else if ((status_code =='64'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".017");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Requesting Agent is not a Special Agent");
	context.setVariable("httpError", "400");
}
else if ((status_code =='66'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".028");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Connection is offline");
	context.setVariable("httpError", "500");
}
else if ((status_code =='67'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".029");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Connection Error");
	context.setVariable("httpError", "500");
}
else if ((status_code =='68'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".030");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Operation not supported");
	context.setVariable("httpError", "500");
}
else if ((status_code =='69'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".031");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Agent has been misconfigured");
	context.setVariable("httpError", "500");
}
else if ((status_code =='70'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".032");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Agent still has transactions outstanding");
	context.setVariable("httpError", "500");
}
else if ((status_code =='71')) 
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".033");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Agent is deleted");
	context.setVariable("httpError", "500");
}
else if ((status_code =='72'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".034");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Target is deleted");
	context.setVariable("httpError", "500");
}
else if ((status_code =='73'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".035");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Agent still has a non-zero balance");
	context.setVariable("httpError", "500");
}
else if ((status_code =='74'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".018");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Invalid password mismatch");
	context.setVariable("httpError", "400");
}
else if ((status_code =='75'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".036");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Reversal Failed.");
	context.setVariable("httpError", "500");
}
else if ((status_code =='76'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".037");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Group name already exists");
	context.setVariable("httpError", "500");
}
else if ((status_code =='77'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".038");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Group not empty");
	context.setVariable("httpError", "500");
}
else if ((status_code =='78'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".039");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Confirmer same as initiator");
	context.setVariable("httpError", "500");
}
else if ((status_code =='103'))
{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".040");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", " Confirmation was rejected");
	context.setVariable("httpError", "500");
}


else if ((status_code =='54')
|| (status_code =='39')
|| (status_code =='40')
|| (status_code =='41')
|| (status_code =='48')
|| (status_code =='312')
|| (status_code =='400')
|| (status_code =='401') 
|| (status_code =='423')
|| (status_code =='424')
||(status_code =='415') 
|| (status_code =='425')
|| (status_code =='501') 
|| (status_code =='502')
||(status_code =='503')
|| (status_code =='504')
|| (status_code =='505')
|| (status_code =='506')
|| (status_code =='507')
||(status_code =='508')
|| (status_code =='509')
|| (status_code =='510')
|| (status_code =='511')
||(status_code =='520')
|| (status_code =='521')
|| (status_code =='522') ||
(status_code =='523') ||
(status_code =='524')
|| (status_code =='525') ||
(status_code =='530') || 
(status_code =='540') || 
(status_code =='541') ||
(status_code =='542') ||
(status_code =='543')
||(status_code =='544')||
(status_code =='545')||
(status_code =='546') || 
(status_code =='547')|| 
(status_code =='550')||
(status_code =='551') ||
(status_code =='552')
|| (status_code =='560') ||
(status_code =='600')|| 
(status_code =='700')||
(status_code =='701') ||
(status_code =='1001')
|| (status_code =='1002') ||
(status_code =='1003')||
(status_code =='1004') || 
(status_code =='1005')|| 
(status_code =='1006') ||
(status_code =='1007') ||
(status_code =='1008')
|| (status_code =='1009') ||
(status_code =='1010')||
(status_code =='1011') ||
(status_code =='1012') ||
(status_code =='1013')
||(status_code =='1014')||
(status_code =='1015')||
(status_code =='1016') || 
(status_code =='1017') || 
(status_code =='1020') ||
(status_code =='1021')||
(status_code =='1022')
|| (status_code =='1023')||
(status_code =='1024')|| 
(status_code =='1025') ||
(status_code =='1026') ||
(status_code =='1027') ||
(status_code =='1028')
|| (status_code =='3011') ||
(status_code =='3012')||
(status_code =='6202')|| 
(status_code =='6203') || 
(status_code =='6204')||
(status_code =='6205') ||
(status_code =='6206') 
|| (status_code =='6207') ||
(status_code =='6208')||
(status_code =='6211') ||
(status_code =='20001')
|| (status_code =='20101')||
(status_code =='20201')||
(status_code =='20252'))

{
context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Internal Server Error");
	context.setVariable("httpError", "500");
}
else
{
    
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Internal Server Error");
	context.setVariable("httpError", "500");
}

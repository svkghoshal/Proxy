 var errorMsg = context.getVariable("ERROR");


if (errorMsg !== null) {
	if (errorMsg.toUpperCase().includes("REQUESTED BILL NOT FOUND")) {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("httpError", "500");
		context.setVariable("errorCode", "500.028.101");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", errorMsg);
	} else if (errorMsg.toUpperCase().includes("CONNECTION REFUSED")) {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("httpError", "500");
		context.setVariable("errorCode", "500.028.102");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", errorMsg);
	} else {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("httpError", "500");
		context.setVariable("errorCode", "500.028.100");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", errorMsg);
	}
}

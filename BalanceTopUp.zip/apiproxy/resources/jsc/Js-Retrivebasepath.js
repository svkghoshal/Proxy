var proxypath = context.getVariable('request.uri');
var newpath=proxypath.substring(0,34);
var sessionpath="/createsession";
var newpath2 = newpath + sessionpath;
//var finalpath=newpath.strconcat(sessionpath);
context.setVariable("newpath2",newpath2);

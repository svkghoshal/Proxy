var errorMsg = context.getVariable("ERROR");
var apiNo = context.getVariable('apiNo');

/*context.setVariable("response.content", "");*/

if (errorMsg !== null) {
	if (errorMsg.toUpperCase().includes("REQUESTED BILL NOT FOUND")) {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("httpError", "500");
		context.setVariable("errorCode", "500."+apiNo+".101");
		context.setVariable("errorDesc", "Requested bill not found");
		context.setVariable("errorMessage", errorMsg);
	} else if (errorMsg.toUpperCase().includes("CONNECTION REFUSED")) {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("httpError", "500");
		context.setVariable("errorCode", "500."+apiNo+".102");
		context.setVariable("errorDesc", "Connection Refused");
		context.setVariable("errorMessage", errorMsg);
	} else {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("httpError", "500");
		context.setVariable("errorCode", "500."+apiNo+".100");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", errorMsg);
	}
}

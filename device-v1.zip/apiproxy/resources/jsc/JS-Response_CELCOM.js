var result = context.getVariable("res.CELCOM");

switch (result) {
    case "OK":
        // For /status
        context.setVariable("CELCOM", "OK");
        context.setVariable("continue_flow", "true");
        break;
    case "NO_DUPLICATE":
        // For /verify
        context.setVariable("CELCOM", "NO_DUPLICATE");
        context.setVariable("continue_flow", "true");
        break;
    case "IMEI_DUPLICATE":
        context.setVariable("CELCOM", "IMEI_DUPLICATE");
        context.setVariable("continue_flow", "false");
        break;
    default:
        context.setVariable("CELCOM", "FAIL");
        context.setVariable("continue_flow", "true");
}

/****************************************************************/

var targetTimeStart = context.getVariable("targetTimeStart");
var targetTimeEnd = context.getVariable("system.timestamp");
context.setVariable("targetTime_CELCOM", ""+(targetTimeEnd-targetTimeStart));

/****************************************************************/

// For debugging purpose
// Only visible in Trace
var failed_oauth = context.getVariable("servicecallout.SC-Oauth_CELCOM.failed");
var failed_verify = context.getVariable("servicecallout.SC-Verify_CELCOM.failed");
var failed_status = context.getVariable("servicecallout.SC-Status_CELCOM.failed");
var oauth_status_code = context.getVariable("response_oauth_CELCOM.status.code");
var oauth_reason_phrase = context.getVariable("response_oauth_CELCOM.reason.phrase");
var callout_status_code = context.getVariable("response_callout_CELCOM.status.code");
var callout_reason_phrase = context.getVariable("response_callout_CELCOM.reason.phrase");

/****************************************************************/

var target_request = context.getVariable("request_callout_CELCOM.content");
try {
    var target_request1 = JSON.parse(target_request);
    var target_request2 = JSON.stringify(target_request1);
    context.setVariable("target_request_CELCOM", target_request2);
} catch (err_json) {
    try {
        var target_request1 = xml2flat(target_request);
        context.setVariable("target_request_CELCOM", target_request1);
        context.setVariable("target_request_CELCOM_err_json", err_json);
    } catch (err_xml) {
        context.setVariable("target_request_CELCOM", target_request);
        context.setVariable("target_request_CELCOM_err_xml", err_xml);
    }
}

var target_response = context.getVariable("response_callout_CELCOM.content");
try {
    var target_response1 = JSON.parse(target_response);
    var target_response2 = JSON.stringify(target_response1);
    context.setVariable("target_response_CELCOM", target_response2);
} catch (err_json) {
    try {
        var target_response1 = xml2flat(target_response);
        context.setVariable("target_response_CELCOM", target_response1);
        context.setVariable("target_response_CELCOM_err_json", err_json);
    } catch (err_xml) {
        context.setVariable("target_response_CELCOM", target_response);
        context.setVariable("target_response_CELCOM_err_xml", err_xml);
    }
}

var sourceId = context.getVariable("req.sourceId");
var requestId = context.getVariable("req.requestId");
var idType = context.getVariable("req.idType");
var idValue = context.getVariable("req.idValue");
var action = context.getVariable("req.action");
var reason = context.getVariable("req.reason");
var target = context.getVariable("req.target");
var date = context.getVariable("req.date");

/****************************************************************/

if (isEmpty(sourceId)) {
    context.setVariable("exceptionName", "MissingSourceID");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingSourceID";
}

if (isEmpty(requestId)) {
    context.setVariable("exceptionName", "MissingRequestID");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Request ID");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingRequestID";
}

if (isEmpty(idType) || isEmpty(idValue)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: ID Type or ID Value");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingIDTypeIDValue";
}

if (isEmpty(action)) {
    context.setVariable("exceptionName", "MissingAction");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Action");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingAction";
}

if (isEmpty(reason)) {
    context.setVariable("exceptionName", "MissingReason");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Reason");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingReason";
}

if (action == "UNBLOCK") {
    if (isEmpty(target)) {
        context.setVariable("req.target", "ALL");
    } else if (!isEmpty(target)) {
        var str_target = String(target);
        var str_length = str_target.length;
        var final_target = str_target.slice(1, (str_length - 1));
        
		var flag_ALL = final_target.includes("ALL");
        var flag_CELCOM = final_target.includes("CELCOM");
		var flag_MAXIS = final_target.includes("MAXIS");
		var flag_UMOBILE = final_target.includes("UMOBILE");
		var flag_WEBE = final_target.includes("WEBE");
		var flag_YES = final_target.includes("YES");
		
        print(flag_ALL);
		print(flag_CELCOM);
		print(flag_MAXIS);
		print(flag_UMOBILE);
		print(flag_WEBE);
		print(flag_YES);
		
		if (flag_ALL === true) {
		    context.setVariable("req.target", "ALL");
		} else {
    		if (flag_CELCOM === true) {
    			context.setVariable("req.target_CELCOM", "CELCOM");
    		}
    		
    		if (flag_MAXIS === true) {
    			context.setVariable("req.target_MAXIS", "MAXIS");
    		}
    		
    		if (flag_UMOBILE === true) {
    			context.setVariable("req.target_UMOBILE", "UMOBILE");
    		}
    		
    		if (flag_WEBE === true) {
    			context.setVariable("req.target_WEBE", "WEBE");
    		}
    		
    		if (flag_YES === true) {
    			context.setVariable("req.target_YES", "YES");
    		}
		}
    }
} else {
    context.setVariable("req.target", "ALL");
}

if (isEmpty(date)) {
    context.setVariable("exceptionName", "MissingDate");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Date");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingDate";
}

/****************************************************************/

var sourceIdlength = sourceId.length;
if (sourceIdlength > 8) {
    context.setVariable("exceptionName", "InvalidSourceID");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidSourceID";
}

var requestIdlength = requestId.length;
if (requestIdlength > 32) {
    context.setVariable("exceptionName", "InvalidRequestID");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Request ID");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidRequestID";
}

if (idType != "IMEI") {
    context.setVariable("exceptionName", "InvalidIDType");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Type");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidIDType";
}

var imeiLength = idValue.length;
if (imeiLength <= 32) {
    context.setVariable("imei", idValue);
} else {
    context.setVariable("exceptionName", "InvalidIDValue");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Value (Invalid IMEI format)");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidIDValue";
}

switch (action) {
    case "BLOCK":
    case "UNBLOCK":
        // Do nothing
        break;
    default:
        context.setVariable("exceptionName", "InvalidAction");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.010");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid input parameter: Action");
        context.setVariable("logType", "TECHNICAL");
        throw "InvalidAction";
}

switch (reason) {
    case "LOST":
    case "STOLEN":
    case "FOUND":
    case "ROLLBACK":
    case "OTHERS":
        // Do nothing
        break;
    default:
        context.setVariable("exceptionName", "InvalidReason");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.010");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid input parameter: Reason");
        context.setVariable("logType", "TECHNICAL");
        throw "InvalidReason";
}

// Temporarily disabled. Checking is not consistent.
/*
if (!isDate(date)) {
    context.setVariable("exceptionName", "InvalidDate");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Date");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidDate";
}
*/

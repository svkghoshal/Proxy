// Set timestamp
context.setVariable("isoTimestamp", ISODateString());

/****************************************************************/

var bodyRequest = context.getVariable("clientBodyRequest");
try {
    var clientBodyParse = JSON.parse(bodyRequest);
    var clientBodyRequest = JSON.stringify(clientBodyParse);
    context.setVariable("clientBodyRequest", clientBodyRequest);
} catch (err) {
    context.setVariable("clientBodyRequest", "N/A");
}

var bodyResponse = context.getVariable("clientBodyResponse");
try {
    var clientBodyParse = JSON.parse(bodyResponse);
    var clientBodyResponse = JSON.stringify(clientBodyParse);
    context.setVariable("clientBodyResponse", clientBodyResponse);
} catch (err) {
    context.setVariable("clientBodyResponse", "N/A");
}

/****************************************************************/

var logType = context.getVariable("logType");
switch (logType) {
    case "BUSINESS":
    case "TECHNICAL":
        // Do nothing
        break;
    default:
        context.setVariable("logType", "OK");
}

/****************************************************************/

// For SC-StatCollector
switch (context.getVariable("logType")) {
    case "OK":
        var statStatusCode = "OK";
        break;
    default:
        var statStatusCode = "FAIL";
}
var statErrorCode = context.getVariable("errorCode");
var statErrorMessage = context.getVariable("errorMessage");
context.setVariable("statStatusCode", statStatusCode);
context.setVariable("statErrorCode", statErrorCode);
context.setVariable("statErrorMessage", statErrorMessage);

/****************************************************************/

// Return the backend environment as Header for Sandbox
var envType = context.getVariable("envType");
var rmp_ip = context.getVariable("system.interface.ens192");
if (envType != "PRODUCTION") {
    switch (rmp_ip) {
        case "10.88.1.20":
            var rmp_hostname = "a0110papirmp01";
            break;
        case "10.88.1.21":
            var rmp_hostname = "a0110papirmp02";
            break;
        default:
            var rmp_hostname = rmp_ip;
    }
    context.setVariable("message.header.Router-Message-Processor", rmp_hostname);
}

/****************************************************************/

var response_oauth_DIGI = context.getVariable("response_oauth_DIGI.status.code");
var response_oauth_CELCOM = context.getVariable("response_oauth_CELCOM.status.code");
var response_oauth_MAXIS = context.getVariable("response_oauth_MAXIS.status.code");
var response_oauth_UMOBILE = context.getVariable("response_oauth_UMOBILE.status.code");
var response_oauth_WEBE = context.getVariable("response_oauth_WEBE.status.code");
var response_oauth_YES = context.getVariable("response_oauth_YES.status.code");

var response_callout_DIGI = context.getVariable("response_callout_DIGI.status.code");
var response_callout_CELCOM = context.getVariable("response_callout_CELCOM.status.code");
var response_callout_MAXIS = context.getVariable("response_callout_MAXIS.status.code");
var response_callout_UMOBILE = context.getVariable("response_callout_UMOBILE.status.code");
var response_callout_WEBE = context.getVariable("response_callout_WEBE.status.code");
var response_callout_YES = context.getVariable("response_callout_YES.status.code");

if (isEmpty(response_oauth_DIGI)) context.setVariable("response_oauth_DIGI.status.code", "X");
if (isEmpty(response_oauth_CELCOM)) context.setVariable("response_oauth_CELCOM.status.code", "X");
if (isEmpty(response_oauth_MAXIS)) context.setVariable("response_oauth_MAXIS.status.code", "X");
if (isEmpty(response_oauth_UMOBILE)) context.setVariable("response_oauth_UMOBILE.status.code", "X");
if (isEmpty(response_oauth_WEBE)) context.setVariable("response_oauth_WEBE.status.code", "X");
if (isEmpty(response_oauth_YES)) context.setVariable("response_oauth_YES.status.code", "X");

if (isEmpty(response_callout_DIGI)) context.setVariable("response_callout_DIGI.status.code", "X");
if (isEmpty(response_callout_CELCOM)) context.setVariable("response_callout_CELCOM.status.code", "X");
if (isEmpty(response_callout_MAXIS)) context.setVariable("response_callout_MAXIS.status.code", "X");
if (isEmpty(response_callout_UMOBILE)) context.setVariable("response_callout_UMOBILE.status.code", "X");
if (isEmpty(response_callout_WEBE)) context.setVariable("response_callout_WEBE.status.code", "X");
if (isEmpty(response_callout_YES)) context.setVariable("response_callout_YES.status.code", "X");

/****************************************************************/

var targetTime_DIGI = context.getVariable("targetTime_DIGI");
var targetTime_CELCOM = context.getVariable("targetTime_CELCOM");
var targetTime_MAXIS = context.getVariable("targetTime_MAXIS");
var targetTime_UMOBILE = context.getVariable("targetTime_UMOBILE");
var targetTime_WEBE = context.getVariable("targetTime_WEBE");
var targetTime_YES = context.getVariable("targetTime_YES");

if (isEmpty(targetTime_DIGI)) context.setVariable("targetTime_DIGI", "X");
if (isEmpty(targetTime_CELCOM)) context.setVariable("targetTime_CELCOM", "X");
if (isEmpty(targetTime_MAXIS)) context.setVariable("targetTime_MAXIS", "X");
if (isEmpty(targetTime_UMOBILE)) context.setVariable("targetTime_UMOBILE", "X");
if (isEmpty(targetTime_WEBE)) context.setVariable("targetTime_WEBE", "X");
if (isEmpty(targetTime_YES)) context.setVariable("targetTime_YES", "X");

/****************************************************************/

// Calculate the total elapsed time
// Time request is received from client to time response is sent back to client
var client_start = context.getVariable("client.received.start.timestamp");
var system_timestamp = context.getVariable("system.timestamp");
context.setVariable("totalElapsedTime", ""+(system_timestamp-client_start));

var envName = context.getVariable("environment.name");
if (envName.indexOf("sandbox") >= 0) {
    context.setVariable("envType", "SANDBOX");
} else {
    context.setVariable("envType", "PRODUCTION");
}

// Set timestamp (initial)
context.setVariable("isoTimestamp", ISODateString());

// Set transactionId
var sourceId = context.getVariable("req.sourceId");
var transactionIdSeq = randomString(6);
context.setVariable("transactionIdSeq", transactionIdSeq);
context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);

// Default response, based on sequence of requests
context.setVariable("UMOBILE", "SKIPPED");
context.setVariable("CELCOM", "SKIPPED");
context.setVariable("YES", "SKIPPED");
context.setVariable("WEBE", "SKIPPED");
context.setVariable("MAXIS", "SKIPPED");

// Default flow, all must be executed
context.setVariable("continue_flow", "true");

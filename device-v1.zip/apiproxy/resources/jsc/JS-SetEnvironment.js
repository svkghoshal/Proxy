// PRODUCTION

client_id_production_DIGI = "apiUser";
client_secret_production_DIGI = "Av7d4J4aZKYo1dfmJnvz";
target_production_DIGI = "10.89.13.116:8080";

client_id_production_CELCOM = "x2VCdzspi68DlF8zu63nTx4e9frP3Igk";
client_secret_production_CELCOM = "GqcOKBl6XGrtQs6w";
target_production_CELCOM = "celcom-prod.apigee.net";

client_id_production_MAXIS = "8e9a6f62-e031-4a96-8db5-5d306d162546";
client_secret_production_MAXIS = "abf9c3f0-ebf9-495b-85c6-9825c2a0f29c";
target_production_MAXIS = "apigateway.maxis.com.my";

client_id_production_UMOBILE = "X16UzhlJHdAB8pDBI6pnTuPtWpUdPWLq";
client_secret_production_UMOBILE = "cHeKhPkRnUrWtYw3";
target_production_UMOBILE = "pcbs.u.com.my";

client_id_production_WEBE = "N/A";
client_secret_production_WEBE = "N/A";
target_production_WEBE = "google.com";

client_id_production_YES = "238e320053f991b6a453d57a25ed6481";
client_secret_production_YES = "224f4f81ddcd695e3bdf3e5b2d38a7af";
target_production_YES = "integration.yes.my";

/****************************************************************/
// STAGING

client_id_staging_DIGI = "apiUser";
client_secret_staging_DIGI = "Av7d4J4aZKYo1dfmJnvz";
target_staging_DIGI = "10.89.13.117:8080";

client_id_staging_CELCOM = "wLbcTop5OHBxSXZM6DOVsAkvH_ka";
client_secret_staging_CELCOM = "GOV3ijwSGkQB2Jm1UIq0B91R_g4a";
target_staging_CELCOM = "igw.apistg.celcom.com.my";

client_id_staging_MAXIS = "25ecc50d-cba6-4df8-80e5-e806a3bc52b0";
client_secret_staging_MAXIS = "63bf4ae1-3dd2-4188-b857-989a0f168b54";
target_staging_MAXIS = "apigwtst.maxis.com.my";

client_id_staging_UMOBILE = "X16UzhlJHdAB8pDBI6pnTuPtWpUdPWLq";
client_secret_staging_UMOBILE = "cHeKhPkRnUrWtYw3";
target_staging_UMOBILE = "umtest.u.com.my";

client_id_staging_WEBE = "N/A";
client_secret_staging_WEBE = "N/A";
target_staging_WEBE = "google.com";

client_id_staging_YES = "592bef6273222cef98152ed338a2d647";
client_secret_staging_YES = "378688028d3085a2fc582fb5fe513ae1";
target_staging_YES = "integrationuat.ytlcomms.my";

/****************************************************************/

envType = context.getVariable("envType");
if (envType == "PRODUCTION") {
    context.setVariable("client_id_DIGI", client_id_production_DIGI);
    context.setVariable("client_secret_DIGI", client_secret_production_DIGI);
    context.setVariable("target_DIGI", target_production_DIGI);
    
    context.setVariable("client_id_CELCOM", client_id_production_CELCOM);
    context.setVariable("client_secret_CELCOM", client_secret_production_CELCOM);
    context.setVariable("target_CELCOM", target_production_CELCOM);
    
    context.setVariable("client_id_MAXIS", client_id_production_MAXIS);
    context.setVariable("client_secret_MAXIS", client_secret_production_MAXIS);
    context.setVariable("target_MAXIS", target_production_MAXIS);
    
    context.setVariable("client_id_UMOBILE", client_id_production_UMOBILE);
    context.setVariable("client_secret_UMOBILE", client_secret_production_UMOBILE);
    context.setVariable("target_UMOBILE", target_production_UMOBILE);
    
    context.setVariable("client_id_WEBE", client_id_production_WEBE);
    context.setVariable("client_secret_WEBE", client_secret_production_WEBE);
    context.setVariable("target_WEBE", target_production_WEBE);
    
    context.setVariable("client_id_YES", client_id_production_YES);
    context.setVariable("client_secret_YES", client_secret_production_YES);
    context.setVariable("target_YES", target_production_YES);
} else {
    context.setVariable("client_id_DIGI", client_id_staging_DIGI);
    context.setVariable("client_secret_DIGI", client_secret_staging_DIGI);
    context.setVariable("target_DIGI", target_staging_DIGI);
    
    context.setVariable("client_id_CELCOM", client_id_staging_CELCOM);
    context.setVariable("client_secret_CELCOM", client_secret_staging_CELCOM);
    context.setVariable("target_CELCOM", target_staging_CELCOM);
    
    context.setVariable("client_id_MAXIS", client_id_staging_MAXIS);
    context.setVariable("client_secret_MAXIS", client_secret_staging_MAXIS);
    context.setVariable("target_MAXIS", target_staging_MAXIS);
    
    context.setVariable("client_id_UMOBILE", client_id_staging_UMOBILE);
    context.setVariable("client_secret_UMOBILE", client_secret_staging_UMOBILE);
    context.setVariable("target_UMOBILE", target_staging_UMOBILE);
    
    context.setVariable("client_id_WEBE", client_id_staging_WEBE);
    context.setVariable("client_secret_WEBE", client_secret_staging_WEBE);
    context.setVariable("target_WEBE", target_staging_WEBE);
    
    context.setVariable("client_id_YES", client_id_staging_YES);
    context.setVariable("client_secret_YES", client_secret_staging_YES);
    context.setVariable("target_YES", target_staging_YES);
}

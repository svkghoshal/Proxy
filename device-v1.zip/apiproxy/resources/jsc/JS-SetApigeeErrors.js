var faultName = context.getVariable("fault.name");

// Set timestamp
context.setVariable("isoTimestamp", ISODateString());

var transactionId = context.getVariable("transactionId");
if (isEmpty(transactionId)) {
    var sourceId = context.getVariable("req.sourceId");
    var transactionIdSeq = randomString(6);
    context.setVariable("transactionIdSeq", transactionIdSeq);
    context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);
}

switch (faultName) {
     case "IPDeniedAccess":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.001");
            context.setVariable("errorDesc", "Forbidden");
            context.setVariable("errorMessage", "Access is denied");
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
        break;
        
    case "access_token_expired":
    case "invalid_access_token":
    case "InvalidAccessToken":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "401.002");
        context.setVariable("errorDesc", "Unauthorized");
        context.setVariable("errorMessage", "Access token is invalid or expired");
        context.setVariable("httpError", "401");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    case "RaiseFault":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "404.003");
        context.setVariable("errorDesc", "Resource Not Found");
        context.setVariable("errorMessage", "Resource not found/Invalid resource");
        context.setVariable("httpError", "404");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    case "SpikeArrestViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429.004");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Spike arrest violation");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    case "QuotaViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429.005");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Quota limit exceeded");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    case "ConcurrentRatelimtViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429.006");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Concurrent rate limit connection exceeded");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    case "ExecutionFailed":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.007");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Request input is malformed or invalid");
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
        break;
        
    default:
		context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500.008");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Internal Server Error: " + faultName);
		context.setVariable("httpError", "500");
		context.setVariable("logType", "TECHNICAL");
		break;
}

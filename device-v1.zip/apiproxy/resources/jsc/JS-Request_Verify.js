var sourceId = context.getVariable("req.sourceId");
var requestId = context.getVariable("req.requestId");
var idType = context.getVariable("req.idType");
var idValue = context.getVariable("req.idValue");

/****************************************************************/

if (isEmpty(sourceId)) {
    context.setVariable("exceptionName", "MissingSourceID");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingSourceID";
}

if (isEmpty(requestId)) {
    context.setVariable("exceptionName", "MissingRequestID");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Request ID");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingRequestID";
}

if (isEmpty(idType) || isEmpty(idValue)) {
    context.setVariable("exceptionName", "MissingIDTypeIDValue");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: ID Type or ID Value");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingIDTypeIDValue";
}

/****************************************************************/

var sourceIdlength = sourceId.length;
if (sourceIdlength > 8) {
    context.setVariable("exceptionName", "InvalidSourceID");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidSourceID";
}

var requestIdlength = requestId.length;
if (requestIdlength > 32) {
    context.setVariable("exceptionName", "InvalidRequestID");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Request ID");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidRequestID";
}

if (idType != "IMEI") {
    context.setVariable("exceptionName", "InvalidIDType");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Type");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidIDType";
}

var imeiLength = idValue.length;
if (imeiLength <= 32) {
    context.setVariable("imei", idValue);
} else {
    context.setVariable("exceptionName", "InvalidIDValue");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Value (Invalid IMEI format)");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidIDValue";
}

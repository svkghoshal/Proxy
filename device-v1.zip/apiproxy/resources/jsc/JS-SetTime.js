var system_timestamp = context.getVariable("system.timestamp");
context.setVariable("targetTimeStart", system_timestamp);

var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);

var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

if(reqVerb == "PUT")
    var apiNo = context.setVariable("apiNo","014");
else if (reqVerb == "GET")
     var apiNo = context.setVariable("apiNo","022");
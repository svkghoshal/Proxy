var reqVerb = context.getVariable("reqVerb");
context.setVariable("request.verb",reqVerb);
var backendResponseContent = context.getVariable("backendResponseContent");

print("backendResponse:" +backendResponseContent);
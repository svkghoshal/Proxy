  var transferee = context.getVariable("res.transfereeAcctChgList");
 var transferor = context.getVariable("res.transferorAcctChgList");

 if(!transferee)
    context.setVariable("res.transfereeAcctChgList", "[]");
 else
 {
    var jsonResponse = String(transferee).replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
    context.setVariable("res.transfereeAcctChgList",jsonResponse);
 }
 if(!transferor)
    context.setVariable("res.transferorAcctChgList", "[]");
 else
 {
    var jsonResponsePrimary = String(transferor).replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
    context.setVariable("res.transferorAcctChgList",jsonResponsePrimary);
 }
var invoiceInfoList = context.getVariable("res.invoiceInfoList");

if (!invoiceInfoList)
	context.setVariable("res.invoiceInfoList", "[]");
else {
	var jsonResponse = String(invoiceInfoList).replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
	context.setVariable("res.invoiceInfoList", jsonResponse);
}

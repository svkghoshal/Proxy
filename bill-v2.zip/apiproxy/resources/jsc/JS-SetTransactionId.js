var apiiNo;
var proxypath = context.getVariable('proxy.pathsuffix');
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
context.setVariable("req.transactionIdseq", transactionIdseq);

var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);
var api = context.getVariable('message.uri');

/*if (proxypath.match('/history'))
    context.setVariable("apiNo","019");
else if(proxypath.match('/info'))
    context.setVariable("apiNo","018");
else
    context.setVariable("apiNo","017");


*/
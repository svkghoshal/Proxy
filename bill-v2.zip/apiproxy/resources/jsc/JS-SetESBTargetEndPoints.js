var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var target;

if (proxypath.match('/history')) {
	target = 'cxf/PostpaidPaymentAndDepositPS';
	context.setVariable('targetPath', target);
} else if (proxypath.match('/info')) {
	target = '/cxf/QueryPostAcctinformationPS';
	context.setVariable('targetPath', target);
} 


var invoiceId = context.getVariable('req.invoiceId');
var year = context.getVariable('req.year');
var month = context.getVariable('req.month');


/*context.setVariable('req.invoiceId','1916987');*/
print("Invoice Id :"+invoiceId);
print("year :"+year);
print("month :"+month);



//string =context.getVariable("");


var apiNo = context.getVariable('apiNo');

if(isEmpty(invoiceId)){
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "500");
    context.setVariable("errorCode", "500."+apiNo+".101");
    context.setVariable("errorDesc", "Internal Server Error");
    context.setVariable("errorMessage", "Requested bill not found");
    throw "serviceException";
}



function isEmpty(input) {
    return (!input || 0 === input.length);
}

 
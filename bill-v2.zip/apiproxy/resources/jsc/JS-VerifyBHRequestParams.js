var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
var idValue = context.getVariable('req.idValue');
var apiNo = context.getVariable('apiNo');
var startDate = context.getVariable('req.startDate');
var endDate = context.getVariable('req.endDate');
var dateFormat = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;

context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionDateTime", transactionDateTime());
context.setVariable("transactionId", apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

if(startDate===null)
    context.setVariable("req.startDate","1900-01-01");
else if(startDate.match(dateFormat))
    {
        context.setVariable("test1","PASS");
        if(startDate>endDate)
        {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".101");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid Input");
	        throw "serviceException";
        }
    }
    else {
        context.setVariable("exceptionName", "exceptionName");
	    context.setVariable("httpError", "400");
	    context.setVariable("errorCode", "400."+apiNo+".101");
	    context.setVariable("errorDesc", "Bad Request");
	    context.setVariable("errorMessage", "Invalid Input.");
	    throw "serviceException";
    }

if(endDate===null)
    context.setVariable("req.endDate",ISODateString().substring(0,10));
else if(endDate.match(dateFormat))
        context.setVariable("test2","PASS");
    else {
        context.setVariable("exceptionName", "exceptionName");
	    context.setVariable("httpError", "400");
	    context.setVariable("errorCode", "400."+apiNo+".101");
	    context.setVariable("errorDesc", "Bad Request");
	    context.setVariable("errorMessage", "Invalid Input.");
	    throw "serviceException";
    }

if (isEmpty(idValue)) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("httpError", "400");
	context.setVariable("errorCode", "400."+apiNo+".101");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Invalid Input.");
	throw "serviceException";
}

function isEmpty(input) {
	return (!input || 0 === input.length);
}

function transactionDateTime() {
	var now = new Date(),
	pad = function (num) {
		var norm = Math.abs(Math.floor(num));
		return (norm < 10 ? '0' : '') + norm;
	};
	return now.getFullYear()
	 + pad(now.getMonth() + 1)
	 + pad(now.getDate())
	 + pad(now.getHours())
	 + pad(now.getMinutes())
	 + pad(now.getSeconds());
}

function ISODateString() {
	var now = new Date(),
	tzo = -now.getTimezoneOffset(),
	dif = tzo >= 0 ? '+' : '-',
	pad = function (num) {
		var norm = Math.abs(Math.floor(num));
		return (norm < 10 ? '0' : '') + norm;
	};
	return now.getFullYear()
	 + '-' + pad(now.getMonth() + 1)
	 + '-' + pad(now.getDate())
	 + 'T' + pad(now.getHours())
	 + ':' + pad(now.getMinutes())
	 + ':' + pad(now.getSeconds())
	 + dif + pad(tzo / 60)
	 + ':' + pad(tzo % 60);
}

function padLeadingZeros(input) {
	var step;
	var output = input;
	for (step = input.length; step < 6; step++)
		output = "0" + output;
	return output;
}

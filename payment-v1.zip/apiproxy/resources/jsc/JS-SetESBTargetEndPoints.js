 var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var target;

if(proxypath.match('/*/payment/history'))
{
    target = '/MyanmarTriumph/ProxyServices/PostpaidPaymentAndDeposit/1.0/PostpaidPaymentAndDeposit';
    context.setVariable('targetPath',target);
}
else 
    if (proxypath.match('/*/deposit/history'))
    {
        target = '/MyanmarTriumph/ProxyServices/PostpaidPaymentAndDeposit/1.0/PostpaidPaymentAndDeposit';
        context.setVariable('targetPath',target);
    }
else 
    if (proxypath.match('/*/bill/history'))
    {
        target = '/MyanmarTriumph/ProxyServices/PostpaidPaymentAndDeposit/1.0/PostpaidPaymentAndDeposit';
        context.setVariable('targetPath',target);
    }
else 
    if (proxypath.match('/*/bill/info'))
    {
        target = '/MyanmarTriumph/ProxyServices/QueryPostAcctinfo/1.0/QueryPostAcctinformationPS';
        context.setVariable('targetPath',target);
    }

var faultString = context.getVariable("res.faultString");
var statusCode = context.getVariable("res.resultCode");
var apiNo = context.getVariable('apiNo');

if(statusCode == "0")
    context.setVariable("Status","Success");
else{

	switch (statusCode) {

	case "1":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "400."+apiNo+".101");
		context.setVariable("errorDesc", "Bad Request");
		context.setVariable("errorMessage", "Badly formatted request");
		context.setVariable("httpError", "400");
		break;
	case "1008":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "400."+apiNo+".102");
		context.setVariable("errorDesc", "Bad Request");
		context.setVariable("errorMessage", "Bad Request");
		context.setVariable("httpError", "400");
		break;
	case "1011":
	case "1012":
	case "1013":
	case "1014":
	case "1015":
	case "1016":
	case "7":
	case "8":
	case "9":
	case "10":
	case "11":
	case "12":
	case "29":
	case "30":
	case "31":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "400."+apiNo+".003");
		context.setVariable("errorDesc", "Bad Request");
		context.setVariable("errorMessage", "Invalid Input");
		context.setVariable("httpError", "400");
		break;
	case "17":
	case "23":
	case "24":
	case "25":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "400."+apiNo+".004");
		context.setVariable("errorDesc", "Bad Request");
		context.setVariable("errorMessage", "Requested amount is invalid");
		context.setVariable("httpError", "400");
		break;
	case "46":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "400."+apiNo+".011");
		context.setVariable("errorDesc", "Bad Request");
		context.setVariable("errorMessage", "Amount requested was not within a valid range");
		context.setVariable("httpError", "400");
		break;
	case "52":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "400."+apiNo+".012");
		context.setVariable("errorDesc", "Bad Request");
		context.setVariable("errorMessage", "The requested device is already active");
		context.setVariable("httpError", "400");
		break;
	case "63":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "400."+apiNo+".016");
		context.setVariable("errorDesc", "Bad Request");
		context.setVariable("errorMessage", "Requested confirmation would potentially match multiple transactions");
		context.setVariable("httpError", "400");
		break;
	case "64":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "400."+apiNo+".017");
		context.setVariable("errorDesc", "Bad Request");
		context.setVariable("errorMessage", "Requesting Agent is not a Special Agent");
		context.setVariable("httpError", "400");
		break;
	case "74":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "400."+apiNo+".018");
		context.setVariable("errorDesc", "Bad Request");
		context.setVariable("errorMessage", "Invalid password mismatch");
		context.setVariable("httpError", "400");
		break;
	case "1001":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".005");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Insufficient funds");
		context.setVariable("httpError", "500");
		break;
	case "1002":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".006");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Transaction Recovered");
		context.setVariable("httpError", "500");
		break;
	case "1003":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".007");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Wallet Balance Exceeded");
		context.setVariable("httpError", "500");
		break;
	case "1004":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".008");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Wallet Cap Exceeded");
		context.setVariable("httpError", "500");
		break;
	case "1005":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".009");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Request Expired");
		context.setVariable("httpError", "500");
		break;
	case "1006":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".010");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "System Error");
		context.setVariable("httpError", "500");
		break;
	case "1007":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".011");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Database Error");
		context.setVariable("httpError", "500");
		break;
	case "1008":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".012");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Database Constraint Error");
		context.setVariable("httpError", "500");
		break;
	case "1009":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".013");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Record no found");
		context.setVariable("httpError", "500");
		break;
	case "3":
	case "4":
	case "5":
	case "6":
	case "13":
	case "14":
	case "15":
	case "16":
	case "19":
	case "20":
	case "22":
	case "26":
	case "27":
	case "28":
	case "35":
	case "54":
	case "55":
	case "56":
	case "57":
	case "58":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".014");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Invalid user");
		context.setVariable("httpError", "500");
		break;
	case "18":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".015");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "User is already registered");
		context.setVariable("httpError", "500");
		break;
	case "32":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".016");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "The original request has expired due to a timeout");
		context.setVariable("httpError", "500");
		break;
	case "33":
	case "34":
	case "36":
	case "37":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".017");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Transaction is not able to complete");
		context.setVariable("httpError", "500");
		break;
	case "41":
	case "42":
	case "43":
	case "44":
	case "45":
	case "42":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".018");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Error from Topup system");
		context.setVariable("httpError", "500");
		break;
	case "48":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".020");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "The supplied Billpay account is not valid");
		context.setVariable("httpError", "500");
		break;
	case "49":
	case "50":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".021");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Error from Bank");
		context.setVariable("httpError", "500");
		break;
	case "51":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".022");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Synchronization is not required at this time");
		context.setVariable("httpError", "500");
		break;
	case "59":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".026");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "User cannot use the requested wallet type");
		context.setVariable("httpError", "500");
	    break;
	case "60":
	case "61":
	case "62":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".027");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Schedule Payment failed");
		context.setVariable("httpError", "500");
		break;
	case "66":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".028");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Connection is offline");
		context.setVariable("httpError", "500");
		break;
	case "67":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".029");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Connection Error");
		context.setVariable("httpError", "500");
		break;
	case "68":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".030");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Operation not supported");
		context.setVariable("httpError", "500");
		break;
	case "69":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".031");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Agent has been misconfigured");
		context.setVariable("httpError", "500");
		break;
	case "70":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".032");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Agent still has transactions outstanding");
		context.setVariable("httpError", "500");
		break;
	case "71":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".033");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Agent is deleted");
		context.setVariable("httpError", "500");
		break;
	case "72":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".034");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Target is deleted");
		context.setVariable("httpError", "500");
		break;
	case "73":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".035");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Agent still has a non-zero balance");
		context.setVariable("httpError", "500");
		break;
	case "75":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".036");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Reversal Failed");
		context.setVariable("httpError", "500");
		break;
	case "76":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".037");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Group name already exists");
		context.setVariable("httpError", "500");
		break;
	case "77":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".038");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Group not empty");
		context.setVariable("httpError", "500");
		break;
	case "78":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".039");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Confirmer same as initiator");
		context.setVariable("httpError", "500");
		break;
	case "103":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".040");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Confirmation was rejected");
		context.setVariable("httpError", "500");
		break;
	case "560":
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".041");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Same amount, same number cannot topup within 2 minutes");
		context.setVariable("httpError", "500");
		break;
	default:
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500."+apiNo+".100");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage","Exception Occured :"+faultstring);
		context.setVariable("httpError", "500");
		break;

	}

}
 var payload = context.getVariable("res.invoiceInfoList");
 if(!payload)
    context.setVariable("res.invoiceInfoList", "[]");
 else
 {
    var jsonResponse = String(payload).replace(/~STR~/g, "").replace(/"~FEE~"/g, "[]").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
    context.setVariable("res.invoiceInfoList",jsonResponse);
 } 
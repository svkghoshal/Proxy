var idValue = context.getVariable("req.idValue");
var correlatorId = context.getVariable("req.correlatorId");
var totalAmount = context.getVariable("req.totalAmount");
var totalAmountunits = context.getVariable("req.totalAmountunits");
var channelId = context.getVariable("req.channelId");
var accountId = context.getVariable("req.accountId");
var accountPassCode = context.getVariable("req.accountPassCode");
var paymentMethodType = context.getVariable("req.paymentMethodType");
var paymentMethodService = context.getVariable("req.paymentMethodService");
var payerId = context.getVariable("req.payerId");

var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();

var apiNo = context.getVariable('apiNo');

context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionDateTime",transactionDateTime());
context.setVariable("transactionId", apiNo +transactionDateTime() + padLeadingZeros(transactionIdseq));
 
 if (isEmpty(idValue) || isEmpty(correlatorId) || isEmpty(totalAmount) || isEmpty(channelId)
|| isEmpty(totalAmountunits)|| isEmpty(accountId)|| isEmpty(accountPassCode)
|| isEmpty(paymentMethodType) || isEmpty(paymentMethodService)|| isEmpty(payerId)
|| (!idValue.startsWith("97") || (idValue.length != 10) 
|| (!payerId.startsWith("97") || (payerId.length != 10))))
 {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
 }


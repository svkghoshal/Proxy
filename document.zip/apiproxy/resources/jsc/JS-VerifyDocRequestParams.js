var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
var idValue = context.getVariable('req.idValue');
var apiNo = context.getVariable('apiNo');
var type=context.getVariable("req.type");

if(!isEmpty(type))
{
    var type=type.toLowerCase();
}

context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionDateTime", transactionDateTime());
context.setVariable("transactionId", apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

if (isEmpty(idValue) || isEmpty(type) || type != 'commission'
    || (!idValue.startsWith("97") || (idValue.length != 10) )) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("httpError", "400");
	context.setVariable("errorCode", "400."+apiNo+".101");
	context.setVariable("errorDesc", "Bad Request");
	context.setVariable("errorMessage", "Invalid Input.");
	throw "serviceException";
}
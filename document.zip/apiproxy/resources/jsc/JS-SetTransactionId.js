var apiNo=132;
var reqVerb = context.getVariable('request.verb');
var proxypath = context.getVariable('proxy.pathsuffix');
var transactionIdseq = context.getVariable("ratelimit.Q-TransactionSeq.used.count");
if(transactionIdseq === null)
{
    transactionIdseq=0;
}
context.setVariable("req.transactionIdseq", transactionIdseq);
context.setVariable("isoTimestamp", ISODateString());
context.setVariable("transactionId",apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));

var path = context.getVariable('message.path');
if(!isEmpty(path)) {
    path_variable_Array = path.split("/");
    
}

if (proxypath.match('/document/pdf'))
{
    context.setVariable("apiNo","132");
}
else{
    context.setVariable("apiNo","133");
}


if(path_variable_Array[1] != "v1" || path_variable_Array[2] != "mm"
 || path_variable_Array[3] != "en" ||path_variable_Array[4] != "documentManagement"
 || path_variable_Array[5] != "document" || reqVerb != "GET")
 {
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "404."+apiNo+".001");
	context.setVariable("errorDesc", "Resource not found");
	context.setVariable("errorMessage", "Resource not found/Invalid resource");
	context.setVariable("httpError", "404");
	throw "serviceException";
 }

var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);


context.setVariable("RequestPath","/"+path_variable_Array[1]
+"/"+path_variable_Array[2]+"/"+path_variable_Array[3]
+"/"+path_variable_Array[4]+"/"+path_variable_Array[5]
+"/pdf/"+path_variable_Array[6]+"?type=Commission");



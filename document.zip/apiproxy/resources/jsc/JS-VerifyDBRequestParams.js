var id=context.getVariable("req.idValue");
var type=context.getVariable("req.type");
 
 if(!isEmpty(type))
{
    var type=type.toLowerCase();
}

 var apiNo = context.getVariable('apiNo');

 
 var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
 context.setVariable("isoTimestamp", ISODateString());
 context.setVariable("transactionDateTime", transactionDateTime());
 context.setVariable("transactionId", apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));
 
if(isEmpty(id) || isEmpty(type)|| type != 'commission'
     || (!id.startsWith("97") || (id.length != 10) )) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input.");
    throw "serviceException";
}

/*var selectDate = year.concat(month, billDate);
context.setVariable("selectedDate", selectDate);
print("dateselectedDate"+selectDate);*/


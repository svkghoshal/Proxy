var targetStatus = context.getVariable("Status");
var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("faultString");
var faultMsg = context.getVariable("faultMessage");
var offerType = context.getVariable("req.offerType");
var list = context.getVariable("req.list");
var proxyPath = context.getVariable("proxy.pathsuffix");
var apiNo = context.getVariable('apiNo');

if (faultCode === null || (faultCode !== null && list == "subscribed" && offerType == "VAS"))
	context.setVariable("Status", "Success");
else if (faultMsg.toUpperCase().includes("OSB VALIDATE ACTION FAILED VALIDATION")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Invalid Input.");
	context.setVariable("httpError", "400");
} else if (faultMsg.toUpperCase().includes("OSB SERVICE CALLOUT ACTION RECEIVED AN ERROR RESPONSE")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Exception occurred at backend server.");
	context.setVariable("httpError", "500");
}  else
	if ((faultMsg !== null && faultMsg.includes("109") && proxyPath.includes("campaign"))) // || (faultString!==null && faultString.includes("No Data Found")))
		context.setVariable("Status", "Success");
	else {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500." + apiNo + ".101");
		context.setVariable("errorDesc", "Internal Server Error");
		if (faultMsg !== null && faultMsg != "null" && faultMsg.length > 0)
			context.setVariable("errorMessage", faultMsg);
		else
			context.setVariable("errorMessage", +faultString);
		context.setVariable("httpError", "500");
	}
 
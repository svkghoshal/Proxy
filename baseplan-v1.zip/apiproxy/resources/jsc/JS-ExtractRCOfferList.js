 var payload = context.getVariable("res.offerList");
 var basePlan = context.getVariable("res.basePlan");
 
 if(!payload)
    context.setVariable("res.offerList", "[]");
 else
 {
    var jsonResponse = String(payload).replace(/~STR~/g, "").replace(/"~FEE~"/g, "[]").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
    context.setVariable("res.offerList",jsonResponse);
 }
 
 if(!basePlan)
    context.setVariable("res.basePlan", "[]");
 else
 {
    var jsonResponsePrimary = String(basePlan).replace(/~STR~/g, "").replace(/"~FEE~"/g, "[]").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
    context.setVariable("res.basePlan",jsonResponsePrimary);
 }
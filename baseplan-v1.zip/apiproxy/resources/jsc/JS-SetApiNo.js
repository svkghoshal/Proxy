var apiNo;
var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);


	    if(reqVerb.equals("GET"))
			context.setVariable("apiNo","024");
        else
            if(reqVerb.equals("PUT"))
                context.setVariable("apiNo","009");

var accountType = context.getVariable("req.accountType");

if (accountType == "POSTPAID")
    context.setVariable("acctType", "3000");
else
    context.setVariable("acctType", "2000");

var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("res.faultString");
//var faultMsg = context.getVariable("faultMessage");
//var status_code= context.getVariable("response.status.code");
var statusCode = context.getVariable("res.resultCode");
var apiNo = context.getVariable('apiNo');

if(statusCode == "405000000")
    context.setVariable("Status","Success");
 else
    {
      if(faultString.toUpperCase().includes("THE ACCOUNT TYPE IS NOT FOUND"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".107");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The subscriber is not valid");
            context.setVariable("httpError", "500");
        } 
     else if(faultString.toUpperCase().includes("THE OPERATION IS NOT ALLOWED"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Invalid Input");
            context.setVariable("httpError", "400");
        }
     else if(faultString.toUpperCase().includes("THE TRANSFER AMOUNT IS INVALID"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Invalid Input");
            context.setVariable("httpError", "400");
        }
     else if(faultString.toUpperCase().includes("THE NUMBER SEGMENT ROUTING INFORMATION ABOUT THE SUBSCRIBER") || faultString.toUpperCase().includes("MUST BE EXIST IN THE SYSTEM"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".106");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The number segment route does not exist");
            context.setVariable("httpError", "500");
        }
     else if(faultString.toUpperCase().includes("INCORRECT NUMBER FORMAT"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Invalid Input");
            context.setVariable("httpError", "400");
        }
     else if(faultString.toUpperCase().includes("INSUFFICIENT BALANCE FOR ACCOUNT"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "In-sufficient Balance of Subscriber");
            context.setVariable("httpError", "500");
        }
    else if(faultString.toUpperCase().includes("THE MINIMUM TRANSFER AMOUNT AT A TIME IS NOT REACHED"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".102");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Transfer amount is less than minimum transfer amount allowed");
            context.setVariable("httpError", "500");
        }
    else if(faultString.toUpperCase().includes("THE MAXIMUM TRANSFER AMOUNT"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".103");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Transfer amount is more than maximum transfer amount allowed");
            context.setVariable("httpError", "500");
        }
    else if(faultString.toUpperCase().includes("THE MAXIMUM NUMBER OF TRANSFER TIMES FOR THE CURRENT DAY IS EXCEEDED"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".104");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Maximum transfer count allowed for current day exceeded");
            context.setVariable("httpError", "500");
        }
    else if(faultString.toUpperCase().includes("THE MAXIMUM TRANSFER AMOUNT FOR THE CURRENT DAY IS EXCEEDED"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".105");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Maximum transfer amount allowed for current day exceeded");
            context.setVariable("httpError", "500");
        }
    else
        {
                context.setVariable("exceptionName", "exceptionName");    
                context.setVariable("errorCode", "500."+apiNo+".100");
                context.setVariable("errorDesc", "Internal Server Error");
                context.setVariable("errorMessage", faultString);
                context.setVariable("httpError", "500");
        }
            
        } 
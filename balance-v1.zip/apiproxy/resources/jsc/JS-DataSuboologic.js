var storedResponse=context.getVariable("response");
context.setVariable("storedResponse",storedResponse);
var hideAccountList = context.getVariable("kvm.DataSuboo_offerids");
var DataSuboo_AccountType =context.getVariable("kvm.DataSuboo_AccountType");
var hideAccountArray = [];
var datasubooorderids='{"orderids":{"order":[{"orderid":"17112901"},{"orderid":"20140810"},{"orderid":"18101625"},{"orderid":"1234"},{"orderid":"1234"}]}} ';
var orderidObj=JSON.parse(datasubooorderids);
context.setVariable("orderidObj",datasubooorderids);
if(hideAccountList.length!==null) {
    hideAccountArray = hideAccountList.split(","); //KVM values(hideAccount) inserting in array
    
}

context.setVariable("hideAccountArray[]",hideAccountArray.toString());

//XElement acctount = new XElement("acctount");

// Walk array of hideAccountArray
var DatasubooOffer="";
var DatasubooOfferXML = "<?xml version='1.0' encoding='UTF-8'?><datasubooofferids>";


for (var count = 0 ; count < hideAccountArray.length; count ++)
{
  //XElement elm = new XElement("AcctId", data[count]);
  DatasubooOffer += "<offer><offerid>" + hideAccountArray[count] + "</offerid></offer>";
 // acctount.Add(elm);
}

DatasubooOfferXML +=  DatasubooOffer + "</datasubooofferids>";

//var oParser = new DOMParser();
//var oDOM = oParser.parseFromString(accountTypes, "text/xml");

//context.setVariable("accountTypes",accountTypes);
context.setVariable("DatasubooOfferXML",DatasubooOfferXML);

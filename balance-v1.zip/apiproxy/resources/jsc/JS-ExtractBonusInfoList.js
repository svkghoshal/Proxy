 var bonusInfo = context.getVariable("res.bonusInfo");

 if(!bonusInfo)
    context.setVariable("res.bonusInfo", "[]");
 else
 {
    var jsonResponsePrimary = String(bonusInfo).replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
    context.setVariable("res.bonusInfo",jsonResponsePrimary);
 }

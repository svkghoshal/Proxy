var targetStatus = context.getVariable("Status");
var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("faultString");
var faultMsg = context.getVariable("faultMessage");
var offerType = context.getVariable("req.offerType");
var list = context.getVariable("req.list");
var proxyPath = context.getVariable("proxy.pathsuffix");
var requestVerb = context.getVariable('reqVerb');
var apiNo = context.getVariable('apiNo');
// var campaignCode=""; 

// if(requestVerb=='GET')
// {
//     campaignCode="006";
// }
// else if(requestVerb=='POST')
// {
//     campaignCode="007";
// }
 
if(faultCode===null || (faultMsg!==null && (faultMsg.toUpperCase().includes("NO RECOMMEDATIONS") || faultMsg.toUpperCase().includes("RECOMMENDED REWARDS DO NOT SATISFY COST") || faultMsg.toUpperCase().includes("NO AVAILABLE OFFERS") || faultMsg.toUpperCase().includes("DID NOT FIND AVAILABLE OFFERS"))))
{
    context.setVariable("Status","Success");
}
else
{
    if(faultMsg.toUpperCase().includes("INCORRECT 12-DIGIT MSISDN"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Invalid input");
        context.setVariable("httpError", "400");
    }
    else if(faultMsg.toUpperCase().includes("MANDATORY REQUEST PARAMETER"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Invalid input");
        context.setVariable("httpError", "400");
    }
    else if(faultMsg.toUpperCase().includes("INCORRECT FORMAT OF PARAMETER"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Invalid input");
        context.setVariable("httpError", "400");
    }
    else if(faultMsg.toUpperCase().includes("INVALID OFFER SOURCE"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Invalid input");
        context.setVariable("httpError", "400");
    }
    else if(faultMsg.toUpperCase().includes("INVALID INCOMING PARAMETERS"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Invalid input");
        context.setVariable("httpError", "400");
    }
    else if(faultMsg.toUpperCase().includes("FAULT RESPONSE RECEIVED"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apiNo+".101");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Fault Response Received from Campaign System");
        context.setVariable("httpError", "500");
    }               
    else if(faultMsg.toUpperCase().includes("Timeout occurred while"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apiNo+".102");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Timeout occurred while action execution");
        context.setVariable("httpError", "500");
    }          
    else if(faultMsg.toUpperCase().includes("INTERNAL APPGW SERVER"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apiNo+".103");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Internal APPGW Server Error");
        context.setVariable("httpError", "500");
    }
    else if(faultMsg.toUpperCase().includes("RECO ENGINE TIMEOUT"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apiNo+".104");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "RECO ENGINE Timeout");
        context.setVariable("httpError", "500");
    }
    else if(faultMsg.toUpperCase().includes("WF_READ_CAMPAIGN_HISTORY SM RESPOND TIMEOUT "))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apiNo+".105");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Read Campaign History Response Timeout");
        context.setVariable("httpError", "500");
    }
    else if(faultMsg.toUpperCase().includes("UNABLE TO CREATE A SCANNER"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apiNo+".106");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Unable to create a Scanner");
        context.setVariable("httpError", "500");
    }
    else if(faultMsg.toUpperCase().includes("UNABLE TO FETCH DATA"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apiNo+".107");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Unable to fetch Data");
        context.setVariable("httpError", "500");
    }
    else if(faultMsg.toUpperCase().includes("UNABLE TO CONNECT TO A SERVER"))
    {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apiNo+".108");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", "Unable to connect to Server");
        context.setVariable("httpError", "500");
    }
    else
    {
        context.setVariable("exceptionName", "exceptionName");    
        context.setVariable("errorCode", "500."+apiNo+".100");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", faultMsg);
        context.setVariable("httpError", "500");
    }
}
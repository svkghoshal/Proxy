var verb = context.getVariable('request.verb')
if (verb == "POST")
{
    context.setVariable("action", "ADD");
} else 
{
    context.setVariable("action", "DELETE");
}
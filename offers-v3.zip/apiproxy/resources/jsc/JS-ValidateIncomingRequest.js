print("JS-ValidateIncoingRequest");

// var key1 = "TEB1Th9AYAWTS93MY";
var key = context.getVariable("key");
print("Key :;" +key);
var idValue = context.getVariable('req.idValue');
print("MSISDN Value Encode ::"+idValue);
context.setVariable("encrypt_msisdn", idValue);  
var decode_msisdn = decodeURIComponent(idValue);
print("encrypt_msisdn:: "+decode_msisdn);
var msisdn = rc4(key, decode64(decode_msisdn));
print("MSISDN Value  ::"+msisdn);

// If msisdn starts with 95 then we need to remove the leading 95 from msisdn.

if (msisdn.startsWith("95")) {
    msisdn = msisdn.substring(2);
    print(" Revised MSISDN ::"+msisdn);
}
context.setVariable('req.idValue', msisdn);


var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var list = context.getVariable('req.list');
var offerType = context.getVariable('req.offerType');
var target;

if(list===null)
    list='';
    
if(reqVerb=='GET' && proxypath.match('/campaign'))
{
    if(list.equals("subscribed"))
    {
        //target = '/CampaignHistorySyncPS?wsdl';
        target = '/CampaignHistorySyncPS';
        context.setVariable('targetPath',target);
    }
    else
    {
        
        //target = '/cxf/proxy/campaign';
        target = '/CampaignAvailableOfferSyncPS';
        context.setVariable('targetPath',target);
    }
}
else if(reqVerb=='POST' && proxypath.match('/campaign/*'))
    {
        //target = '/CapaignOptInSyncPS?wsdl ';
        target = '/CapaignOptInSyncPS';
        context.setVariable('targetPath',target);
    }
else if(reqVerb=='GET')
        {
            if(offerType=='VAS' && list.equals("subscribed")){
                target = '/cxf/VASSubscriptionDetailsSyncPS';
                //target ='/VASSubscriptiondetails/PS/VASSubscriptiondetailsPS';
            }
            else {
                target = '/cxf/PrepaidAccountSyncPSMyTelenorAPP';
                //target ='/PrepaidAccount/PS/PrepaidAccountSyncPS';
                
            }
            print("target :"+target);
            context.setVariable('targetPath',target);
        }
else if ((reqVerb=='POST' || reqVerb=='DELETE'))
            {
                target = '/cxf/ManageOfferSyncPS';
                //target ="/MyanmarTriumph/ProxyServices/ManageOffer/1.0/ManageOfferSyncPS";
                context.setVariable('targetPath',target);
            }

var RequestBody = context.getVariable("message.content");

context.setVariable("merchantKeyId", "08c94330-f618-42a3-b09d-e1e43be5efda");
context.setVariable("merchantsecretKey", "yBJxy6LjM2TmcPGu+GaJrHtkke25fPpUX+UY6/L/1tE=");
context.setVariable("merchantId", "testrest");
context.setVariable("requestHost", "apitest.cybersource.com");
context.setVariable("USER_AGENT", "Mozilla/5.0");
context.setVariable("postRequestTarget", "post /pts/v2/payments");
context.setVariable("APINAME", "payments");
context.setVariable("resource", "/pts/v2/payments");
context.setVariable("payload", RequestBody);

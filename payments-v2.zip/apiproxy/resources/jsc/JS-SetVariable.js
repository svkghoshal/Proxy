var sourceId = context.getVariable("req.sourceId");
context.setVariable("req.sourceId", sourceId);

var idType = context.getVariable("req.idType");
context.setVariable("req.idType", idType);

var idValue = context.getVariable("req.idValue");
context.setVariable("req.idValue", idValue);

var correlationId = context.getVariable("req.correlationId");
context.setVariable("req.correlationId", correlationId);

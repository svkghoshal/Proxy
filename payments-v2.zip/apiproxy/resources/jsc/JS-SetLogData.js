var statusCode = context.getVariable("statusCode");

// Request URI from external client
var uriRequest = context.getVariable("clientUriRequest");
var clientUriRequest = uriRequest;
context.setVariable("clientUriRequest", clientUriRequest);

// Request Body from external Client
// CLIENT_REQUEST
var bodyRequest = context.getVariable("clientBodyRequest");
try {
    var clientBodyParse = JSON.parse(bodyRequest);
    var clientBodyRequest = JSON.stringify(clientBodyParse);
    context.setVariable("clientBodyRequest", clientBodyRequest);
} catch (err) {
    context.setVariable("clientBodyRequest_error", err);
}

// If Body is empty, use URI as Body request
if (isEmpty(bodyRequest)) {
    context.setVariable("clientBodyRequest", clientUriRequest);
}

// Response body to external client
// CLIENT_RESPONSE
var bodyResponse = context.getVariable("clientBodyResponse");
try {
    var clientBodyParse = JSON.parse(bodyResponse);
    var clientBodyResponse = JSON.stringify(clientBodyParse);
    context.setVariable("clientBodyResponse", clientBodyResponse);
} catch (err) {
    context.setVariable("clientBodyResponse_error", err);
}

/****************************************************************/

// If request is OK, do not need to log target payloads (to save space!)
if (statusCode == "1") {
    context.setVariable("HeadersRequestFull", "OK");
    context.setVariable("HeadersResponseFull", "OK");
    context.setVariable("targetEndpoint", "OK");
    context.setVariable("targetPayloadRequest", "OK");
    context.setVariable("targetPayloadResponse", "OK");
} else {
    // Target endpoint
    var targetScheme = context.getVariable("target.scheme");
    var targetHost = context.getVariable("target.host");
    var targetPort = context.getVariable("target.port");
    var targetUrl = context.getVariable("targetUrl");
    var backendRequestVerb = context.getVariable("backendRequestVerb");
    var backendRequestQueryString = context.getVariable("backendRequestQueryString");
    if (!isEmpty(targetHost) && !isEmpty(targetUrl)) {
        var targetEndpoint = backendRequestVerb+"|"+targetScheme+"://"+targetHost+":"+targetPort+targetUrl+((!isEmpty(backendRequestQueryString))?"?"+backendRequestQueryString:"");
    } else {
        var targetEndpoint = "N/A";
    }
    context.setVariable("targetEndpoint", targetEndpoint);
    
    // Request payload to target/downstream
    // TARGET_REQUEST
    // Charge: CPA (SOAP/XML)
    // Refund: CSG2.0 (REST/JSON)
    var bck_req_content = context.getVariable("backendRequestContent");
    if (!isEmpty(bck_req_content)) {
        try {
            // Content is JSON
            var targetPayloadParse = JSON.parse(bck_req_content);
            var targetPayloadRequest = JSON.stringify(targetPayloadParse);
        } catch (err) {
            // Content is XML
            var targetPayloadRequest = xml2flat(bck_req_content);
        }
        context.setVariable("targetPayloadRequest", targetPayloadRequest);
    } else {
        context.setVariable("targetPayloadRequest", "N/A");
    }
    
    // Response payload from target/downstream
    // TARGET_RESPONSE
    var bck_res_content = context.getVariable("revisedResponse");
    if (!isEmpty(bck_res_content)) {
        try {
            var targetPayloadResponse = "";
            
            // If content is empty, get information from Headers instead
            if (bck_res_content == "{}") {
                var responseHeaderNames = context.getVariable("response.headers.names");
                var responseHeaderCount = context.getVariable("response.headers.count");
                try {
                    var resHeaderArr = responseHeaderNames.toArray();
                    var resHeaderVal = new Array();
                    for (var i=0; i<responseHeaderCount; i++) {
                        var n = resHeaderArr[i];
                        var a = context.getVariable("response.header."+n+".values").toArray();
                        var v = a.join(",");
                        var s = n+"="+v;
                        resHeaderVal.push(s);
                        
                        // For debugging purpose
                        //context.setVariable("response_"+n, v);
                    }
                    targetPayloadResponse = resHeaderVal.join("|");
                } catch (err) {
                    // Do nothing
                }
            } else {
                // Content is JSON
                // If not JSON, will throw exception
                var targetPayloadParse = JSON.parse(bck_res_content);
                var targetPayloadResponse = JSON.stringify(targetPayloadParse);
            }
            context.setVariable("targetPayloadResponse", targetPayloadResponse);
        } catch (err) {
            // Content is not JSON, assume it's XML
            var targetPayloadResponse = xml2flat(bck_res_content);
            context.setVariable("targetPayloadResponse", targetPayloadResponse);
        }
    } else {
        context.setVariable("targetPayloadResponse", "N/A");
    }
    
    // Extract Headers (request)
    var reqHeaderNames = context.getVariable("request.headers.names");
    var reqHeaderCount = context.getVariable("request.headers.count");
    try {
        var reqHeaderArr = reqHeaderNames.toArray();
        var reqHeaderVal = new Array();
        for (var i=0; i<reqHeaderCount; i++) {
            var n = reqHeaderArr[i];
            var a = context.getVariable("request.header."+n+".values").toArray();
            var v = a.join(",");
            context.setVariable("HeadersRequest_"+n, v);
            
            var s = n+"="+v;
            reqHeaderVal.push(s);
        }
        context.setVariable("HeadersRequestFull", reqHeaderVal.join("|"));
    } catch (err) {
        context.setVariable("HeadersRequestFull", "N/A");
    }
    
    // (Workaround) If targetEndpoint is not set, then header still be not available as well
    if (targetEndpoint == "N/A") {
        context.setVariable("HeadersRequestFull", "N/A");
    }
    
    // Extract Headers (response)
    var resHeaderNames = context.getVariable("response.headers.names");
    var resHeaderCount = context.getVariable("response.headers.count");
    try {
        var resHeaderArr = resHeaderNames.toArray();
        var resHeaderVal = new Array();
        
        // Set response status code and reason
        var TargetStatusCode = context.getVariable("TargetStatusCode");
        var TargetStatusReason = context.getVariable("TargetStatusReason");
        var StatusCode = "StatusCode="+TargetStatusCode;
        var StatusReason = "StatusReason="+TargetStatusReason;
        resHeaderVal.push(StatusCode);
        resHeaderVal.push(StatusReason);
        
        for (var i=0; i<resHeaderCount; i++) {
            var n = resHeaderArr[i];
            var a = context.getVariable("response.header."+n+".values").toArray();
            var v = a.join(",");
            context.setVariable("HeadersResponse_"+n, v);
            
            var s = n+"="+v;
            resHeaderVal.push(s);
        }
        context.setVariable("HeadersResponseFull", resHeaderVal.join("|"));
    } catch (err) {
        context.setVariable("HeadersResponseFull", "N/A");
    }
}
// End statusCode check

/****************************************************************/

// Check if request is new or cached
var isResponseCache = false;
var pathSuffix = context.getVariable("proxy.pathsuffix");

if (pathSuffix == "/refund") {
    if (context.getVariable("environment.name") == "production") {
        var isResponseCache = context.getVariable("responsecache.RC-CacheRefundResponse.cachehit");
    } else {
        if (context.getVariable("envTarget") == "PRODUCTION") {
            var isResponseCache = context.getVariable("responsecache.RC-CacheRefundResponseSandboxProd.cachehit");
        } else {
            var isResponseCache = context.getVariable("responsecache.RC-CacheRefundResponseSandboxPreProd.cachehit");
        }
    }
} else {
    // For /charge, /reserve, /commit
    if (context.getVariable("environment.name") == "production") {
        var isResponseCache = context.getVariable("responsecache.RC-CacheChargeResponse.cachehit");
    } else {
        var isResponseCache = context.getVariable("responsecache.RC-CacheChargeResponseSandbox.cachehit");
    }
}

if (isResponseCache === true) {
    context.setVariable("isResponseCache", "1");
} else {
    context.setVariable("isResponseCache", "0");
}

/****************************************************************/

// Calculate the total elapsed time
// Time request is received from client to time response is sent back to client
var client_start = context.getVariable("client.received.start.timestamp");
var system_timestamp = context.getVariable("system.timestamp");
var totalElapsedTime = context.setVariable("totalElapsedTime", ""+(system_timestamp-client_start));

var targetElapsedTime = context.getVariable("targetElapsedTime");
if (!targetElapsedTime) {
    context.setVariable("targetElapsedTime", "X");
}

var RefundProfile = context.getVariable("SC_RefundProfile_elapsed");
if (!RefundProfile) {
    context.setVariable("SC_RefundProfile_elapsed", "X");
}

var SBPRefundVerify = context.getVariable("SC_SBPRefundVerify_elapsed");
if (!SBPRefundVerify) {
    context.setVariable("SC_SBPRefundVerify_elapsed", "X");
}

var SBPRefundUpdate = context.getVariable("SC_SBPRefundUpdate_elapsed");
if (!SBPRefundUpdate) {
    context.setVariable("SC_SBPRefundUpdate_elapsed", "X");
}

/****************************************************************/

// For SC-StatCollector
var statStatusCode = (context.getVariable("statusCode") == "1") ? "OK" : "FAIL";
var statErrorCode = context.getVariable("errorCode");
var statErrorMessage = context.getVariable("errorMessage");
context.setVariable("statStatusCode", statStatusCode);
context.setVariable("statErrorCode", statErrorCode);
context.setVariable("statErrorMessage", statErrorMessage);

// Return the backend environment as Header for Sandbox
var envType = context.getVariable("envType");
var envTarget = context.getVariable("envTarget");
var rmp_ip = context.getVariable("system.interface.ens192");
if (envType != "PRODUCTION") {
    context.setVariable("message.header.Backend-Environment", envTarget);
    switch (rmp_ip) {
        case "10.88.1.20":
            var rmp_hostname = "a0110papirmp01";
            break;
        case "10.88.1.21":
            var rmp_hostname = "a0110papirmp02";
            break;
        default:
            var rmp_hostname = rmp_ip;
    }
    context.setVariable("message.header.Router-Message-Processor", rmp_hostname);
}

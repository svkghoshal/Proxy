// Log the timestamp for Service Callout lapse time calculation
var systemTimestamp = context.getVariable("system.timestamp");
context.setVariable("serviceCalloutTimestamp", systemTimestamp);

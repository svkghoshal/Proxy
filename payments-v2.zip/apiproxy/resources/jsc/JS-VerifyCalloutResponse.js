var callresp = context.getVariable("calloutSBP.content");

if (callresp != "OK" && callresp === "") {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("errorCode", "500.004.013");
    context.setVariable("errorDesc", "Internal Server Error");
    context.setVariable("errorMessage", "Internal Server Error: SBP Verification Failed");
    context.setVariable("httpError", "500");
    throw "InternalServerErrorSBP";
}

var faultName = context.getVariable("fault.name");
var sourceId = context.getVariable("req.sourceId");
var transactionId = context.getVariable("transactionId");

// Set the timestamp if there's an error
context.setVariable("isoTimestamp", ISODateString());

if (isEmpty(transactionId)) {
    var transactionIdSeq = randomString(6);
    context.setVariable("transactionIdSeq", transactionIdSeq);
    context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);
}

// Set target response code
var TargetStatusCode = context.getVariable("response.status.code");
var TargetStatusReason = context.getVariable("response.reason.phrase");
context.setVariable("TargetStatusCode", TargetStatusCode);
context.setVariable("TargetStatusReason", TargetStatusReason);

/**********************************************************************/

// Get ServiceCallout elapsed time
var serviceCalloutTimestamp = context.getVariable("serviceCalloutTimestamp");
var systemTimestamp = context.getVariable("system.timestamp");
if (serviceCalloutTimestamp !== null) {
    var serviceCalloutElapsed = ""+(systemTimestamp-serviceCalloutTimestamp);
    context.setVariable("serviceCalloutElapsed", serviceCalloutElapsed);
}

// One of these ServiceCallouts failed
var RefundProfile = context.getVariable("servicecallout.SC-RefundProfile.failed");
var RefundProfilePreProd = context.getVariable("servicecallout.SC-RefundProfilePreProd.failed");
var SBPRefundVerify = context.getVariable("servicecallout.SC-SBPRefundVerify.failed");
var SBPRefundUpdate = context.getVariable("servicecallout.SC-SBPRefundUpdate.failed");
if (RefundProfile === true || RefundProfilePreProd === true) {
    context.setVariable("SC_RefundProfile_elapsed", serviceCalloutElapsed);
}
if (SBPRefundVerify === true) {
    context.setVariable("SC_SBPRefundVerify_elapsed", serviceCalloutElapsed);
}
if (SBPRefundUpdate === true) {
    context.setVariable("SC_SBPRefundUpdate_elapsed", serviceCalloutElapsed);
}

/**********************************************************************/

switch (faultName) {
    case "RaiseFault":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "404.004.001");
        context.setVariable("errorDesc", "Resource Not Found");
        context.setVariable("errorMessage", "Resource not found/Invalid resource");
        context.setVariable("httpError", "404");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    case "ServiceUnavailable":
    case "ErrorResponseCode":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "503.004.101");
        context.setVariable("errorDesc", "Service Unavailable");
        context.setVariable("errorMessage", "The service is unavailable ("+faultName+")");
        context.setVariable("httpError", "503");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "GatewayTimeout":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "504.004.102");
        context.setVariable("errorDesc", "Gateway Timeout");
        context.setVariable("errorMessage", "The service is unavailable");
        context.setVariable("httpError", "504");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    case "RequestTimeout":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "408.004.103");
        context.setVariable("errorDesc", "Request Timeout");
        context.setVariable("errorMessage", "The service is unavailable");
        context.setVariable("httpError", "408");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    case "SpikeArrestViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429.004.002");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Spike arrest violation");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "QuotaViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429.004.003");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Quota limit exceeded");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
    
    case "ConcurrentRatelimtViolation":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "429.004.004");
        context.setVariable("errorDesc", "Too Many Requests");
        context.setVariable("errorMessage", "Concurrent rate limit connection exceeded");
        context.setVariable("httpError", "429");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    case "ExecutionFailed":
        var servicecall = context.getVariable("ServiceCallout.response");
        var servicecallCode = context.getVariable("message.status.code");
        
        switch (servicecall) {
            case "Already refunded":
                context.setVariable("exceptionName", "exceptionName");
                context.setVariable("errorCode", "400.004.024");
                context.setVariable("errorDesc", "Bad Request");
                context.setVariable("errorMessage", "This Transaction ID has already been refunded (409)");
                context.setVariable("httpError", "400");
                context.setVariable("logType", "BUSINESS");
                break;
            case "No transaction found":
                context.setVariable("exceptionName", "exceptionName");
                context.setVariable("errorCode", "400.004.023");
                context.setVariable("errorDesc", "Bad Request");
                context.setVariable("errorMessage", "Subscriber/Transaction ID not found (404)");
                context.setVariable("httpError", "400");
                context.setVariable("logType", "BUSINESS");
                break;
            case "Refund value exceed":
                context.setVariable("exceptionName", "exceptionName");
                context.setVariable("errorCode", "400.004.022");
                context.setVariable("errorDesc", "Bad Request");
                context.setVariable("errorMessage", "Refund value exceeded the transaction price value (403)");
                context.setVariable("httpError", "400");
                context.setVariable("logType", "BUSINESS");
                break;
            default:
                if (servicecallCode == "500") {
                    // Check which Service Callout is causing the timeout
                    var envTarget = context.getVariable("envTarget");
                    if (envTarget == "PREPRODUCTION") {
                        var scCsgProfile = context.getVariable("servicecallout.SC-RefundProfilePreProd.failed");
                    } else {
                        var scCsgProfile = context.getVariable("servicecallout.SC-RefundProfile.failed");
                    }
                    var scSbpVerify = context.getVariable("servicecallout.SC-SBPRefundVerify.failed");
                    var scSbpUpdate = context.getVariable("servicecallout.SC-SBPRefundUpdate.failed");
                    
                    var errorMessage = "The service is unavailable (Callout Timeout)";
                    if (scCsgProfile === true) {
                        errorMessage = "The service is unavailable (Callout Timeout) (Profile)";
                    }
                    if (scSbpVerify === true) {
                        errorMessage = "The service is unavailable (Callout Timeout) (Verify)";
                    }
                    if (scSbpUpdate === true) {
                        errorMessage = "The service is unavailable (Callout Timeout) (Update)";
                    }
                    
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "503.004.101");
                    context.setVariable("errorDesc", "Service Unavailable");
                    context.setVariable("errorMessage", errorMessage);
                    context.setVariable("httpError", "503");
                    context.setVariable("logType", "TECHNICAL");
                } else {
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500.004.013");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", " Internal Server Error: " + faultName);
                    context.setVariable("httpError", "500");
                    context.setVariable("logType", "TECHNICAL");
                }
        }
        break;   
        
    case "access_token_expired":
    case "invalid_access_token":
    case "InvalidAccessToken":
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "401.004.006");
        context.setVariable("errorDesc", "Unauthorized");
        context.setVariable("errorMessage", "Access token is invalid or expired");
        context.setVariable("httpError", "401");
        context.setVariable("logType", "TECHNICAL");
        break;
        
    default:
		context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500.004.007");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", "Internal Server Error: " + faultName);
		context.setVariable("httpError", "500");
		context.setVariable("logType", "TECHNICAL");
		break;
}

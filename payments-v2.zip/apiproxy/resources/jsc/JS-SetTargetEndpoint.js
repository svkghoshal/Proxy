var pathSuffix = context.getVariable("proxy.pathsuffix");
var target;

switch (pathSuffix) {
    case "/charge":
        target = "/billing/services/SDPValidateBill";
        context.setVariable("targetUrl", target);
        break;
    case "/reserve":
        target = "/billing/services/SDPValidateBill";
        context.setVariable("targetUrl", target);
        break;
    case "/commit":
        target = "/billing/services/SDPValidateBill";
        context.setVariable("targetUrl", target);
        break;
    case "/refund":
        // These are already set in Target Endpoints
        target = "/cxf/v1/brm/accountAdjustment";
        context.setVariable("targetUrl", target);
        break;
    default:
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "404");
    	context.setVariable("errorCode", "404.004.001");
        context.setVariable("errorDesc", "Resource not found.");
        context.setVariable("errorMessage", "Resource not found/Invalid resource");
        context.setVariable("logType", "TECHNICAL");
        throw "ResourceNotFound";
}

// Get ServiceCallout elapsed time
var serviceCalloutTimestamp = context.getVariable("serviceCalloutTimestamp");
var systemTimestamp = context.getVariable("system.timestamp");
if (serviceCalloutTimestamp !== null) {
    var serviceCalloutElapsed = ""+(systemTimestamp-serviceCalloutTimestamp);
    context.setVariable("serviceCalloutElapsed", serviceCalloutElapsed);
}

// If the elapsed time has been set, do not set again
var SC_RefundProfile_elapsed = context.getVariable("SC_RefundProfile_elapsed");
var SC_SBPRefundVerify_elapsed = context.getVariable("SC_SBPRefundVerify_elapsed");
var SC_SBPRefundUpdate_elapsed = context.getVariable("SC_SBPRefundUpdate_elapsed");

// Check which ServiceCallout is called last
var RefundProfile = context.getVariable("servicecallout.SC-RefundProfile.failed");
var RefundProfilePreProd = context.getVariable("servicecallout.SC-RefundProfilePreProd.failed");
var SBPRefundVerify = context.getVariable("servicecallout.SC-SBPRefundVerify.failed");
var SBPRefundUpdate = context.getVariable("servicecallout.SC-SBPRefundUpdate.failed");
if (!SC_RefundProfile_elapsed && (RefundProfile === false || RefundProfilePreProd === false)) {
    context.setVariable("SC_RefundProfile_elapsed", serviceCalloutElapsed);
}
if (!SC_SBPRefundVerify_elapsed && SBPRefundVerify === false) {
    context.setVariable("SC_SBPRefundVerify_elapsed", serviceCalloutElapsed);
}
if (!SC_SBPRefundUpdate_elapsed && SBPRefundUpdate === false) {
    context.setVariable("SC_SBPRefundUpdate_elapsed", serviceCalloutElapsed);
}

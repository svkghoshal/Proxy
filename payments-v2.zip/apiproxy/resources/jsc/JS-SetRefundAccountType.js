// For debugging purpose
/*
var profileContent = context.getVariable("calloutProfile.content");
var profileHeaderNames = context.getVariable("calloutProfile.headers.names");
var profileHeaderCount = context.getVariable("calloutProfile.headers.count");
try {
    var resHeaderArr = profileHeaderNames.toArray();
    var resHeaderVal = new Array();
    for (var i=0; i<profileHeaderCount; i++) {
        var n = resHeaderArr[i];
        var a = context.getVariable("calloutProfile.header."+n+".values").toArray();
        var v = a.join(",");
        context.setVariable("CalloutProfileHeader_"+n, v);
        
        var s = n+"="+v;
        resHeaderVal.push(s);
    }
    context.setVariable("CalloutHeaderFull", resHeaderVal.join("|"));
} catch (err) {
    context.setVariable("CalloutHeaderFull", "N/A");
}
*/

var payType = context.getVariable("req.payType");
var csgStatusCode = context.getVariable("csgStatusCode");
var csgErrorCode = context.getVariable("csgErrorCode");
var csgErrorDescription = context.getVariable("csgErrorDescription");

// If Profile (via CSG) request is failed, return error
// Note:
// - If payType is passed in as parameter, callout to Profile (via CSG) is not required
// - If payType is empty, checking is not required
if (csgStatusCode != "Successful" && isEmpty(payType)) {
    switch (csgErrorCode) {
        case "CRM:00009":
        case "CRM:60010":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.014");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Subscriber not found (" + csgErrorCode + ")");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            throw "SubscriberNotFound";
            break;
        default:
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.004.012");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Internal Server Error: " + csgErrorCode);
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
            throw "InternalServiceError";
    }
}

if (payType == "PREPAID") {
    var AccountType = context.setVariable("accountType", "2000");
} else if (payType == "POSTPAID") {
    var AccountType = context.setVariable("accountType", "3000");
} else {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.004.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Pay Type");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidPayType";
}

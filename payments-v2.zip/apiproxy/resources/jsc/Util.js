function isEmpty(input) {
    return (!input || 0 === input.length);
}

function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear()
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes())
        + ':' + pad(now.getSeconds())
        + dif + pad(tzo / 60)
        + ':' + pad(tzo % 60);
}

function transactionDateTime() {
    var now = new Date(),
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear()
        + pad(now.getMonth()+1)
        + pad(now.getDate())
        + pad(now.getHours())
        + pad(now.getMinutes())
        + pad(now.getSeconds());
}

function randomString(length) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for(var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}

function extractSourceId(input) {
    input = (isEmpty(input)) ? "UNK" : input;
	var newSourceId = input.substring(0, 3);
	return newSourceId;
}

// Flatten the payload into a single line
function xml2flat(str) {
    str = str.replace(/>\s*/g, '>');  // Remove space after >
    str = str.replace(/\s*</g, '<');  // Remove space before <
    str = str.replace(/[\n\r]/g, ''); // Remove all newlines
    return str;
}

function padLeadingZeros(input) {
    var step;
    var output=input;
    if (output.length<=6) {
        for (step=input.length; step <6; step++) {
            output="0"+output;
        }
    } else {
        output=output.substr(-6);
    }
    return output;
}

function getTargetStartTime() {
    if (isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.sent.start.timestamp"));
    }
}

function getTargetEndTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp"))) {
        return "";
    } else {
        return getTimePattern(context.getVariable("target.received.end.timestamp"));
    }
}

function getTargetElaspedTime() {
    if (isEmpty(context.getVariable("target.received.end.timestamp")) || isEmpty(context.getVariable("target.sent.start.timestamp"))) {
        return "";
    } else {
        var targetElapsedTime = context.getVariable("target.received.end.timestamp") - context.getVariable("target.sent.start.timestamp");
        return "" + targetElapsedTime;
    }
}

function getTimePattern(dateTime) {
    var today = new Date(dateTime);
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second + "," + milliSecond;
}

function checkLengthDateFormat(today) {
    if (today.length == 1) {
        today = "0" + today;
    }
    return today;
}

function generateNonce(length) {
    var nonceChars = "0123456789abcdef";
    var result = "";
    for (var i = 0; i < length; i++) {
        result += nonceChars.charAt(Math.floor(Math.random() * nonceChars.length));
    }
    return result;
}

function getW3CDate(date) {
    var yyyy = date.getUTCFullYear();
    var mm = (date.getUTCMonth() + 1);
    if (mm < 10) mm = "0" + mm;
    var dd = (date.getUTCDate());
    if (dd < 10) dd = "0" + dd;
    var hh = (date.getUTCHours());
    if (hh < 10) hh = "0" + hh;
    var mn = (date.getUTCMinutes());
    if (mn < 10) mn = "0" + mn;
    var ss = (date.getUTCSeconds());
    if (ss < 10) ss = "0" + ss;
    return yyyy+"-"+mm+"-"+dd+"T"+hh+":"+mn+":"+ss+"Z";
}

function isInteger(value) {
    var x;
    return isNaN(value) ? !1 : (x = parseFloat(value), (0 | x) === x);
}

function matchExact(r, str) {
   var match = str.match(r);
   return match !== null && str == match[0];
}

function padWithZero(number, strLength) {
    var newString = '' + number;
    while (newString.length < strLength) {
        newString = '0' + newString;
    }
    return newString;
}

/* Convert special characters into acceptable values */
function escapeHtml(text) {
	var map = {
		'&': '&amp;',
		'<': '&lt;',
		'>': '&gt;',
		'"': '&quot;',
		"'": '&#039;'};
	return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

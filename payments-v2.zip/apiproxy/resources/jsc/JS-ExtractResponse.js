var response = context.getVariable("backendResponseContent");
var resource = context.getVariable("proxy.pathsuffix");

if (resource != "/refund") {
    // CPA response appended some text to payload
    var start = response.indexOf("soap:Envelope");
    var end = response.lastIndexOf("soap:Envelope");
    var revisedResponse = response.substring(start-1, end+14);
    
    context.setVariable("revisedResponse", revisedResponse);
} else {
    // CSG response (AdjustAccount)
    context.setVariable("revisedResponse", response);
}

// Set the timestamp after receiving response from target
context.setVariable("isoTimestamp", ISODateString());

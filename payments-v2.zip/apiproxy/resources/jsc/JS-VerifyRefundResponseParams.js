var status_code = context.getVariable("csgStatusCode");
var error_code = context.getVariable("csgErrorCode");
var error_description = context.getVariable("csgErrorDescription");
var error_more = context.getVariable("csgErrorMore");

// If CSG2.0 cache is empty, it means CSG1.0 cache is still valid
if (isEmpty(status_code) && isEmpty(error_code) && isEmpty(error_description)) {
    var status_code = context.getVariable("csg1StatusCode");
    var error_code = context.getVariable("csg1ErrorCode");
    var error_description = context.getVariable("csg1ErrorDescription");
}

// Populate the transactionId if it's empty
var sourceId = context.getVariable("req.sourceId");
var transactionId = context.getVariable("transactionId");
if (isEmpty(transactionId)) {
    var transactionIdSeq = randomString(6);
    context.setVariable("transactionIdSeq", transactionIdSeq);
    context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);
}

// Set target response code
var TargetStatusCode = context.getVariable("response.status.code");
var TargetStatusReason = context.getVariable("response.reason.phrase");
context.setVariable("TargetStatusCode", TargetStatusCode);
context.setVariable("TargetStatusReason", TargetStatusReason);

/**********************************************************************/

// Target Elapse Time
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());

// Target Elapsed Time
context.setVariable("targetElapsedTime", getTargetElaspedTime());

/**********************************************************************/

if (status_code == "Successful") {
    context.setVariable("statusCode", "1");
    context.setVariable("logType", "OK");
} else {
    switch (error_code) {
        case "BRM:20009":
        case "BRM:20010":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.014");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Subscriber not found (" + error_code + ")");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "BRM:20021":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.025");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Pay Type does not match subscriber profile (BRM:20021)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "BRM:00106":
        case "102010172":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.031");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Service is not allowed due to subscriber status ("+error_code+")");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "BRM:00008":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.032");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "The service request has been submitted and processed successfully (BRM:00008)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
        case "BRM:20182":
        case "102011534":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.033");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Simultaneous actions detected ("+error_code+")");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
        case "405914569":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.035");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "The service is not allowed due to subscriber account balance has exceeded (405914569)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
        default:
            var error_message = error_description+" ("+error_code+")";
            if (!isEmpty(error_more)) {
                var error_message = error_description+" (MoreInfo: "+error_more+") ("+error_code+")";
            }
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.004.012");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Internal Server Error: " + error_message);
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
    }
}

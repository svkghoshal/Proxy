var envType = context.getVariable("envType");
var envTarget = context.getVariable("envTarget");

/**********************************************************************/

// Configure CSG2.0 username/password (credentials)
// Production
var prodUsername = "APIGW";
var prodPassword = "Apigw*&^%12";
// Non-Production (Staging)
var nonProdUsername = "APIGW";
var nonProdPassword = "weblogic";

/**********************************************************************/

// Configure CSG username/password (credentials)
if (envType == "SANDBOX") {
    if (envTarget == "PRODUCTION") {
        var userName = prodUsername;
        var password = prodPassword;
    } else {
        // PREPRODUCTION, STAGING
        var userName = nonProdUsername;
        var password = nonProdPassword;
    }
} else {
    // PRODUCTION
    var userName = prodUsername;
    var password = prodPassword;
}

context.setVariable("userName", userName);
context.setVariable("password", password);

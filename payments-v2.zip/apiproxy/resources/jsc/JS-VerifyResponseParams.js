// Error code mapping for Payment
var status_code = context.getVariable("statusCode");
var error_desc = context.getVariable("error_desc");

var amount = context.getVariable("req.amount");
context.setVariable("Amount", amount);

// Populate the transactionId if it's empty
var sourceId = context.getVariable("req.sourceId");
var transactionId = context.getVariable("transactionId");
if (isEmpty(transactionId)) {
    var transactionIdSeq = randomString(6);
    context.setVariable("transactionIdSeq", transactionIdSeq);
    context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);
}

// Set target response code
var TargetStatusCode = context.getVariable("response.status.code");
var TargetStatusReason = context.getVariable("response.reason.phrase");
context.setVariable("TargetStatusCode", TargetStatusCode);
context.setVariable("TargetStatusReason", TargetStatusReason);

/**********************************************************************/

// Target Elapse Time
context.setVariable("targetStartTime", getTargetStartTime());
context.setVariable("targetEndTime", getTargetEndTime());

// Target Elapsed Time
context.setVariable("targetElapsedTime", getTargetElaspedTime());

/**********************************************************************/

if (status_code != 1) {
    switch (status_code) {
        case "105":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.014");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Subscriber not found (105)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
            
        case "126":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.015");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Transaction ID is invalid (126)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
            
        case "137":
            var error_list = context.getVariable("error_list");
            var uri_dec = decodeURIComponent(error_list);
            var sub_error = uri_dec.split(":");
            var cpa_error_code = sub_error[1].replace(",", "");
            
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("httpError", "400");
            
            switch (cpa_error_code) {
                case "105":
                    context.setVariable("errorCode", "400.004.014");
                    context.setVariable("errorMessage", "Subscriber not found (105)");
                    context.setVariable("logType", "BUSINESS");
                    break;
                case "200":
                    context.setVariable("errorCode", "400.004.019");
                    context.setVariable("errorMessage", "Subscriber has been barred (200)");
                    context.setVariable("logType", "BUSINESS");
                    break;
                case "202":
                    context.setVariable("errorCode", "400.004.020");
                    context.setVariable("errorMessage", "Subscriber has insufficient balance (202)");
                    context.setVariable("logType", "BUSINESS");
                    break;
                case "4012":
                    context.setVariable("errorCode", "400.004.021");
                    context.setVariable("errorMessage", "Subscriber credit limit has been reached (4012)");
                    context.setVariable("logType", "BUSINESS");
                    break;
                case "601":
                    context.setVariable("errorCode", "400.004.028");
                    context.setVariable("errorMessage", "Billing environment is not available (601)");
                    context.setVariable("logType", "TECHNICAL");
                    break;
                case "864":
                    context.setVariable("errorCode", "400.004.029");
                    context.setVariable("errorMessage", "Service is not allowed for MVNO subscribers (864)");
                    context.setVariable("logType", "BUSINESS");
                    break;
                case "145":
                    context.setVariable("errorCode", "400.004.030");
                    context.setVariable("errorMessage", "Subscriber is not in eligibility list (Whitelist/Blacklist) (145)");
                    context.setVariable("logType", "TECHNICAL");
                    break;
                default:
                    context.setVariable("exceptionName", "exceptionName");
                    context.setVariable("errorCode", "500.004.011");
                    context.setVariable("errorDesc", "Internal Server Error");
                    context.setVariable("errorMessage", "Internal Server Error: " + cpa_error_code + " (137)");
                    context.setVariable("httpError", "500");
                    context.setVariable("logType", "TECHNICAL");
            }
            break;
            
        case "155":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.016");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Transaction ID has been used (155)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
            
        case "158":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.017");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Transaction ID has expired (> 1 hour) (158)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
            
        case "176":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.018");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Transaction ID has expired/invalid (176)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
            
        case "200":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.019");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Subscriber has been barred (200)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
            
        case "202":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.020");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Subscriber has insufficient balance (202)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
            
        case "4012":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.021");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Subscriber credit limit has been reached (4012)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "BUSINESS");
            break;
            
        case "147":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.026");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Charging unsuccessful, database operation fail (147)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
            
        case "51":
        case "52":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.027");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid CP credentials (" + status_code + ")");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
            
        case "282":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.036");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Service has been suspended (282)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
            
        case "283":
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400.004.037");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Service has been terminated (283)");
            context.setVariable("httpError", "400");
            context.setVariable("logType", "TECHNICAL");
            break;
        
        // Default error
        default:
            if (!isEmpty(error_desc)) {
                var default_error = error_desc + " (" + status_code + ")";
            } else {
                var default_error = status_code;
            }
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500.004.011");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Internal Server Error: " + default_error);
            context.setVariable("httpError", "500");
            context.setVariable("logType", "TECHNICAL");
            break;
    }
} else {
    context.setVariable("logType", "OK");
}

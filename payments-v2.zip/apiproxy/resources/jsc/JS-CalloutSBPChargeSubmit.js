var SBPhostname = context.getVariable("SBPhostnameCharge");

var transactionId = context.getVariable("transactionId");
var revisedMsisdn = context.getVariable("revisedMsisdn");
var serviceId = context.getVariable("app.cpaServiceId");
var encodedServiceId = encodeURIComponent(serviceId);
context.setVariable("encodedServiceId", encodedServiceId);

var reqAmount = context.getVariable("req.amount");
var centAmount = (reqAmount/100);
var sbpAmount = centAmount.toFixed(2);
context.setVariable("sbpAmount", sbpAmount);

// Build SBP Charge Submit Endpoint
var sbpSubmitEndpoint = "http://"+SBPhostname+"/sdprefund/refund/"+transactionId+"/"+revisedMsisdn+"/"+sbpAmount+"/"+encodedServiceId;
context.setVariable("sbpSubmitEndpoint", sbpSubmitEndpoint);

// Send as POST
var sendSBPSubmitRequest = new Request(sbpSubmitEndpoint, "POST");
var calloutSBPSubmitResponse = httpClient.send(sendSBPSubmitRequest);
context.session["calloutSBPSubmitResponse"] = calloutSBPSubmitResponse;

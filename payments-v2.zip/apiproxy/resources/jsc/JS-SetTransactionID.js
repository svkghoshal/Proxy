var sourceId = context.getVariable("req.sourceId");
var idType = context.getVariable("req.idType");
var idValue = context.getVariable("req.idValue");

// Randomly generate the last 6 characters
var transactionIdSeq = randomString(6);
context.setVariable("transactionIdSeq", transactionIdSeq);
context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);

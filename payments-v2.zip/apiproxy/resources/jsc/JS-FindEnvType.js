/**********************************************************************/

// Configure SBP (Digilusion) endpoint *Deprecated*
/*
var SBP_production = "172.16.44.11:8020";
var SBP_staging = "172.16.44.11:8030";
*/

// Configure SBP (Digilusion) endpoint *Cloud* (2019-02-19)
// 2019-04-29: Temporarily use direct IP address for performance/connectivity issue
// var SBP_production = "internal-DIGI-DIGILUSION-LBAPP-1076332872.ap-southeast-1.elb.amazonaws.com:8070";
var SBP_production = "10.92.16.58:8070"
var SBP_staging = "13.229.243.190";

// 2019-06-17
// SBP (Digilusion direct IP)
// 10.92.16.23:8070
// 10.92.16.36:8070
var SBP_production_alternative = "10.92.16.36:8070";
var SBP_staging_alternative = "13.229.243.190";

// Change the below if testing is required
SBP_production_charge = SBP_production;
SBP_production_refund = SBP_production;
SBP_staging_charge = SBP_staging;
SBP_staging_refund = SBP_staging;

/**********************************************************************/

var envName = context.getVariable("environment.name");

// Set the initial timestamp
context.setVariable("isoTimestamp", ISODateString());

if (envName.indexOf("sandbox") >= 0) {
    context.setVariable("envType", "SANDBOX");
    context.setVariable("SBPhostnameCharge", SBP_staging_charge);
    context.setVariable("SBPhostnameRefund", SBP_staging_refund);
} else {
    context.setVariable("envType", "PRODUCTION");
    context.setVariable("SBPhostnameCharge", SBP_production_charge);
    context.setVariable("SBPhostnameRefund", SBP_production_refund);
}

// Retrieve values from Developer App (Custom Attributes)
var cpId = context.getVariable("app.cpaCpId");
var loginName = context.getVariable("app.cpaLoginName");
var serviceId = context.getVariable("app.cpaServiceId");

context.setVariable("cpId", cpId);
context.setVariable("loginName", loginName);
context.setVariable("serviceId", serviceId);

// Validate Custom Attributes
if (isEmpty(cpId) || isEmpty(loginName) || isEmpty(serviceId)) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.004.008");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing CP credentials");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingCPCredentials";
}

// Fix issue with CSG2.0 require Header User-Agent to be populated
var UserAgent = context.getVariable("message.header.User-Agent");
context.setVariable("UserAgent", (isEmpty(UserAgent)) ? "APIGW" : UserAgent);

// Add "environment" flag for Sandbox
// Acceptable values: production (default), preproduction, staging
var pathSuffix = context.getVariable("proxy.pathsuffix");
var envParam = context.getVariable("message.queryparam.environment");
var envTarget = "DISABLED";
if (envName == "sandbox") {
    switch (pathSuffix) {
        case "/charge":
        case "/reserve":
        case "/commit":
        case "/refund":
            switch (envParam) {
                case "preproduction":
                case "preprod":
                case "staging":
                case "stage":
                    envTarget = "PREPRODUCTION";
                    break;
                default:
                // Only the above APIs are defaulted to Production
                envTarget = "PRODUCTION";
            }
            break;
        default:
            // All others will be defaulted to Production
            envTarget = "PRODUCTION";
    }
}
context.setVariable("envTarget", envTarget);

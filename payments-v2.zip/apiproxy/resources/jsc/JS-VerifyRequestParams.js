var sourceId = context.getVariable("req.sourceId");
var correlationId = context.getVariable("req.correlationId");
var idType = context.getVariable("req.idType");
var idValue = context.getVariable("req.idValue");
var amount = context.getVariable("req.amount");
var description = context.getVariable("req.description");
var reqTransactionId = context.getVariable("req.transactionId");
var resource = context.getVariable("proxy.pathsuffix");

// Status flag in CPA, default=1
// Acceptable values=1,4,5,6,7
var statusMt = context.getVariable("req.statusMt");

// "refund" flag for Charge
// 1: Refund is enabled (default)
// 0: Refund is disabled
var refundFlag = context.getVariable("req.refundFlag");

// transactionId may be from cache
var transactionId = context.getVariable("transactionId");
if (isEmpty(transactionId)) {
    var transactionIdSeq = randomString(6);
    context.setVariable("transactionIdSeq", transactionIdSeq);
    context.setVariable("transactionId", extractSourceId(sourceId) + transactionDateTime() + transactionIdSeq);
}

/****************************************************************/

if (isEmpty(sourceId)) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.004.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingSourceID";
}

if (isEmpty(correlationId)) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.004.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Correlation ID");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingCorrelationID";
}

if (isEmpty(idType) || isEmpty(idValue)) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.004.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: ID Type or ID Value");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingIDTypeIDValue";
}

if (isEmpty(amount)) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.004.009");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameter: Amount");
    context.setVariable("logType", "TECHNICAL");
    throw "MissingAmount";
}

if (resource === "/commit") {
    if (isEmpty(reqTransactionId)) {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.004.009");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Missing input parameter: Transaction ID");
        context.setVariable("logType", "TECHNICAL");
        throw "MissingTransactionID";
    }
}

/****************************************************************/

var sourceIdlength = sourceId.length;
if (sourceIdlength > 8) {
    context.setVariable("exceptionName", "Bad Request");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.004.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Source ID");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidSourceID";
}

var correlationIDLength = correlationId.length;
if (correlationIDLength > 128) {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.004.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Correlation ID");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidCorrelationID";
}

if (idType != "MSISDN") {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.004.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Type");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidIDType";
}

var msisdnLength = idValue.length;
var revisedMsisdn = "";
if (idValue.startsWith("6") && ((msisdnLength == 11) || (msisdnLength == 12))) {
    revisedMsisdn = idValue.substring(1);
    context.setVariable("msisdn", idValue);
    context.setVariable("revisedMsisdn", revisedMsisdn);
} else {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.004.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: ID Value (Invalid MSISDN format)");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidMSISDN";
}

if (resource === "/commit") {
    var transactionIdlength = reqTransactionId.length;
    if (transactionIdlength > 10) {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.004.010");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid input parameter: Transaction ID");
        context.setVariable("logType", "TECHNICAL");
        throw "InvalidTransactionID";
    }
}

// Updated 20171215
// Increased validation to 50000
var chargeAmountLength = amount.length;
var chargeAmtPrefix = "CBS22";
if ((amount >= 0) && (amount <= 50000) && isInteger(amount)) {
    revisedAmount = chargeAmtPrefix.concat(padWithZero(amount,5));  
    context.setVariable("price", amount);
    context.setVariable("revisedAmount", revisedAmount);
} else {
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.004.010");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid input parameter: Amount (value between 0 and 50000)");
    context.setVariable("logType", "TECHNICAL");
    throw "InvalidAmount";
}

if (!isEmpty(description)) {
    var descriptionLength = description.length;
    if (descriptionLength > 32) {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.004.010");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid input parameter: Description");
        context.setVariable("logType", "TECHNICAL");
        throw "InvalidDescription";
    } else {
        // Added 20171105 (CRQ000000412213)
        // Description is valid, but do an escape!
        var descriptionEsc = escapeHtml(description);
        context.setVariable("req.description", descriptionEsc);
    }
} else {
    context.setVariable("req.description", " ");
}

// Status flag in CPA, default=1
// Acceptable values=1,4,5,6,7
if (isEmpty(statusMt)) {
    context.setVariable("statusMt", "1");
} else {
    statusMt = "" + statusMt; // Convert to string
    switch (statusMt) {
        case "1":
        case "4":
        case "5":
        case "6":
        case "7":
            // Acceptable values
            context.setVariable("statusMt", statusMt);
            break;
        default:
            // Invalid values
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("httpError", "400");
            context.setVariable("errorCode", "400.004.010");
            context.setVariable("errorDesc", "Bad Request");
            context.setVariable("errorMessage", "Invalid input parameter: Status");
            context.setVariable("logType", "TECHNICAL");
            throw "InvalidStatusFlag";
    }
}

// Refund flag, default=1
// Acceptable values=0,1
if (!refundFlag && refundFlag !== 0) {
    // If refund flag is not passed in, default to 1
    context.setVariable("refundFlag", "1");
} else {
    refundFlag = "" + refundFlag; // Convert to string
    if (refundFlag == "0" || refundFlag == "1") {
        context.setVariable("refundFlag", refundFlag);
    } else {
        // Invalid values
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("httpError", "400");
        context.setVariable("errorCode", "400.004.010");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid input parameter: Refund");
        context.setVariable("logType", "TECHNICAL");
        throw "InvalidRefundFlag";
    }
}

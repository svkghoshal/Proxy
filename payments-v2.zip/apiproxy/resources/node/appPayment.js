http = require('http');
var apigee = require('apigee-access');

server= http.createServer( function(req, res) {
    console.log ('payments-v2 sandbox');
    
    //var body = "Payment Charge";
    //var body = "------=_Part_0_22402548.1467562719058 Content-Type: application/xop+xml; charset=UTF-8; type=\"application/soap+xml\"; Content-Transfer-Encoding: binary Content-ID: <root.message@cxf.apache.org> <soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\"><soap:Body><ValidateAndBillResponse xmlns=\"http://xsd.gateway.sdp.digi.com\"><return><transaction_id>9999999999</transaction_id><error_code>1</error_code><error_desc></error_desc><error_list></error_list><success_list>0146690306%2C</success_list></return></ValidateAndBillResponse></soap:Body></soap:Envelope> ------=_Part_0_22402548.1467562719058--";
    
    res.writeHead(200, {'Content-Type': 'application/xop+xml'});
    
var proxypath = apigee.getVariable(req,'proxy.pathsuffix');


var refund = "<?xml version='1.0' encoding='UTF-8'?>"+
"<soapenv:Envelope xmlns:digi=\"http://digi.com.my/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:sub=\"http://digi.com.my/Subscriber\">"+
"<soapenv:Header xmlns:digi=\"http://digi.com.my/\" xmlns:sub=\"http://digi.com.my/Subscriber\">"+
"<digi:CSGResponseHeader>"+
"<digi:GUID>e2034f18-244a-4d69-8ed9-3ef7be6e218f</digi:GUID>"+
"<digi:ReferenceId>YTB20170209193146000075</digi:ReferenceId>"+
"<digi:InstanceId>70209193146790177699674914816</digi:InstanceId>"+
"<digi:ChannelId>MSISDN</digi:ChannelId>"+
"<digi:ChannelMedia>APIGW</digi:ChannelMedia>"+
"</digi:CSGResponseHeader>"+
"</soapenv:Header>"+
"<soapenv:Body xmlns:digi=\"http://digi.com.my/\" xmlns:sub=\"http://digi.com.my/Subscriber\">"+
"<digi:AdjustAccountRequest>"+
"<digi:ResultStatus>"+
"<digi:StatusCode>Sucessful</digi:StatusCode>"+
"<digi:ErrorCode></digi:ErrorCode>"+
"<digi:ErrorDescription></digi:ErrorDescription>"+
"</digi:ResultStatus>"+
"<digi:AccountBalanceList>"+
  "<digi:AccountRecord>"+
     "<digi:AccountType></digi:AccountType>"+
     "<digi:NewBalance></digi:NewBalance>"+
     "<digi:AdjustmentAmount></digi:AdjustmentAmount>"+
     "<digi:PreviousExpiryDate></digi:PreviousExpiryDate>"+
     "<digi:ExpiryPeriod></digi:ExpiryPeriod>"+
     "<digi:BalanceId></digi:BalanceId>"+
     "<digi:MeasurementUnit></digi:MeasurementUnit>"+
  "</digi:AccountRecord>"+
"</digi:AccountBalanceList>"+
"</digi:AdjustAccountRequest>"+
"</soapenv:Body>"+
"</soapenv:Envelope>";

var body = "";

if(proxypath == '/refund')
    body = refund;


res.end(body);

});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);
console.log ('Listening at http://' + host + ':' + port);

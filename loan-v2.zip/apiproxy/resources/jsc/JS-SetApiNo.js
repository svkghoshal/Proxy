 var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

var apiiNo;

if (reqVerb == "GET") 
    context.setVariable("apiNo","015");
else
    context.setVariable("apiNo","016");

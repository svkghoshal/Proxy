 var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("res.faultString");
//var faultMsg = context.getVariable("faultMessage");
//var status_code= context.getVariable("response.status.code");
var statusCode = context.getVariable("res.resultCode");
var apiNo = context.getVariable('apiNo');

if(statusCode == "405000000")
    context.setVariable("Status","Success");
else
    {
    if(faultString.toUpperCase().includes("THE MAIN ACCOUNT BALANCE OF THE"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".103");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The subscriber is not eligible for loan as main account balance is above threshold");
            context.setVariable("httpError", "500");
        }
   else if(faultString.toUpperCase().includes("THE SUBSCRIBER HAS LOANS"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".104");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The subscriber has active loan");
            context.setVariable("httpError", "500");
        }
    else if(faultString.toUpperCase().includes("THE NUMBER SEGMENT ROUTING INFORMATION"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".102");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The number segment route does not exist");
            context.setVariable("httpError", "500");
        }
    else if(faultString.toUpperCase().includes("Incorrect number format"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "400."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "Invalid Input");
            context.setVariable("httpError", "400");
        }
    else if(faultString.toUpperCase().includes("THE NUMBER RESOURCE DOES NOT EXIST IN THE OCS"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The subscriber is not valid");
            context.setVariable("httpError", "500");
        }
    else if(faultString.toUpperCase().includes("THE MAIN PRODUCT SUBSCRIBED TO BY A POSTPAID SUBSCRIBER HAS NO LOAN FUNCTION"))
        {
            context.setVariable("exceptionName", "exceptionName");
            context.setVariable("errorCode", "500."+apiNo+".101");
            context.setVariable("errorDesc", "Internal Server Error");
            context.setVariable("errorMessage", "The subscriber is not valid");
            context.setVariable("httpError", "500");
        }
    else
    {
                context.setVariable("exceptionName", "exceptionName");    
                context.setVariable("errorCode", "500."+apiNo+".100");
                context.setVariable("errorDesc", "Internal Server Error");
                context.setVariable("errorMessage", faultString);
                context.setVariable("httpError", "500");
    }
}
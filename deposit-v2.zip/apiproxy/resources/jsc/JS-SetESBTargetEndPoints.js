 var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var target;

if(proxypath.match('/*/payment/history'))
{
    target = '/cxf/PostpaidPaymentAndDepositPS';
    context.setVariable('targetPath',target);
}
else 
    if (proxypath.match('/*/deposit/history'))
    {
        target = '/cxf/PostpaidPaymentAndDepositPS';
        context.setVariable('targetPath',target);
    }
else 
    if (proxypath.match('/*/bill/history'))
    {
        target = '/cxf/PostpaidPaymentAndDepositPS';
        context.setVariable('targetPath',target);
    }
else 
    if (proxypath.match('/*/bill/info'))
    {
        target = '/cxf/QueryPostAcctinformationPS';
        context.setVariable('targetPath',target);
    }

 var paymentList = context.getVariable("res.paymentList");

 if(!paymentList)
    context.setVariable("res.paymentList", "[]");
 else
 {
    var jsonResponsePrimary = String(paymentList).replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
    context.setVariable("res.paymentList",jsonResponsePrimary);
 }

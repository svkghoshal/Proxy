 http = require('http');
 var apigee = require('apigee-access');

server= http.createServer( function(req, res) 
{
console.log ('user'+req);
console.log ('Request ::: '+JSON.stringify(req.Body));
var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
console.log('proxypath : '+proxypath);
var reqVerb = apigee.getVariable(req,'request.verb');
console.log('requestVerb : '+reqVerb);

var bodyLQ = "<soapenv:Envelope 	xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"> "+
"<soap:Header 	xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"</soap:Header>"+
"<soapenv:Body>"+
"<man:QueryLoanInfoResultMsg xmlns:man=\"http://www.huawei.com/bme/cbsinterface/manageloanmgr\" xmlns:loan=\"http://www.huawei.com/bme/cbsinterface/loan\" xmlns:com=\"http://www.huawei.com/bme/cbsinterface/common\"> " +
	"<ResultHeader> " + 
		"<com:CommandId>QueryLoanInfo</com:CommandId> " + 
		"<com:Version>1</com:Version> " + 
		"<com:TransactionId>1</com:TransactionId> " + 
		"<com:SequenceId>1</com:SequenceId> " + 
		"<com:ResultCode>405000000</com:ResultCode> " + 
		"<com:ResultDesc>Operation is successful.</com:ResultDesc> " + 
		"<com:OrderId>361</com:OrderId> " + 
		"<com:OperationTime>20111228135937</com:OperationTime> " + 
	"</ResultHeader> " + 
	"<QueryLoanInfoResult> " + 
		"<loan:ServiceStatus>1</loan:ServiceStatus> " + 
		"<loan:LoanAmount>200</loan:LoanAmount> " + 
		"<loan:LoanTime>2011-12-28</loan:LoanTime> " + 
		"<loan:PayBackTime>2012-01-01</loan:PayBackTime> " + 
		"<loan:LastPayBackTime>1970-01-01</loan:LastPayBackTime> " + 
		"<loan:DepositAmount>0</loan:DepositAmount> " + 
		"<loan:MakeDepositTime>2011-12-28</loan:MakeDepositTime> " + 
	"</QueryLoanInfoResult> " + 
"</man:QueryLoanInfoResultMsg> " + 
"</soapenv:Body> "+
"</soapenv:Envelope>";

var bodyECB = "<soapenv:Envelope 	xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"> "+
"<soap:Header 	xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"</soap:Header>"+
"<soapenv:Body>"+
" <LoanManageResultMsg  xmlns=\"http://www.huawei.com/bme/cbsinterface/manageloanmgr\"> " + 
     " <ResultHeader xmlns=\"\"> " +
         " <CommandId xmlns=\"http://www.huawei.com/bme/cbsinterface/common\">LoanManage</CommandId> " + 
         " <Version xmlns=\"http://www.huawei.com/bme/cbsinterface/common\">1</Version> " + 
         " <TransactionId xmlns=\"http://www.huawei.com/bme/cbsinterface/common\">null</TransactionId> " + 
         " <SequenceId xmlns=\"http://www.huawei.com/bme/cbsinterface/common\">1</SequenceId> " + 
         " <ResultCode xmlns=\"http://www.huawei.com/bme/cbsinterface/common\">405000000</ResultCode> " + 
         " <ResultDesc xmlns=\"http://www.huawei.com/bme/cbsinterface/common\">Operation is successful.</ResultDesc> " + 
     " </ResultHeader> " + 
     " <LoanManageResult> " + 
         " <LoanGrade>1</LoanGrade> " + 
         " <LoanAmount>100</LoanAmount> " + 
         " <RepayAmount>100</RepayAmount> " + 
         " <ETUGracePeriod>20110811</ETUGracePeriod> " + 
         " <GracePeriod>20110812</GracePeriod> " + 
         " <LoanAcctType>2000</LoanAcctType> " + 
         " <LoanBalance>200</LoanBalance> " + 
     " </LoanManageResult> " + 
" </LoanManageResultMsg>" +
"</soapenv:Body> "+
"</soapenv:Envelope>";

var bodyTU = "<soapenv:Envelope 	xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"> "+
"<soap:Header 	xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"</soap:Header>"+
"<soapenv:Body>"+
" <car:VoucherRechargeResultMsg xmlns:car=\"http://www.huawei.com/bme/cbsinterface/cardrechargemgr\" " +
"xmlns:com=\"http://www.huawei.com/bme/cbsinterface/common\" " +
 "xmlns:car1=\"http://www.huawei.com/bme/cbsinterface/cardrecharge\" " +
 "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"> "+
	" <ResultHeader> "+ 
		" <com:CommandId>VoucherRechargeReques</com:CommandId> "+ 
		" <com:Version>1</com:Version> "+ 
		" <com:TransactionId>1</com:TransactionId> "+ 
		" <com:SequenceId>1</com:SequenceId> "+ 
		" <com:ResultCode>405000000</com:ResultCode> "+ 
		" <com:ResultDesc>Operation is successful.</com:ResultDesc> "+ 
		" <com:OrderId>1302070000000015889</com:OrderId> "+ 
		" <com:OperationTime>20130711182121</com:OperationTime> "+ 
	" </ResultHeader> "+ 
	" <VoucherRechargeResult> "+ 
		" <car1:FaceValue>10000</car1:FaceValue> "+ 
		" <car1:NewBalance>40000</car1:NewBalance> "+ 
		" <car1:NewActiveStop>20130909</car1:NewActiveStop> "+ 
		" <car1:ValidityPeriod>30</car1:ValidityPeriod> "+ 
		" <car1:BalanceAfterRecharge>0</car1:BalanceAfterRecharge> "+ 
		" <car1:NewSuspendStopDate xsi:nil=\"true\"/> "+
		" <car1:NewDisableStopDate xsi:nil=\"true\"/> "+
		" <car1:RechargeBonus> "+ 
			" <car1:PrmAcctType>2000</car1:PrmAcctType> "+ 
			" <car1:PrmAmt>40000</car1:PrmAmt> "+ 
			" <car1:CurrAcctBal>139810100</car1:CurrAcctBal> "+ 
			" <car1:CurrExpTime>20130810000000</car1:CurrExpTime> "+ 
			" <car1:ChgExpTime>0</car1:ChgExpTime> "+ 
			" <car1:MinMeasureId>2</car1:MinMeasureId> "+ 
		" </car1:RechargeBonus> "+ 
		" <car1:RechargeBonus> "+ 
			" <car1:PrmAcctType>4203</car1:PrmAcctType> "+ 
			" <car1:PrmAmt>13981013200</car1:PrmAmt> "+ 
			" <car1:CurrAcctBal>0</car1:CurrAcctBal> "+ 
			" <car1:ChgExpTime>0</car1:ChgExpTime> "+ 
			" <car1:MinMeasureId>0</car1:MinMeasureId> "+ 
		" </car1:RechargeBonus> "+ 
		" <car1:ExtraValidity>0</car1:ExtraValidity> "+ 
		" <car1:LoanAmount>0</car1:LoanAmount> "+ 
		" <car1:LoanPoundage>0</car1:LoanPoundage> "+ 
		" <car1:LoanRecovered>0</car1:LoanRecovered> "+ 
	" </VoucherRechargeResult> "+ 
" </car:VoucherRechargeResultMsg> " + 
"</soapenv:Body> "+
"</soapenv:Envelope>"; 
 
var bodyBT = "<soapenv:Envelope 	xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"> "+
"<soap:Header 	xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"</soap:Header>"+
"<soapenv:Body>"+
" <tran:TransferAccountResultMsg   " +
" xmlns:tran=\"http://www.huawei.com/bme/cbsinterface/transferaccountmgr\"  " +
" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
" xmlns:com=\"http://www.huawei.com/bme/cbsinterface/common\"   " +
" xmlns:tran1=\"http://www.huawei.com/bme/cbsinterface/transferaccount\"> " +
	" <ResultHeader> " + 
		" <com:CommandId>TransferAccount</com:CommandId> " + 
		" <com:Version>1</com:Version> " + 
		" <com:TransactionId>1</com:TransactionId> " + 
		" <com:SequenceId>1</com:SequenceId> " + 
		" <com:ResultCode>405000000</com:ResultCode> " + 
		" <com:ResultDesc>Operation is successful.</com:ResultDesc> " + 
		" <com:OrderId>2037</com:OrderId> " + 
		" <com:OperationTime>20111020165425</com:OperationTime> " + 
	" </ResultHeader> " + 
	" <TransferAccountResult> " + 
		" <tran1:TransfereeHandlingCharge>2</tran1:TransfereeHandlingCharge> " + 
		" <tran1:TransferorHandlingCharge>0</tran1:TransferorHandlingCharge> " + 
		" <tran1:TransfereeAcctChgList> " + 
		" </tran1:TransfereeAcctChgList> " +
		" <tran1:TransferorAcctChgList> " + 
			" <tran1:AcctChgRec> " + 
				" <com:CurrAcctBal>1996</com:CurrAcctBal> " + 
				" <com:ChgAcctBal>-5</com:ChgAcctBal> " + 
				" <com:CurrExpTime>20370101000002</com:CurrExpTime> " + 
				" <com:ChgExpTime>0</com:ChgExpTime> " + 
				" <com:AccountType>2000</com:AccountType> " + 
				" <com:BalanceId>999000000000000431</com:BalanceId> " + 
				" <com:MinMeasureId>101</com:MinMeasureId> " + 
			" </tran1:AcctChgRec> " +
		" </tran1:TransferorAcctChgList> " + 
		" <tran1:TransfereeOldActiveStop xsi:nil=\"true\"/> " + 
		" <tran1:TransfereeNewActiveStop>20111020</tran1:TransfereeNewActiveStop> " + 
		" <tran1:TransferorOldActiveStop>20111020</tran1:TransferorOldActiveStop> " + 
		" <tran1:TransferorNewActiveStop>20111020</tran1:TransferorNewActiveStop> " + 
		" <tran1:TransferorBalanceValidity>19700101</tran1:TransferorBalanceValidity> " + 
		" <tran1:TransferorBalanceValidityPeriod>0</tran1:TransferorBalanceValidityPeriod> " + 
	" </TransferAccountResult> " + 
" </tran:TransferAccountResultMsg>" +
"</soapenv:Body> "+
"</soapenv:Envelope>";

var bodyPH = " <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"> " +
	" <soap:Header xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> " +
	" </soap:Header> " +
	" <soapenv:Body> " +
" <ns3:QueryInvoicePaymentresponse xmlns:ns3=\"http://www.example.org/PostpaidInvoicePayment\" xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\"> " +
	" <ns3:QueryInvoicePaymentResultList> " +
		" <ns3:ResultHeader> " +
			" <ns3:SerialNo>2345</ns3:SerialNo> " +
			" <ns3:ResultCode>0</ns3:ResultCode> " +
			" <ns3:ResultDesc>Operation successfully.</ns3:ResultDesc> " +
		" </ns3:ResultHeader> " +
		" <ns3:InvoicePaymentResultList> " +
			" <ns3:AcctCode>201460</ns3:AcctCode> " +
			" <ns3:Acctid>201460</ns3:Acctid> " +
			" <ns3:MSISDN>9908765432</ns3:MSISDN> " +
			" <ns3:SubID>97903999</ns3:SubID> " +
			" <ns3:TransId>7890000009</ns3:TransId> " +
			" <ns3:PaymentMethod>Cash</ns3:PaymentMethod> " +
			" <ns3:AccessMethod>dddffg</ns3:AccessMethod> " +
			" <ns3:RechargeCardno>23455678990</ns3:RechargeCardno> " +
			" <ns3:TransType>fdggdg</ns3:TransType> " +
			" <ns3:Amount>345</ns3:Amount> " +
			" <ns3:EntryDate>20170302191750</ns3:EntryDate> " +
			" <ns3:CloseAmount>5000</ns3:CloseAmount> " +
			" <ns3:OpenAmount>100</ns3:OpenAmount> " +
			" <ns3:OperId>2341</ns3:OperId> " +
			" <ns3:DeptId>342</ns3:DeptId> " +
			" <ns3:OpAcctCode>677899</ns3:OpAcctCode> " +
			" <ns3:Status>SUCCESS</ns3:Status> " +
			" <ns3:EffectiveDate>20170423191750</ns3:EffectiveDate> " +
			" <ns3:Remark>sdfghjjk</ns3:Remark> " +
		" </ns3:InvoicePaymentResultList> " +
		" <ns3:TotalRownum>1</ns3:TotalRownum> " +
		" <ns3:BeginRowNum>2</ns3:BeginRowNum> " +
		" <ns3:FetchRowNum>3</ns3:FetchRowNum> " +
	" </ns3:QueryInvoicePaymentResultList> " +
" </ns3:QueryInvoicePaymentresponse> " +
	" </soapenv:Body> " +
" </soapenv:Envelope> " ;

var bodyDH = " <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"> " +
	" <soap:Header xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> " +
	" </soap:Header> " +
	" <soapenv:Body> " +
		" <quer:QueryDepositDetailRes xmlns:quer=\"http://www.telenor.com.mm/QueryDepositDetail\"> " +
			" <quer:DepositDetailResultListList> " +
				" <quer:DepositDetailResultList> " +
					" <com:TransactionReference xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\"> " +
						" <com:IdRef>2017032115361908eaf1cd</com:IdRef> " +
					" </com:TransactionReference> " +
					" <quer:ResultHeader> " +
						" <quer:SerialNo>2017032115361908eaf1cd</quer:SerialNo> " +
						" <quer:ResultCode>0</quer:ResultCode> " +
						" <quer:ResultDesc>Operation successfully.</quer:ResultDesc> " +
						" <quer:Version>1</quer:Version> " +
						" <quer:TenantId>100</quer:TenantId> " +
						" <quer:CommandId>QueryDepositDetail</quer:CommandId> " +
						" <quer:TransactionId>1</quer:TransactionId> " +
						" <quer:SequenceId>1</quer:SequenceId> " +
					" </quer:ResultHeader> " +
					" <quer:DepositDetailResultValue> " +
						" <quer:AcctCode>101460</quer:AcctCode> " +
						" <quer:AcctId>101460</quer:AcctId> " +
						" <quer:Msisdn>9790399988</quer:Msisdn> " +
						" <quer:SubId>97903999803218</quer:SubId> " +
						" <quer:InvoiceAmount>5000</quer:InvoiceAmount> " +
						" <quer:OpenAmount>0</quer:OpenAmount> " +
						" <quer:WaiveReason/> " +
						" <quer:Status>SUCCESS</quer:Status> " +
						" <quer:DepPaymentList> " +
							" <quer:DepPaymentValue> " +
								" <quer:Amount>5000</quer:Amount> " +
								" <quer:PaymentMethod>Cash</quer:PaymentMethod> " +
								" <quer:EntryDate>20170302191750</quer:EntryDate> " +
								" <quer:DepositType>Deposit for Enhanced CrediLimit</quer:DepositType> " +
							" </quer:DepPaymentValue> " +
							" <quer:DepPaymentValue> " +
								" <quer:Amount>4500</quer:Amount> " +
								" <quer:PaymentMethod>Cash</quer:PaymentMethod> " +
								" <quer:EntryDate>20170423191750</quer:EntryDate> " +
								" <quer:DepositType>Deposit for Enhanced Credit Limit</quer:DepositType> " +
							" </quer:DepPaymentValue> " +
							" <quer:DepPaymentValue> " +
								" <quer:Amount>10000</quer:Amount> " +
								" <quer:PaymentMethod>Cash</quer:PaymentMethod> " +
								" <quer:EntryDate>20160310191750</quer:EntryDate> " +
								" <quer:DepositType>Deposit for Enhanced Credit Limit</quer:DepositType> " +
							" </quer:DepPaymentValue> " +
							" <quer:DepPaymentValue> " +
								" <quer:Amount>10000</quer:Amount> " +
								" <quer:PaymentMethod>Cash</quer:PaymentMethod> " +
								" <quer:EntryDate>20160310191750</quer:EntryDate> " +
								" <quer:DepositType>Deposit for Enhanced Credit Limit</quer:DepositType> " +
							" </quer:DepPaymentValue> " +
						" </quer:DepPaymentList> " +
					" </quer:DepositDetailResultValue> " +
				" </quer:DepositDetailResultList> " +
			" </quer:DepositDetailResultListList> " +
		" </quer:QueryDepositDetailRes> " +
	" </soapenv:Body> " +
" </soapenv:Envelope> " ;

var bodyMB= " <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"> " +
   " <soapenv:Header xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\" xmlns:quer=\"http://www.telenor.com.mm/QueryPostAcctinfo\"/> " +
   " <soapenv:Body xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\" xmlns:quer=\"http://www.telenor.com.mm/QueryPostAcctinfo\"> " +
      " <quer:QueryPostAcctinfoResp> " +
         " <quer:QueryPostAcctinfoResponse> " +
            " <com:TransactionReference> " +
               " <com:IdRef>97903999902017030318415048c53b53</com:IdRef> " +
            " </com:TransactionReference> " +
            " <quer:SerialNo>97903999902017030318415048c53b53</quer:SerialNo> " +
            " <quer:ResultCode>0</quer:ResultCode> " +
            " <quer:ResultDesc>Operation successfully.</quer:ResultDesc> " +
            " <quer:Remark>0</quer:Remark> " +
            " <quer:Version>1</quer:Version> " +
            " <quer:TenantId>0</quer:TenantId> " +
            " <quer:OrderId/> " +
            " <quer:QueryPostAcctinformationResult> " +
               " <quer:CreditClass>0</quer:CreditClass> " +
               " <quer:Waiver>0</quer:Waiver> " +
               " <quer:TempWaiver>0</quer:TempWaiver> " +
               " <quer:ExpiryDateOfAcct>20370101000000</quer:ExpiryDateOfAcct> " +
               " <quer:DepAmount>0</quer:DepAmount> " +
               " <quer:TotalUnpaidAmtOfLastBill>820000</quer:TotalUnpaidAmtOfLastBill> " +
               " <quer:LastInvoiceAmt>820000</quer:LastInvoiceAmt> " +
               " <quer:LastInvoiceDate>20170101235959</quer:LastInvoiceDate> " +
               " <quer:LastInvoiceDueDate>20170131000000</quer:LastInvoiceDueDate> " +
               " <quer:TotalOverDueAmt>595000</quer:TotalOverDueAmt> " +
               " <quer:TotalPaymentAmt>0</quer:TotalPaymentAmt> " +
               " <quer:TotalBilledAmt>595000</quer:TotalBilledAmt> " +
               " <quer:LastPaymentAmt>0</quer:LastPaymentAmt> " +
               " <quer:LastPaymentDate/> " +
               " <quer:LastBillCycleEndDate>20170301235959</quer:LastBillCycleEndDate> " +
               " <quer:NextBillCycleEndDate>20170401235959</quer:NextBillCycleEndDate> " +
               " <quer:TotalUnpaidAmt>2170000</quer:TotalUnpaidAmt> " +
               " <quer:AdvAmt>0</quer:AdvAmt> " +
               " <quer:TotalUnbilledAmount>0</quer:TotalUnbilledAmount> " +
               " <quer:TotalCreditLimit>0</quer:TotalCreditLimit> " +
               " <quer:ActualCreditLimit>-1350000</quer:ActualCreditLimit> " +
               " <quer:AmountSpent>595000</quer:AmountSpent> " +
               " <quer:CreditPrecentage>10000.0</quer:CreditPrecentage> " +
               " <quer:MRAAmt>0</quer:MRAAmt> " +
               " <quer:CurAdminStatus>1000010</quer:CurAdminStatus> " +
               " <quer:CurCLStatus>0</quer:CurCLStatus> " +
               " <quer:CurCOLStatus>0</quer:CurCOLStatus> " +
               " <quer:LastCLAction>0</quer:LastCLAction> " +
               " <quer:LastCOLAction>0</quer:LastCOLAction> " +
               " <quer:LastCLActionDate/> " +
               " <quer:LastCOLActionDate/> " +
               " <quer:TotalPoints>0</quer:TotalPoints> " +
               " <quer:TerminationDate/> " +
               " <quer:BillSequenceID>1</quer:BillSequenceID> " +
               " <quer:TotalNonPaidInvoice>2</quer:TotalNonPaidInvoice> " +
               " <quer:AgeofReceivable>64</quer:AgeofReceivable> " +
               " <quer:ReceivablesofOldestInvoice>70000.0</quer:ReceivablesofOldestInvoice> " +
               " <quer:ActionDtm/> " +
               " <quer:FinalInvoiceAmt>0.0</quer:FinalInvoiceAmt> " +
               " <quer:FinalBillFalg>0</quer:FinalBillFalg> " +
               " <quer:Reason>1</quer:Reason> " +
               " <quer:CurMostSereveStatus>Normal</quer:CurMostSereveStatus> " +
            " </quer:QueryPostAcctinformationResult> " +
         " </quer:QueryPostAcctinfoResponse> " +
      " </quer:QueryPostAcctinfoResp> " +
   " </soapenv:Body> " +
" </soapenv:Envelope> " ;

var bodyBH= " <soapenv:Envelope  xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"> " +
   " <soapenv:Header xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\" xmlns:ns3=\"http://www.telenor.com.mm/QueryInvoice\" /> " +
   " <soapenv:Body xmlns:ns3=\"http://www.telenor.com.mm/QueryInvoice\" xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\"> " +
" <ns3:QueryInvoiceResponse xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\"  > " +
        " <ns3:TransactionReference>" +
            " <ns3:IdRef>123</ns3:IdRef>" +
        " </ns3:TransactionReference>" +
        " <ns3:ResultHeader>" +
            " <ns3:SerialNo></ns3:SerialNo>" +
            " <ns3:ResultCode>0</ns3:ResultCode>" +
            " <ns3:ResultDesc>successful</ns3:ResultDesc>" +
            " <ns3:Version></ns3:Version>" +
            " <ns3:TenantId></ns3:TenantId>" +
            " <ns3:Language></ns3:Language>" +
            " <ns3:CommandId></ns3:CommandId>" +
            " <ns3:TransactionId></ns3:TransactionId>" +
            " <ns3:SequenceId></ns3:SequenceId>" +
            " <ns3:OrderId></ns3:OrderId>" +
       	" </ns3:ResultHeader>" +
        " <ns3:QueryInvoiceResultList>" +
            " <ns3:InvoiceResultValue>" +
                " <ns3:acctCode>90890</ns3:acctCode>" +
                " <ns3:acctId>123456</ns3:acctId>" +
                " <ns3:custCode>5678</ns3:custCode>" +
                " <ns3:custId>123456798</ns3:custId>" +
                " <ns3:msisdn>67876</ns3:msisdn>" +
                " <ns3:subId></ns3:subId>" +
                " <ns3:transType>fdggdg</ns3:transType>" +
                " <ns3:invoiceId>2345</ns3:invoiceId>" +
                " <ns3:InvoiceAmount>345</ns3:InvoiceAmount>" +
                " <ns3:VatAmount>34</ns3:VatAmount>" +
                " <ns3:OpenAmount>1234</ns3:OpenAmount>" +
                " <ns3:OpenVatAmount>23</ns3:OpenVatAmount>" +
                " <ns3:WhtAmount></ns3:WhtAmount>" +
                " <ns3:WhtAmt1></ns3:WhtAmt1>" +
                " <ns3:WhtAmt3></ns3:WhtAmt3>" +
                " <ns3:WhtAmt5></ns3:WhtAmt5>" +
                " <ns3:invoiceNo>123</ns3:invoiceNo>" +
                " <ns3:invoiceDate>12122017</ns3:invoiceDate>" +
                " <ns3:dueDate>12122017</ns3:dueDate>" +
                " <ns3:SettleDate>12122017</ns3:SettleDate>" +
                " <ns3:ReasonCode></ns3:ReasonCode>" +
                " <ns3:BillCycleId>3445</ns3:BillCycleId>" +
                " <ns3:BillStartDate>12122017</ns3:BillStartDate>" +
                " <ns3:BillEndDate>12122017</ns3:BillEndDate>" +
                " <ns3:InvoiceAmtSubopen></ns3:InvoiceAmtSubopen>" +
                " <ns3:DisputeAmount>667</ns3:DisputeAmount>" +
                " <ns3:PendingAmount>455</ns3:PendingAmount>" +
                " <ns3:InvoiceStatus>success</ns3:InvoiceStatus>" +
                " <ns3:TaxAmt>sddf</ns3:TaxAmt>" +
                " <ns3:LateFee>344</ns3:LateFee>" +
                " <ns3:NormalDate>12122017</ns3:NormalDate>" +
                " <ns3:TotalPayment>3456</ns3:TotalPayment>" +
                " <ns3:TotalRefund>0</ns3:TotalRefund>" +
                " <ns3:TotalAdjustment>0</ns3:TotalAdjustment>" +
                " <ns3:BalForward>23</ns3:BalForward>" +
                " <ns3:AgeofReceivable>90</ns3:AgeofReceivable>" +
                " <ns3:TotalPayableAmount>234</ns3:TotalPayableAmount>" +
                " <ns3:InvoiceNetAmount>344</ns3:InvoiceNetAmount>" +
            " </ns3:InvoiceResultValue>" +
        " </ns3:QueryInvoiceResultList>" +
        " <ns3:TotalRowNum></ns3:TotalRowNum>" +
        " <ns3:BeginRowNum></ns3:BeginRowNum>" +
        " <ns3:FetchRowNum></ns3:FetchRowNum>" +
        " <ns3:CustomerType></ns3:CustomerType>" +
        " <ns3:AccountCloseFlag></ns3:AccountCloseFlag>" +
    " </ns3:QueryInvoiceResponse>" +
   " </soapenv:Body> " +
" </soapenv:Envelope> " ;

res.writeHead(200, {'Content-Type': 'application/xop+xml'});
 
 var body = "";

if(proxypath.match("/*/loan"))
    if(reqVerb == 'POST')
        body = bodyECB;
    else  
        if (reqVerb == 'GET')
            body = bodyLQ;
        else
            console.log('NO TARGET selected ');
else if(proxypath.match("/*/recharge"))
        body = bodyTU;
else if(proxypath.match("/*/balance"))
        body = bodyBT;
else if (proxypath.match("/*/payment/history"))
    body = bodyPH;
else if (proxypath.match("/*/deposit/history"))
    body = bodyDH;
else if (proxypath.match("/*/bill/info"))
    body = bodyMB;
else if (proxypath.match("/*/bill/history"))
    body = bodyBH;
    
res.end(body);

});


port = 3000;

host = '127.0.0.1';

server.listen(port, host);

console.log ('Listening at http://' + host + ':' + port);
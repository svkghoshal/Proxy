var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var target;

if(proxypath.match('/*/loan') && (reqVerb == 'GET' || reqVerb == 'POST'))
{
    target = '/services/LoanMgrService';
    context.setVariable('targetPath',target);
}
else 
    if (proxypath.match('/*/recharge'))
    {
        target = '/services/CardRechargeMgrService';
        context.setVariable('targetPath',target);
    }
else 
    if (proxypath.match('/*/balance'))
    {
        target = '/services/TransferAccountMgrService';
        context.setVariable('targetPath',target);
    }

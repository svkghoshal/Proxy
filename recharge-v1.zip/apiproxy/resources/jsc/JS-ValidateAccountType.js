var accountType = context.getVariable("req.accountType");

if (accountType == "POSTPAID")
    context.setVariable("req.accountType", "3000");
else
    context.setVariable("req.accountType", "2000");

var targetStatus = context.getVariable("Status");
var faultCode = context.getVariable("faultCode");
var faultString = context.getVariable("faultMessage");
var faultMsg = context.getVariable("faultString");
var offerType = context.getVariable("req.offerType");
var list = context.getVariable("req.list");
var proxyPath = context.getVariable("proxy.pathsuffix");
var apiNo = context.getVariable('apiNo');

print("faultString ::" + faultString);
print("faultMsg ::" + faultMsg);
print("faultCode ::" + faultCode);


if (faultCode === null || (faultCode !== null && list == "subscribed" && offerType == "VAS"))
	context.setVariable("Status", "Success");
else if (faultMsg.toUpperCase().includes("VALIDATIONERROR") || faultMsg.toUpperCase().includes("PLEASE ENTER THE VALID INPUT") || faultMsg.toUpperCase().includes("INVALID PARAMETER") || faultMsg.toUpperCase().includes("INCORRECT SETTING OF") || faultMsg.toUpperCase().includes("INVALID PARAMETER VALUE.") || faultMsg.toUpperCase().includes("INCORRECT NUMBER TYPE") || faultMsg.toUpperCase().includes("INCORRECT FORMAT OF THE NUMBER") || faultMsg.toUpperCase().includes("CANNOT BE BLANK.") || faultMsg.toUpperCase().includes("FAILED TO VERIFY THE COUNTRY CODE.")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "400." + apiNo + ".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Invalid Input.");
	context.setVariable("httpError", "400");
} else if (faultMsg.toUpperCase().includes("QUERY OFFER FAILURE") || faultMsg.toUpperCase().includes("QUERY OFFER CATEGORY FAILURE") || faultMsg.toUpperCase().includes("QUERY OFFER FAILED") || faultMsg.toUpperCase().includes("QUERY SUBSCRIBER FAILED")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".101");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Query VAS Offer Failure.");
	context.setVariable("httpError", "500");
} else if (faultMsg.toUpperCase().includes("THE SUBSCRIBER'S ACCOUNT BALANCE IS SMALLER THAN")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".102");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "In-sufficient Balance of Subscriber.");
	context.setVariable("httpError", "500");
} else if (faultMsg.toUpperCase().includes("THE SYSTEM DOES NOT SUPPORT THE QUERY TYPE")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".103");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "Invalid Query.");
	context.setVariable("httpError", "500");
} else if (faultMsg.toUpperCase().includes("THE NUMBER SEGMENT ROUTE DOES NOT EXIST")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".104");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "The number segment route does not exist.");
	context.setVariable("httpError", "500");
} else if (faultMsg.toUpperCase().includes("THE CUSTOMER DOES NOT SUBSCRIBE TO THE OFFER")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".105");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "The customer does not subscribe to the offer.");
	context.setVariable("httpError", "500");
} else if (faultMsg.toUpperCase().includes("THE PHONE NUMBER IS DUPLICATED")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".106");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "The phone number is duplicated.");
	context.setVariable("httpError", "500");
} else if (faultMsg.toUpperCase().includes("IS NOT ACTIVATED") || faultMsg.toUpperCase().includes("THE ROUTING INFORMATION ABOUT THE SUBSCRIBER") || faultMsg.toUpperCase().includes("THE SUBSCRIBER DOES NOT EXIST") || faultMsg.toUpperCase().includes("CANNOT BE FOUND IN THE SUBSCRIBER") || faultMsg.toUpperCase().includes("EXISTS AND CANNOT BE REGISTERED")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".107");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "The subscriber is not valid.");
	context.setVariable("httpError", "500");
} else if (faultMsg.toUpperCase().includes("IS NOT OF THE SUBSCRIPTION TYPE") || faultMsg.toUpperCase().includes("DOES NOT EXIST") || faultMsg.toUpperCase().includes("INVALID OFFER") || faultMsg.toUpperCase().includes("DOES NOT EXIST") || faultMsg.toUpperCase().includes("THE OFFER INSTANCE") || faultMsg.toUpperCase().includes("INVALID OFFER") || faultMsg.toUpperCase().includes("CANNOT BE SUBSCRIBED TO REPEATEDLY")) {
	context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".108");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage", "The offer is not valid.");
	context.setVariable("httpError", "500");
} else
	if ((faultMsg !== null && faultMsg.includes("109") && proxyPath.includes("campaign"))) // || (faultString!==null && faultString.includes("No Data Found")))
		context.setVariable("Status", "Success");
	else {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("errorCode", "500." + apiNo + ".100");
		context.setVariable("errorDesc", "Internal Server Error");
		if (faultMsg !== null && faultMsg != "null" && faultMsg.length > 0)
			context.setVariable("errorMessage", faultMsg);
		else
			context.setVariable("errorMessage", faultString);
		context.setVariable("httpError", "500");
	}

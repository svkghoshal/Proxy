var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable('request.verb');
var list = context.getVariable('req.list');
var offerType = context.getVariable('req.offerType');
var target;

if(list===null)
    list='';
    
if(reqVerb=='GET' && proxypath.match('/campaign'))
{
    if(list.equals("subscribed"))
    {
        target = '/CampaignHistorySyncPS';
        context.setVariable('targetPath',target);
    }
    else
    {
        //target = '/cxf/proxy/campaign';
        target = '/CampaignAvailableOfferSyncPS';
        context.setVariable('targetPath',target);
    }
}
else if(reqVerb=='POST' && proxypath.match('/campaign/*'))
    {
        target = '/CapaignOptInSyncPS';
        context.setVariable('targetPath',target);
    }
else if(reqVerb=='GET')
        {
            if(offerType=='VAS' && list.equals("subscribed"))
                target = '/cxf/VASSubscriptionDetailsSyncPS';
            else
                target = '/cxf/PrepaidAccountSyncPSMyTelenorAPP';
            context.setVariable('targetPath',target);
        }
else if ((reqVerb=='POST' || reqVerb=='DELETE'))
            {
                target = '/cxf/ManageOfferSyncPS';
                context.setVariable('targetPath',target);
            }
            
            
            print("target:"+target);
            print("server::"+context.getVariable("target.host"));
            print("targeturl::"+context.getVariable("target.url"));
            
            
            print(context.getVariable("loadbalancing.targetserver"))
            print(context.getVariable("target.host"))

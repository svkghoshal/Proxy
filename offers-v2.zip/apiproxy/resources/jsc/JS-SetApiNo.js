var apiNo;
var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);


if(proxypath.match('/campaign') && (reqVerb.equals("GET")))
	context.setVariable("apiNo","006");
else
    if(proxypath.match('/campaign/*') && (reqVerb.equals("POST")))
        context.setVariable("apiNo","007");
    else
	    if((reqVerb.equals("GET")))
			print(context.setVariable("apiNo","003"));
        else
            if(reqVerb.equals("POST"))
                context.setVariable("apiNo","004");
            else
                if(reqVerb.equals("DELETE"))
					context.setVariable("apiNo","005");
http = require('http');
server= http.createServer( function(req, res) 
{
console.log ('user'+req);
var body ="{"+ 
"\"status\": \"success\","+
  "\"data\": {"+
    "\"triggerId\": \"TRIG_123k45lkj25\","+
    "\"requestId\": \"VrCU1xhRV9cRK48bRVMf\""+
  "},"+
  "\"message\": null"+
"};"

 res.writeHead(200, {'Content-Type': 'application/json'});
 res.end(body);
});

port = 3000;

host = '127.0.0.1';

server.listen(port, host);

console.log ('Listening at http://' + host + ':' + port);

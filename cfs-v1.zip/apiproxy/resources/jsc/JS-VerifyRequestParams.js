var brand = context.getVariable("req.brand");
var contact = context.getVariable("req.contact");
var requestId = context.getVariable("req.requestId");

if((isEmpty(brand)) ||  isEmpty(contact) || isEmpty(requestId)){
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400.002.0001");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Missing input parameters");
    throw "serviceException";
}
function isEmpty(input) {
    return (!input || 0 === input.length);
}

 http = require('http');
 var apigee = require('apigee-access');

server= http.createServer( function(req, res) 
{
console.log ('user'+req);
console.log ('Request ::: '+JSON.stringify(req.Body));
var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
console.log('proxypath : '+proxypath);
var list = apigee.getVariable(req,'req.list');
console.log('list : '+list);

var bodySO = "<soapenv:Envelope 	xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"<soap:Header 	xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"</soap:Header>"+
"<soapenv:Body>"+
"<man:ManageOfferResponseMsg 	xmlns:man=\"http://www.telenor.com.mm/ManageOffer\">"+
"<man:ManageOffer_Response>"+
"<com:TransactionReference 	xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\">"+
"<com:IdRef>ID1234</com:IdRef>"+
"</com:TransactionReference>"+
"<man:Status>Success</man:Status>"+
"<com:CustomRef 	xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\">"+
"<com:IDType/>"+
"<com:IDValue/>"+
"</com:CustomRef>"+
"</man:ManageOffer_Response>"+
"</man:ManageOfferResponseMsg>"+
"</soapenv:Body>"+
"</soapenv:Envelope>";

var bodySC = "<soapenv:Envelope 	xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"<soap:Header 	xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"</soap:Header>"+
"<soapenv:Body>"+
"<cam:OptInResponse 	xmlns:cam=\"http://www.telenor.com.mm/CampaignOptIn\">"+
	"<com:TransactionReference 	xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\">"+
	"<com:SourceSystemId>string</com:SourceSystemId>"+
	"<com:IdRef>string</com:IdRef/>"+
	"</com:TransactionReference>"+
	"<cam:Status>Success</cam:Status>"+
	"</cam:OptInResponse>"+
"</soapenv:Body>"+
"</soapenv:Envelope>";

var bodyROA = "<soapenv:Envelope 	xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"<soap:Header 	xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"</soap:Header>"+
"<soapenv:Body>"+
"<ns2:QueryAvailableOffersResponseMsg  xmlns:ns2=\"http://www.telenor.com.mm/QueryAvailableOffers\">"+ 
 "<ns2:OfferAvailable_Response>"+
 "<ns2:AvailableOffer>"+
 "<ns2:OfferType>CBS</ns2:OfferType>"+
 "<ns2:OfferId>B111</ns2:OfferId>"+
 "<ns2:MarketingName>MonthlyVoice</ns2:MarketingName>"+
 "<ns2:CircleId>MM</ns2:CircleId>"+
 "<ns2:OfferProvider>CBS</ns2:OfferProvider>"+
 "<ns2:Price>0</ns2:Price>"+
 "<ns2:Status>Available</ns2:Status>"+
 "</ns2:AvailableOffer>"+
 "<ns2:AvailableOffer>"+
 "<ns2:OfferType>CBS</ns2:OfferType>"+
 "<ns2:OfferId>605</ns2:OfferId>"+
 "<ns2:MarketingName>MonthlyVoice</ns2:MarketingName>"+
 "<ns2:CircleId>MM</ns2:CircleId>"+
 "<ns2:OfferProvider>CBS</ns2:OfferProvider>"+
 "<ns2:Price>30</ns2:Price>"+
 "<ns2:Status>Available</ns2:Status>"+
 "</ns2:AvailableOffer>"+
 "<ns2:AvailableOffer>"+
 "<ns2:OfferType>CBS</ns2:OfferType>"+
 "<ns2:OfferId>MCA</ns2:OfferId>"+
 "<ns2:MarketingName>My Happy Talk Pack</ns2:MarketingName>"+
 "<ns2:CircleId>MM</ns2:CircleId>"+
 "<ns2:OfferProvider>CBS</ns2:OfferProvider>"+
 "<ns2:Price>0</ns2:Price>"+
 "<ns2:Status>Available</ns2:Status>"+
 "</ns2:AvailableOffer>"+
 "<ns2:AvailableOffer>"+
 "<ns2:OfferType>CBS</ns2:OfferType>"+
 "<ns2:OfferId>uni0716</ns2:OfferId>"+
 "<ns2:MarketingName>uni0716</ns2:MarketingName>"+
 "<ns2:CircleId>MM</ns2:CircleId>"+
 "<ns2:OfferProvider>CBS</ns2:OfferProvider>"+
 "<ns2:Price>4999</ns2:Price>"+
 "<ns2:Status>Available</ns2:Status>"+
 "</ns2:AvailableOffer>"+
 "<ns2:AvailableOffer>"+
 "<ns2:OfferType>CBS</ns2:OfferType>"+
 "<ns2:OfferId>myhappy</ns2:OfferId>"+
 "<ns2:MarketingName>My Happy Talk Pack</ns2:MarketingName>"+
 "<ns2:CircleId>MM</ns2:CircleId>"+
 "<ns2:OfferProvider>CBS</ns2:OfferProvider>"+
 "<ns2:Price>150</ns2:Price>"+
 "<ns2:Status>Available</ns2:Status>"+
 "</ns2:AvailableOffer>"+
 "<ns2:AvailableOffer>"+
 "<ns2:OfferType>CBS</ns2:OfferType>"+
 "<ns2:OfferId>15022901</ns2:OfferId>"+
 "<ns2:MarketingName>TnM_Free_Offer</ns2:MarketingName>"+
 "<ns2:CircleId>MM</ns2:CircleId>"+
 "<ns2:OfferProvider>CBS</ns2:OfferProvider>"+
 "<ns2:Price>0</ns2:Price>"+
 "<ns2:Status>Available</ns2:Status>"+
 "</ns2:AvailableOffer>"+
 "</ns2:OfferAvailable_Response>"+
 "</ns2:QueryAvailableOffersResponseMsg>"+
"</soapenv:Body>"+
"</soapenv:Envelope>";

var bodyROS = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"<soap:Header xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"</soap:Header>"+
"<soapenv:Body>"+
"<quer:QueryOffersSubscribedResponseMsg xmlns:quer=\"http://www.telenor.com.mm/QueryOffersSubscribedRequest\">"+
"<quer:OfferSubscribedResponse>"+
"<com:TransactionReference xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\">"+
"<com:IdRef>20160701162351e5c6949b</com:IdRef>"+
"</com:TransactionReference>"+
"<quer:OfferSubscribed>"+
"<quer:OfferType>0</quer:OfferType>"+
"<quer:OfferId>B111</quer:OfferId>"+
"<quer:MarketingName>Btesting</quer:MarketingName>"+
"<quer:CircleId>MM</quer:CircleId>"+
"<quer:EffectiveDate>2016-06-29 14:56:46</quer:EffectiveDate>"+
"<quer:ExpireDate>2037-01-01 00:00:00</quer:ExpireDate>"+
"<quer:OfferProvider>CBS</quer:OfferProvider>"+
"<quer:Price>0</quer:Price>"+
"<quer:Status>Subscribed</quer:Status>"+
"<com:CustomRef xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\">"+
"<com:IDType>OfferCategory</com:IDType>"+
"<com:IDValue>PRIMARY_OFFER</com:IDValue>"+
"</com:CustomRef>"+
"</quer:OfferSubscribed>"+
"</quer:OfferSubscribedResponse>"+
"</quer:QueryOffersSubscribedResponseMsg>"+
"</soapenv:Body>"+
"</soapenv:Envelope>";

var bodyRCA = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
"<soap:Header xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
"</soap:Header>" +
"<soapenv:Body>" +
"<quer:CampaignAvailableResponseMsg xmlns:quer=\"http://www.telenor.com.mm/CampaignAvailableRequest\">" +
"<quer:CampaignAvailableResponse>" +
"<com:TransactionReference xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\">" +
"<com:IdRef>20160701162351e5c6949b</com:IdRef>" +
"</com:TransactionReference>" +
"<quer:Status>Success</quer:Status>" +
"<quer:RecommendationsOffer>" +
"<quer:ProductOfferingID>5678</quer:ProductOfferingID>" +
"<quer:ProductOfferingName>Test PO1</quer:ProductOfferingName>" +
"<quer:ShortOfferDescription>TestPO1 for API checking</quer:ShortOfferDescription>" +
"<quer:OfferPrice>100</quer:OfferPrice>" +
"<quer:CorrelationId>abcd1234</quer:CorrelationId>" +
"<quer:ProductOfferingType>NA</quer:ProductOfferingType>" +
"<quer:Keyword>1</quer:Keyword>" +
"</quer:RecommendationsOffer>" +
"<quer:RecommendationsOffer>" +
"<quer:ProductOfferingID>9012</quer:ProductOfferingID>" +
"<quer:ProductOfferingName>Test PO1</quer:ProductOfferingName>" +
"<quer:ShortOfferDescription>TestPO1 for API checking</quer:ShortOfferDescription>" +
"<quer:OfferPrice>100</quer:OfferPrice>" +
"<quer:CorrelationId>abcd1234</quer:CorrelationId>" +
"<quer:ProductOfferingType>NA</quer:ProductOfferingType>" +
"<quer:Keyword>1</quer:Keyword>" +
"</quer:RecommendationsOffer>" +
"<quer:RecommendationsOffer>" +
"<quer:ProductOfferingID>3456</quer:ProductOfferingID>" +
"<quer:ProductOfferingName>Test PO1</quer:ProductOfferingName>" +
"<quer:ShortOfferDescription>TestPO1 for API checking</quer:ShortOfferDescription>" +
"<quer:OfferPrice>100</quer:OfferPrice>" +
"<quer:CorrelationId>abcd1234</quer:CorrelationId>" +
"<quer:ProductOfferingType>NA</quer:ProductOfferingType>" +
"<quer:Keyword>1</quer:Keyword>" +
"</quer:RecommendationsOffer>" +
"</quer:CampaignAvailableResponse>" +
"</quer:CampaignAvailableResponseMsg>" +
"</soapenv:Body>" +
"</soapenv:Envelope>";
			
var bodyRCS = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
"<soap:Header xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
"</soap:Header>" +
"<soapenv:Body>" +
"<quer:CampaignSubscribedResposeMsg xmlns:quer=\"http://www.telenor.com.mm/CampaignAvailableRequest\">" +
"<quer:CampaignSubscribedResponse>" +
"<com:TransactionReference xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\">" +
"<com:IdRef>20160701162351e5c6949b</com:IdRef>" +
"</com:TransactionReference>" +
"<quer:Status>Success</quer:Status>" +
"<quer:RecommendationsOffer>" +
"<quer:ProductOfferingID>5678</quer:ProductOfferingID>" +
"<quer:ProductOfferingName>Test PO1</quer:ProductOfferingName>" +
"<quer:ActivationDate>2016-06-29 14:56:46</quer:ActivationDate>" +
"<quer:ExpiryDate>2037-01-01 00:00:00</quer:ExpiryDate>" +
"<quer:ShortOfferDescription>TestPO1 for API checking</quer:ShortOfferDescription>" +
"<quer:OfferPrice>100</quer:OfferPrice>" +
"<quer:CorrelationId>abcd1234</quer:CorrelationId>" +
"<quer:ProductOfferingType>NA</quer:ProductOfferingType>" +
"<quer:Keyword>1</quer:Keyword>" +
"</quer:RecommendationsOffer>" +
"<quer:RecommendationsOffer>" +
"<quer:ProductOfferingID>7890</quer:ProductOfferingID>" +
"<quer:ProductOfferingName>Test PO1</quer:ProductOfferingName>" +
"<quer:ActivationDate>2016-06-29 14:56:46</quer:ActivationDate>" +
"<quer:ExpiryDate>2037-01-01 00:00:00</quer:ExpiryDate>" +
"<quer:ShortOfferDescription>TestPO1 for API checking</quer:ShortOfferDescription>" +
"<quer:OfferPrice>100</quer:OfferPrice>" +
"<quer:CorrelationId>abcd1234</quer:CorrelationId>" +
"<quer:ProductOfferingType>NA</quer:ProductOfferingType>" +
"<quer:Keyword>1</quer:Keyword>" +
"</quer:RecommendationsOffer>" +
"<quer:RecommendationsOffer>" +
"<quer:ProductOfferingID>1234</quer:ProductOfferingID>" +
"<quer:ProductOfferingName>Test PO1</quer:ProductOfferingName>" +
"<quer:ActivationDate>2016-06-29 14:56:46</quer:ActivationDate>" +
"<quer:ExpiryDate>2037-01-01 00:00:00</quer:ExpiryDate>" +
"<quer:ShortOfferDescription>TestPO1 for API checking</quer:ShortOfferDescription>" +
"<quer:OfferPrice>100</quer:OfferPrice>" +
"<quer:CorrelationId>abcd1234</quer:CorrelationId>" +
"<quer:ProductOfferingType>NA</quer:ProductOfferingType>" +
"<quer:Keyword>1</quer:Keyword>" +
"</quer:RecommendationsOffer>" +
"</quer:CampaignSubscribedResponse>" +
"</quer:CampaignSubscribedResposeMsg>" +
"</soapenv:Body>" +
"</soapenv:Envelope>";

var bodyCBP = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"+ 
 "<soap:Header xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
 "</soap:Header>"+
 "<soapenv:Body>"+
 "<chan:ChangePrimaryPlanRes xmlns:chan=\"http://www.telenor.com.mm/ChangePrimaryPlan\">"+
 "<chan:Status>Success</chan:Status>"+
 "</chan:ChangePrimaryPlanRes>"+
 "</soapenv:Body>"+
 "</soapenv:Envelope>";
 
 var bodySIM = "<soapenv:Envelope 	xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
	"<soap:Header 	xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
	"</soap:Header>" +
	"<soapenv:Body>" +
		"<sub:SubscriberECAFInfoResponseMsg 	xmlns:sub=\"http://www.telenor.com.mm/SubscriberECAFDetails\">" +
			"<com:TransactionReference 	xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\">" +
				"<com:SourceSystemId>MOBIAPP</com:SourceSystemId>" +
				"<com:IdRef>ID1234</com:IdRef>" +
			"</com:TransactionReference>" +
			"<sub:Status>SUCCESS</sub:Status>" +
			"<sub:SubscriberECAFInfoRes>" +
				"<sub:CustomerName>Vaibhav</sub:CustomerName>" +
				"<sub:CustomerID>XXb354</sub:CustomerID>" +
				"<sub:CustomerDOB>1988-10-22T00:00:00.000+05:30</sub:CustomerDOB>" +
				"<sub:CutsomerAddress/>" +
				"<sub:CAFStatus>Approved</sub:CAFStatus>" +
			"</sub:SubscriberECAFInfoRes>" +
		"</sub:SubscriberECAFInfoResponseMsg>" +
	"</soapenv:Body>" +
"</soapenv:Envelope> " ;

var bodyEcaf= "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"<soap:Header xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"</soap:Header>"+
"<soapenv:Body>"+
"<cam:OptInResponse xmlns:cam=\"http://www.telenor.com.mm/CampaignOptIn\">"+
	"<com:TransactionReference 	xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\">"+
	"<com:SourceSystemId>string</com:SourceSystemId>"+
	"<com:IdRef>string</com:IdRef>"+
	"</com:TransactionReference>"+
	"<cam:Status>SUCCESS</cam:Status>"+
	"</cam:OptInResponse>"+
"</soapenv:Body>"+
"</soapenv:Envelope>";

 
var bodyEcafUpload= "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"<soap:Header xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
"</soap:Header>"+
"<soapenv:Body>"+
"<cam:OptInResponse xmlns:cam=\"http://www.telenor.com.mm/CampaignOptIn\">"+
	"<com:TransactionReference 	xmlns:com=\"http://xmlns.telenor.com.mm/Schema/Common/1.0/Common.xsd\">"+
	"<com:SourceSystemId>string</com:SourceSystemId>"+
	"<com:IdRef>string</com:IdRef>"+
	"</com:TransactionReference>"+
	"<cam:Status>SUCCESS</cam:Status>"+
	"</cam:OptInResponse>"+
"</soapenv:Body>"+
"</soapenv:Envelope>";

 res.writeHead(200, {'Content-Type': 'application/xop+xml'});
 
 var body = "";

if(proxypath.match('/*/offers/campaign'))
{
    if(list=='subscribed')
        body = bodyRCS;
    else
        body = bodyRCA;
}
else
    if(proxypath.match('/*/offers/campaign/*'))
        body = bodySC;
    else
        if(proxypath.match('/*/offers'))
        {
            if(list=='subscribed')
                body = bodyROS;
            else
                body = bodyROA;
        }
        else
            if(proxypath.match('/*/offers/*'))
                body = bodySO;
            else
                if(proxypath.match('/*/baseplan'))
                    body = bodyCBP;
                else 
                    if(proxypath.match('/*/registration') && (verb.equals("GET")))
                        body = bodySIM;
                    else 
                        if(proxypath.match('/*/registration') && (verb.equals("POST")))
                            body = bodyEcaf;
                        else 
                            if(proxypath.match('/*/registration') && (verb.equals("PUT")))
                                body = bodyEcafUpload;  
                                
res.end(body);

});


port = 3000;

host = '127.0.0.1';

server.listen(port, host);

console.log ('Listening at http://' + host + ':' + port);
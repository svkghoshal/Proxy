/*var payType = context.getVariable("req.payType");*/
var subscriptionType = context.getVariable("req.subscriptionType");
var apiNo = context.getVariable('apiNo');
var searchUserResp = context.getVariable("searchUserResp.content");
print("searchUserResp" +searchUserResp);
/*print("payType" +payType);*/
print("subscriptionType" +subscriptionType);


var payTypeLatest = context.getVariable("pay");
print("payTypeLatest::" +payTypeLatest);


if(payTypeLatest=="VANITY")
{
    context.setVariable("payTypeLatest", subscriptionType);
    context.setVariable("req.subscriptionType", "");
}



if(payTypeLatest === null)
{
    context.setVariable("exceptionName", "exceptionName");
    context.setVariable("httpError", "400");
    context.setVariable("errorCode", "400."+apiNo+".101");
    context.setVariable("errorDesc", "Bad Request");
    context.setVariable("errorMessage", "Invalid Input");
    throw "serviceException";
}

context.setVariable("payTypeoutput", payTypeLatest);
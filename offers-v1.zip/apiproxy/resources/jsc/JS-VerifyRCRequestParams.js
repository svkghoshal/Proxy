 var sourceId = context.getVariable('req.sourceId');
 var list = context.getVariable('req.list');
 var idValue = context.getVariable('req.idValue');
 var kvmUserIdentityType = context.getVariable('kvm.userIdentityType') 
 var recommendLimit = context.getVariable('req.recommendLimit');
 var campaignLimit = context.getVariable('req.campaignLimit');
 var minPrice = context.getVariable('req.minPrice');
 var maxPrice = context.getVariable('req.maxPrice');
 var transactionIdseq = (context.getVariable("req.transactionIdseq")).toString();
 var apiNo = context.getVariable('apiNo');
 
 context.setVariable("isoTimestamp", ISODateString());
 context.setVariable("old6mTimeStamp",Old6MDateString());
 context.setVariable("transactionDateTime",transactionDateTime());
 context.setVariable("transactionId", apiNo + transactionDateTime() + padLeadingZeros(transactionIdseq));
 
 if (isEmpty(idValue) || isEmpty(sourceId) || isEmpty(list))
 {
            context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".101");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid Input");
	        throw "serviceException";
 }
 LetterNumber(sourceId);
function LetterNumber(inputtext) {
var LetterExpression = /^[0-9A-Za-z]+$/;
if (LetterExpression.test(inputtext))
{
	context.setVariable("sourceId",inputtext);
}
else{
    context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".101");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid Input");
	        throw "serviceException";

}
}
 
  	
 var msisdnLength = idValue.length;
//var revisedMsisdn = "";
if((idValue.startsWith("976") && ((msisdnLength == 10)))||((idValue.startsWith("977") && ((msisdnLength == 10))))||((idValue.startsWith("978") && ((msisdnLength == 10))))||((idValue.startsWith("979") && ((msisdnLength == 10)))) || (idValue.startsWith("95") && ((msisdnLength == 12)))||(idValue.startsWith("959") && ((msisdnLength == 12)))){
    //revisedMsisdn = idValue.substring(1);
    context.setVariable("idValue", idValue);
   // context.setVariable("revisedMsisdn", revisedMsisdn);
}
else {
    
    context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".101");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid Input");
	        throw "serviceException";
}
//var idValue = "req.idValue";
phonenumber(idValue);
function phonenumber(input){
var numericExpression = /^[0-9]+$/;
if(numericExpression.test(input))
{
    context.setVariable("idValue", input);
}
else{
    context.setVariable("exceptionName", "exceptionName");
	        context.setVariable("httpError", "400");
	        context.setVariable("errorCode", "400."+apiNo+".101");
	        context.setVariable("errorDesc", "Bad Request");
	        context.setVariable("errorMessage", "Invalid Input");
	        throw "serviceException";

}
} 
 

function isEmpty(input) {
    return (!input || 0 === input.length);
}

function transactionDateTime() {
    var now = new Date(),
                pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
         + pad(now.getMonth()+1)
         + pad(now.getDate())
         + pad(now.getHours())
         + pad(now.getMinutes()) 
         + pad(now.getSeconds());
}

function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}

function Old6MDateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    now.setMonth(now.getMonth() - 6);
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds());
}

function padLeadingZeros(input) {
    var step;
    var output=input;
    for(step=input.length; step<6; step++)
        output="0"+output;
    return output;
}
var ErrorCode = context.getVariable("req.ErrorCode");
print("ErrorCode::" +ErrorCode);
var payTypeOrginal = context.getVariable("req.payType");
var payTypeSet;
    
if(ErrorCode == "UWL_BIZERR-APP004") 
    {
        payTypeSet = 'PREPAID';
        context.setVariable('payTypeNew',payTypeSet);
    }
else if(ErrorCode===null)
    {
        context.setVariable('payTypeNew',payTypeOrginal);
    }
var pay = context.getVariable("payTypeNew");
print("pay:"+pay);
context.setVariable('pay',pay);  
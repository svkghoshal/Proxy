var pathValue = context.getVariable('message.path');
if (pathValue.equals('*/campaign/*'))
{
	context.setVariable("message.path","/v1/*/*/users/{idValue}/offers/campaign/{offerId}");
}
else{
    context.setVariable("message.path","/v1/*/*/users/{idValue}/offers");
	       

}
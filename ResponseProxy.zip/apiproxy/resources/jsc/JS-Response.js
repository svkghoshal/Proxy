var hey1 = JSON.parse(context.getVariable("calloutResponsePost.content"));
var hey2 = JSON.parse(context.getVariable("calloutResponseUser.content"));
var respjson = [];


for(i = 0; i<hey1.length; i++){
    
    var post = hey1[i].id;
    
    for(j = 0; j<hey2.length; j++)
    {
        var  User = hey2[j].id;
        
        if (post == User)
        {
         var obj = {};
         obj.id = hey1[i].id ? hey1[i].id : "";
         obj.title = hey1[i].title ? hey1[i].title : "";
         obj.body = hey1[i].body ? hey1[i].body : "";
         obj.name = hey2[j].name ? hey2[j].name : "";
         obj.email = hey2[j].email ? hey2[j].email : "";
         obj.company = hey2[j].company ? hey2[j].company : "";
         obj.lat =  hey2[j].address.geo.lat ? hey2[j].address.geo.lat : "";
         respjson.push(obj);
         break;
        }
        
    }
    
    
}

//print(JSON.stringify(respjson));
context.setVariable("response.content",JSON.stringify(respjson));
context.setVariable("Content-Type","application/json"); 
//print("JSONString"+JSON.stringify(hey1[0].id));

